#!/bin/bash

# turn on bash's job control
set -m

## mission-control
cd /workspace/mission-control
# install packages
yarn install
# run migration and generate schema
yarn prisma migrate dev --schema "../db/schema.prisma"

## interstellar
cd /workspace/interstellar
# install packages
pip install -r requirements.txt
# generate prisma schema
python3 -m prisma generate --schema="../db/schema.prisma" --generator "clientPy"
