"""
DATABASE MIGRATIONS

This launcher migrates our databases automatically based on the schema.
"""

import json
import os
import boto3

def _get_aws_secret(secret_name: str):
    region_name = os.environ.get("AWS_REGION")
    client = boto3.client(
        "secretsmanager",
        region_name=region_name,
    )

    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except Exception as e:
        raise e

    secret = get_secret_value_response["SecretString"]
    return secret

def set_database_url_env():
    # Check if DATABASE_URL is in environment variables
    db_url = os.environ.get("DATABASE_URL")
    if not db_url:
        # Check if DATABASE_URL is in cloud secrets
        print("DATABASE_URL not found in environment variables, checking in secrets")
        cloud_secret = os.environ.get("CLOUD_SECRET")
        if not cloud_secret:
            raise Exception("CLOUD_SECRET not found in environment variables")
        
        db_url = None
        try:
            secret_str = _get_aws_secret(cloud_secret)
            secret_json = json.loads(secret_str)
            db_url = secret_json.get("DATABASE_URL")
        except Exception as e:
            print(f"Error fetching secret: {e}")
        
    if not db_url:
        # Check if DATABASE_URL is in secrets
        db_url = _get_aws_secret("DATABASE_URL")

    if not db_url:
        raise Exception("DATABASE_URL not found in environment variables or secrets")

    os.environ["DATABASE_URL"] = db_url


set_database_url_env()
# Break out to shell and run migrations
os.system(f"python3 -m prisma migrate deploy")
