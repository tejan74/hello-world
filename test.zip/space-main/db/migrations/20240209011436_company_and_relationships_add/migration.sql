-- CreateTable
CREATE TABLE "Company" (
    "uuid" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "domain" TEXT NOT NULL,
    "logo" TEXT,
    "email" TEXT,
    "phone" TEXT,
    "unverifiedAddressFromApollo" JSONB,
    "alternateDomains" TEXT[],
    "alternateNames" TEXT[],
    "description" TEXT,
    "headcount" INTEGER,
    "revenue" DOUBLE PRECISION,
    "foundedYear" INTEGER,
    "industry" TEXT[],
    "naicsCode" TEXT,
    "sicCodes" TEXT[],
    "linkedin" TEXT,
    "facebook" TEXT,
    "twitter" TEXT,
    "totalFunding" DOUBLE PRECISION,
    "latestFundingDate" TIMESTAMP(3),
    "latestFundingAmount" DOUBLE PRECISION,
    "latestFundingRound" TEXT,
    "stockPublic" BOOLEAN NOT NULL DEFAULT false,
    "stockSymbol" TEXT,
    "stockExchange" TEXT,
    "officePolicy" TEXT,
    "officePolicyConfidence" INTEGER,
    "officePolicyDescription" TEXT,
    "officePolicySource" TEXT,
    "technologies" TEXT[],
    "marketingKeywords" TEXT[],
    "seoDescription" TEXT,
    "locationCoverage" TEXT,
    "tags" TEXT[],
    "flags" TEXT[],
    "status" TEXT,
    "internalNotes" TEXT[],
    "sources" JSONB NOT NULL DEFAULT '{}',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT NOT NULL,
    "version" TEXT NOT NULL,
    "apolloId" TEXT,
    "dunsNumber" TEXT,

    CONSTRAINT "Company_pkey" PRIMARY KEY ("uuid")
);

-- CreateTable
CREATE TABLE "CompanyRelationship" (
    "relationType" TEXT NOT NULL,
    "sourceCompanyUuid" TEXT NOT NULL,
    "destinationCompanyUuid" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT NOT NULL,
    "version" TEXT NOT NULL,

    CONSTRAINT "CompanyRelationship_pkey" PRIMARY KEY ("sourceCompanyUuid","destinationCompanyUuid")
);

-- CreateIndex
CREATE UNIQUE INDEX "Company_domain_key" ON "Company"("domain");

-- CreateIndex
CREATE INDEX "CompanyRelationship_sourceCompanyUuid_idx" ON "CompanyRelationship"("sourceCompanyUuid");

-- CreateIndex
CREATE INDEX "CompanyRelationship_destinationCompanyUuid_idx" ON "CompanyRelationship"("destinationCompanyUuid");

-- AddForeignKey
ALTER TABLE "CompanyRelationship" ADD CONSTRAINT "CompanyRelationship_sourceCompanyUuid_fkey" FOREIGN KEY ("sourceCompanyUuid") REFERENCES "Company"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CompanyRelationship" ADD CONSTRAINT "CompanyRelationship_destinationCompanyUuid_fkey" FOREIGN KEY ("destinationCompanyUuid") REFERENCES "Company"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;
