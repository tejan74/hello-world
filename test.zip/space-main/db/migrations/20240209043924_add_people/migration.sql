-- CreateTable
CREATE TABLE "Person" (
    "uuid" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "firstName" TEXT,
    "lastName" TEXT,
    "jobTitle" TEXT,
    "description" TEXT,
    "linkedin" TEXT,
    "score" TEXT,
    "phoneNumber" TEXT,
    "email" TEXT,
    "otherPhoneNumbers" JSONB NOT NULL DEFAULT '{}',
    "otherEmails" JSONB NOT NULL DEFAULT '{}',
    "tags" TEXT[],
    "flags" TEXT[],
    "status" TEXT NOT NULL,
    "internalNotes" TEXT,
    "sources" JSONB NOT NULL DEFAULT '{}',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT NOT NULL,
    "version" TEXT NOT NULL,
    "companyUuid" TEXT,

    CONSTRAINT "Person_pkey" PRIMARY KEY ("uuid")
);

-- CreateIndex
CREATE UNIQUE INDEX "Person_linkedin_key" ON "Person"("linkedin");

-- AddForeignKey
ALTER TABLE "Person" ADD CONSTRAINT "Person_companyUuid_fkey" FOREIGN KEY ("companyUuid") REFERENCES "Company"("uuid") ON DELETE SET NULL ON UPDATE CASCADE;
