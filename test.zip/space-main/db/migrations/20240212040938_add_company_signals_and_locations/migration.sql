-- CreateTable
CREATE TABLE "CompanySignal" (
    "uuid" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "data" JSONB NOT NULL DEFAULT '{}',
    "dataJsonGeneration" TEXT NOT NULL,
    "source" TEXT NOT NULL,
    "score" TEXT,
    "description" TEXT,
    "confidence" INTEGER,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT NOT NULL,
    "companyUuid" TEXT NOT NULL,

    CONSTRAINT "CompanySignal_pkey" PRIMARY KEY ("uuid")
);

-- CreateTable
CREATE TABLE "CompanyLocation" (
    "uuid" TEXT NOT NULL,
    "type" TEXT,
    "street" TEXT,
    "city" TEXT,
    "state" TEXT,
    "country" TEXT NOT NULL,
    "postalCode" TEXT,
    "countryCode" TEXT NOT NULL,
    "region" TEXT NOT NULL,
    "latitude" DOUBLE PRECISION,
    "longitude" DOUBLE PRECISION,
    "rawAddress" TEXT NOT NULL,
    "headcount" INTEGER,
    "isHQ" BOOLEAN NOT NULL DEFAULT false,
    "openJobs" INTEGER,
    "internalNotes" TEXT,
    "sources" JSONB NOT NULL DEFAULT '{}',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT NOT NULL,
    "companyUuid" TEXT NOT NULL,

    CONSTRAINT "CompanyLocation_pkey" PRIMARY KEY ("uuid")
);

-- CreateTable
CREATE TABLE "_CompanyLocationToPerson" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "CompanySignal_companyUuid_key" ON "CompanySignal"("companyUuid");

-- CreateIndex
CREATE UNIQUE INDEX "CompanySignal_companyUuid_type_key" ON "CompanySignal"("companyUuid", "type");

-- CreateIndex
CREATE UNIQUE INDEX "CompanyLocation_companyUuid_street_city_state_country_posta_key" ON "CompanyLocation"("companyUuid", "street", "city", "state", "country", "postalCode", "countryCode", "region");

-- CreateIndex
CREATE UNIQUE INDEX "CompanyLocation_companyUuid_latitude_longitude_key" ON "CompanyLocation"("companyUuid", "latitude", "longitude");

-- CreateIndex
CREATE UNIQUE INDEX "CompanyLocation_companyUuid_rawAddress_key" ON "CompanyLocation"("companyUuid", "rawAddress");

-- CreateIndex
CREATE UNIQUE INDEX "_CompanyLocationToPerson_AB_unique" ON "_CompanyLocationToPerson"("A", "B");

-- CreateIndex
CREATE INDEX "_CompanyLocationToPerson_B_index" ON "_CompanyLocationToPerson"("B");

-- AddForeignKey
ALTER TABLE "CompanySignal" ADD CONSTRAINT "CompanySignal_companyUuid_fkey" FOREIGN KEY ("companyUuid") REFERENCES "Company"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CompanyLocation" ADD CONSTRAINT "CompanyLocation_companyUuid_fkey" FOREIGN KEY ("companyUuid") REFERENCES "Company"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_CompanyLocationToPerson" ADD CONSTRAINT "_CompanyLocationToPerson_A_fkey" FOREIGN KEY ("A") REFERENCES "CompanyLocation"("uuid") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_CompanyLocationToPerson" ADD CONSTRAINT "_CompanyLocationToPerson_B_fkey" FOREIGN KEY ("B") REFERENCES "Person"("uuid") ON DELETE CASCADE ON UPDATE CASCADE;
