-- AlterTable
ALTER TABLE "Company" ADD COLUMN     "glassdoorId" TEXT[];

-- CreateTable
CREATE TABLE "EDS_GlassdoorCompany" (
    "id" TEXT NOT NULL,
    "sourceId" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "website" TEXT NOT NULL,
    "industry" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "mission" TEXT NOT NULL,
    "location" TEXT NOT NULL,
    "image" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "founded" INTEGER NOT NULL,
    "employeeCount" TEXT NOT NULL,
    "contactInfo" JSONB NOT NULL,
    "revenue" TEXT NOT NULL,
    "jobCount" INTEGER NOT NULL,
    "salaryCount" INTEGER NOT NULL,
    "benefitCount" INTEGER NOT NULL,
    "reviewCount" INTEGER NOT NULL,
    "interviewCount" INTEGER NOT NULL,
    "ceo" TEXT NOT NULL,
    "ceoApprovalCount" INTEGER NOT NULL,
    "rating" JSONB NOT NULL,
    "meta" JSONB NOT NULL
);

-- CreateTable
CREATE TABLE "EDS_GlassdoorReview" (
    "id" TEXT NOT NULL,
    "companyId" TEXT NOT NULL,
    "sourceId" TEXT NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "isCurrent" BOOLEAN NOT NULL,
    "isDeleted" BOOLEAN NOT NULL,
    "authorTitle" TEXT NOT NULL,
    "authorLocation" TEXT NOT NULL,
    "authorEmploymentLength" TEXT NOT NULL,
    "authorStatus" TEXT NOT NULL,
    "language" TEXT NOT NULL,
    "pros" TEXT NOT NULL,
    "cons" TEXT NOT NULL,
    "summary" TEXT NOT NULL,
    "recomended" JSONB NOT NULL,
    "starRating" JSONB NOT NULL,
    "meta" JSONB NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "EDS_GlassdoorCompany_id_key" ON "EDS_GlassdoorCompany"("id");

-- CreateIndex
CREATE UNIQUE INDEX "EDS_GlassdoorReview_id_key" ON "EDS_GlassdoorReview"("id");

-- AddForeignKey
ALTER TABLE "EDS_GlassdoorReview" ADD CONSTRAINT "EDS_GlassdoorReview_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "EDS_GlassdoorCompany"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
