-- CreateIndex
CREATE INDEX "EDS_GlassdoorCompany_website_idx" ON "EDS_GlassdoorCompany"("website");
