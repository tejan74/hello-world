-- CreateExtension
CREATE EXTENSION IF NOT EXISTS postgis;

-- CreateTable
CREATE TABLE "GEO_StateCode" (
    "state" VARCHAR NOT NULL,
    "stateCode" VARCHAR NOT NULL,
    "countryCode" VARCHAR NOT NULL,
    CONSTRAINT "country_code_state_code_key" PRIMARY KEY ("countryCode","stateCode")
);

-- CreateTable
CREATE TABLE "GEO_ZipCode" (
    "zip" VARCHAR NOT NULL,
    "city" VARCHAR NOT NULL,
    "county" VARCHAR NOT NULL,
    "state" VARCHAR NOT NULL,
    "stateId" VARCHAR NOT NULL,
    "country" VARCHAR NOT NULL,
    "countryCode" VARCHAR NOT NULL,
    "geo" geography(Point, 4326) NOT NULL,
    CONSTRAINT "zip_code_zip_region_code_key" PRIMARY KEY ("zip", "countryCode")
);

ALTER TABLE "GEO_ZipCode" ADD COLUMN "lat" numeric
    GENERATED ALWAYS AS (st_y("geo"::geometry)) STORED;

ALTER TABLE "GEO_ZipCode" ADD COLUMN "lng" numeric
    GENERATED ALWAYS AS (st_x("geo"::geometry)) STORED;
