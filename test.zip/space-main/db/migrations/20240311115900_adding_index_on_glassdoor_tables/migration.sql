/*
  Warnings:

  - A unique constraint covering the columns `[sourceId]` on the table `EDS_GlassdoorCompany` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[sourceId]` on the table `EDS_GlassdoorReview` will be added. If there are existing duplicate values, this will fail.

*/
-- DropForeignKey
ALTER TABLE "EDS_GlassdoorReview" DROP CONSTRAINT "EDS_GlassdoorReview_companyId_fkey";

-- CreateTable
CREATE TABLE "Tenant" (
    "uuid" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "domain" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "alias" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Tenant_pkey" PRIMARY KEY ("uuid")
);

-- CreateTable
CREATE TABLE "TenantIntegration" (
    "uuid" TEXT NOT NULL,
    "integration" TEXT NOT NULL,
    "authType" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "data" JSONB NOT NULL,
    "config" JSONB NOT NULL,
    "tenantUuid" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "TenantIntegration_pkey" PRIMARY KEY ("uuid")
);

-- CreateTable
CREATE TABLE "Cache" (
    "type" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "data" JSONB NOT NULL,
    "ttl" INTEGER NOT NULL DEFAULT 86400,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Cache_pkey" PRIMARY KEY ("type","key")
);

-- CreateIndex
CREATE UNIQUE INDEX "Tenant_domain_key" ON "Tenant"("domain");

-- CreateIndex
CREATE UNIQUE INDEX "Tenant_alias_key" ON "Tenant"("alias");

-- CreateIndex
CREATE UNIQUE INDEX "EDS_GlassdoorCompany_sourceId_key" ON "EDS_GlassdoorCompany"("sourceId");

-- CreateIndex
CREATE UNIQUE INDEX "EDS_GlassdoorReview_sourceId_key" ON "EDS_GlassdoorReview"("sourceId");

-- CreateIndex
CREATE INDEX "EDS_GlassdoorReview_companyId_idx" ON "EDS_GlassdoorReview"("companyId");

-- AddForeignKey
ALTER TABLE "EDS_GlassdoorReview" ADD CONSTRAINT "EDS_GlassdoorReview_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "EDS_GlassdoorCompany"("sourceId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TenantIntegration" ADD CONSTRAINT "TenantIntegration_tenantUuid_fkey" FOREIGN KEY ("tenantUuid") REFERENCES "Tenant"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;
