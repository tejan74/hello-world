-- DropIndex
DROP INDEX "EDS_GlassdoorReview_companyId_idx";

-- DropIndex
DROP INDEX "EDS_GlassdoorReview_sourceId_key";

-- CreateIndex
CREATE INDEX "EDS_GlassdoorReview_companyId_sourceId_idx" ON "EDS_GlassdoorReview"("companyId", "sourceId");
