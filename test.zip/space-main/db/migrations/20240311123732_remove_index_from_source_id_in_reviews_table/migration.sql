-- DropIndex
DROP INDEX "EDS_GlassdoorReview_companyId_sourceId_idx";

-- CreateIndex
CREATE INDEX "EDS_GlassdoorReview_companyId_idx" ON "EDS_GlassdoorReview"("companyId");
