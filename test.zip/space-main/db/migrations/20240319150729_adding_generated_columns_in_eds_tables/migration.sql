-- AlterTable
ALTER TABLE
    "EDS_GlassdoorCompany"
ADD
    COLUMN "domain" TEXT GENERATED ALWAYS AS (
        "substring"(
            website :: text,
            '(?:.*://)?(?:www\.)?([^/?]*)' :: text
        )
    ) STORED;

-- AlterTable
ALTER TABLE
    "EDS_GlassdoorReview"
ADD
    COLUMN "ts_cons" tsvector GENERATED ALWAYS AS (
        to_tsvector('english' :: regconfig, cons :: text)
    ) STORED,
ADD
    COLUMN "ts_pros" tsvector GENERATED ALWAYS AS (
        to_tsvector('english' :: regconfig, pros :: text)
    ) STORED;
