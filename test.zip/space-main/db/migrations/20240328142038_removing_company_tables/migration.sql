/*
  Warnings:

  - You are about to drop the `Company` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `CompanyLocation` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `CompanyRelationship` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `CompanySignal` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `Person` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `_CompanyLocationToPerson` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "CompanyLocation" DROP CONSTRAINT "CompanyLocation_companyUuid_fkey";

-- DropForeignKey
ALTER TABLE "CompanyRelationship" DROP CONSTRAINT "CompanyRelationship_destinationCompanyUuid_fkey";

-- DropForeignKey
ALTER TABLE "CompanyRelationship" DROP CONSTRAINT "CompanyRelationship_sourceCompanyUuid_fkey";

-- DropForeignKey
ALTER TABLE "CompanySignal" DROP CONSTRAINT "CompanySignal_companyUuid_fkey";

-- DropForeignKey
ALTER TABLE "Person" DROP CONSTRAINT "Person_companyUuid_fkey";

-- DropForeignKey
ALTER TABLE "_CompanyLocationToPerson" DROP CONSTRAINT "_CompanyLocationToPerson_A_fkey";

-- DropForeignKey
ALTER TABLE "_CompanyLocationToPerson" DROP CONSTRAINT "_CompanyLocationToPerson_B_fkey";

-- DropTable
DROP TABLE "Company";

-- DropTable
DROP TABLE "CompanyLocation";

-- DropTable
DROP TABLE "CompanyRelationship";

-- DropTable
DROP TABLE "CompanySignal";

-- DropTable
DROP TABLE "Person";

-- DropTable
DROP TABLE "_CompanyLocationToPerson";
