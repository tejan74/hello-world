-- AlterTable
ALTER TABLE "Tenant" ADD COLUMN     "credits" INTEGER,
ADD COLUMN     "subscription" TEXT;
