-- CreateEnum
CREATE TYPE "UI_ColumnType" AS ENUM ('TEXT', 'NUMBER', 'BOOL', 'DATE', 'DYNAMIC', 'DERIVED');

-- CreateTable
CREATE TABLE "UI_Table" (
    "uuid" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "icon" TEXT,
    "locked" BOOLEAN NOT NULL DEFAULT false,
    "lastColumnUpdatedAt" TIMESTAMP(3),
    "lastDataUpdatedAt" TIMESTAMP(3),
    "tenantUuid" TEXT NOT NULL,
    "deletedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "columnOrder" TEXT[] DEFAULT ARRAY[]::TEXT[],

    CONSTRAINT "UI_Table_pkey" PRIMARY KEY ("uuid")
);

-- CreateTable
CREATE TABLE "UI_Column" (
    "uuid" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "internalId" TEXT NOT NULL,
    "description" TEXT,
    "type" "UI_ColumnType" NOT NULL,
    "icon" TEXT,
    "dependencies" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "tableUuid" TEXT NOT NULL,
    "deletedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "UI_Column_pkey" PRIMARY KEY ("uuid")
);

-- CreateTable
CREATE TABLE "UI_DynamicColumnConfig" (
    "preCheckFormula" TEXT,
    "inputConfig" JSONB NOT NULL DEFAULT '{}',
    "outputPath" TEXT NOT NULL,
    "columnUuid" TEXT NOT NULL,
    "actionUuid" TEXT NOT NULL
);

-- CreateTable
CREATE TABLE "UI_Row" (
    "uuid" TEXT NOT NULL,
    "tableUuid" TEXT NOT NULL,
    "deletedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "UI_Row_pkey" PRIMARY KEY ("uuid")
);

-- CreateTable
CREATE TABLE "UI_StaticData" (
    "rowUuid" TEXT NOT NULL,
    "columnUuid" TEXT NOT NULL,
    "data" TEXT NOT NULL,

    CONSTRAINT "UI_StaticData_pkey" PRIMARY KEY ("rowUuid","columnUuid")
);

-- CreateTable
CREATE TABLE "UI_Action" (
    "uuid" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "icon" TEXT NOT NULL,
    "invocationDetails" JSONB NOT NULL DEFAULT '{}',
    "inputSchema" JSONB NOT NULL DEFAULT '{}',
    "outputSchema" JSONB NOT NULL DEFAULT '{}',
    "defaultOutputPath" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "tags" TEXT[],
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "UI_Action_pkey" PRIMARY KEY ("uuid")
);

-- CreateTable
CREATE TABLE "WF_StepState" (
    "uuid" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "input" JSONB NOT NULL,
    "output" JSONB,
    "preCheck" BOOLEAN NOT NULL,
    "instanceData" JSONB NOT NULL DEFAULT '{}',
    "instanceId" TEXT NOT NULL,
    "stepId" TEXT NOT NULL,
    "workflowId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3),

    CONSTRAINT "WF_StepState_pkey" PRIMARY KEY ("uuid")
);

-- CreateIndex
CREATE INDEX "UI_Table_tenantUuid_idx" ON "UI_Table"("tenantUuid");

-- CreateIndex
CREATE UNIQUE INDEX "UI_Column_tableUuid_internalId_key" ON "UI_Column"("tableUuid", "internalId");

-- CreateIndex
CREATE UNIQUE INDEX "UI_DynamicColumnConfig_columnUuid_key" ON "UI_DynamicColumnConfig"("columnUuid");

-- CreateIndex
CREATE INDEX "UI_Row_tableUuid_idx" ON "UI_Row"("tableUuid");

-- CreateIndex
CREATE UNIQUE INDEX "UI_Row_tableUuid_uuid_key" ON "UI_Row"("tableUuid", "uuid");

-- CreateIndex
CREATE UNIQUE INDEX "UI_Action_uuid_key" ON "UI_Action"("uuid");

-- CreateIndex
CREATE INDEX "WF_StepState_workflowId_instanceId_idx" ON "WF_StepState"("workflowId", "instanceId");

-- AddForeignKey
ALTER TABLE "UI_Table" ADD CONSTRAINT "UI_Table_tenantUuid_fkey" FOREIGN KEY ("tenantUuid") REFERENCES "Tenant"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UI_Column" ADD CONSTRAINT "UI_Column_tableUuid_fkey" FOREIGN KEY ("tableUuid") REFERENCES "UI_Table"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UI_DynamicColumnConfig" ADD CONSTRAINT "UI_DynamicColumnConfig_columnUuid_fkey" FOREIGN KEY ("columnUuid") REFERENCES "UI_Column"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UI_DynamicColumnConfig" ADD CONSTRAINT "UI_DynamicColumnConfig_actionUuid_fkey" FOREIGN KEY ("actionUuid") REFERENCES "UI_Action"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UI_Row" ADD CONSTRAINT "UI_Row_tableUuid_fkey" FOREIGN KEY ("tableUuid") REFERENCES "UI_Table"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UI_StaticData" ADD CONSTRAINT "UI_StaticData_rowUuid_fkey" FOREIGN KEY ("rowUuid") REFERENCES "UI_Row"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UI_StaticData" ADD CONSTRAINT "UI_StaticData_columnUuid_fkey" FOREIGN KEY ("columnUuid") REFERENCES "UI_Column"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;
