/*
  Warnings:

  - Added the required column `actionId` to the `WF_StepState` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "UI_DynamicColumnConfig" ALTER COLUMN "outputPath" DROP NOT NULL;

-- AlterTable
ALTER TABLE "WF_StepState" ADD COLUMN     "actionId" TEXT NOT NULL;
