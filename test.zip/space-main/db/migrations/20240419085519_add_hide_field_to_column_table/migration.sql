-- AlterTable
ALTER TABLE "UI_Column" ADD COLUMN     "hidden" BOOLEAN NOT NULL DEFAULT false;
