-- DropIndex
DROP INDEX "WF_StepState_workflowId_instanceId_idx";

-- CreateIndex
CREATE INDEX "WF_StepState_instanceId_stepId_idx" ON "WF_StepState"("instanceId", "stepId");
