-- CreateEnum
CREATE TYPE "TenantDataType" AS ENUM ('COMPANY', 'CONTACT', 'LOCATION', 'OTHER');

-- CreateEnum
CREATE TYPE "TenantDataSources" AS ENUM ('SALESFORCE', 'HUBSPOT', 'APOLLO', 'ZOOMINFO');

-- CreateTable
CREATE TABLE "TenantData" (
    "uuid" TEXT NOT NULL,
    "data" JSONB NOT NULL DEFAULT '{}',
    "type" "TenantDataType" NOT NULL,
    "text" TEXT,
    "instanceIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "sourceId" TEXT NOT NULL,
    "source" "TenantDataSources" NOT NULL,
    "tenantUuid" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "TenantData_pkey" PRIMARY KEY ("uuid")
);

-- CreateIndex
CREATE UNIQUE INDEX "TenantData_tenantUuid_source_sourceId_key" ON "TenantData"("tenantUuid", "source", "sourceId");

-- AddForeignKey
ALTER TABLE "TenantData" ADD CONSTRAINT "TenantData_tenantUuid_fkey" FOREIGN KEY ("tenantUuid") REFERENCES "Tenant"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;
