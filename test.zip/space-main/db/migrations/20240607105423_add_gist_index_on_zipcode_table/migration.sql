-- CreateIndex
CREATE INDEX "GEO_ZipCode_geo_idx" ON "GEO_ZipCode" USING GIST ("geo");
