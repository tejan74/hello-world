-- CreateIndex
CREATE INDEX "UI_Row_createdAt_idx" ON "UI_Row"("createdAt");

-- CreateIndex
CREATE INDEX "WF_StepState_createdAt_idx" ON "WF_StepState"("createdAt");
