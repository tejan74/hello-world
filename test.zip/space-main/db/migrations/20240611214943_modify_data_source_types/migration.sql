/*
  Warnings:

  - The values [SALESFORCE,HUBSPOT,APOLLO,ZOOMINFO] on the enum `TenantDataSources` will be removed. If these variants are still used in the database, this will fail.
  - The values [COMPANY,CONTACT,LOCATION,OTHER] on the enum `TenantDataType` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "TenantDataSources_new" AS ENUM ('Salesforce', 'Hubspot', 'Apollo', 'ZoomInfo');
ALTER TABLE "TenantData" ALTER COLUMN "source" TYPE "TenantDataSources_new" USING ("source"::text::"TenantDataSources_new");
ALTER TYPE "TenantDataSources" RENAME TO "TenantDataSources_old";
ALTER TYPE "TenantDataSources_new" RENAME TO "TenantDataSources";
DROP TYPE "TenantDataSources_old";
COMMIT;

-- AlterEnum
BEGIN;
CREATE TYPE "TenantDataType_new" AS ENUM ('CrmCompany', 'CrmContact', 'CrmLocation');
ALTER TABLE "TenantData" ALTER COLUMN "type" TYPE "TenantDataType_new" USING ("type"::text::"TenantDataType_new");
ALTER TYPE "TenantDataType" RENAME TO "TenantDataType_old";
ALTER TYPE "TenantDataType_new" RENAME TO "TenantDataType";
DROP TYPE "TenantDataType_old";
COMMIT;
