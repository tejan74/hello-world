-- AlterTable
ALTER TABLE "UI_DynamicColumnConfig" ADD COLUMN     "disableAutoRun" BOOLEAN NOT NULL DEFAULT false;
