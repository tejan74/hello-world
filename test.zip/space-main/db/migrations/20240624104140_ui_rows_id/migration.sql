-- AlterTable
ALTER TABLE "UI_Row" ADD COLUMN     "id" SERIAL NOT NULL;

-- CreateIndex
CREATE INDEX "UI_Row_id_idx" ON "UI_Row"("id");
