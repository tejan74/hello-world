-- AlterTable
ALTER TABLE "UI_Column" ADD COLUMN     "pinned" BOOLEAN NOT NULL DEFAULT false;
