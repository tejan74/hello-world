-- AlterTable
ALTER TABLE "UI_Column" ADD COLUMN     "locked" BOOLEAN NOT NULL DEFAULT false;
