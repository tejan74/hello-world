-- CreateEnum
CREATE TYPE "Permission" AS ENUM ('ASTRONAUT', 'ADMIN', 'TABLE_EDITOR', 'TABLE_VIEWER', 'GUEST');

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "permission" "Permission" NOT NULL DEFAULT 'TABLE_VIEWER';
