/*
  Warnings:

  - You are about to drop the column `permission` on the `User` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "User" DROP COLUMN "permission",
ADD COLUMN     "roleUuid" TEXT NOT NULL DEFAULT '52c3a2e1-da07-46e1-bffd-a5eede556579';

-- DropEnum
DROP TYPE "Permission";

-- CreateTable
CREATE TABLE "UserRole" (
    "uuid" TEXT NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "UserRole_pkey" PRIMARY KEY ("uuid")
);

-- Manual Migration --
-- Default Values for user role
INSERT INTO "UserRole" ("uuid","name") VALUES
('6c14adca-9552-473c-bfe9-87f0152e0c4c','Astronaut'),
('8b6da5c5-4f5e-42f4-bcd9-d21944c94ab7','Admin'),
('77f78fc1-79bb-429e-8740-f087320cd210','Table Editor'),
('6df5c978-504e-4f1b-9bb7-a849c476161c','Table Viewer'),
('52c3a2e1-da07-46e1-bffd-a5eede556579','Guest');
-- End Manual Migration --

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_roleUuid_fkey" FOREIGN KEY ("roleUuid") REFERENCES "UserRole"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;
