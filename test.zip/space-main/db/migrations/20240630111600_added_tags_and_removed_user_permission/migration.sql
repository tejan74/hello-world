-- AlterTable
ALTER TABLE "UI_Table" ADD COLUMN     "tags" TEXT[] DEFAULT ARRAY[]::TEXT[];
