-- CreateTable
CREATE TABLE "UI_DynamicData" (
    "status" TEXT NOT NULL,
    "input" JSONB NOT NULL,
    "output" JSONB,
    "preCheckStatus" BOOLEAN NOT NULL,
    "rowUuid" TEXT NOT NULL,
    "columnInternalId" TEXT NOT NULL,
    "tableUuid" TEXT NOT NULL,
    "stateCreatedAt" TIMESTAMP(3) NOT NULL,
    "stateUpdatedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3),

    CONSTRAINT "UI_DynamicData_pkey" PRIMARY KEY ("rowUuid","columnInternalId")
);

-- CreateIndex
CREATE INDEX "UI_DynamicData_tableUuid_idx" ON "UI_DynamicData"("tableUuid");


-- Manual Migration --
-------------------------------------------------------------
-- NOTE: This migration was taking too long to run so we didn't run it in prod directly, 
    -- but ran it through a python script table by table with this same query but with a 
    -- where clause on tableUuid. prisma migration table was updated manually.
-------------------------------------------------------------
--- Migrate existing data to UI_DynamicData
INSERT INTO "UI_DynamicData" 
	(status, input, output, "preCheckStatus", "rowUuid", "columnInternalId", "tableUuid", "stateCreatedAt", "stateUpdatedAt")
SELECT DISTINCT ON ("instanceId","stepId") 
	status, input, output, "preCheck", "instanceId", "stepId", "workflowId", "createdAt", "updatedAt"
FROM "WF_StepState" ORDER BY "instanceId", "stepId", "createdAt" desc
ON CONFLICT DO NOTHING;
-- End Manual Migration --
