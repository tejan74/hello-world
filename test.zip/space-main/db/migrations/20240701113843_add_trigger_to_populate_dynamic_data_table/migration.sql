-- Manual Migration --
-- Trigger function to populate UI_DynamicData table with recent data from WF_StepState table
CREATE OR REPLACE FUNCTION UI_PopulateDynamicData() RETURNS trigger AS $$
    BEGIN
        /*
            There is a race that needs to be handled here.
            Scenario: Two instance of same action column is running in parallel,
            one was started earlier and the other later with different input.
            In this case the correct result is produced by the later instance.
            But if the later instance completes first, then when the earlier
            instance completes, it will overwrite the data in UI_DynamicData.
            TODO (ankith): handle this later, when we have a solid execution model.
        */
        INSERT INTO "UI_DynamicData" (
            status, input, output, "preCheckStatus", 
            "rowUuid", "columnInternalId", "tableUuid", 
            "stateCreatedAt", "stateUpdatedAt", "updatedAt"
        )
        VALUES (
            NEW."status", NEW."input", NEW."output", NEW."preCheck", 
            NEW."instanceId", NEW."stepId", NEW."workflowId", 
            NEW."createdAt", NEW."updatedAt", now()
        )
        ON CONFLICT ("rowUuid", "columnInternalId") 
        DO UPDATE SET
            status = NEW."status",
            input = NEW."input",
            output = NEW."output",
            "preCheckStatus" = NEW."preCheck",
            "stateCreatedAt" = NEW."createdAt",
            "stateUpdatedAt" = NEW."updatedAt",
            "updatedAt" = now();
        RETURN NULL;
    END;
$$ LANGUAGE plpgsql;

-- Register trigger to populate UI_DynamicData table with recent data from WF_StepState table
CREATE TRIGGER "populateDynamicData" AFTER INSERT OR UPDATE ON "WF_StepState"
    FOR EACH ROW EXECUTE FUNCTION UI_PopulateDynamicData();

