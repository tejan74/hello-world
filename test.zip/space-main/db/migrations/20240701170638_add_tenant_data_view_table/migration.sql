-- CreateTable
CREATE TABLE "TenantDataView" (
    "uuid" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "source" "TenantDataSources" NOT NULL,
    "dataType" "TenantDataType" NOT NULL,
    "config" JSONB NOT NULL,
    "tenantUuid" TEXT NOT NULL,

    CONSTRAINT "TenantDataView_pkey" PRIMARY KEY ("uuid")
);

-- CreateIndex
CREATE UNIQUE INDEX "TenantDataView_tenantUuid_slug_key" ON "TenantDataView"("tenantUuid", "slug");

-- AddForeignKey
ALTER TABLE "TenantDataView" ADD CONSTRAINT "TenantDataView_tenantUuid_fkey" FOREIGN KEY ("tenantUuid") REFERENCES "Tenant"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;
