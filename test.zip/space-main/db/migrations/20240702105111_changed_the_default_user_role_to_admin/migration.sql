-- AlterTable
ALTER TABLE "User" ALTER COLUMN "roleUuid" SET DEFAULT '8b6da5c5-4f5e-42f4-bcd9-d21944c94ab7';
