-- AlterTable
ALTER TABLE "UI_Column" ADD COLUMN     "color" TEXT;
