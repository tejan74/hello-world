-- AlterTable
ALTER TABLE "UI_Table" ADD COLUMN     "folderUuid" TEXT;

-- CreateTable
CREATE TABLE "Folder" (
    "uuid" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "icon" TEXT,
    "parentFolderUuid" TEXT,
    "tenantUuid" TEXT NOT NULL,
    "createdByUuid" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "Folder_pkey" PRIMARY KEY ("uuid")
);

-- CreateIndex
CREATE INDEX "Folder_tenantUuid_idx" ON "Folder"("tenantUuid");

-- AddForeignKey
ALTER TABLE "Folder" ADD CONSTRAINT "Folder_parentFolderUuid_fkey" FOREIGN KEY ("parentFolderUuid") REFERENCES "Folder"("uuid") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Folder" ADD CONSTRAINT "Folder_tenantUuid_fkey" FOREIGN KEY ("tenantUuid") REFERENCES "Tenant"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Folder" ADD CONSTRAINT "Folder_createdByUuid_fkey" FOREIGN KEY ("createdByUuid") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UI_Table" ADD CONSTRAINT "UI_Table_folderUuid_fkey" FOREIGN KEY ("folderUuid") REFERENCES "Folder"("uuid") ON DELETE SET NULL ON UPDATE CASCADE;
