/*
  Warnings:

  - You are about to drop the column `dataType` on the `TenantDataView` table. All the data in the column will be lost.
  - You are about to drop the column `slug` on the `TenantDataView` table. All the data in the column will be lost.
  - You are about to drop the column `source` on the `TenantDataView` table. All the data in the column will be lost.

*/
-- DropIndex
DROP INDEX "TenantDataView_tenantUuid_slug_key";

-- AlterTable
ALTER TABLE "TenantDataView" DROP COLUMN "dataType",
DROP COLUMN "slug",
DROP COLUMN "source";
