-- CreateTable
CREATE TABLE "ActionUsage" (
    "uuid" TEXT NOT NULL,
    "orbUnits" INTEGER NOT NULL,
    "actionUnits" INTEGER NOT NULL,
    "actionUnitType" TEXT NOT NULL,
    "extraData" JSONB,
    "stateUuid" TEXT NOT NULL,
    "tableUuid" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ActionUsage_pkey" PRIMARY KEY ("uuid")
);

-- AddForeignKey
ALTER TABLE "ActionUsage" ADD CONSTRAINT "ActionUsage_stateUuid_fkey" FOREIGN KEY ("stateUuid") REFERENCES "WF_StepState"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ActionUsage" ADD CONSTRAINT "ActionUsage_tableUuid_fkey" FOREIGN KEY ("tableUuid") REFERENCES "UI_Table"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;
