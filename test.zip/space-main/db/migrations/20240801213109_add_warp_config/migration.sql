-- CreateTable
CREATE TABLE "WarpConfig" (
    "uuid" TEXT NOT NULL,
    "description" TEXT,
    "status" TEXT NOT NULL,
    "config" JSONB NOT NULL,
    "tenantUuid" TEXT NOT NULL,
    "sourceIntegrationUuid" TEXT NOT NULL,
    "destinationIntegrationUuid" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "WarpConfig_pkey" PRIMARY KEY ("uuid")
);

-- AddForeignKey
ALTER TABLE "WarpConfig" ADD CONSTRAINT "WarpConfig_tenantUuid_fkey" FOREIGN KEY ("tenantUuid") REFERENCES "Tenant"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WarpConfig" ADD CONSTRAINT "WarpConfig_sourceIntegrationUuid_fkey" FOREIGN KEY ("sourceIntegrationUuid") REFERENCES "TenantIntegration"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WarpConfig" ADD CONSTRAINT "WarpConfig_destinationIntegrationUuid_fkey" FOREIGN KEY ("destinationIntegrationUuid") REFERENCES "TenantIntegration"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;
