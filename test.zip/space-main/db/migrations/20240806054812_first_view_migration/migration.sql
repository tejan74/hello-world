-- CreateEnum
CREATE TYPE "TableViewType" AS ENUM ('PERSONAL', 'TENANT');

-- CreateTable
CREATE TABLE "TableView" (
    "uuid" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "tenantUuid" TEXT NOT NULL,
    "tableUuid" TEXT NOT NULL,
    "filter" JSONB,
    "sort" JSONB,
    "aggregation" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3),
    "createdById" TEXT,
    "updatedById" TEXT,
    "type" "TableViewType" NOT NULL,
    "default" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "TableView_pkey" PRIMARY KEY ("uuid")
);

-- CreateTable
CREATE TABLE "TableViewColumnOption" (
    "viewUuid" TEXT NOT NULL,
    "columnUuid" TEXT NOT NULL,
    "pinned" BOOLEAN NOT NULL DEFAULT false,
    "hidden" BOOLEAN NOT NULL DEFAULT false,
    "color" TEXT,

    CONSTRAINT "TableViewColumnOption_pkey" PRIMARY KEY ("viewUuid","columnUuid")
);

-- AddForeignKey
ALTER TABLE "TableView" ADD CONSTRAINT "TableView_tableUuid_fkey" FOREIGN KEY ("tableUuid") REFERENCES "UI_Table"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TableView" ADD CONSTRAINT "TableView_tenantUuid_fkey" FOREIGN KEY ("tenantUuid") REFERENCES "Tenant"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TableView" ADD CONSTRAINT "TableView_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TableView" ADD CONSTRAINT "TableView_updatedById_fkey" FOREIGN KEY ("updatedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TableViewColumnOption" ADD CONSTRAINT "TableViewColumnOption_viewUuid_fkey" FOREIGN KEY ("viewUuid") REFERENCES "TableView"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TableViewColumnOption" ADD CONSTRAINT "TableViewColumnOption_columnUuid_fkey" FOREIGN KEY ("columnUuid") REFERENCES "UI_Column"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;
