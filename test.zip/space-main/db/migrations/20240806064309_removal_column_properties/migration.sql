/*
  Warnings:

  - You are about to drop the column `color` on the `UI_Column` table. All the data in the column will be lost.
  - You are about to drop the column `hidden` on the `UI_Column` table. All the data in the column will be lost.
  - You are about to drop the column `pinned` on the `UI_Column` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "UI_Column" DROP COLUMN "color",
DROP COLUMN "hidden",
DROP COLUMN "pinned";
