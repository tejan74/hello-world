-- AlterTable
ALTER TABLE "WarpConfig" ADD COLUMN     "destinationSchema" JSONB NOT NULL DEFAULT '{}',
ADD COLUMN     "sourceSchema" JSONB NOT NULL DEFAULT '{}';
