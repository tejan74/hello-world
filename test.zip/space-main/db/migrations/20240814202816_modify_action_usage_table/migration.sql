/*
  Warnings:

  - Added the required column `chargeableUnits` to the `ActionUsage` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "ActionUsage" ADD COLUMN     "chargeableUnits" INTEGER NOT NULL,
ALTER COLUMN "actionUnits" DROP NOT NULL,
ALTER COLUMN "actionUnitType" DROP NOT NULL;
