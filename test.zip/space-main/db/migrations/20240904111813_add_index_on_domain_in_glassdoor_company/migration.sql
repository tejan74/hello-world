-- CreateIndex
CREATE INDEX "EDS_GlassdoorCompany_domain_idx" ON "EDS_GlassdoorCompany"("domain");
