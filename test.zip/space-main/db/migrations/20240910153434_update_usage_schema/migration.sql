-- AlterTable
ALTER TABLE "ActionUsage" DROP COLUMN "actionUnitType",
DROP COLUMN "actionUnits",
DROP COLUMN "chargeableUnits",
DROP COLUMN "orbUnits",
ADD COLUMN     "runDuration" INTEGER,
ADD COLUMN     "unitType" TEXT,
ADD COLUMN     "units" INTEGER;
