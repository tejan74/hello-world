/*
  Warnings:

  - A unique constraint covering the columns `[tableImportUuid,tableImportSourceId]` on the table `UI_Row` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateEnum
CREATE TYPE "TableImportSource" AS ENUM ('TABLE', 'TENANT_DATA');

-- AlterTable
ALTER TABLE "UI_Row" ADD COLUMN     "tableImportSourceId" TEXT,
ADD COLUMN     "tableImportUuid" TEXT;

-- CreateTable
CREATE TABLE "TableImport" (
    "uuid" TEXT NOT NULL,
    "source" "TableImportSource" NOT NULL,
    "status" TEXT NOT NULL,
    "destTableUuid" TEXT NOT NULL,
    "srcTableUuid" TEXT,
    "tenantDataSource" JSONB,
    "config" JSONB NOT NULL,
    "tenantUuid" TEXT NOT NULL,
    "startedAt" TIMESTAMP(3),
    "finishedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "TableImport_pkey" PRIMARY KEY ("uuid")
);

-- CreateIndex
CREATE UNIQUE INDEX "UI_Row_tableImportUuid_tableImportSourceId_key" ON "UI_Row"("tableImportUuid", "tableImportSourceId");

-- AddForeignKey
ALTER TABLE "TableImport" ADD CONSTRAINT "TableImport_destTableUuid_fkey" FOREIGN KEY ("destTableUuid") REFERENCES "UI_Table"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TableImport" ADD CONSTRAINT "TableImport_srcTableUuid_fkey" FOREIGN KEY ("srcTableUuid") REFERENCES "UI_Table"("uuid") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TableImport" ADD CONSTRAINT "TableImport_tenantUuid_fkey" FOREIGN KEY ("tenantUuid") REFERENCES "Tenant"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UI_Row" ADD CONSTRAINT "UI_Row_tableImportUuid_fkey" FOREIGN KEY ("tableImportUuid") REFERENCES "TableImport"("uuid") ON DELETE SET NULL ON UPDATE CASCADE;
