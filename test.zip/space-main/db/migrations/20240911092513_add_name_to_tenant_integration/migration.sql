/*
  Warnings:

  - Added the required column `name` to the `TenantIntegration` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "TenantIntegration" ADD COLUMN     "deletedAt" TIMESTAMP(3),
ADD COLUMN     "name" TEXT;

UPDATE "TenantIntegration" t SET "name" = t."integration" WHERE "name" IS NULL;

ALTER TABLE "TenantIntegration" ALTER COLUMN "name" SET NOT NULL;
