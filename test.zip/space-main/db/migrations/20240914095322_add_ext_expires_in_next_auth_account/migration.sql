-- AlterTable
ALTER TABLE "NextAuthAccount" ADD COLUMN     "ext_expires_in" INTEGER;
