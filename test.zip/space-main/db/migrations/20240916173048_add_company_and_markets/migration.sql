-- CreateTable
CREATE TABLE "Market" (
    "uuid" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "tenantUuid" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "Market_pkey" PRIMARY KEY ("uuid")
);

-- CreateTable
CREATE TABLE "Company" (
    "id" SERIAL NOT NULL,
    "uuid" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "domain" TEXT NOT NULL,
    "logo" TEXT,
    "description" TEXT,
    "linkedIn" TEXT,
    "headcount" INTEGER,
    "address" TEXT,
    "city" TEXT,
    "state" TEXT,
    "country" TEXT,
    "region" TEXT,
    "zipCode" INTEGER,
    "extras" JSONB NOT NULL DEFAULT '{}',
    "tenantUuid" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "Company_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_CompanyToMarket" (
    "A" INTEGER NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "Company_uuid_key" ON "Company"("uuid");

-- CreateIndex
CREATE INDEX "Company_tenantUuid_idx" ON "Company"("tenantUuid");

-- CreateIndex
CREATE UNIQUE INDEX "Company_tenantUuid_domain_key" ON "Company"("tenantUuid", "domain");

-- CreateIndex
CREATE UNIQUE INDEX "_CompanyToMarket_AB_unique" ON "_CompanyToMarket"("A", "B");

-- CreateIndex
CREATE INDEX "_CompanyToMarket_B_index" ON "_CompanyToMarket"("B");

-- AddForeignKey
ALTER TABLE "Market" ADD CONSTRAINT "Market_tenantUuid_fkey" FOREIGN KEY ("tenantUuid") REFERENCES "Tenant"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Company" ADD CONSTRAINT "Company_tenantUuid_fkey" FOREIGN KEY ("tenantUuid") REFERENCES "Tenant"("uuid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_CompanyToMarket" ADD CONSTRAINT "_CompanyToMarket_A_fkey" FOREIGN KEY ("A") REFERENCES "Company"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_CompanyToMarket" ADD CONSTRAINT "_CompanyToMarket_B_fkey" FOREIGN KEY ("B") REFERENCES "Market"("uuid") ON DELETE CASCADE ON UPDATE CASCADE;
