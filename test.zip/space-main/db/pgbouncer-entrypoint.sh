#!/bin/bash
sed -i "s/{{{DB_HOST}}}/$DB_HOST/g" /etc/pgbouncer/pgbouncer.ini && \
sed -i "s/{{{DB_PORT}}}/$DB_PORT/g" /etc/pgbouncer/pgbouncer.ini && \
sed -i "s/{{{DB_USER}}}/$DB_USER/g" /etc/pgbouncer/pgbouncer.ini && \
sed -i "s/{{{DB_PASSWORD}}}/$DB_PASSWORD/g" /etc/pgbouncer/pgbouncer.ini && \
sed -i "s/{{{PGB_USER}}}/$PGB_USER/g" /etc/pgbouncer/userlist.txt && \
sed -i "s/{{{PGB_PASSWORD}}}/$PGB_PASSWORD/g" /etc/pgbouncer/userlist.txt && \
pgbouncer -u nobody /etc/pgbouncer/pgbouncer.ini 2>&1
