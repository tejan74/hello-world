# Artifact Registry
We use Google Cloud Artifact Registry to store our Docker images, but because we store exclusively Docker images, all registries are the same to us. 

To save on costs, our registries are created as follows:

- Name of registry is same as name of repository in Github
- Standard repositories, no need to replicate upstream images
- Regional only repositories, same region as k8s cluster (most providers don’t charge for the network traffic if the images don’t traverse regions)
- Store only last 5 versions of image, after that delete remaining ones (most providers charge by the GB/month) using artifact policies
- Encryption enabled, use cloud-hosting provider managed keys (e.g. let Google manage this for us)

As an example, we’d do the following config for our registry:

- space
- Standard repository
- us-central1 region only
- Store 5 versions and delete rest immediately
- Encryption enabled using Google Cloud key