### **Objective**

Add a `config` field of type `Json` to the `UI_Column` model in the Prisma schema, which includes an `ui_type` property. This allows for custom-style visual elements in columns, with a default `ui_type` value of `normal` from ['normal','pill','select'].

### **Benefits**

- **Flexibility**: Enables dynamic configuration of column appearance.
- **Enhanced UI**: Supports custom-style visuals, improving user experience.
- **Future-Proofing**: The `Json` type allows for easy addition of more configuration options later.

### **Changes**

**Schema Update**: Add `config` field to `UI_Column`.  
prisma  
Copy code  
`model UI_Column {`  
 `// ...existing fields...`  
 `uuid String @id @default(uuid())`
`// Column info`
`name        String`
`// This is to avoid using the uuid in the input config`
`// Internal id is to be used in the input config of dynamic columns`
`// First Name -> first_name`
`// This doesn't change if the column name changes`
`internalId  String`
`description String?`
`type        UI_ColumnType`
`icon        String?`
`hidden      Boolean       @default(false)`
`pinned      Boolean       @default(false)`
`locked      Boolean       @default(false)`
`color       String?`

`// dependencies will store internalIds of columns that this column depends on`
`dependencies String[] @default([])`

`tableUuid String`
`Table     UI_Table @relation(fields: [tableUuid], references: [uuid])`

`// Common fields`
`deletedAt DateTime?`
`createdAt DateTime  @default(now())`
`updatedAt DateTime  @updatedAt`

`StaticData          UI_StaticData[]`
`// Only dynamic and formula columns will have dynamic column config`
`DynamicColumnConfig UI_DynamicColumnConfig?`

`@@unique([tableUuid, internalId])`

`config Json @default("{}")`  
`}`

1.
1. **Migration**: Apply a migration to update the database schema.
1. **Application Code**: Update code to handle and apply the `ui_type` property from the `config` field.
1. **Testing & Documentation**: Ensure functionality and update documentation.

### \*\*Sample Json

`config: {ui_type: "pill" | "normal" | "select"}`

### **Conclusion**

This enhancement provides greater flexibility and visual customization for columns, while maintaining backward compatibility with the default `normal` value for `ui_type` from ['normal','pill','select'].
