# Table Views v1

Design: tulasi // Ticket: [EPD-472](https://linear.app/withorbital/issue/EPD-472])

## Feature

Support the ability for users to create "saved views" that are subsets of a full table with:

- rows filtered and/or sorted
- columns shown/hidden
- aggregation metrics added/removed
  Other feature requirements:
- Should be restricted to one table
- Should have a name and users should be able to rename
- Should be accessible via a direct link on the table (e.g. `/table/{table-uuid}/{view-name}` or `/table/{table-uuid}?view={view-uuid}`)
- For now: views are accessible to everyone on the team, but we may create "personal" vs. "tenant" level views in the future

Considerations:

- Today, we have an issue where if you add too many filters, sorts, or aggregations the URL gets too long so we shouldn't store view config in the URL itself

## Schema

Here is the proposed schema:

```

model TableView {
 uuid             String   @id @default(uuid())
 name             String
 tenantUuid       String
 tableUuid        String
 columnOrder String[] @default([]) //order of columns stored in UUID form
 // From here onwards column related data will store
 filter           Json?
 sort             Json?
 // end of column related data
 createdAt        DateTime @default(now())
 updatedAt        DateTime @updatedAt
 createdBy        String
 updatedBy        String
 // type either personal or tenant
 type             String   @default("personal")
}


model ViewColumnMapping {


 uuid String @id @default(uuid())
 viewUuid String
 Pin boolean
 Hidden boolean
 Color string
 aggregation Json?

 @@unique([viewUuid, uuid])
}

UI_Column Schema (removed pin,color, hidden)

```

## logic

in table we should some view icon
-> when we click on view icon we can see all views and create view button
-> when that button is clicked we can open popup for name and type
-> On save

Migration of pin, hidden, color from UI_Columns to ViewColumnMapping
Need to change existing functionality of pin, hidden, color changing
Migration of default view to every table
View UI
View functionality
On deletion of column we need to remove that column in columnOrder

## Questions
