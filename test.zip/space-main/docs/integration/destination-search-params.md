
# Note on Parameter Alignment

Please note that the parameters used in the examples, such as `operator` and `match_pattern`, may not be aligned with the actual code implementation. This document serves as an explanation of how the filter works, and you should refer to the code itself to get the correct values for each argument.

The provided code snippets demonstrate the usage of the `SearchParamsGroup` and `ObjectMapping` models, showcasing how to define complex search conditions for the destination object. By combining different search parameter groups using "AND" and "OR" logic, you can create powerful filters for your search queries.

To understand the values of each argument, please refer to the code and its corresponding documentation.

Remember to always consult the code implementation for accurate information on the available parameters and their usage.

# Destination Search Parameters
The `dest_search_params` field in the `ObjectMapping` model allows you to define complex search conditions for the destination object by grouping and applying filters using "AND" and "OR" logic.

## Search Parameters Group

The `SearchParamsGroup` model represents a group of search parameters that are applied together. By including multiple instances of `SearchParams` inside the `params` list, you can define multiple conditions that are combined using "AND" logic. This means that all conditions within the group must be satisfied for the search to match.

Example:
```python
params_group = SearchParamsGroup(
    params=[
        SearchParams(destination_key="name", operator=SearchOperators.EQUALS, match_pattern="John"),
        SearchParams(destination_key="age", operator=SearchOperators.GREATER_THAN, match_pattern=18)
    ]
)
```

In the above example, the `params_group` contains two search parameters. The first parameter checks if the `name` field in the destination object is equal to "John", and the second parameter checks if the `age` field is greater than 18. Both conditions must be satisfied for the search to match.

## Destination Search Parameters

The `dest_search_params` field in the `ObjectMapping` model allows you to define multiple `SearchParamsGroup` instances, which are combined using "OR" logic. This means that if any of the search parameter groups match, the search is considered successful.

Example:
```python
object_mapping = ObjectMapping(
    dest_search_params=[
        SearchParamsGroup(
            params=[
                SearchParams(destination_key="name", operator=SearchOperators.EQUALS, match_pattern="John"),
                SearchParams(destination_key="age", operator=SearchOperators.GREATER_THAN, match_pattern=18)
            ]
        ),
        SearchParamsGroup(
            params=[
                SearchParams(destination_key="city", operator=SearchOperators.EQUALS, match_pattern="New York"),
                SearchParams(destination_key="country", operator=SearchOperators.EQUALS, match_pattern="USA")
            ]
        )
    ]
)
```

In the above example, the `object_mapping` contains two `SearchParamsGroup` instances. The first group checks if the `name` field is equal to "John" and the `age` field is greater than 18. The second group checks if the `city` field is equal to "New York" and the `country` field is equal to "USA". If any of these groups match, the search is considered successful.

Additional Examples:

Example 1:
```python
params_group = SearchParamsGroup(
    params=[
        SearchParams(destination_key="name", operator=SearchOperators.CONTAINS, match_pattern="Doe"),
        SearchParams(destination_key="age", operator=SearchOperators.LESS_THAN, match_pattern=30)
    ]
)
```
In this example, the `params_group` contains two search parameters. The first parameter checks if the `name` field in the destination object contains the string "Doe", and the second parameter checks if the `age` field is less than 30. Both conditions must be satisfied for the search to match.

Example 2:
```python
object_mapping = ObjectMapping(
    dest_search_params=[
        SearchParamsGroup(
            params=[
                SearchParams(destination_key="name", operator=SearchOperators.CONTAINS, match_pattern="Doe"),
                SearchParams(destination_key="age", operator=SearchOperators.LESS_THAN, match_pattern=30)
            ]
        ),
        SearchParamsGroup(
            params=[
                SearchParams(destination_key="city", operator=SearchOperators.EQUALS, match_pattern="London"),
                SearchParams(destination_key="country", operator=SearchOperators.EQUALS, match_pattern="UK")
            ]
        )
    ]
)
```
In this example, the `object_mapping` contains two `SearchParamsGroup` instances. The first group checks if the `name` field contains the string "Doe" and the `age` field is less than 30. The second group checks if the `city` field is equal to "London" and the `country` field is equal to "UK". If any of these groups match, the search is considered successful.

Note: The `dest_search_params` field can also be set to `None`, indicating that no additional search parameters are required.

Example in JSON:
```json
"dest_search_params": [
    {
        "params": [
            {
                "destination_key": "name",
                "operator": "EQUALS",
                "match_pattern": "John"
            },
            {
                "destination_key": "age",
                "operator": "GREATER_THAN",
                "match_pattern": 18
            }
        ]
    },
    {
        "params": [
            {
                "destination_key": "city",
                "operator": "EQUALS",
                "match_pattern": "New York"
            },
            {
                "destination_key": "country",
                "operator": "EQUALS",
                "match_pattern": "USA"
            }
        ]
    }
]
```

In the above example, the `dest_search_params` field is an array of `SearchParamsGroup` objects. Each `SearchParamsGroup` object represents a group of search parameters that are applied together. 

The first `SearchParamsGroup` contains two search parameters. The first parameter checks if the `name` field in the destination object is equal to "John", and the second parameter checks if the `age` field is greater than 18.

The second `SearchParamsGroup` also contains two search parameters. The first parameter checks if the `city` field in the destination object is equal to "New York", and the second parameter checks if the `country` field is equal to "USA".

If any of these search parameter groups match, the search is considered successful.

Note: The `dest_search_params` field can contain multiple `SearchParamsGroup` instances, allowing you to define complex search conditions by combining different groups using "OR" logic.

