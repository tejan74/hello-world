# Integrations

**Vocabulary**

- Serializers = out-sync, converting our IR in TenantData JSON format to the respective format for third-party service
- Deserializer = in-sync, converting third-party service into IR for TenantData JSON format
- Validators = validate serialized and deserialized data

**Structure**

- interstellar
  - <lib> /
    - …existing libraries…
    - <salesforce>
    - <hubspot>
  - <integration>/
    - <interface>/
      - _Unify interfaces for all integrations to execute standard processes, e.g. every serializer has the same 2-3 functions that perform the needful_
      - <serialize>.py
      - <deserialize>.py
      - <validate>.py
    - <source>/ *(e.g. salesforce)*
      - *e.g. Salesforce; implementation of each integration*
      - serialize
      - deserialize
      - _validate.py
