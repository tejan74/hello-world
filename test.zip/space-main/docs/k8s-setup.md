# Kubernetes Setup

> 🥳 This document was created with Google Cloud in mind.


### Create New Cluster

Today, we use GUI to setup the cluster. Be sure to use the standard edition during setup and configure the following properties:

- Enable Workload Identity Federation

### Authentication and Authorization

We need to do a two-way binding of Google Cloud IAM service accounts with Kubernetes service accounts to connect with GCP services.

On the Kubernetes side, we need to run this templated command: 

```bash
kubectl annotate serviceaccount <serviceaccount> \
	--namespace <namespace> \
	iam.gke.io/gcp-service-account=<GCP Service Account Principal>

# *As an example, populated for our development environment:*
kubectl annotate serviceaccount default \
  --namespace default \
 iam.gke.io/gcp-service-account=k8s-node-default-service-accou@orbital-development-2.iam.gserviceaccount.com
```

On the Google Cloud side, we need to run this templated command: 

```bash
gcloud iam service-accounts \
	add-iam-policy-binding <GCP Service Account Principal>  \ 
	--role roles/iam.workloadIdentityUser \
	--member "serviceAccount:<k8s Workload Identifier>[<namespace>/<serviceaccount>]"

# *As an example, populated for our development environment:*
*gcloud iam service-accounts \
	add-iam-policy-binding k8s-node-default-service-accou@orbital-development-2.iam.gserviceaccount.com  \ 
	--role roles/iam.workloadIdentityUser \
	--member "serviceAccount:orbital-development-2.svc.id.goog[default/default]"*
```

### Network

We create private Kubernetes clusters that by default don’t have access to the public internet. We create public NAT gateways that bridge the internal VPC networks and the underlying VMs that the cluster runs on.

@ani write how to create a public NAT gateway in GCP for GKE

### Secrets

We rely on Google Secret Manager to store all of our secrets and configuration. See this document for adding relevant secrets: [Secret Management](https://www.notion.so/Secret-Management-2819a437a16d4235b135d465b2d7c364?pvs=21) 

### Artifact Registry

We rely on Google Artifact Registry to store our Docker images for building and deploying. See this document for creating/editing registries: [Artifact Registry](https://www.notion.so/Artifact-Registry-abe1bc4d2706437b98114aa026b3d715?pvs=21) 

### Source Code