# Secret Management
We use Google Secret Manager, see [docs](https://cloud.google.com/secret-manager/docs). All secret names are unique in the environment and are case insensitive. 

## Environments

- Production
- Development

## Secrets

**Cross-platform**

- Google Service API: `GOOGLE_SERVICE_API_KEY`
    - Scoped to: Custom Search, Places, Geocode, Address Validation

**Enrichment**

- Coresignal API: `CORESIGNAL_API_KEY`
- Apollo API: `APOLLO_API_KEY`

**LLMs**

- OpenAI API Key: `OPENAI_API_KEY`
- Perplexity API Key: `PERPLEXITY_API_KEY`
- Anthropic API Key: `ANTHROPIC_API_KEY`

**Maps**

- Here Maps API: `HERE_MAPS_API_KEY`

**Search**

- Google Search Engine ID: `GOOGLE_SEARCH_ENGINE_ID`

**Other**

- RapidAPI API Key: `RAPIDAPI_API_KEY`