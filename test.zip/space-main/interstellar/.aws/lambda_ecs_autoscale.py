import boto3
import os


def scale_ecs_service(cluster_name, service_name, desired_task_count):
    ecs = boto3.client("ecs")

    response = ecs.update_service(
        cluster=cluster_name, service=service_name, desiredCount=desired_task_count
    )

    return response


def get_number_of_active_tasks(service_name, cluster_name):
    ecs_client = boto3.client("ecs")

    response = ecs_client.describe_services(
        cluster=cluster_name, services=[service_name]
    )

    # Extract the number of running tasks
    active_tasks = 0
    if response["services"]:
        service = response["services"][0]
        active_tasks = service.get("runningCount", 0)

    return active_tasks


def lambda_handler(event, context):
    sqs = boto3.client("sqs")

    max_instances = 1000
    cluster_name = "space-1-ecs-cluster"
    service_name = "interstellar-action-long"
    queue_attributes = sqs.get_queue_attributes(
        QueueUrl=os.environ.get("QUEUE_URL"), AttributeNames=["All"]
    )
    approximate_number_of_messages = float(
        queue_attributes["Attributes"]["ApproximateNumberOfMessages"]
    )

    number_of_active_task_in_service = float(
        get_number_of_active_tasks(service_name, cluster_name)
    )

    desired_task_count = min(max_instances, approximate_number_of_messages)

    if desired_task_count == 0:
        desired_task_count = 1

    print(f"Scaling ecs task to {desired_task_count}")

    response = scale_ecs_service(cluster_name, service_name, int(desired_task_count))

    return {"statusCode": 200, "body": desired_task_count}
