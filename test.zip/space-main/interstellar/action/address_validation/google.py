import iso3166
import types
import pydantic

# TODO(ankith): use pydash chaining
from pydash import get, find

from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionError, ActionResponse, ActionUsage
from lib import google_maps
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class GoogleAddressValidationInput(BaseActionInput):
    api_key: str | None = None
    raw_address: str
    region_code: str | None = None


class ComponentName(pydantic.BaseModel):
    text: str
    languageCode: str | None = None


class AddressComponent(pydantic.BaseModel):
    componentName: ComponentName
    componentType: str
    confirmationLevel: str | None = None


class GoogleAddressValidationOutput(BaseActionOutput):
    street: str | None = None
    city: str | None = None
    state: str | None = None
    country: str | None = None
    zip_code: str | None = None
    country_iso: str | None = None
    formatted_address: str | None = None
    state_id: str | None = None
    region_code: str | None = None
    lat: float | None = None
    lng: float | None = None
    raw_address: str | None = None
    address_components: list[AddressComponent] | None = None


class GoogleAddressValidationAction(
    BaseAction[GoogleAddressValidationInput, GoogleAddressValidationOutput]
):
    id = "2799ab51-bd82-4536-862c-12900d5dfd16"
    name = "Address Validation (Google Maps)"
    description = "Validate an address"
    icon = "https://www.google.com/favicon.ico"
    default_output_path = "result.street"
    input_schema = GoogleAddressValidationInput
    output_schema = GoogleAddressValidationOutput
    usage = ActionUsage(units=1, unit_type="credit")
    tags = ["Maps & Locations"]

    # TODO: rewrite this to be more readable and easy to understand as well as build waterfall to nokia here maps
    def _run(
        self, input: GoogleAddressValidationInput
    ) -> ActionResponse[GoogleAddressValidationOutput]:
        try:
            client = google_maps.ApiClient(input.api_key)
            # Verify input params
            if not input.raw_address:
                logger.error(
                    "Address is required.", extra={"address": input.raw_address}
                )
                return ActionResponse(
                    error=ActionError(
                        code="INVALID_INPUT", message="Address is required.", e=None
                    )
                )

            # Run an address validation request on Google Maps with the address
            response = client.address_validation(
                address=input.raw_address, region_code=input.region_code
            )
            # TODO: store this error state in a static var and return error if no address is provided
            if "error" in response:
                logger.error(
                    "Error validating address.", extra={"address": input.raw_address}
                )
                return ActionResponse(
                    error=ActionError(
                        code="VALIDATION_ERROR",
                        message=get(response, "error.message"),
                        e=None,
                    ),
                )

            # Parse response from Google Maps
            address = get(response, "result.address")
            address_lines = get(address, "postalAddress.addressLines")
            state_id = get(address, "postalAddress.administrativeArea")
            region_code = get(address, "postalAddress.regionCode")

            # Build internal representative output format
            # TODO: redo this process logic to have better logic, if necessary in switch case
            result = GoogleAddressValidationOutput(
                street=", ".join(address_lines) if address_lines else None,
                city=get(address, "postalAddress.locality")
                or get(
                    find(
                        get(address, "addressComponents"),
                        lambda x: x["componentType"] == "locality",
                    ),
                    "componentName.text",
                ),
                state=get(
                    find(
                        get(address, "addressComponents"),
                        lambda x: x["componentType"] == "administrative_area_level_1",
                    ),
                    "componentName.text",
                ),
                country=get(
                    find(
                        get(address, "addressComponents"),
                        lambda x: x["componentType"] == "country",
                    ),
                    "componentName.text",
                )
                or iso3166.countries.get(
                    region_code if region_code else "", types.SimpleNamespace(name="")
                ).name,
                zip_code=get(address, "postalAddress.postalCode")
                or get(
                    find(
                        get(address, "addressComponents"),
                        lambda x: x["componentType"] == "postal_code",
                    ),
                    "componentName.text",
                ),
                country_iso=iso3166.countries.get(
                    region_code if region_code else "", types.SimpleNamespace(name="")
                ).name,
                formatted_address=get(address, "formattedAddress"),
                state_id=state_id,
                region_code=region_code,
                lat=get(response, "result.geocode.location.latitude"),
                lng=get(response, "result.geocode.location.longitude"),
                raw_address=input.raw_address,
                address_components=get(address, "addressComponents"),
            )

            return ActionResponse(result=result)

        except Exception as e:
            # Log error
            logger.exception(
                "Error validating address.", extra={"address": input.raw_address}
            )
            # Return error
            return ActionResponse(
                error=ActionError(
                    code="ERROR", message="Error validating address - " + str(e), e=e
                )
            )
