from typing import Literal
from pydantic import BaseModel, ConfigDict, model_validator


class LLMInput(BaseModel):
    llm: Literal["OpenAI", "Anthropic"] = "OpenAI"
    model: str

    @model_validator(mode="before")
    def validate_model(cls, values):
        llm = values.get("llm")
        model = values.get("model")

        openai_models = ["gpt-4o", "gpt-4o-mini"]
        anthropic_models = [
            "claude-3-opus-20240229",
            "claude-3-sonnet-20240229",
            "claude-3-haiku-20240307",
            "claude-3-5-sonnet-20240620",
        ]

        valid_models = {
            "OpenAI": openai_models,
            "Anthropic": anthropic_models,
        }

        if model not in valid_models.get(llm, []):
            raise ValueError(f"Model '{model}' is not valid for LLM '{llm}'.")

        return values

    model_config = ConfigDict(
        json_schema_extra={
            "$schema": "http://json-schema.org/draft-07/schema#",
            "dependencies": {
                "llm": {
                    "oneOf": [
                        {
                            "properties": {
                                "llm": {"enum": ["OpenAI"]},
                                "model": {
                                    "enum": [
                                        "gpt-4o",
                                        "gpt-4o-mini",
                                    ]
                                },
                            }
                        },
                        {
                            "properties": {
                                "llm": {"enum": ["Anthropic"]},
                                "model": {
                                    "enum": [
                                        "claude-3-opus-20240229",
                                        "claude-3-sonnet-20240229",
                                        "claude-3-haiku-20240307",
                                        "claude-3-5-sonnet-20240620",
                                    ]
                                },
                            }
                        },
                    ]
                }
            },
        }
    )
