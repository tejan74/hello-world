from __future__ import annotations

import ast
from typing import List, Tuple, Type, cast

from pydantic import BaseModel, Field
from playwright.sync_api import sync_playwright, Page, BrowserContext

from langchain_core.pydantic_v1 import Extra
from langchain_core.tools import BaseTool, BaseToolkit

from bs4 import BeautifulSoup

from lib.selenium.playwright_chromium import PlaywrightOrbBrowser
from util.logger import interstellar_logger


# TODOS:
# 1. Add ProxyBrowser support
# 2. Add Proxy support
# 3. Add Captcha support
# 4. Add more browser support
# 5. Add Zoom and Screen Resolution support

logger = interstellar_logger(__name__)


class PlaywrightBrowserToolkit(BaseToolkit):
    """Toolkit for Playwright browser tools.

    **Security Note**: This toolkit provides code to control a web-browser.

        Careful if exposing this toolkit to end-users. The tools in the toolkit
        are capable of navigating to arbitrary webpages, clicking on arbitrary
        elements, and extracting arbitrary text and hyperlinks from webpages.

        Specifically, by default this toolkit allows navigating to:

        - Any URL (including any internal network URLs)
        - And local files

        If exposing to end-users, consider limiting network access to the
        server that hosts the agent; in addition, consider it is advised
        to create a custom NavigationTool wht an args_schema that limits the URLs
        that can be navigated to (e.g., only allow navigating to URLs that
        start with a particular prefix).

        Remember to scope permissions to the minimal permissions necessary for
        the application. If the default tool selection is not appropriate for
        the application, consider creating a custom toolkit with the appropriate
        tools.

        See https://python.langchain.com/docs/security for more information.

    Parameters:
        browser: The Playwright browser.
    """

    orb_browser: PlaywrightOrbBrowser

    class Config:
        """Configuration for this pydantic object."""

        extra = Extra.forbid
        arbitrary_types_allowed = True

    def get_tools(self) -> List[BaseTool]:
        """Get the tools in the toolkit."""
        tool_classes: List[Type[BaseBrowserTool]] = [
            PlaywrightClickTool,
            PlaywrightNavigateTool,
            PlaywrightExtractTextTool,
            PlaywrightExtractHyperlinksTool,
            PlaywrightCurrentWebPageTool,
            PlaywrightGetPageContent,
            PlaywrightExecuteScriptTool,
            PlaywrightCreateNewTabTool,
            PlaywrightSwitchTabTool,
            PlaywrightListTabsTool,
            PlaywrightFillFormTool,
        ]

        tools = [
            tool_cls.from_browser(browser=self.orb_browser.browser)
            for tool_cls in tool_classes
        ]
        return cast(List[BaseTool], tools)

    @classmethod
    def from_browser(
        cls,
        orb_browser: PlaywrightOrbBrowser,
    ) -> PlaywrightBrowserToolkit:
        """Instantiate the toolkit.

        Args:
            browser: The Playwright browser.

        Returns:
            The toolkit.
        """
        return cls(orb_browser=orb_browser)


class BaseBrowserTool(BaseTool):
    """Base class for browser tools."""

    browser: BrowserContext
    page: Page

    @classmethod
    def from_browser(
        cls,
        browser: BrowserContext,
    ) -> BaseBrowserTool:
        """Instantiate the tool."""
        return cls(browser=browser, page=browser.pages[0])  # type: ignore[call-arg]


class SelectorInput(BaseModel):
    """Input to Select element."""

    css_selector: str = Field(..., description="CSS selector for the element to click")


class NavigateToolInput(BaseModel):
    """Input for NavigateTool."""

    url: str = Field(..., description="URL to navigate to")


class ExecuteScriptInput(BaseModel):
    """Input for ExecuteScriptTool."""

    script: str = Field(..., description="The script to execute.")


class PlaywrightClickTool(BaseBrowserTool):
    """Tool for clicking elements in a Playwright browser."""

    name: str = "Click Element"
    description: str = "Click an element by its locator."
    args_schema: Type[BaseModel] = SelectorInput

    def _run(self, css_selector: str):
        """Click an element by its locator."""
        try:
            self.page.click(css_selector)
            return f"Clicked element with selector: {css_selector}"
        except Exception as e:
            return f"Error clicking element {css_selector}: {e}"


class PlaywrightCreateNewTabTool(BaseBrowserTool):
    """Tool for creating a new tab in a Playwright browser."""

    name: str = "Create New Tab"
    description: str = "Create a new tab in the browser."

    def _to_args_and_kwargs(self, tool_input: str | dict) -> Tuple[Tuple, dict]:
        return (), {}

    def _run(self):
        """Create a new tab."""
        self.page = self.browser.new_page()
        return "Created new tab."


class PlaywrightSwitchTabInput(BaseModel):
    """Input to Switch Tab."""

    tab_index: int = Field(..., description="Index of the tab to switch to")


class PlaywrightSwitchTabTool(BaseBrowserTool):
    """Tool for switching tabs in a Playwright browser."""

    name: str = "Switch Tab"
    description: str = "Switch to a tab by its index."
    args_schema: Type[BaseModel] = PlaywrightSwitchTabInput

    def _run(self, tab_index: int):
        """Switch to a tab by its index."""
        context = self.page.context
        pages = context.pages
        pages[tab_index].bring_to_front()
        self.page = pages[tab_index]
        return f"Switched to tab with index: {tab_index}"


class PlaywrightListTabsTool(BaseBrowserTool):
    """Tool for listing tabs in a Playwright browser."""

    name: str = "List Tabs"
    description: str = "List all tabs in the browser."

    def _to_args_and_kwargs(self, tool_input: str | dict) -> Tuple[Tuple, dict]:
        return (), {}

    def _run(self):
        """List all tabs in the browser."""
        context = self.page.context
        tabs = []
        for index, page in enumerate(context.pages):
            tabs.append(f"Tab {index}: {page.url}")

        return tabs


class PlaywrightNavigateTool(BaseBrowserTool):
    """Tool for navigating to a URL in a Playwright browser."""

    name: str = "Navigate to URL"
    description: str = "Navigate to a URL."
    args_schema: Type[BaseModel] = NavigateToolInput

    def _run(self, url: str):
        """Navigate to a URL."""
        self.page.goto(url)
        return f"Navigated to URL: {url}"


class PlaywrightExtractTextTool(BaseBrowserTool):
    """Tool for extracting text from a Playwright browser."""

    name: str = "Extract Text"
    description: str = "Extract text from an element."
    args_schema: Type[BaseModel] = SelectorInput

    def _run(self, css_selector: str) -> str:
        """Extract text from an element."""
        try:
            element = self.page.query_selector(css_selector)

            if element is None:
                return f"Error: Element with selector {css_selector} not found"

            text = element.inner_text()
            return text
        except Exception as e:
            return f"Error extracting text from element {css_selector}: {e}"


class PlaywrightExtractHyperlinksTool(BaseBrowserTool):
    """Tool for extracting hyperlinks from a Playwright browser."""

    name: str = "Extract Hyperlinks"
    description: str = "Extract hyperlinks from an element."
    args_schema: Type[BaseModel] = SelectorInput

    def _run(self, css_selector: str) -> List[tuple[str, str | None]] | str:
        """Extract hyperlinks from an element."""
        try:
            elements = self.page.query_selector_all(css_selector)

            # filter out elements that don't have href attribute
            elements = [
                element
                for element in elements
                if element.get_attribute("href") is not None
            ]

            hyperlinks = [
                (element.inner_text(), element.get_attribute("href"))
                for element in elements
            ]

            return hyperlinks
        except Exception as e:
            return f"Error extracting hyperlinks from element {css_selector}: {e}"


class PlaywrightGetPageContent(BaseBrowserTool):
    """Tool for getting the page content in a Playwright browser."""

    name: str = "Get Full Page Html"
    description: str = "Get Full Page Html"

    def _to_args_and_kwargs(self, tool_input: str | dict) -> Tuple[Tuple, dict]:
        return (), {}

    def _run(self) -> str:
        content = self.page.content()
        soup = BeautifulSoup(content, "html.parser")

        for data in soup(["style", "script", "svg"]):
            # Remove tags
            data.decompose()

        return str(soup)


class PlaywrightCurrentWebPageTool(BaseBrowserTool):
    """Tool for getting the current webpage in a Playwright browser."""

    name: str = "Current Webpage"
    description: str = "Get the current webpage URL."

    def _to_args_and_kwargs(self, tool_input: str | dict) -> Tuple[Tuple, dict]:
        return (), {}

    def _run(self) -> str:
        """Get the current webpage URL."""
        return self.page.url


class PlaywrightExecuteScriptTool(BaseBrowserTool):
    """Tool for executing a script in a Playwright browser."""

    name: str = "Execute Script"
    description: str = "Execute a script in the browser."
    args_schema: Type[BaseModel] = ExecuteScriptInput

    def _run(self, script: str):
        """Execute a script."""
        try:
            value = self.page.evaluate(script)
            return f"Executed script: {script}, returned: {value}"
        except Exception as e:
            return f"Error executing script: {e}"


class FillFormInputInput(BaseModel):
    """Input to Fill Form."""

    selector: str = Field(
        ..., description="CSS selector for the form element, example #id or .class"
    )
    value: str = Field(..., description="Value to fill in the form element")


class PlaywrightFillFormTool(BaseBrowserTool):
    """Input to Fill Form."""

    name: str = "Fill Form Element"
    description: str = "Fill a form element."
    args_schema: Type[BaseModel] = FillFormInputInput

    def _to_args_and_kwargs(self, tool_input: dict | str) -> Tuple[Tuple, dict]:

        args = {}
        if isinstance(tool_input, str):
            try:
                args = ast.literal_eval(tool_input)
            except Exception as e:
                logger.warning(f"Error parsing input: {e}")
                _array = tool_input.split(",")
                args["selector"] = _array[0]
                args["value"] = _array[1]

        return (args.get("selector"), args.get("value")), {}

    def _run(self, selector: str, value: str):
        """Fill a form element."""
        element = self.page.query_selector(selector)

        if element is None:
            return f"Error: Element with selector {selector} not found"

        element.fill(value)
        return f"Filled form element with selector: {selector} with value: {value}"
