import json
from typing import Any, Optional
from langchain.pydantic_v1 import BaseModel, Field
from langchain.tools import StructuredTool, tool
from pydash import get, has, set_
import pydash
from lib import scraper_api


class GoogleSearchInput(BaseModel):
    query: str = Field(..., title="Query", description="The search query to be used.")
    limit: Optional[int] = Field(
        None, title="Limit", description="The number of search results to return."
    )


class ScraperInput(BaseModel):
    url: str = Field(..., title="URL", description="The URL to scrape.")


def _google_search(query: str, limit: Optional[int] | None = None) -> str:
    try:
        scraper = scraper_api.ApiClient()
        status, res = scraper.google_search(query, limit)
        results = res["organic_results"] if "organic_results" in res else []
        if status != 200:
            return json.dumps(
                {
                    "result": {"items": [], "count": -1},
                    "status": "FAILED_TO_SEARCH",
                    "error": "Failed to perform google search using this tool",
                }
            )

        return json.dumps(
            {
                "result": {
                    "items": [
                        {
                            "title": pydash.get(item, "title", None),
                            "link": pydash.get(item, "link", None),
                            "displayLink": pydash.get(item, "displayed_link", None),
                            "snippet": pydash.get(item, "snippet", None),
                            "position": pydash.get(item, "position", None),
                        }
                        for item in results
                    ],
                    "count": len(results),
                },
            }
        )
    except Exception as e:
        return json.dumps(
            {
                "result": {"items": [], "count": -1},
                "status": "FAILED_TO_SEARCH",
                "error": f"Failed to perform google search using this tool: {e}",
            }
        )


def _get_scraper_result(url: str) -> dict[str, Any]:
    scraper = scraper_api.ApiClient()
    status_code = scraper.load_url(url)
    if status_code != 200:
        return {
            "result": {
                "text_content": f"FAILED_TO_SCRAPE, error code: {status_code}. content: {scraper.get_raw()}",
                "links": [],
                "images": [],
                "url": url,
                "title": None,
                "description": None,
            },
        }

    return {
        "result": {
            "text_content": scraper.scrape_full_text(),
            "links": scraper.scrape_links(),
            "images": [],
            "url": url,
            "title": scraper.get_meta().get("title"),
            "description": scraper.get_meta().get("description"),
            "base_uri": scraper.get_base_uri(),
        },
    }


def _scraper(url: str) -> str:
    try:
        return json.dumps(_get_scraper_result(url))
    except Exception as e:
        return f"Failed to scrape using this tool: {e}"


# !!! this is for a poc, remove this later
def _scraper_no_text(url: str) -> str:
    try:
        response = _get_scraper_result(url)
        if has(response, "result.text_content"):
            delattr(response["result"], "text_content")
        if has(response, "result.links") and len(get(response, "result.links")) > 500:
            set_(response, "result.links", [])
            set_(response, "result.text_content", "Limit Exceeded")

        return json.dumps(response)
    except Exception as e:
        return f"Failed to scrape using this tool: {e}"


google_search_tool = StructuredTool.from_function(
    func=_google_search,
    name="Google Search",
    description="Search the web using Google, this returns the search results",
    args_schema=GoogleSearchInput,
    return_direct=False,
)

scraper_tool = StructuredTool.from_function(
    func=_scraper,
    name="Web Scraper",
    description="Scrape the content of a web page.",
    args_schema=ScraperInput,
    return_direct=False,
)

# !!! this is for a poc, remove this later
scraper_no_text_tool = StructuredTool.from_function(
    func=_scraper_no_text,
    name="Web Scraper",
    description="Scrape the content of a web page.",
    args_schema=ScraperInput,
    return_direct=False,
)
