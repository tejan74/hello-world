from action.agents._llm import LLMInput
from action.base import BaseAction
from action.types import ActionResponse, ActionUsage, BaseActionInput, BaseActionOutput
from pydantic import model_validator, ConfigDict
from typing import Literal, Any
import pydantic
import os
import config
from langchain_openai import ChatOpenAI
from langchain import hub
from langchain import agents
from langchain_core.language_models import BaseLanguageModel
from langchain_core.tools import BaseTool
from util.logger import interstellar_logger
from lib.selenium.playwright_chromium import PlaywrightOrbBrowser
from action.agents._playwright_toolkit import PlaywrightBrowserToolkit
from langchain_core.tools import BaseTool, render_text_description_and_args


logger = interstellar_logger(__name__)


class BrowserAgentInput(BaseActionInput):
    input: str
    llm: LLMInput
    # hardcoding tools for now
    tools: pydantic.json_schema.SkipJsonSchema[list[dict[str, Any]]] = [
        {"type": "TavilySearch"},
        {"type": "GoogleSearch"},
        {"type": "Scraper"},
    ]
    tags: list[str] = pydantic.Field(
        # TODO (ankith): add table uuid magic variable
        default=[]
    )
    max_iterations: int = pydantic.Field(default=15, ge=1, le=20)


class BrowserAgentOutput(BaseActionOutput):
    input: str
    output: str


class BrowserAgent:
    def __init__(
        self,
        llm_input: LLMInput,
        tags: list[str] = [],
        max_iterations: int = 15,
    ):
        os.environ["LANGCHAIN_API_KEY"] = config.safe_get_parameter(
            "LANGCHAIN_API_KEY", ""
        )
        os.environ["LANGCHAIN_TRACING_V2"] = config.safe_get_parameter(
            "LANGCHAIN_TRACING_V2", "false"
        )

        # Needs LANGCHAIN_API_KEY and LANGCHAIN_TRACING_V2="true" to be set to track the agent in https://smith.langchain.com/ (This is cool)
        self.llm_input = llm_input
        # ref: https://www.promptingguide.ai/techniques/react
        self.prompt = hub.pull("hwchase17/react")
        self.llm = self._create_llm()
        self.tools = self._create_tools()
        self.agent = self._create_agent()
        self.agent_executor = agents.AgentExecutor(agent=self.agent, tools=self.tools, tags=tags, max_iterations=max_iterations, verbose=True)  # type: ignore

    def _create_llm(self) -> BaseLanguageModel:
        if self.llm_input.llm == "OpenAI":
            api_key = config.get_parameter("OPENAI_API_KEY")
            return ChatOpenAI(
                model=self.llm_input.model,
                api_key=api_key,  # type: ignore
            )
        else:
            raise ValueError("Unsupported LLM type")

    def _create_tools(self) -> list[BaseTool]:
        orb_browser = PlaywrightOrbBrowser()
        toolkit = PlaywrightBrowserToolkit.from_browser(orb_browser=orb_browser)
        return toolkit.get_tools()

    def _create_agent(self):
        return agents.create_react_agent(
            self.llm,
            self.tools,
            self.prompt,
            tools_renderer=render_text_description_and_args,
        )

    def run(self, input: str) -> dict[str, Any]:
        return self.agent_executor.invoke({"input": input}, verbose=True)


class BrowserAgentActon(BaseAction[BrowserAgentInput, BrowserAgentOutput]):
    id = "57a0fcab-87ed-4fdc-8791-2bd369e0dfdd"
    name = "Browser OrbAI"
    description = "AI Browser Agent"
    icon = "https://framerusercontent.com/images/SVnOX35aSSWgPEKYAhutlTOu9NI.png"
    default_output_path = "result.output"
    input_schema = BrowserAgentInput
    output_schema = BrowserAgentOutput
    usage = ActionUsage(units=1, unit_type="token")
    tags = ["Agents"]

    def _run(self, input: BrowserAgentInput) -> ActionResponse[BrowserAgentOutput]:
        try:
            logger.info("Running OrbAgent", extra={"input": input})
            agent = BrowserAgent(
                input.llm,
                tags=input.tags,
                max_iterations=input.max_iterations,
            )
            input_string = f"""
                You are browser agent that can interact with web pages.
                Make sure to read the page first and use proper css selectors using ids or classes instead of attributes.
                If don't know where to start, start with google search.
                You have all the tools needed for you.
                Give proper inputs to the tools, don't include any unnecessary information in the input.

                {input.input}
            """
            output = agent.run(input_string)
            if "output" not in output:
                return ActionResponse(
                    result=BrowserAgentOutput(
                        input=input.input, output="ERROR: No output"
                    )
                )
            return ActionResponse(
                result=BrowserAgentOutput(input=input.input, output=output["output"])
            )
        except Exception as e:
            logger.exception("Error running OrbAgent", extra={"input": input})
            return ActionResponse(
                result=BrowserAgentOutput(
                    input=input.input, output="ERROR: running OrbAgent"
                ),
            )
