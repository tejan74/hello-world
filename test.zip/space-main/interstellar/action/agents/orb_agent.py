from action.agents._llm import LLMInput
from action.base import BaseAction
from action.types import ActionResponse, ActionUsage, BaseActionInput, BaseActionOutput
from pydantic import BaseModel, model_validator, ConfigDict
from typing import Literal, Any
import pydantic
import os
import config
from langchain_openai import ChatOpenAI
from langchain import hub
from langchain import agents
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.language_models import BaseLanguageModel
from langchain_core.tools import BaseTool
from langchain_mistralai import ChatMistralAI
from langchain_anthropic import ChatAnthropic
from util.logger import interstellar_logger
from action.agents._tools import google_search_tool, scraper_tool

logger = interstellar_logger(__name__)


class OrbAgentInput(BaseActionInput):
    input: str
    llm: LLMInput
    # hardcoding tools for now
    tools: pydantic.json_schema.SkipJsonSchema[list[dict[str, Any]]] = [
        {"type": "TavilySearch"},
        {"type": "GoogleSearch"},
        {"type": "Scraper"},
    ]
    tags: list[str] = pydantic.Field(
        # TODO (ankith): add table uuid magic variable
        default=[]
    )
    max_iterations: int = pydantic.Field(default=15, ge=1, le=20)


class OrbAgentOutput(BaseActionOutput):
    input: str
    output: str


class LangChainAgent:
    def __init__(
        self,
        llm_input: LLMInput,
        tools_input: list[dict[str, Any]] = [],
        tags: list[str] = [],
        max_iterations: int = 15,
    ):
        # Not able to inject the API key from the Tavily constructor
        os.environ["TAVILY_API_KEY"] = config.safe_get_parameter("TAVILY_API_KEY", "")
        os.environ["LANGCHAIN_API_KEY"] = config.safe_get_parameter(
            "LANGCHAIN_API_KEY", ""
        )
        os.environ["LANGCHAIN_TRACING_V2"] = config.safe_get_parameter(
            "LANGCHAIN_TRACING_V2", "false"
        )

        # Needs LANGCHAIN_API_KEY and LANGCHAIN_TRACING_V2="true" to be set to track the agent in https://smith.langchain.com/ (This is cool)
        self.llm_input = llm_input
        self.tools_input = tools_input
        # ref: https://www.promptingguide.ai/techniques/react
        self.prompt = hub.pull("hwchase17/react")
        self.llm = self._create_llm()
        self.tools = self._create_tools()
        self.agent = self._create_agent()
        self.agent_executor = agents.AgentExecutor(agent=self.agent, tools=self.tools, tags=tags, max_iterations=max_iterations)  # type: ignore

    def _create_llm(self) -> BaseLanguageModel:
        if self.llm_input.llm == "OpenAI":
            api_key = config.get_parameter("OPENAI_API_KEY")
            return ChatOpenAI(
                model=self.llm_input.model,
                api_key=api_key,  # type: ignore
            )
        elif self.llm_input.llm == "MistralAI":
            # Needs MISTRALAI_API_KEY to be set
            api_key = config.get_parameter("MISTRALAI_API_KEY")
            return ChatMistralAI(model=self.llm_input.model, api_key=api_key)  # type: ignore
        elif self.llm_input.llm == "Anthropic":
            # Needs ANTHROPIC_API_KEY to be set
            api_key = config.get_parameter("ANTHROPIC_API_KEY")
            return ChatAnthropic(model_name=self.llm_input.model, timeout=60, api_key=api_key)  # type: ignore
        else:
            raise ValueError("Unsupported LLM type")

    def _create_tools(self) -> list[BaseTool]:
        tools = []
        for config in self.tools_input:
            tool_type = config.get("type")
            if tool_type == "TavilySearch":
                config.pop("type")
                # ref: https://tavily.com/
                # Needs TAVILY_API_KEY to be set
                tools.append(TavilySearchResults(**config))
            elif tool_type == "GoogleSearch":
                tools.append(google_search_tool)
            elif tool_type == "Scraper":
                tools.append(scraper_tool)
            else:
                # TODO: Add more tools here
                raise ValueError(f"Unsupported tool type: {tool_type}")
        return tools

    def _create_agent(self):
        return agents.create_react_agent(self.llm, self.tools, self.prompt)

    def run(self, input: str) -> dict[str, Any]:
        return self.agent_executor.invoke({"input": input})


class OrbAgentAction(BaseAction[OrbAgentInput, OrbAgentOutput]):
    id = "74592751-d1d6-4960-8685-296e088cbae9"
    name = "OrbAI"
    description = "AI Agent"
    icon = "https://framerusercontent.com/images/SVnOX35aSSWgPEKYAhutlTOu9NI.png"
    default_output_path = "result.output"
    input_schema = OrbAgentInput
    output_schema = OrbAgentOutput
    usage = ActionUsage(units=1, unit_type="token")
    tags = ["Agents"]

    def _run(self, input: OrbAgentInput) -> ActionResponse[OrbAgentOutput]:
        try:
            logger.info("Running OrbAgent", extra={"input": input})
            agent = LangChainAgent(
                input.llm,
                input.tools,
                tags=input.tags,
                max_iterations=input.max_iterations,
            )
            output = agent.run(input.input)
            if "output" not in output:
                return ActionResponse(
                    result=OrbAgentOutput(input=input.input, output="ERROR: No output")
                )
            return ActionResponse(
                result=OrbAgentOutput(input=input.input, output=output["output"])
            )
        except Exception as e:
            logger.exception("Error running OrbAgent", extra={"input": input})
            return ActionResponse(
                result=OrbAgentOutput(
                    input=input.input, output="ERROR: running OrbAgent"
                ),
            )
