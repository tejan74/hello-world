from action.agents._llm import LLMInput
from action.agents.orb_agent import LangChainAgent
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from pydantic import BaseModel, model_validator, ConfigDict
from typing import Literal, Any
import pydantic
import os
import config
from langchain_openai import ChatOpenAI
from langchain import hub
from langchain import agents
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.language_models import BaseLanguageModel
from langchain_core.tools import BaseTool
from langchain_mistralai import ChatMistralAI
from langchain_anthropic import ChatAnthropic
from util.logger import interstellar_logger
from action.agents._tools import google_search_tool, scraper_tool, scraper_no_text_tool

logger = interstellar_logger(__name__)


class OrbAgentPocInput(BaseActionInput):
    input: str
    llm: LLMInput
    # hardcoding tools for now
    tools: pydantic.json_schema.SkipJsonSchema[list[dict[str, Any]]] = [
        {"type": "TavilySearch"},
        {"type": "GoogleSearch"},
        {"type": "Scraper"},
    ]
    tags: list[str] = pydantic.Field(
        # TODO (ankith): add table uuid magic variable
        default=[]
    )
    max_iterations: int = pydantic.Field(default=15, ge=1, le=20)


class OrbAgentPocOutput(BaseActionOutput):
    input: str
    output: str


class LangChainAgentPoc(LangChainAgent):

    def _create_tools(self) -> list[BaseTool]:
        tools = super()._create_tools()
        index = tools.index(scraper_tool)
        tools[index] = scraper_no_text_tool
        return tools


class OrbAgentAction(BaseAction[OrbAgentPocInput, OrbAgentPocOutput]):
    id = "991fd96d-3451-4562-98e2-2d050e5d0b53"
    name = "OrbAI POC"
    description = "AI Agent for a poc dont use this"
    icon = "https://framerusercontent.com/images/SVnOX35aSSWgPEKYAhutlTOu9NI.png"
    default_output_path = "result.output"
    input_schema = OrbAgentPocInput
    output_schema = OrbAgentPocOutput
    usage = ActionUsage(units=1, unit_type="token")
    tags = ["Agents"]

    def _run(self, input: OrbAgentPocInput) -> ActionResponse[OrbAgentPocOutput]:
        try:
            logger.info("Running OrbAgent", extra={"input": input})
            agent = LangChainAgentPoc(
                input.llm,
                input.tools,
                tags=input.tags,
                max_iterations=input.max_iterations,
            )
            output = agent.run(input.input)
            if "output" not in output:
                return ActionResponse(
                    error=ActionError(
                        code="NO_OUTPUT", message="No output from Agent", e=None
                    )
                )
            return ActionResponse(
                result=OrbAgentPocOutput(input=input.input, output=output["output"])
            )
        except Exception as e:
            logger.exception("Error running OrbAgent", extra={"input": input})
            return ActionResponse(
                error=ActionError(code="ERROR", message="Error running OrbAgent", e=e)
            )
