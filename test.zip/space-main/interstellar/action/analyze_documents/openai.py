from mimetypes import MimeTypes
import os
import re
from typing import Annotated, Any
import uuid
import pydantic
import pydash
import requests
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionError, ActionResponse, ActionUsage
import config
from lib import open_ai, scraper_api
from util.http import get_redirect_url_from_html
from util.files import DEFAULT_USER_AGENT, delete_file
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


DEFAULT_SYSTEM_INSTRUCTION = "Answer questions based on the document / file you have. Do not return answers that is not mentioned in the document / file. If you don't find an answer in the document / file return NA"

DEFAULT_CLEANUP_PROMPT = "Cleanup the message user sends. Don't include any other text just return the cleaned up text. Also remove anything that is like: '[10+ sources]'"

SUPPORTED_FILE_TYPES = [
    ".html",
    ".pdf",
    ".txt",
    ".doc",
    ".docx",
    ".docm",
    ".dotx",
    ".dotm",
    ".xls",
    ".xlsx",
    ".xlsm",
    ".xltx",
    ".xltm",
    ".xlam",
    ".xlsb",
    ".ppt",
    ".pptx",
    ".pptm",
    ".potx",
    ".potm",
    ".ppsx",
    ".ppsm",
    ".odt",
    ".ods",
    ".odp",
    ".bin",
]


class FileObject(pydantic.BaseModel):
    url: str
    headers: Annotated[
        dict[str, Any],
        pydantic.WithJsonSchema({"additionalProperties": True, "type": "object"}),
    ]
    timeout: int | None = None
    has_browser_based_redirection: bool = False


class OpenAiDocumentSearchInput(BaseActionInput):
    model: open_ai.SupportedModel = "gpt-4o"
    queries: list[str]
    files: list[FileObject]
    number_of_chunks: int | None = None


class LLMUsage(pydantic.BaseModel):
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None


class Message(pydantic.BaseModel):
    id: str
    query: str
    response_value: str | None = None
    response_source: str | None = None
    usage: LLMUsage | None = None


class OpenAiDocumentSearchOutput(BaseActionOutput):
    messages: list[Message]


class OpenAiDocumentSearchAction(
    BaseAction[OpenAiDocumentSearchInput, OpenAiDocumentSearchOutput]
):
    id = "d0fa8218-d3e8-4795-aeff-b6b674d53284"
    name = "Data Research"
    description = "Research data from given sources ** Keep the number of files and questions to a minimum to avoid timeout **"
    icon = "https://openai.com/favicon.ico"
    default_output_path = "result.messages.0.response_value"
    input_schema = OpenAiDocumentSearchInput
    output_schema = OpenAiDocumentSearchOutput
    usage = ActionUsage(units=1, unit_type="token")
    tags = ["Documents"]

    # Setup empty assistant
    assistant = None
    assistant_id = None
    file_ids: list[str] = []
    downloaded_files: list[str] = []

    def _run(
        self, input: OpenAiDocumentSearchInput
    ) -> ActionResponse[OpenAiDocumentSearchOutput]:
        # Setup OpenAPI client
        self.model = input.model
        self.api_client = open_ai.ApiClient(model=self.model)

        try:
            # Add files to assistant
            try:
                self._download_files(input.files)
            except Exception as e:
                return self._delete_and_error(
                    code="DOWNLOAD_FAILED",
                    message=f"Failed to download file! Error = {e}",
                )

            for d_file in self.downloaded_files:
                if os.path.exists(d_file):
                    created_file = self.api_client.create_file(d_file)
                    if (not created_file) or not (created_file.id):
                        return self._delete_and_error(
                            code="FILE_CREATION_FAILED",
                            message="Failed to create file",
                        )
                    self.file_ids.append(created_file.id)

            # Setup
            assistant_id = self._create_assistant(input.model, input.number_of_chunks)
            if not assistant_id:
                return ActionResponse(
                    error=ActionError(
                        code="CREATE_FAILED", message="Failed to create assistant"
                    )
                )

            formatted_messages: list[Message] = []

            # Check if assistant is setup
            if not self.assistant or not self.assistant_id:
                return self._delete_and_error(
                    code="ASSISTANT_MISSING",
                    message="Assistant not setup! Please run 'create' method first.",
                )

            # Create thread
            thread = self.api_client.create_thread()
            if (not thread) or (not thread.id):
                return self._delete_and_error(
                    code="THREAD_CREATION_FAILED",
                    message="Failed to create thread",
                )

            # Add question to thread
            for query in input.queries:
                try:
                    msg = self.api_client.create_message(
                        thread.id,
                        query,
                        [
                            {"file_id": f, "tools": [{"type": "file_search"}]}
                            for f in self.file_ids
                        ],
                    )
                    if not msg.id:
                        return self._delete_and_error(
                            code="MESSAGE_CREATION_FAILED",
                            message="Failed to create message",
                        )

                    # Run assistant
                    run = self.api_client.run_thread_and_poll(
                        thread.id, self.assistant_id
                    )
                    if (not run) or (not run.id):
                        # TODO: Revisit this to decide if we run other questions if one fails
                        return self._delete_and_error(
                            code="ASSISTANT_RUN_FAILED",
                            message="Failed to run assistant",
                        )
                    if run.status != "completed":
                        return self._delete_and_error(
                            code="ASSISTANT_RUN_INCOMPLETE",
                            message="Failed to complete assistant run",
                        )

                    # Fetch messages
                    messages = self.api_client.list_messages(thread.id)
                    if (
                        (not messages)
                        or (not messages.data)
                        or (len(messages.data) == 0)
                        or (not messages.data[0].content)
                    ):
                        return self._delete_and_error(
                            code="EMPTY_OUTPUT", message="Failed to retrieve message"
                        )

                    # Extract query response into format
                    # TODO: Build a class for this response object
                    formatted_messages.append(
                        Message(
                            id=str(uuid.uuid4()),
                            query=query,
                            response_value=re.sub(
                                r"【[^【】]*】",
                                "",
                                pydash.get(
                                    messages, "data[0].content[0].text.value", ""
                                )
                                or "",
                            ),
                            response_source=re.sub(
                                r"【[^【】]*】",
                                "",
                                pydash.get(
                                    messages,
                                    "data[0].content[0].text.annotations[0].file_citation.quote",
                                    "",
                                )
                                or "",
                            ),
                            usage=LLMUsage(
                                prompt_tokens=pydash.get(
                                    run, "usage.prompt_tokens", None
                                ),
                                completion_tokens=pydash.get(
                                    run, "usage.completion_tokens", None
                                ),
                                total_tokens=pydash.get(
                                    run, "usage.total_tokens", None
                                ),
                            ),
                        )
                    )
                except Exception as e:
                    return self._delete_and_error(
                        code="SOMETHING_WENT_WRONG", message=f"{e}"
                    )

            # Delete thread
            self.api_client.delete_thread(thread.id)

            # Destroy
            self._destroy()

            # Delete files
            self._delete_files()

            # Return messages
            return ActionResponse(
                result=OpenAiDocumentSearchOutput(messages=formatted_messages)
            )
        except Exception as e:
            return self._delete_and_error(code="SOMETHING_WENT_WRONG", message=f"{e}")

    def _make_request(
        self, url: str, headers: dict[str, Any], timeout: int | None = None
    ):
        headers = headers
        keys = [x.lower().strip() for x in list(headers.keys())]
        if "user-agent" not in keys:
            headers["User-Agent"] = DEFAULT_USER_AGENT

        response = requests.get(
            url=url,
            headers=headers,
            timeout=timeout or 300,
            allow_redirects=True,
        )

        return response

    # Download files for assistant
    def _download_files(self, files: list[FileObject]):
        for file in files:
            url = file.url.strip()
            if not url.startswith("http"):
                url = "https://" + url
            response = self._make_request(url, file.headers, file.timeout)
            if response.status_code == 200:
                if file.has_browser_based_redirection:
                    redirected_url = get_redirect_url_from_html(response.content)
                    if redirected_url:
                        response = self._make_request(
                            redirected_url, file.headers, file.timeout
                        )
                    else:
                        raise Exception(f"Failed to find redirect url in {file.url}")
                content_type = (
                    pydash.get(response.headers, "Content-Type", "")
                    .strip()
                    .split(";")[0]
                    .strip()
                )
                file_type = MimeTypes().guess_extension(content_type)
                if file_type not in SUPPORTED_FILE_TYPES:
                    raise Exception(f"Unsupported content type: {content_type}")
                file_name = f"{str(uuid.uuid4())}"
                if file_type == ".html":
                    result = None
                    try:
                        scraper = scraper_api.ApiClient()
                        status_code = scraper.load_url(url, file.headers)
                        if status_code != 200:
                            raise Exception(f"Failed to scrape url: {file.url}")
                        else:
                            result = {
                                "text_content": scraper.scrape_full_text(),
                                "title": scraper.get_meta().get("title"),
                                "description": scraper.get_meta().get("description"),
                                "url": file.url,
                                "links": scraper.scrape_links(),
                            }

                    except Exception as e:
                        logger.exception(e)
                        result = None

                    if result:
                        file_name_with_extension = f"{file_name}.txt"
                        with open(file_name_with_extension, "a", newline="\n") as f:
                            if result["title"]:
                                f.write(pydash.clean(result["title"]) + "\n")
                            f.write(pydash.clean(result["url"]) + "\n")
                            if result["description"]:
                                f.write(pydash.clean(result["description"]) + "\n")
                            f.write(pydash.clean(result["text_content"]) + "\n")
                            for link in result["links"]:
                                if link["text"]:
                                    f.write(pydash.clean(link["text"]) + " ")
                                if link["link"]:
                                    f.write(pydash.clean(link["link"]) + "\n")
                        self.downloaded_files.append(file_name_with_extension)
                    else:
                        raise Exception(f"Failed to scrape url: {file.url}")
                else:
                    file_name_with_extension = (
                        config.get_tmp_dir() + "/" + file_name + file_type
                    )
                    with open(file_name_with_extension, "wb") as f:
                        f.write(response.content)
                    self.downloaded_files.append(file_name_with_extension)
            else:
                raise Exception(
                    f"Failed to fetch url: {file.url}. Response Code = {response.status_code}"
                )

    # Create the assistant
    def _create_assistant(
        self,
        model: open_ai.SupportedModel | None = None,
        number_of_chunks: int | None = None,
    ):
        # Create assistant
        assistant = self.api_client.create_assistant(
            name="Document Search Assistant",
            instructions=DEFAULT_SYSTEM_INSTRUCTION,
            model=model,
            max_num_results=number_of_chunks,
        )
        if (not assistant) or (not assistant.id):
            return None

        # Set assistant and return ID
        self.assistant = assistant
        self.assistant_id = assistant.id
        return self.assistant_id

    def _destroy(self):
        # Delete files
        if self.file_ids:
            for file_id in self.file_ids:
                self.api_client.delete_file(file_id)

        # Delete assistant
        if self.assistant_id:
            self.api_client.delete_assistant(self.assistant_id)

        # Reset assistant
        self.assistant = None
        self.assistant_id = None
        self.file_ids = []

    def _delete_files(self):
        # Delete files from local
        for file in self.downloaded_files:
            if os.path.exists(file):
                delete_file(file)

        self.downloaded_files = []

    def _delete_and_error(self, code: str, message: str):
        self._delete_files()
        self._destroy()

        return ActionResponse(
            error=ActionError(
                code=code,
                message=message,
            )
        )
