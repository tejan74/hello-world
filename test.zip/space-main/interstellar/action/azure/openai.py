import json
from typing import Literal
import pydantic
from pydash import get
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
import config
from lib import open_ai
from util.logger import interstellar_logger
from prisma import Prisma

logger = interstellar_logger(__name__)

INTEGRATION_TYPE = "azure_openai"


class AzureOpenAiInput(BaseActionInput):
    integration_uuid: str = pydantic.Field(
        title="Integration",
        json_schema_extra={
            "format": "IntegrationSelect",
            "integrationType": INTEGRATION_TYPE,
        },
    )
    query: str
    output_format: Literal["text", "json_object"] = "text"
    temperature: float | None = None
    max_tokens: int | None = None


class LLMUsage(pydantic.BaseModel):
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None


class AzureOpenAiOutput(BaseActionOutput):
    message: str | dict | None
    usage: LLMUsage | None


class AzureOpenAiAction(BaseAction[AzureOpenAiInput, AzureOpenAiOutput]):
    id = "azure-openai-action"
    name = "Azure OpenAI"
    description = "Azure OpenAI LLM"
    icon = "https://portal.azure.com/Content/favicon.ico"
    default_output_path = "result.message"
    input_schema = AzureOpenAiInput
    output_schema = AzureOpenAiOutput
    tags = ["AI"]

    def _run(self, input: AzureOpenAiInput) -> ActionResponse[AzureOpenAiOutput]:

        with Prisma(datasource={"url": config.get_parameter("DATABASE_URL")}) as prisma:
            integration = self._get_integration_data(prisma, input.integration_uuid)

            if not integration:
                return ActionResponse(
                    error=ActionError(
                        code="INTEGRATION_NOT_FOUND",
                        message="Integration not found",
                    )
                )

            self.client = open_ai.AzureOpenAIClient(
                endpoint_url=integration.get("endpoint"),
                key=integration.get("key"),
                deployment=integration.get("deployment_name"),
            )

            try:
                response = self.client.azure_completion(
                    query=input.query,
                    temperature=(
                        input.temperature if input.temperature is not None else 0.75
                    ),
                    max_tokens=(
                        input.max_tokens if input.max_tokens is not None else 300
                    ),
                )
                choice = response.choices[0] if len(response.choices) > 0 else None
                if choice is None:
                    return ActionResponse(
                        error=ActionError(
                            code="EMPTY_OUTPUT", message="No choice received."
                        )
                    )

                message = choice.message.content
                if message is None:
                    return ActionResponse(
                        error=ActionError(
                            code="EMPTY_OUTPUT", message="No message received"
                        )
                    )

                # Extract JSON from the response for an extra layer of protection
                # this only works with json_object, not json_array.
                # openai API only supports json_object
                # TODO: lets do this for other providers as well
                if input.output_format == "json_object":
                    if "{" not in message or "}" not in message:
                        logger.error(
                            "No JSON found in response", extra={"query": input.query}
                        )
                    else:
                        message = message[message.index("{") : message.rindex("}") + 1]
                        try:
                            message = json.loads(message)
                        except Exception as e:
                            logger.error(
                                "Error while parsing JSON", extra={"query": input.query}
                            )

                logger.info(
                    "Usage: ", extra={"query": input.query, "usage": response.usage}
                )
                return ActionResponse(
                    result=AzureOpenAiOutput(
                        message=response.choices[0].message.content,
                        usage=LLMUsage(
                            prompt_tokens=get(response, "usage.prompt_tokens", None),
                            completion_tokens=get(
                                response, "usage.completion_tokens", None
                            ),
                            total_tokens=get(response, "usage.total_tokens", None),
                        ),
                    ),
                    usage=ActionUsage(
                        units=get(response, "usage.total_tokens", None),
                        unit_type="token",
                        extra_data={
                            "prompt_tokens": get(response, "usage.prompt_tokens", None),
                            "completion_tokens": get(
                                response, "usage.completion_tokens", None
                            ),
                            "total_tokens": get(response, "usage.total_tokens", None),
                        },
                    ),
                )
            except Exception as e:
                return ActionResponse(
                    error=ActionError(code="EMPTY_OUTPUT", message=str(e))
                )

    # Get integration data from prisma using the integration_uuid and the integration type
    def _get_integration_data(self, prisma: Prisma, integration_uuid: str):
        integration = prisma.tenantintegration.find_first(
            where={"uuid": integration_uuid, "integration": INTEGRATION_TYPE},
        )
        if integration:
            integration_data = integration.data
            return json.loads(json.dumps(integration_data))
        return None
