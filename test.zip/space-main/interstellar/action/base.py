import abc
from typing import Any, Generic, Type

from action.types import (
    BaseActionInput,
    IsBaseActionInput,
    IsBaseActionOutput,
    ActionError,
    ActionResponse,
    ActionResumeState,
    ActionUsage,
    BaseActionOutput,
)
from util.logger import interstellar_logger


logger = interstellar_logger(__name__)


class BaseAction(abc.ABC, Generic[IsBaseActionInput, IsBaseActionOutput]):
    id: str
    """The unique id of the action."""
    name: str
    """The unique name of the action."""
    description: str
    """A short description of the action."""
    icon: str
    """The icon of the action."""
    default_output_path: str
    """The default output path of the action."""
    input_schema: Type[IsBaseActionInput]
    """The input schema of the action."""
    output_schema: Type[BaseActionOutput]
    """The output schema of the action."""
    usage: ActionUsage | None = None
    """The usage of the action."""
    tags: list[str] = []
    """The tags of the action."""
    provider: str | None = None
    """The provider of the action."""

    def __init__(self, run_id: str | None = None) -> None:
        self.run_id = run_id
        self.validate()

    def validate(self):
        if not hasattr(self, "name"):
            raise ValueError("name is required")
        if not hasattr(self, "description"):
            raise ValueError("description is required")
        if not hasattr(self, "default_output_path"):
            raise ValueError("default_output_path is required")
        if not hasattr(self, "input_schema"):
            raise ValueError("input_schema is required")
        if not hasattr(self, "output_schema"):
            raise ValueError("output_schema is required")

        return True

    @abc.abstractmethod
    def _run(self, input: IsBaseActionInput) -> ActionResponse[IsBaseActionOutput]:
        pass

    def _construct_response(
        self, response: ActionResponse[IsBaseActionOutput]
    ) -> tuple[
        BaseActionOutput | None,
        ActionError | None,
        ActionUsage | None,
        ActionResumeState | None,
    ]:
        usage = response.usage or self.usage

        if (not usage) and (not response.error):
            # TODO: Doing this on purpose to make sure that usage is always set and we find the issue when testing
            raise ValueError("Usage is required")

        return response.result, response.error, usage, None

    def run(self, input: Any) -> tuple[
        BaseActionOutput | None,
        ActionError | None,
        ActionUsage | None,
        ActionResumeState | None,
    ]:
        input_model = self.input_schema.model_validate(input)
        try:
            response = self._run(input=input_model)
            return self._construct_response(response)
        except Exception as e:
            logger.exception(
                "Error while executing the action", extra={"input data": input}
            )
            return self._construct_response(
                ActionResponse(
                    result=None,
                    error=ActionError(code="ERROR", message=str(e), e=e),
                    usage=None,
                )
            )
