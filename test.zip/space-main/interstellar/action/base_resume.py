import abc
from typing import Any, Generic, Literal, Type, get_args, override
from action.base import (
    BaseAction,
    BaseActionOutput,
)
from action.types import (
    IsPartialState,
    IsBaseActionInput,
    IsBaseActionOutput,
    ActionError,
    ActionResumeState,
    ActionUsage,
    ResumableActionResponse,
)

ResumeTriggerType = Literal["schedule", "webhook"]


class BaseResumableAction(
    BaseAction[IsBaseActionInput, IsBaseActionOutput],
    Generic[IsBaseActionInput, IsBaseActionOutput, IsPartialState],
):
    partial_state_schema: Type[IsPartialState]

    def get_webhook_url(self) -> str:
        return f"/action/{self.run_id}/webhook"

    @abc.abstractmethod
    def _run(
        self, input: IsBaseActionInput
    ) -> ResumableActionResponse[IsBaseActionOutput, IsPartialState]:
        pass

    @override
    # Ignore the type here to override the type of response to ResumableActionResponse
    def _construct_response(self, response: ResumableActionResponse):  # type: ignore
        (result, error, usage, _) = super()._construct_response(response)
        return result, error, usage, response.resume

    @abc.abstractmethod
    def _resume(
        self,
        type: ResumeTriggerType,
        input: IsBaseActionInput,
        state: IsPartialState,
        webhook_data: dict[str, Any] | None = None,
    ) -> ResumableActionResponse[IsBaseActionOutput, IsPartialState]:
        pass

    def resume(
        self,
        trigger_type: str,
        input: dict[str, Any],
        state: dict[str, Any] | None = None,
        webhook_data: dict[str, Any] | None = None,
    ) -> tuple[
        BaseActionOutput | None,
        ActionError | None,
        ActionUsage | None,
        ActionResumeState | None,
    ]:
        if trigger_type not in get_args(ResumeTriggerType):
            raise ValueError(f"Invalid resume type {trigger_type}")

        input_data = self.input_schema.model_validate(input)
        partial_state = self.partial_state_schema.model_validate(state)
        response = self._resume(trigger_type, input_data, partial_state, webhook_data)  # type: ignore

        return self._construct_response(response)
