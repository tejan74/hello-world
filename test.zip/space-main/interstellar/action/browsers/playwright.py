from typing import Any
import pydantic
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionError, ActionResponse, ActionUsage
from util.logger import interstellar_logger
from concurrent.futures import ThreadPoolExecutor
import json
import os
import time
import config
from asgi_correlation_id import correlation_id
from lib.selenium.playwright_chromium import PlaywrightOrbBrowser
from lib import google_cloud_storage


logger = interstellar_logger(__name__)


class PlaywrightBrowserInput(BaseActionInput):
    url: str
    wait_after_load: int | None = None
    get_content: bool = True
    parse_html: bool = True
    use_proxy: bool = False
    bypass_captcha: bool = False
    captcha_max_timeout: int | None = None
    scroll_screenshot: list[str] = []
    screenshot: bool = False
    screenshot_elements: list[str] = []
    resolution: str | None = "1366,768"
    zoom: int | None = 100
    auto_solve_captcha: bool = False
    # TODO @ankith: Doing this as json strings are converting to objects during mapping
    instructions: str | Any | None = None
    record_video: bool = False
    click_type: str | None = None
    upload_instructions_output: bool = False


class Link(pydantic.BaseModel):
    link: str | None = None
    text: str | None = None


class ScreenshotResult(pydantic.BaseModel):
    base64: str
    name: str


class PlaywrightBrowserOutput(BaseActionOutput):
    message: str | None = None
    content: str = ""
    links: list[Link]
    url: str
    script_execution_status: bool | None = False
    captcha_solved: bool | None = False
    screenshots: list[ScreenshotResult] = []
    instructions_output: list[dict[str, Any]] | None = []
    video_link: str | None = None


class PlaywrightBrowserAction(
    BaseAction[PlaywrightBrowserInput, PlaywrightBrowserOutput]
):
    id = "1e275d44-d38f-4d40-8c5c-5d5e1a158078"
    name = "Playwright Browser with Script Execution"
    description = "Playwright Browser with Script Execution"
    icon = "https://logo.clearbit.com/playwright.dev"
    default_output_path = "result.url"
    input_schema = PlaywrightBrowserInput
    output_schema = PlaywrightBrowserOutput
    usage = ActionUsage(units=0, unit_type="credit")
    tags = ["Web"]

    # TODO: Use async playwright
    def _run(
        self, input: PlaywrightBrowserInput
    ) -> ActionResponse[PlaywrightBrowserOutput]:
        request_id = correlation_id.get()
        with ThreadPoolExecutor() as executor:
            future = executor.submit(self._get, input, request_id=request_id)
            response = future.result()
            return response

    def _get(
        self, input: PlaywrightBrowserInput, request_id: str | None
    ) -> ActionResponse[PlaywrightBrowserOutput]:
        if request_id:
            correlation_id.set(request_id)

        status = "SUCCESS"
        scraper = None
        video_path = None
        try:
            scraper = PlaywrightOrbBrowser(
                use_proxy=input.use_proxy,
                use_captcha_solver=True,
                resolution=input.resolution,
                auto_captcha=input.auto_solve_captcha,
                record_video=input.record_video,
                click_type=input.click_type,
            )
            logger.info(f"Loading {input.url}")
            scraper.load_url(input.url)

            cloud_path = None
            if input.record_video:
                video_path = scraper.page.video.path() if scraper.page.video else None
                logger.info("Video path: " + str(video_path))

            if input.wait_after_load:
                logger.info(f"Waiting for {input.wait_after_load} seconds")
                time.sleep(input.wait_after_load)

            scraper.close_dialog_modals()

            if input.zoom:
                logger.info(f"Setting page zoom to {input.zoom}")
                scraper.execute_script(f"document.body.style.zoom = '{input.zoom}%'")

            captcha_solved = None
            if input.bypass_captcha:
                if not input.auto_solve_captcha:
                    logger.info("Checking for captcha")
                    try:
                        if scraper.has_captcha():
                            logger.info("Captcha found")
                            scraper.solve_captcha()
                            captcha_solved = scraper.wait_for_captcha(
                                input.captcha_max_timeout
                            )
                    except Exception as e:
                        logger.error(f"Error while solving captcha: {e}")
                        captcha_solved = False
                else:
                    time.sleep(input.captcha_max_timeout or 60)

            instructions_output = []
            try:
                if input.instructions and len(input.instructions) > 0:
                    logger.info("Parsing instructions")

                    instructions = input.instructions
                    if isinstance(input.instructions, str):
                        instructions = json.loads(input.instructions)

                    if len(instructions) > 0:
                        logger.info("Executing instructions")
                        instructions_output = scraper.execute_instructions(instructions)

                    if input.bypass_captcha and not captcha_solved:
                        if not input.auto_solve_captcha:
                            logger.info("Checking for captcha")
                            try:
                                if scraper.has_captcha():
                                    logger.info("Captcha found")
                                    scraper.solve_captcha()
                                    captcha_solved = scraper.wait_for_captcha(
                                        input.captcha_max_timeout
                                    )
                            except Exception as e:
                                logger.error(f"Error while solving captcha: {e}")
                                captcha_solved = False
                        else:
                            time.sleep(input.captcha_max_timeout or 60)
                else:
                    logger.info("No instructions provided")
            except Exception as e:
                logger.error(input.instructions)
                logger.error(f"Error while executing instructions: {e}")
                status = "FAILED_TO_EXECUTE_INSTRUCTIONS"

            content = ""
            links = []
            if input.get_content:
                content = (
                    scraper.scrape_full_text()
                    if input.parse_html
                    else scraper.get_raw()
                )

            screenshots = []
            if input.screenshot:
                screenshot_base64 = scraper.screenshot_as_base64()
                screenshots.append(
                    ScreenshotResult(
                        base64=screenshot_base64,
                        name="full_page",
                    )
                )

            if len(input.scroll_screenshot) > 0:
                logger.info("Taking screenshot")
                for scroll_screenshot in input.scroll_screenshot:
                    scraper.scroll_to_element_by_css_selector(scroll_screenshot)
                    screenshot_base64 = scraper.screenshot_as_base64()
                    screenshots.append(
                        ScreenshotResult(
                            base64=screenshot_base64,
                            name=scroll_screenshot,
                        )
                    )

            if input.screenshot_elements:
                logger.info("Taking screenshot of elements")
                for screenshot_element in input.screenshot_elements:
                    screenshot_base64 = scraper.get_element_screenshot(
                        css_selector=screenshot_element
                    )

                    if screenshot_base64:
                        screenshots.append(
                            ScreenshotResult(
                                base64=screenshot_base64,
                                name=screenshot_element,
                            )
                        )

            scraper.close()
            if input.record_video:
                cloud_path = self._upload_file(video_path, "playwright")

            if input.upload_instructions_output:
                try:
                    # write instructions_output to a file
                    local_file = "instructions_output.json"
                    with open(local_file, "w") as f:
                        f.write("\n".join(instructions_output))

                    instruction_path = self._upload_file(
                        local_file, "playwright_instructions"
                    )

                    os.remove(local_file)

                    instructions_output = [
                        {
                            "link": instruction_path,
                        }
                    ]
                except Exception as e:
                    logger.error(f"Error while uploading instructions: {e}")

            return ActionResponse(
                result=PlaywrightBrowserOutput(
                    message=status,
                    content=content,
                    links=links,
                    url=input.url,
                    script_execution_status=None,
                    captcha_solved=captcha_solved,
                    screenshots=screenshots,
                    instructions_output=instructions_output,
                    video_link=cloud_path,
                )
            )
        except Exception as e:
            return ActionResponse(
                error=ActionError(
                    code="SCRAPER_ERROR", message="Error while scraping", e=e
                )
            )
        finally:
            if scraper and not scraper.page.is_closed():
                scraper.close()
            logger.info("Browser closed")

    def _upload_file(self, video_path, folder):
        cloud_path = None
        try:
            if video_path:
                logger.info("Uploading file")
                video_path_str = str(video_path)
                bucket = config.safe_get_parameter(
                    "ORBITAL_GOOGLE_CLOUD_STORAGE_BUCKET", "orbital-dev"
                )
                bucket_path = f"{folder}/{video_path_str.split('/')[-1]}"
                bucket_path = google_cloud_storage.ApiClient(bucket).upload_file(
                    bucket_path, video_path_str
                )

                cloud_path = f"https://storage.cloud.google.com/{bucket}/{bucket_path}"
                logger.info(f"file uploaded to {cloud_path}")
        except Exception as e:
            logger.error(f"Error while uploading video: {e}")
        finally:
            try:
                if video_path:
                    logger.info("Deleting video")
                    os.remove(video_path)
            except Exception as e:
                logger.error(f"Error while deleting video: {e}")
        return cloud_path
