from typing import Annotated, Any

import pydantic
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib.code_executor.python.executor import PythonExecutor


class PythonCodeInput(BaseActionInput):
    code: Annotated[
        str, pydantic.WithJsonSchema({"format": "code-editor", "type": "string"})
    ]
    input: Annotated[
        dict[str, Any],
        pydantic.WithJsonSchema({"additionalProperties": True, "type": "object"}),
    ]


class PythonCodeOutput(BaseActionOutput):
    # TODO: Add more datatypes here or support custom return types
    output: str | dict[str, Any] | list[Any] | None


class PythonCodeAction(BaseAction[PythonCodeInput, PythonCodeOutput]):
    id = "67c46b8d-cab7-41ca-bc72-f4cbf7ab666f"
    name = "Custom Python code"
    description = "Execute custom Python code"
    icon = "https://www.python.org/static/favicon.ico"
    default_output_path = "result.output"
    input_schema = PythonCodeInput
    output_schema = PythonCodeOutput
    usage = ActionUsage(units=0, unit_type="credit")
    tags = ["Custom"]

    def _run(self, input: PythonCodeInput) -> ActionResponse[PythonCodeOutput]:
        """
        Execute a Python script.
        """
        executor = PythonExecutor(
            builtins_module=self._get_safe_builtins(), globals_dict=input.input
        )
        try:
            output = executor.execute(input.code)
            return ActionResponse(result=PythonCodeOutput(output=output))
        except Exception as e:
            return ActionResponse(error=ActionError(code="ERROR", message=str(e), e=e))

    def _get_safe_builtins(self):
        """
        Get a safe set of builtins.
        """
        safe_builtins = {}

        def raise_error(msg: str):
            raise Exception(msg)

        for k in __builtins__:
            # Not allowing these builtins
            # This is not a final list, more builtins can be added when needed
            if k in ["__import__", "eval", "exec", "compile"]:
                safe_builtins[k] = lambda *a, **k: raise_error(
                    f"{k} statements are not allowed"
                )
            else:
                safe_builtins[k] = __builtins__[k]

            # add safe modules to builtins directly
            import math
            import json
            import pydash
            import requests
            import re

            safe_builtins["math"] = math
            safe_builtins["json"] = json
            safe_builtins["pydash"] = pydash
            safe_builtins["requests"] = requests
            safe_builtins["re"] = re

        return safe_builtins


class PythonCodeNoDependencyAction(PythonCodeAction):
    id = "0c480600-db39-40e4-a9a7-ec358b15db1a"
    name = "Custom Python code (no dependency check)"
    description = "Execute custom Python code with no dependency check"
