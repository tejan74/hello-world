import pydantic
import pydash
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import built_with


class GetCompanyUsingTechnologyBuiltWithInput(BaseActionInput):
    api_key: str | None = None
    technology: str
    company_count: int = 250
    country_code: str | None = None
    since: str | None = None
    historical_data: bool = False


class GetCompaniesFromTechnologiesResultItem(pydantic.BaseModel):
    domain: str | None = None
    detected_locations: list[str] | None = None
    monthly_technology_spend_usd: int | None = None
    sales_revenue: int | None = None
    social_followers: int | None = None
    employee_count: int | None = None
    company_name: str | None = None
    city: str | None = None
    postcode: str | None = None
    state: str | None = None
    country: str | None = None
    vertical: str | None = None
    telephones: list[str] | None = None
    emails: list[str] | None = None
    social: list[str] | None = None
    titles: list[str] | None = None


class GetCompanyUsingTechnologyBuiltWithOutput(BaseActionOutput):
    data: list[GetCompaniesFromTechnologiesResultItem] = []


class GetCompanyUsingTechnologyBuiltWithAction(
    BaseAction[
        GetCompanyUsingTechnologyBuiltWithInput,
        GetCompanyUsingTechnologyBuiltWithOutput,
    ]
):
    id = "6f297407-8339-4986-85f1-a8a2edcac2ec"
    name = "Company using Technology"
    description = "Get Companies using Technology"
    icon = "https://builtwith.com/favicon.ico"
    default_output_path = "result.data"
    input_schema = GetCompanyUsingTechnologyBuiltWithInput
    output_schema = GetCompanyUsingTechnologyBuiltWithOutput
    usage = ActionUsage(units=1, unit_type="credit")
    tags = ["Companies"]

    def _run(
        self, input: GetCompanyUsingTechnologyBuiltWithInput
    ) -> ActionResponse[GetCompanyUsingTechnologyBuiltWithOutput]:
        self.api_client = built_with.ApiClient(key=input.api_key)

        response = self.api_client.get_companies(
            input.technology, input.country_code, input.since, input.historical_data
        )
        error = pydash.get(response, "error", None)
        if error:
            return ActionResponse(error=ActionError(code="ERROR", message=error))

        result = pydash.get(response, "Results", None)
        offset = pydash.get(response, "NextOffset", None)

        if (not result) or (not isinstance(result, list)):
            return ActionResponse(
                result=GetCompanyUsingTechnologyBuiltWithOutput(data=[])
            )

        # built with will send a offset = "END" if there are no more results else it will send a offset string for the next call.
        while (offset and offset != "END") and (len(result) < input.company_count):
            response = self.api_client.get_companies(
                input.technology,
                input.country_code,
                input.since,
                input.historical_data,
                offset,
            )
            result.extend(pydash.get(response, "Results", []))
            offset = pydash.get(response, "NextOffset", None)

        return ActionResponse(
            result=GetCompanyUsingTechnologyBuiltWithOutput(
                data=[
                    GetCompaniesFromTechnologiesResultItem(
                        domain=pydash.get(x, "D"),
                        detected_locations=pydash.get(x, "LOS"),
                        monthly_technology_spend_usd=pydash.get(x, "S"),
                        sales_revenue=pydash.get(x, "R"),
                        social_followers=pydash.get(x, "F"),
                        employee_count=pydash.get(x, "E"),
                        company_name=pydash.get(x, "META.CompanyName"),
                        city=pydash.get(x, "META.City"),
                        postcode=pydash.get(x, "META.Postcode"),
                        state=pydash.get(x, "META.State"),
                        country=pydash.get(x, "META.Country"),
                        vertical=pydash.get(x, "META.Vertical"),
                        telephones=pydash.get(x, "META.Telephones"),
                        emails=pydash.get(x, "META.Emails"),
                        social=pydash.get(x, "META.Social"),
                        titles=pydash.get(x, "META.Titles"),
                    )
                    for x in result
                ]
            )
        )
