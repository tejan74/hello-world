from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.findymail import FindymailClient


class EnrichAllEmailsFromDomainInput(BaseActionInput):
    domain: str
    roles: list
    webhook_url: str | None = None
    api_key: str | None = None


class EnrichAllEmailsFromDomainOutput(BaseActionOutput):
    emails: list[str] | None


class EnrichAllEmailsFromDomainAction(
    BaseAction[EnrichAllEmailsFromDomainInput, EnrichAllEmailsFromDomainOutput]
):
    id = "findymail-enrich-all-valid-emails-with-domain"
    name = "Enrich All Valid Emails in a Domain with Findymail"
    description = "Enrich all valid email addresses within a domain using Findymail. Provide the domain and a list of roles to obtain a comprehensive set of enriched email addresses associated with that domain."
    icon = "https://www.findymail.com/images/favicon.ico"
    default_output_path = "result.emails"
    input_schema = EnrichAllEmailsFromDomainInput
    output_schema = EnrichAllEmailsFromDomainOutput
    usage_type = None
    tags = ["Companies"]

    def _run(
        self, input: EnrichAllEmailsFromDomainInput, **kwargs: Any
    ) -> ActionResponse[EnrichAllEmailsFromDomainOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("FINDYMAIL_API_KEY")
        )
        client = FindymailClient(api_key=self.api_key)
        response = client.search_domain(
            domain=input.domain, roles=input.roles, webhook_url=input.webhook_url
        )

        if response and response.contacts is not None and len(response.contacts) > 0:
            emails = list(
                filter(None, map(lambda contact: contact.email, response.contacts))
            )
            return ActionResponse(
                result=EnrichAllEmailsFromDomainOutput(emails=emails),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichAllEmailsFromDomainOutput(emails=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
