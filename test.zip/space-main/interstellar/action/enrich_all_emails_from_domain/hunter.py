from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.hunter import HunterClient
from lib.hunter.types import EmailType, SeniorityType


class EnrichAllEmailsFromDomainInput(BaseActionInput):
    domain: str
    company: str
    limit: int = 10
    offset: int = 0
    type: EmailType | None = None
    seniority: SeniorityType | None = None
    department: str | None = None
    required_field: str | None = None
    api_key: str | None = None


class EnrichAllEmailsFromDomainOutput(BaseActionOutput):
    emails: list[str] | None


class EnrichAllEmailsFromDomainAction(
    BaseAction[EnrichAllEmailsFromDomainInput, EnrichAllEmailsFromDomainOutput]
):
    id = "hunter-enrich-all-valid-emails-with-domain"
    name = "Enrich All Valid Emails in a Domain with Hunter.io"
    description = "Enrich email addresses using Hunter by providing the domain, company, and various optional parameters such as limit, offset, email type, seniority, department, and required field. This will help you retrieve and refine email addresses according to your specific criteria."
    icon = "https://hunter.io/assets/favicon/favicon-35c267ca9f2a39f1c9d7118c8533e74385d9e7a4fad1ced75fd51442ecfbceb2.ico"
    default_output_path = "result.emails"
    input_schema = EnrichAllEmailsFromDomainInput
    output_schema = EnrichAllEmailsFromDomainOutput
    usage_type = None
    tags = ["Companies"]

    def _run(
        self, input: EnrichAllEmailsFromDomainInput, **kwargs: Any
    ) -> ActionResponse[EnrichAllEmailsFromDomainOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("HUNTER_API_KEY")
        )
        client = HunterClient(api_key=self.api_key)
        output = client.domain_search(
            domain=input.domain,
            company=input.company,
            limit=input.limit,
            offset=input.offset,
            type=input.type,
            seniority=input.seniority,
            department=input.department,
            required_field=input.required_field,
        )

        if (
            output
            and output.data
            and output.data.emails is not None
            and len(output.data.emails) > 0
        ):
            emails = list(
                filter(None, map(lambda contact: contact.value, output.data.emails))
            )
            return ActionResponse(
                result=EnrichAllEmailsFromDomainOutput(emails=emails),
                usage=ActionUsage(
                    units=1,
                    unit_type="credit",
                    extra_data={
                        "credits": 0.1,
                        "multiplier": 10,
                    },
                ),
            )
        else:
            return ActionResponse(
                result=EnrichAllEmailsFromDomainOutput(emails=None),
                usage=ActionUsage(
                    units=0,
                    unit_type="credit",
                ),
            )
