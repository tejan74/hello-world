from typing import Any, Literal
from action.base import BaseActionInput, BaseActionOutput, BaseAction
from action.types import ActionResponse, ActionUsage
import config
from lib.prospeo import ProspeoClient


class EnrichAllEmailsFromDomainInput(BaseActionInput):
    company_domain: str
    limit: int = 50
    email_type: Literal["all", "professional", "generic"] = "all"
    company_enrichment: bool = False
    api_key: str | None = None


class EnrichAllEmailsFromDomainOutput(BaseActionOutput):
    emails: list[str] | None


class EnrichAllEmailsFromDomainAction(
    BaseAction[EnrichAllEmailsFromDomainInput, EnrichAllEmailsFromDomainOutput]
):
    id = "prospeo-enrich-all-valid-emails-with-domain"
    name = "Enrich All Valid Emails in a Domain with Prospeo"
    description = "Enrich email addresses using Prospeo by providing the company domain and optional parameters such as limit, email type, and company enrichment. This will help you obtain and refine email addresses tailored to your specified criteria."
    icon = "https://lh3.googleusercontent.com/ZnecyuZStWFBHS3436Db5_BMOYXh6_pmlaNUR7zzf-BfE26eLdnmMmGefsxS5EQBmKF6KUKVsUQjCqIZXfOxYFJPOg=s60"
    default_output_path = "result.emails"
    input_schema = EnrichAllEmailsFromDomainInput
    output_schema = EnrichAllEmailsFromDomainOutput
    usage_type = None
    tags = ["Companies"]

    def _run(
        self, input: EnrichAllEmailsFromDomainInput, **kwargs: Any
    ) -> ActionResponse[EnrichAllEmailsFromDomainOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("PROSPEO_API_KEY")
        )
        client = ProspeoClient(api_key=self.api_key)
        output = client.domain_search(
            company=input.company_domain,
            limit=input.limit,
            email_type=input.email_type,
            company_enrichment=input.company_enrichment,
        )

        if output and output.response and output.response["email_list"] is not None:
            email_list = output.response.get("email_list", [])
            emails = list(
                filter(
                    None,
                    map(lambda contact: contact.get("email"), email_list),
                )
            )
            return ActionResponse(
                result=EnrichAllEmailsFromDomainOutput(emails=emails),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichAllEmailsFromDomainOutput(emails=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
