from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.serp_api import SerpApiClient
from lib.serp_api.types import GetSearchResponse


class GoogleSearchBusinessInput(BaseActionInput):
    company_name: str | None = None
    company_address: str | None = None
    company_website: str | None = None
    api_key: str | None = None


class GoogleSearchBusinessOutput(BaseActionOutput):
    result: GetSearchResponse | None


"""
Each time you perform a search using one of SerpAPIs, exactly 1 credit is consumed,
regardless of the number of results returned in the response.
The exception to this is when you execute the exact same request 
with the exact same parameters again within one hour period. 
In this case the response is served from a cache, instead of performing a new live search,
and 1 search credit is not charged for this.
The behavior explained above could be changed by using the no_cache parameter in the request. 
This will force a new live search to be performed and 1 search credit to be deducted.
"""


class FindBusinessDetailsUsingGoogleSearchAction(
    BaseAction[GoogleSearchBusinessInput, GoogleSearchBusinessOutput]
):
    id = "serpapi_enrich_business_search_action"
    name = "Find Google Business"
    description = "Search results by leveraging google advanced search capabilities. This action helps you to refine and enhance search queries with a variety of parameters, including location, language, and specific filters. By integrating these options, you can achieve more accurate and tailored search results"
    icon = "https://serpapi.com/favicon-32x32.png"
    default_output_path = "result"
    input_schema = GoogleSearchBusinessInput
    output_schema = GoogleSearchBusinessOutput
    usage_type = None
    tags = ["Companies"]

    def _query_builder(self, input: GoogleSearchBusinessInput):
        only_comany_input = input.company_name and not (
            input.company_address or input.company_website
        )
        query_params = []
        if input.company_name:
            query_params.append(input.company_name)
        if input.company_address:
            query_params.append(input.company_address)
        if input.company_website:
            query_params.append(input.company_website)
        query = " ".join(query_params)
        query = query + (" places" if not only_comany_input else "")
        return query

    def _run(
        self, input: GoogleSearchBusinessInput, **kwargs: Any
    ) -> ActionResponse[GoogleSearchBusinessOutput]:
        self.api_key = input.api_key or config.get_parameter("SERP_API_KEY")
        client = SerpApiClient(api_key=self.api_key, provider="GoogleSearch")
        query = self._query_builder(input=input)
        response = client.search_google(query)

        if response is not None:
            return ActionResponse(
                result=GoogleSearchBusinessOutput(result=response),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=GoogleSearchBusinessOutput(result=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
