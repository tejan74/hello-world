from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import apollo

from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class ApolloCompanyEnrichInput(BaseActionInput):
    api_key: str | None = None
    domain: str


class ApolloCompanyEnrichOutput(BaseActionOutput):
    name: str
    domain: str
    website: str
    blog: str | None = None
    linkedin: str | None = None
    twitter: str | None = None
    facebook: str | None = None
    angellist: str | None = None
    phone: str | None = None
    founded_year: int | None = None
    logo: str | None = None
    crunchbase: str | None = None
    industry: str | None = None
    no_of_employees: int | None = None
    raw_address: str | None = None
    street_address: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = None
    short_description: str | None = None
    annual_revenue: int | None = None
    total_funding: int | None = None
    latest_funding_round_date: str | None = None
    latest_funding_stage: str | None = None
    technology_names: list[str] = []


class ApolloCompanyEnrichAction(
    BaseAction[ApolloCompanyEnrichInput, ApolloCompanyEnrichOutput]
):
    id = "d4369b3b-207f-4c15-8c9b-05ed2b2cf8d9"
    name = "Company Enrich (Apollo)"
    description = "Enrich company by domain"
    icon = "https://www.apollo.io/favicon.ico"
    default_output_path = "result.name"
    input_schema = ApolloCompanyEnrichInput
    output_schema = ApolloCompanyEnrichOutput
    usage = ActionUsage(units=1, unit_type="credit")  # I don't know the correct credits
    tags = ["Companies"]

    def _run(
        self, input: ApolloCompanyEnrichInput
    ) -> ActionResponse[ApolloCompanyEnrichOutput]:
        client = apollo.ApiClient(input.api_key)
        # validate domain
        if not input.domain:
            return ActionResponse(
                error=ActionError(code="INVALID_INPUT", message="Invalid domain.")
            )

        try:
            # enrich company by domain
            response = client.organization_enrichment(input.domain)

            # extract organization data
            organization = response.get("organization", {})

            # check if organization data is found, this is None if no company is found
            if not organization:
                return ActionResponse(
                    error=ActionError(
                        code="NO_DATA",
                        message="No data found for company.",
                    )
                )

            # build result object
            result = ApolloCompanyEnrichOutput(
                name=organization["name"],
                domain=organization["primary_domain"],
                website=organization["website_url"],
                blog=organization.get("blog_url"),
                linkedin=organization.get("linkedin_url"),
                twitter=organization.get("twitter_url"),
                facebook=organization.get("facebook_url"),
                angellist=organization.get("angellist_url"),
                phone=organization.get("phone"),
                founded_year=organization.get("founded_year"),
                logo=organization.get("logo_url"),
                crunchbase=organization.get("crunchbase_url"),
                industry=organization.get("industry"),
                no_of_employees=organization.get("estimated_num_employees"),
                raw_address=organization.get("raw_address"),
                street_address=organization.get("street_address"),
                city=organization.get("city"),
                state=organization.get("state"),
                postal_code=organization.get("postal_code"),
                country=organization.get("country"),
                short_description=organization.get("short_description"),
                annual_revenue=organization.get("annual_revenue"),
                total_funding=organization.get("total_funding"),
                latest_funding_round_date=organization.get("latest_funding_round_date"),
                latest_funding_stage=organization.get("latest_funding_stage"),
                technology_names=organization.get("technology_names", []),
            )

            # return response
            return ActionResponse(result=result)

        except apollo.ApolloException as e:
            logger.exception(
                "Error enriching company data.", extra={"domain": input.domain}
            )
            return ActionResponse(
                error=ActionError(
                    code=f"APOLLO_ERROR_{e.status_code}",
                    message="Error enriching company data.",
                    e=e,
                )
            )
        except Exception as e:
            logger.exception(
                "Error enriching company data.", extra={"domain": input.domain}
            )
            return ActionResponse(
                error=ActionError(
                    code="APOLLO_ERROR_UNKNOWN",
                    message="Error enriching company data.",
                    e=e,
                )
            )
