from grpc import services
import pydantic
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import clearbit
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class ClearbitCompanyEnrichInput(BaseActionInput):
    domain: str
    api_key: str | None = None


class ClearbitWebsitePhoneAndEmails(pydantic.BaseModel):
    phoneNumbers: list[str] = []
    emailAddresses: list[str] = []


class ClearbitCompanyCategory(pydantic.BaseModel):
    sector: str | None = None
    industryGroup: str | None = None
    industry: str | None = None
    subIndustry: str | None = None
    gicsCode: str | None = None
    sicCode: str | None = None
    sic4Codes: list[str] = []
    naicsCode: str | None = None
    naics6Codes: list[str] = []
    naics6Codes2022: list[str] = []
    tags: list[str] = []


class ClearbitGeographicInfo(pydantic.BaseModel):
    streetNumber: str | None = None
    streetName: str | None = None
    subPremise: str | None = None
    streetAddress: str | None = None
    city: str | None = None
    postalCode: str | None = None
    state: str | None = None
    stateCode: str | None = None
    country: str | None = None
    countryCode: str | None = None
    lat: float | None = None
    lng: float | None = None


class ClearbitCompanyFacebook(pydantic.BaseModel):
    handle: str | None = None
    likes: int | None = None


class ClearbitCompanyLinkedin(pydantic.BaseModel):
    handle: str | None = None


class ClearbitCompanyTwitter(pydantic.BaseModel):
    handle: str | None = None
    id: str | None = None
    bio: str | None = None
    followers: int | None = None
    following: int | None = None
    location: str | None = None
    site: str | None = None
    avatar: str | None = None


class ClearbitCompanyCrunchBase(pydantic.BaseModel):
    handle: str | None = None


class ClearbitCompanyIdentifier(pydantic.BaseModel):
    usEIN: str | None = None


class ClearbitCompanyMetrics(pydantic.BaseModel):
    alexaUsRank: int | None = None
    alexaGlobalRank: int | None = None
    trafficRank: str | None = None
    employees: int | None = None
    employeesRange: str | None = None
    marketCap: int | None = None
    raised: int | None = None
    annualRevenue: int | None = None
    estimatedAnnualRevenue: str | None = None
    fiscalYearEnd: int | None = None


class ParentCompany(pydantic.BaseModel):
    domain: str | None = None


class ClearbitCompanyEnrichOutput(BaseActionOutput):
    id: str
    name: str | None = None
    legalName: str | None = None
    domain: str | None = None
    domainAliases: list[str] = []
    site: ClearbitWebsitePhoneAndEmails | None = None
    category: ClearbitCompanyCategory | None = None
    tags: list[str] = []
    description: str | None = None
    foundedYear: int | None = None
    location: str | None = None
    timeZone: str | None = None
    utcOffset: int | None = None
    geo: ClearbitGeographicInfo | None = None
    logo: str | None = None
    facebook: ClearbitCompanyFacebook | None = None
    linkedin: ClearbitCompanyLinkedin | None = None
    twitter: ClearbitCompanyTwitter | None = None
    crunchBase: ClearbitCompanyCrunchBase | None = None
    emailProvider: bool | None = None
    type: str | None = None
    ticker: str | None = None
    identifiers: ClearbitCompanyIdentifier | None = None
    phone: str | None = None
    metrics: ClearbitCompanyMetrics | None = None
    tech: list[str] = []
    techCategories: list[str] = []
    parent: ParentCompany | None = None
    ultimateParent: ParentCompany | None = None


class ClearbitCompanyEnrichAction(
    BaseAction[ClearbitCompanyEnrichInput, ClearbitCompanyEnrichOutput]
):
    id = "759358df-61bc-4dd7-b804-6f81e8a8648d"
    name = "Company Enrich (Clearbit)"
    description = "Enrich company by domain"
    icon = "https://www.clearbit.com/favicon.ico"
    default_output_path = "result.name"
    input_schema = ClearbitCompanyEnrichInput
    output_schema = ClearbitCompanyEnrichOutput
    tags = ["Companies"]
    usage = ActionUsage(units=1, unit_type="credit")  # I don't know the correct credits

    def _run(
        self, input: ClearbitCompanyEnrichInput
    ) -> ActionResponse[ClearbitCompanyEnrichOutput]:
        client = clearbit.ApiClient(input.api_key)
        # enrich company by domain
        (data, status_code, response) = client.enrich_company_using_domain(input.domain)

        # Rate limit exceeded
        if status_code == 429:
            logger.error(f"Rate limit exceed while calling clearbit API")
            return ActionResponse(
                error=ActionError(
                    code=f"{status_code}", message=response.text, retryable=True
                )
            )

        if status_code != 200:
            return ActionResponse(
                error=ActionError(code=f"{status_code}", message=response.text)
            )

        return ActionResponse(result=ClearbitCompanyEnrichOutput(**data))
