import pydantic
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import coresignal
from lib.coresignal.helper import CoreSignalDBCache

from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class CoresignalCompanyEnrichInput(BaseActionInput):
    linkedin: str
    api_key: str | None = None


class CoresignalCompanyInvestorsList(pydantic.BaseModel):
    name: str | None = None
    hash: str | None = None
    cb_url: str | None = None
    created: str | None = None
    last_updated: str | None = None


class CoresignalCompanyFeaturedInvestor(pydantic.BaseModel):
    investor_id: int | None = None
    round_id: int | None = None
    created: str | None = None
    last_updated: str | None = None
    deleted: int | None = None
    company_investors_list: CoresignalCompanyInvestorsList | None = None


class CoresignalCompanyFundingRound(pydantic.BaseModel):
    last_round_investors_count: int | None = None
    total_rounds_count: int | None = None
    last_round_type: str | None = None
    last_round_date: str | None = None
    last_round_money_raised: str | None = None
    cb_url: str | None = None
    created: str | None = None
    last_updated: str | None = None
    deleted: int | None = None


class CoresignalCompanyLocation(pydantic.BaseModel):
    location_address: str | None = None
    is_primary: int | None = None
    created: str | None = None
    last_updated: str | None = None
    deleted: int | None = None


class CoresignalCompanyEnrichOutput(BaseActionOutput):
    id: int
    url: str | None = None
    hash: str | None = None
    name: str | None = None
    website: str | None = None
    size: str | None = None
    industry: str | None = None
    description: str | None = None
    headquarters_city: str | None = None
    headquarters_country: str | None = None
    headquarters_state: str | None = None
    headquarters_street1: str | None = None
    headquarters_street2: str | None = None
    headquarters_zip: str | None = None
    type: str | None = None
    headquarters_new_address: str | None = None
    employees_count: int | None = None
    headquarters_country_restored: str | None = None
    headquarters_country_parsed: str | None = None
    deleted: int | None = None
    company_featured_investors_collection: list[CoresignalCompanyFeaturedInvestor] = []
    company_funding_rounds_collection: list[CoresignalCompanyFundingRound] = []
    company_locations_collection: list[CoresignalCompanyLocation] = []


class CoresignalCompanyEnrichAction(
    BaseAction[CoresignalCompanyEnrichInput, CoresignalCompanyEnrichOutput]
):
    id = "32815ab8-6b9f-4bcf-8411-547a023d3b19"
    name = "Company Enrich (Coresignal)"
    description = "Enrich company by linkedin"
    icon = "https://www.linkedin.com/favicon.ico"
    default_output_path = "result.name"
    input_schema = CoresignalCompanyEnrichInput
    output_schema = CoresignalCompanyEnrichOutput
    usage = ActionUsage(
        units=2,
        unit_type="credit",
        extra_data={"coresignal_credit": {"search_credit": 1, "collect_credit": 1}},
    )
    tags = ["Companies"]

    def _run(
        self, input: CoresignalCompanyEnrichInput
    ) -> ActionResponse[CoresignalCompanyEnrichOutput]:

        if not input.linkedin:
            logger.error("linkedin param is required for company's profile")
            return ActionResponse(
                error=ActionError(
                    code="NOT_FOUND",
                    message="linkedin param is required for company's profile",
                )
            )

        try:
            cs = coresignal.ApiClient(input.api_key, CoreSignalDBCache())
            company = cs.get_company_by_linkedin(input.linkedin)

            if not company:
                logger.error("Company not found", extra={"linkedin": input.linkedin})
                return ActionResponse(
                    error=ActionError(code="NOT_FOUND", message="Company not found")
                )

            return ActionResponse(result=CoresignalCompanyEnrichOutput(**company))

        except Exception as e:
            logger.exception(
                f"Error getting the company profile", extra={"linkedin": input.linkedin}
            )
            return ActionResponse(
                error=ActionError(
                    code="PROFILE_ERROR_UNKNOWN",
                    message="Error getting the profile",
                    e=e,
                )
            )
