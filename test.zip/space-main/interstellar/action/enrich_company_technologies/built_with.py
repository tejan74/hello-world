import pydantic
import pydash
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import built_with
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class EnrichCompanyTechnologiesBuiltWithInput(BaseActionInput):
    api_key: str | None = None
    domain: str
    only_live: bool = True


class Technology(pydantic.BaseModel):
    Categories: list[str] | None = None
    Name: str | None = None
    Description: str | None = None
    Link: str | None = None
    Tag: str | None = None
    Parent: str | None = None


class EnrichCompanyResultItem(pydantic.BaseModel):
    Technologies: list[Technology] | None = None
    Domain: str | None = None
    Url: str | None = None
    SubDomain: str | None = None


class EnrichCompanyTechnologiesBuiltWithOutput(BaseActionOutput):
    data: list[EnrichCompanyResultItem] = []


class EnrichCompanyTechnologiesBuiltWithAction(
    BaseAction[
        EnrichCompanyTechnologiesBuiltWithInput,
        EnrichCompanyTechnologiesBuiltWithOutput,
    ]
):
    id = "76c3b63c-390d-4d0c-83a0-9290ad9ec1e1"
    name = "Technographics"
    description = "Get technologies used by a company using BuiltWith"
    icon = "https://builtwith.com/favicon.ico"
    default_output_path = "result.Results"
    input_schema = EnrichCompanyTechnologiesBuiltWithInput
    output_schema = EnrichCompanyTechnologiesBuiltWithOutput
    usage = ActionUsage(units=1, unit_type="credit")
    tags = ["Companies"]

    def _run(
        self, input: EnrichCompanyTechnologiesBuiltWithInput
    ) -> ActionResponse[EnrichCompanyTechnologiesBuiltWithOutput]:
        self.api_client = built_with.ApiClient(key=input.api_key)

        response = self.api_client.get_technologies(input.domain, input.only_live)

        if response.status_code != 200:
            logger.error(
                f"Error getting Technographics: {response.status_code} {response.text}"
            )
            if response.status_code == 403 or response.status_code == 429:
                logger.info(
                    f"Rate limited while getting Technographics (Retrying): {response.status_code} {response.text}"
                )
                return ActionResponse(
                    error=ActionError(
                        code="API_LIMIT_EXCEEDED",
                        message="API limit exceeded. Please try again later.",
                        retryable=True,
                    )
                )
            return ActionResponse(
                error=ActionError(code="ERROR", message=response.text)
            )

        response = response.json()

        results = pydash.get(response, "Results")
        if (not results) or (not isinstance(results, list)):
            return ActionResponse(
                result=EnrichCompanyTechnologiesBuiltWithOutput(data=[])
            )

        final_result: list[EnrichCompanyResultItem] = []
        for result in results:
            paths = pydash.get(result, "Result.Paths")
            if paths and (isinstance(paths, list)):
                for path in paths:
                    final_result.append(EnrichCompanyResultItem(**path))

        return ActionResponse(
            result=EnrichCompanyTechnologiesBuiltWithOutput(data=final_result)
        )
