from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.hunter import HunterClient


class EnrichEmailInput(BaseActionInput):
    domain: str
    company: str
    first_name: str
    last_name: str
    full_name: str
    api_key: str | None = None


class EnrichEmailOutput(BaseActionOutput):
    email: str | None


class EnrichEmailAction(BaseAction[EnrichEmailInput, EnrichEmailOutput]):
    id = "hunter-enrich-email-action"
    name = "Enrich Email Addresses with Hunter.io"
    description = "Enrich email addresses using Hunter.io by providing details such as domain, company name, first name, last name, and full name. This action will help you find and verify email addresses based on the provided information"
    icon = "https://hunter.io/assets/favicon/favicon-35c267ca9f2a39f1c9d7118c8533e74385d9e7a4fad1ced75fd51442ecfbceb2.ico"
    default_output_path = "result.email"
    input_schema = EnrichEmailInput
    output_schema = EnrichEmailOutput
    usage_type = None
    tags = ["People"]

    def _run(
        self, input: EnrichEmailInput, **kwargs: Any
    ) -> ActionResponse[EnrichEmailOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("HUNTER_API_KEY")
        )
        client = HunterClient(api_key=self.api_key)
        output = client.email_finder(
            domain=input.domain,
            company=input.company,
            first_name=input.first_name,
            last_name=input.last_name,
            full_name=input.full_name,
        )

        if output and output.data is not None:
            return ActionResponse(
                result=EnrichEmailOutput(email=output.data.email),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichEmailOutput(email=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
