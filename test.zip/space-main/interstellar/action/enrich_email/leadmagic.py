from typing import Any
from action.base import BaseActionInput, BaseActionOutput, BaseAction
from action.types import ActionResponse, ActionUsage
import config
from lib.leadmagic import LeadMagicClient


class EnrichEmailInput(BaseActionInput):
    first_name: str
    last_name: str
    domain: str
    company_name: str
    api_key: str | None = None


class EnrichEmailOutput(BaseActionOutput):
    email: str | None


class EnrichEmailAction(BaseAction[EnrichEmailInput, EnrichEmailOutput]):
    id = "leadmagic-enrich-email-action"
    name = "Enrich Email Addresses with LeadMagic"
    description = "Enrich email addresses using LeadMagic by providing details such as  company name, first name, last name, and domain. This action will help you find and verify email addresses based on the provided information"
    icon = "https://beta.leadmagic.io/favicon.ico"
    default_output_path = "result.email"
    input_schema = EnrichEmailInput
    output_schema = EnrichEmailOutput
    usage_type = None
    tags = ["People"]

    def _run(
        self, input: EnrichEmailInput, **kwargs: Any
    ) -> ActionResponse[EnrichEmailOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("LEADMAGIC_API_KEY")
        )
        client = LeadMagicClient(api_key=self.api_key)
        response = client.email_finder(
            first_name=input.first_name,
            last_name=input.last_name,
            domain=input.domain,
            company_name=input.company_name,
        )

        if response and response.status != "not_found" and response.email:
            return ActionResponse(
                result=EnrichEmailOutput(email=response.email),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichEmailOutput(email=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
