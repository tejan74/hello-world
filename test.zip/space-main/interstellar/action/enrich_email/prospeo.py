from typing import Any
from action.base import BaseActionInput, BaseActionOutput, BaseAction
from action.types import ActionResponse, ActionUsage
import config
from lib.prospeo import ProspeoClient


class EnrichEmailInput(BaseActionInput):
    company: str
    first_name: str | None = None
    last_name: str | None = None
    full_name: str | None = None
    api_key: str | None = None


class EnrichEmailOutput(BaseActionOutput):
    email: str | None


class EnrichEmailAction(BaseAction[EnrichEmailInput, EnrichEmailOutput]):
    id = "prospeo-enrich-email-action"
    name = "Enrich Email Addresses with Prospeo"
    description = "Enrich email addresses using Prospeo by providing details such as company name, first name, last name, and full name. This action will help you find and verify email addresses based on the provided information"
    icon = "https://lh3.googleusercontent.com/ZnecyuZStWFBHS3436Db5_BMOYXh6_pmlaNUR7zzf-BfE26eLdnmMmGefsxS5EQBmKF6KUKVsUQjCqIZXfOxYFJPOg=s60"
    default_output_path = "result.email"
    input_schema = EnrichEmailInput
    output_schema = EnrichEmailOutput
    usage_type = None
    tags = ["People"]

    def _run(
        self, input: EnrichEmailInput, **kwargs: Any
    ) -> ActionResponse[EnrichEmailOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("PROSPEO_API_KEY")
        )
        client = ProspeoClient(api_key=self.api_key)
        output = client.email_finder(
            company=input.company,
            first_name=input.first_name,
            last_name=input.last_name,
            full_name=input.full_name,
        )

        if output and output.response and output.response.email is not None:
            return ActionResponse(
                result=EnrichEmailOutput(email=output.response.email),
                usage=ActionUsage(
                    units=1 if output.response.email_status == "VALID" else 0,
                    unit_type="credit",
                ),
            )
        else:
            return ActionResponse(
                result=EnrichEmailOutput(email=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
