from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.serp_api import SerpApiClient
from lib.serp_api.types import GetSearchResponse


class GoogleMapBusinessInput(BaseActionInput):
    company_name: str
    address: str
    longitude: float | None = None
    latitude: float | None = None
    data: str | None = None  # It can be used to filter the search results
    place_id: str | None = (
        None  # It defines the unique reference to a place on a Google Map
    )
    api_key: str | None = None


class GoogleMapBusinessOutput(BaseActionOutput):
    result: GetSearchResponse | None


"""
Each time you perform a search using one of SerpAPIs, exactly 1 credit is consumed,
regardless of the number of results returned in the response.
The exception to this is when you execute the exact same request 
with the exact same parameters again within one hour period. 
In this case the response is served from a cache, instead of performing a new live search,
and 1 search credit is not charged for this.
The behavior explained above could be changed by using the no_cache parameter in the request. 
This will force a new live search to be performed and 1 search credit to be deducted.
"""


class LocateBusinessUsingGoogleMapsAction(
    BaseAction[GoogleMapBusinessInput, GoogleMapBusinessOutput]
):
    id = "google_maps_business_locator_action"
    name = "Locate Business on Google Maps"
    description = "Retrieve detailed location information for businesses via Google Maps. This action allows you to perform refined searches based on parameters such as location, place ID, and additional data fields to obtain accurate and relevant results."
    icon = "https://www.google.com/images/branding/product/ico/maps15_bnuw3a_32dp.ico"
    default_output_path = "result"
    input_schema = GoogleMapBusinessInput
    output_schema = GoogleMapBusinessOutput
    usage_type = None
    tags = ["Maps & Locations"]

    def _run(
        self, input: GoogleMapBusinessInput, **kwargs: Any
    ) -> ActionResponse[GoogleMapBusinessOutput]:
        self.api_key = input.api_key or config.get_parameter("SERP_API_KEY")
        client = SerpApiClient(api_key=self.api_key, provider="GoogleMaps")
        # here 14z is the zoom level of the map
        ll = ""
        if (input.latitude is not None) and (input.longitude is not None):
            ll = f"@{input.latitude},{input.longitude},14z"
        if input.address and input.company_name:
            query = f"{input.company_name} {input.address}"
        response = client.search_google_maps(
            q=query,
            ll=ll if ll else None,
            data=input.data,
            place_id=input.place_id,
            engine="google_maps",
        )

        if response is not None:
            return ActionResponse(
                result=GoogleMapBusinessOutput(result=response),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=GoogleMapBusinessOutput(result=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
