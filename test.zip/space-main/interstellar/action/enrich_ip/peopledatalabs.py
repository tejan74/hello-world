from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.people_data_labs import PeopleDataLabsClient
from lib.people_data_labs.types import IPData


class EnrichIPAddressInput(BaseActionInput):
    ip: str
    return_ip_location: bool = False
    return_ip_metadata: bool = False
    return_person: bool = False
    return_if_unmatched: bool = False
    titlecase: bool = False
    pretty: bool = False
    api_key: str | None = None


class EnrichIPAddressOutput(BaseActionOutput):
    data: IPData | None


class EnrichIPAddressAction(BaseAction[EnrichIPAddressInput, EnrichIPAddressOutput]):
    id = "pdl-enrich-ip-address-data"
    name = "Enrich IP Address Data with People Data Labs"
    description = "Enrich IP address data using People Data Labs by providing the IP address and optional parameters. Specify if you want to return IP location, metadata, person information, or handle unmatched IPs to get comprehensive and detailed IP-related data."
    icon = (
        "https://www.peopledatalabs.com/_next/static/media/brain-nav-icon.b24e1ee3.svg"
    )
    default_output_path = "result.data"
    input_schema = EnrichIPAddressInput
    output_schema = EnrichIPAddressOutput
    usage_type = None
    tags = ["Companies"]

    def _run(
        self, input: EnrichIPAddressInput, **kwargs: Any
    ) -> ActionResponse[EnrichIPAddressOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("PEOPLE_DATA_LABS_API_KEY")
        )
        client = PeopleDataLabsClient(api_key=self.api_key)
        response = client.ip_enrich(
            ip=input.ip,
            return_ip_location=input.return_ip_location,
            return_ip_metadata=input.return_ip_location,
            return_person=input.return_person,
            return_if_unmatched=input.return_if_unmatched,
            titlecase=input.titlecase,
            pretty=input.pretty,
        )

        if response and response.data is not None:
            return ActionResponse(
                result=EnrichIPAddressOutput(data=response.data),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichIPAddressOutput(data=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
