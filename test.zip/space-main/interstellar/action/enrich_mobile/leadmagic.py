from typing import Any
from action.base import BaseActionInput, BaseActionOutput, BaseAction
from action.types import ActionResponse, ActionUsage
import config
from lib.leadmagic import LeadMagicClient


class EnrichMobileInput(BaseActionInput):
    profile_url: str
    api_key: str | None = None


class EnrichMobileOutput(BaseActionOutput):
    mobile_number: str | None


class EnrichMobileAction(BaseAction[EnrichMobileInput, EnrichMobileOutput]):
    id = "leadmagic-enrich-mobile-action"
    name = "Enrich Mobile with LeadMagic"
    description = "Enrich mobile numbers by providing a social media profile URL (e.g., LinkedIn or Facebook). This action will help you find and retrieve mobile numbers associated with the provided profile."
    icon = "https://beta.leadmagic.io/favicon.ico"
    default_output_path = "result.mobile_number"
    input_schema = EnrichMobileInput
    output_schema = EnrichMobileOutput
    usage_type = None
    tags = ["People"]

    def _run(
        self, input: EnrichMobileInput, **kwargs: Any
    ) -> ActionResponse[EnrichMobileOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("LEADMAGIC_API_KEY")
        )
        client = LeadMagicClient(api_key=self.api_key)
        response = client.mobile_finder(profile_url=input.profile_url)

        if response is not None:
            return ActionResponse(
                result=EnrichMobileOutput(mobile_number=response.mobile_number),
                usage=ActionUsage(units=5, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichMobileOutput(mobile_number=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
