import pydantic
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import apollo
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class ApolloEnrichProfileInput(BaseActionInput):
    api_key: str | None = None
    linkedin: str
    enrich_email: bool = False
    # TODO: Enable phone enrich after supporting webhook for phone number enrichment
    enrich_phone: pydantic.json_schema.SkipJsonSchema[bool] = False


class EnrichLeadPhone(pydantic.BaseModel):
    number: str
    type: str | None
    status: str | None


# Unified model for lead
class Job(pydantic.BaseModel):
    title: str | None = None
    date_to: str | None = None
    date_from: str | None = None
    duration: str | int | None = None
    location: str | None = None
    company_url: str | None = None
    company_name: str | None = None


class Lead(pydantic.BaseModel):
    name: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    title: str | None = None
    url: str | None = None
    location: str | None = None
    industry: str | None = None
    summary: str | None = None
    country: str | None = None
    connections_count: int | None = None
    experience_count: int | None = None
    job: Job | None = None


class ApolloLead(Lead):
    personal_emails: list[str]
    office_email: str | None
    phone_numbers: list[EnrichLeadPhone]
    departments: list[str]
    seniority: str | None


class ApolloEnrichProfileOutput(BaseActionOutput):
    lead: ApolloLead


class ApolloEnrichProfileAction(
    BaseAction[ApolloEnrichProfileInput, ApolloEnrichProfileOutput]
):
    id = "f80428ba-b869-41cf-ab1f-0b70271580c9"
    name = "Person Enrich Lead"
    description = "Enrich a lead using Apollo"
    icon = "https://www.apollo.io/favicon.ico"
    default_output_path = "result.lead.name"
    input_schema = ApolloEnrichProfileInput
    output_schema = ApolloEnrichProfileOutput
    usage = ActionUsage(units=1, unit_type="credit")
    tags = ["People"]

    def _run(
        self, input: ApolloEnrichProfileInput
    ) -> ActionResponse[ApolloEnrichProfileOutput]:
        self.client = apollo.ApiClient(input.api_key)
        # Validation
        if not input.linkedin:
            logger.error("linkedin param is required for person enrichment")
            raise ValueError("linkedin param is required for person enrichment")

        try:
            # TODO: Get request uuid if enrich_phone is True
            # request_uuid = None
            # webhook_url = f"https://api.interstellar.com/webhook/apollo/phone?uuid={request_uuid}"

            # Call the client
            response = self.client.person_enrichment(
                input.linkedin, input.enrich_email, input.enrich_phone
            )

            # if enrich_phone:
            # TODO: Check if phone number is revealed or wait for the webhook cal

            person = response.get("person")

            if not person:
                logger.error("Person not found", extra={"linkedin": input.linkedin})
                return ActionResponse(
                    error=ActionError(code="NOT_FOUND", message="Person not found")
                )

            # Build the response
            lead = ApolloLead(
                name=person.get("name"),
                first_name=person.get("first_name"),
                last_name=person.get("last_name"),
                title=person.get("title"),
                url=person.get("linkedin_url"),
                country=person.get("country"),
                personal_emails=person.get("personal_emails", []),
                office_email=person.get("email"),
                phone_numbers=(
                    [
                        EnrichLeadPhone(
                            number=phone.get("raw_number"),
                            type=phone.get("type"),
                            status=phone.get("status"),
                        )
                        for phone in person.get("phone_numbers")
                    ]
                    if person.get("phone_numbers")
                    else []
                ),
                departments=person.get("departments") or [],
                seniority=person.get("seniority"),
            )

            return ActionResponse(result=ApolloEnrichProfileOutput(lead=lead))
        except Exception as e:
            logger.exception(
                f"Error enriching lead",
                extra={
                    "linkedin": input.linkedin,
                    "enrich_email": input.enrich_email,
                    "enrich_phone": input.enrich_phone,
                },
            )
            return ActionResponse(
                error=ActionError(
                    code="ENRICH_ERROR_UNKNOWN", message="Error enriching lead", e=e
                )
            )
