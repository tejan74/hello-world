import re
from typing import Any
import pydantic
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import apollo, coresignal
from lib.coresignal.helper import CoreSignalDBCache
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class CoresignalEnrichProfileInput(BaseActionInput):
    api_key: str | None = None
    linkedin: str


class CoresignalLeadExperience(pydantic.BaseModel):
    company: str | None = None
    title: str | None = None
    location: str | None = None
    description: str | None = None
    start: str | None = None
    end: str | None = None
    company_linkedin: str | None = None


class CoresignalLeadEducation(pydantic.BaseModel):
    title: str | None = None
    subtitle: str | None = None
    description: str | None = None
    start: str | None = None
    end: str | None = None


# Unified model for lead
class Job(pydantic.BaseModel):
    title: str | None = None
    date_to: str | None = None
    date_from: str | None = None
    duration: str | int | None = None
    location: str | None = None
    company_url: str | None = None
    company_name: str | None = None


class Lead(pydantic.BaseModel):
    name: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    title: str | None = None
    url: str | None = None
    location: str | None = None
    industry: str | None = None
    summary: str | None = None
    country: str | None = None
    connections_count: int | None = None
    experience_count: int | None = None
    job: Job | None = None


class CoresignalLead(Lead):
    experience: list[CoresignalLeadExperience]
    education: list[CoresignalLeadEducation]
    skills: list[Any] = []


class CoresignalEnrichProfileOutput(BaseActionOutput):
    lead: CoresignalLead


class CoresignalEnrichProfileAction(
    BaseAction[CoresignalEnrichProfileInput, CoresignalEnrichProfileOutput]
):
    id = "4bd017c3-332c-4df7-9f9f-9de4c6fbb857"
    name = "Lead Enrich (Coresignal)"
    description = "Enrich a lead using Coresignal"
    icon = "https://www.linkedin.com/favicon.ico"
    default_output_path = "result.lead.name"
    input_schema = CoresignalEnrichProfileInput
    output_schema = CoresignalEnrichProfileOutput
    usage = ActionUsage(units=1, unit_type="credit")
    tags = ["People"]

    def _run(
        self, input: CoresignalEnrichProfileInput
    ) -> ActionResponse[CoresignalEnrichProfileOutput]:
        cs = coresignal.ApiClient(input.api_key, CoreSignalDBCache())

        if not input.linkedin:
            logger.error("linkedin param is required for person's profile")
            return ActionResponse(
                error=ActionError(
                    code="NOT_FOUND",
                    message="linkedin param is required for person's profile",
                )
            )

        try:
            person_id = self.extract_user_id(input.linkedin)

            if not person_id:
                logger.error("Invalid LinkedIn Profile URL")
                return ActionResponse(
                    error=ActionError(
                        code="NOT_FOUND", message="Invalid LinkedIn Profile URL"
                    )
                )

            person = cs.get_member_by_id(person_id)
            if not person:
                logger.error("Person not found", extra={"linkedin": input.linkedin})
                return ActionResponse(
                    error=ActionError(code="NOT_FOUND", message="Person not found")
                )
            # Extract values with None fallbacks if not present
            name = person.get("name")
            first_name = person.get("first_name")
            last_name = person.get("last_name")
            title = person.get("title")
            url = person.get("url")
            country = person.get("country")
            connections_count = person.get("connections_count")
            experience_count = person.get("experience_count")

            # Extract and process experience
            experience = [
                CoresignalLeadExperience(
                    company=exp.get("company_name"),
                    title=exp.get("title"),
                    location=exp.get("location"),
                    description=exp.get("description"),
                    start=exp.get("date_from"),
                    end=exp.get("date_to"),
                    company_linkedin=exp.get("company_url"),
                )
                for exp in person.get("member_experience_collection", [])
                if not exp.get("deleted")
            ]

            # Extract and process education
            education = [
                CoresignalLeadEducation(
                    title=edu.get("title"),
                    subtitle=edu.get("subtitle"),
                    description=edu.get("description"),
                    start=edu.get("date_from"),
                    end=edu.get("date_to"),
                )
                for edu in person.get("member_education_collection", [])
                if not edu.get("deleted")
            ]

            # Extract skills
            skills = person.get("member_skills_collection", [])
            lead = CoresignalLead(
                name=name,
                first_name=first_name,
                last_name=last_name,
                title=title,
                url=url,
                country=country,
                experience=experience,
                education=education,
                skills=skills,
                connections_count=connections_count,
                experience_count=experience_count,
            )
            return ActionResponse(result=CoresignalEnrichProfileOutput(lead=lead))

        except coresignal.CoreSignalException as e:
            logger.exception("Core signal, member error", e)
            # Rate limit exceeded
            if e.status_code == 429 or e.status_code == 503:
                logger.info(f"Rate limit exceeded while getting members: {e}")
                return ActionResponse(
                    error=ActionError(
                        code=f"CORESIGNAL_MEMBER_ERROR_{e.status_code}",
                        message="Core signal member search rate limit exceeded error",
                        retryable=True,
                        e=e,
                    )
                )

            return ActionResponse(
                error=ActionError(
                    code=f"CORESIGNAL_MEMBER_ERROR_{e.status_code}",
                    message="Core signal, member error",
                    e=e,
                )
            )

        except Exception as e:
            logger.exception(
                f"Error getting the profile", extra={"linkedin": input.linkedin}
            )
            return ActionResponse(
                error=ActionError(
                    code="PROFILE_ERROR_UNKNOWN",
                    message="Error getting the profile",
                    e=e,
                )
            )

    def extract_user_id(self, linkedin_url: str) -> str | None:
        """
        Extracts the LinkedIn user ID from a LinkedIn URL.

        Args:
        linkedin_url (str): The LinkedIn profile URL.

        Returns:
        str: The LinkedIn user ID if found, otherwise None.
        """
        # Define a regular expression pattern for LinkedIn profile URLs
        pattern = r".*?linkedin\.\w+/in/([^/?#]+)"

        match = re.search(pattern, linkedin_url)

        if match:
            return match.group(1)

        return None
