from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.findymail import FindymailClient
from lib.findymail.types import Contact


class EnrichLinkedInProfileDataInput(BaseActionInput):
    linkedin_profile_url: str
    api_key: str | None = None


class EnrichLinkedInProfileDataOutput(BaseActionOutput):
    data: Contact | None


class EnrichLinkedInProfileDataAction(
    BaseAction[EnrichLinkedInProfileDataInput, EnrichLinkedInProfileDataOutput]
):
    id = "findymail-enrich-linkedin-profile-data"
    name = "Enrich LinkedIn Profile Data with Findymail"
    description = "Enrich LinkedIn profile data by providing a LinkedIn profile URL using Findymail. This action helps you retrieve detailed and enhanced information from the specified LinkedIn profile."
    icon = "https://www.findymail.com/images/logo/findymail.svg"
    default_output_path = "result.data"
    input_schema = EnrichLinkedInProfileDataInput
    output_schema = EnrichLinkedInProfileDataOutput
    usage_type = None
    tags = ["People"]

    def _run(
        self, input: EnrichLinkedInProfileDataInput, **kwargs: Any
    ) -> ActionResponse[EnrichLinkedInProfileDataOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("FINDYMAIL_API_KEY")
        )
        client = FindymailClient(api_key=self.api_key)
        response = client.search_linkedIn(
            linkedIn_url=input.linkedin_profile_url,
        )

        if response and response.contact is not None:
            return ActionResponse(
                result=EnrichLinkedInProfileDataOutput(data=response.contact),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichLinkedInProfileDataOutput(data=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
