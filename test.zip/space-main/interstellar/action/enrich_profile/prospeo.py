from typing import Any
from action.base import BaseActionInput, BaseActionOutput, BaseAction
from action.types import ActionResponse, ActionUsage
import config
from lib.prospeo.types import LinkedInData
from lib.prospeo import ProspeoClient


class EnrichLinkedInProfileDataInput(BaseActionInput):
    linkedin_profile_url: str
    profile_only: bool = False
    api_key: str | None = None


class EnrichLinkedInProfileDataOutput(BaseActionOutput):
    data: LinkedInData | None


class EnrichLinkedInProfileDataAction(
    BaseAction[EnrichLinkedInProfileDataInput, EnrichLinkedInProfileDataOutput]
):
    id = "prospeo-enrich-linkedin-profile-data"
    name = "Enrich LinkedIn Profile Data with Prospeo"
    description = "Enrich LinkedIn profile data using Prospeo by providing a LinkedIn profile URL. Optionally, specify whether to retrieve profile information only. This action helps you obtain detailed and enhanced data from the specified LinkedIn profile."
    icon = "https://lh3.googleusercontent.com/ZnecyuZStWFBHS3436Db5_BMOYXh6_pmlaNUR7zzf-BfE26eLdnmMmGefsxS5EQBmKF6KUKVsUQjCqIZXfOxYFJPOg=s60"
    default_output_path = "result.data"
    input_schema = EnrichLinkedInProfileDataInput
    output_schema = EnrichLinkedInProfileDataOutput
    usage_type = None
    tags = ["People"]

    def _run(
        self, input: EnrichLinkedInProfileDataInput, **kwargs: Any
    ) -> ActionResponse[EnrichLinkedInProfileDataOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("PROSPEO_API_KEY")
        )
        client = ProspeoClient(api_key=self.api_key)
        output = client.linkedin_email_finder(
            url=input.linkedin_profile_url, profile_only=input.profile_only
        )

        if output and output.response is not None:
            return ActionResponse(
                result=EnrichLinkedInProfileDataOutput(data=output.response),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichLinkedInProfileDataOutput(data=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
