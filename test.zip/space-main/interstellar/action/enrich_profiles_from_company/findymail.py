from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.findymail import FindymailClient
from lib.findymail.types import Contact


class EnrichProfilesFromCompanyInput(BaseActionInput):
    domain: str
    roles: list[str]
    webhook_url: str | None = None
    api_key: str | None = None


class EnrichProfilesFromCompanyOutput(BaseActionOutput):
    data: list[Contact] | None


class EnrichProfilesFromCompanyAction(
    BaseAction[EnrichProfilesFromCompanyInput, EnrichProfilesFromCompanyOutput]
):
    id = "findymail-enrich-profiles"
    name = "Enrich Profiles by Company with Findymail"
    description = "Enrich profiles based on a company's domain and specified roles using Findymail. Provide the domain and list of roles to receive detailed and enriched profile information."
    icon = "https://www.findymail.com/images/favicon.ico"
    default_output_path = "result.data"
    input_schema = EnrichProfilesFromCompanyInput
    output_schema = EnrichProfilesFromCompanyOutput
    usage_type = None
    tags = ["People"]

    def _run(
        self, input: EnrichProfilesFromCompanyInput, **kwargs: Any
    ) -> ActionResponse[EnrichProfilesFromCompanyOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("FINDYMAIL_API_KEY")
        )
        client = FindymailClient(api_key=self.api_key)
        response = client.search_domain(
            domain=input.domain, roles=input.roles, webhook_url=input.webhook_url
        )

        if response and response.contacts is not None:
            return ActionResponse(
                result=EnrichProfilesFromCompanyOutput(data=response.contacts),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichProfilesFromCompanyOutput(data=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
