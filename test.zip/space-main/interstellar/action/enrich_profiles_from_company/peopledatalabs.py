from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.people_data_labs import PeopleDataLabsClient
from lib.people_data_labs.types import PersonEnrichmentResponse


class EnrichProfilesFromCompanyInput(BaseActionInput):
    email: str
    company: str
    api_key: str | None = None


class EnrichProfilesFromCompanyOutput(BaseActionOutput):
    data: PersonEnrichmentResponse | None


class EnrichProfilesFromCompanyAction(
    BaseAction[EnrichProfilesFromCompanyInput, EnrichProfilesFromCompanyOutput]
):
    id = "peopledatalabs-enrich-profiles"
    name = "Enrich Profiles by Company with Peopledatalabs"
    description = "Enrich profile-related data using Peopledatalabs. Provide an email address and company name to obtain detailed and enhanced profile information."
    icon = (
        "https://www.peopledatalabs.com/_next/static/media/brain-nav-icon.b24e1ee3.svg"
    )
    default_output_path = "result.data"
    input_schema = EnrichProfilesFromCompanyInput
    output_schema = EnrichProfilesFromCompanyOutput
    usage_type = None
    tags = ["People"]

    def _run(
        self, input: EnrichProfilesFromCompanyInput, **kwargs: Any
    ) -> ActionResponse[EnrichProfilesFromCompanyOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("PEOPLE_DATA_LABS_API_KEY")
        )
        client = PeopleDataLabsClient(api_key=self.api_key)
        response = client.person_enrich(email=input.email, company=input.company)

        if response is not None:
            return ActionResponse(
                result=EnrichProfilesFromCompanyOutput(data=response),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichProfilesFromCompanyOutput(data=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
