from typing import Any
from action.base import BaseActionInput, BaseActionOutput, BaseAction
from action.types import ActionResponse, ActionUsage
from lib.yelp import YelpClient
from lib.yelp.types import (
    SearchPhoneResponse,
)
import config


class EnrichBusinessByPhoneInput(BaseActionInput):
    phone: str
    locale: str | None = None
    api_key: str | None = None


class EnrichBusinessByPhoneOutput(BaseActionOutput):
    result: SearchPhoneResponse | None


class EnrichBusinessByPhoneAction(
    BaseAction[EnrichBusinessByPhoneInput, EnrichBusinessByPhoneOutput]
):
    id = "enrich_yelp_business_by_phone"
    name = "Enrich Business Information by Phone Number with Yelp"
    description = (
        "Enrich business details using Yelp's API based on a provided phone number."
    )
    icon = "https://s3-media0.fl.yelpcdn.com/assets/public/default.yji-0a2bf1d9c330d8747446.svg"
    default_output_path = "result"
    input_schema = EnrichBusinessByPhoneInput
    output_schema = EnrichBusinessByPhoneOutput
    usage_type = None
    tags = ["SMB"]

    def _run(
        self, input: EnrichBusinessByPhoneInput, **kwargs: Any
    ) -> ActionResponse[EnrichBusinessByPhoneOutput]:
        self.api_key = input.api_key or config.get_parameter("YELP_API_KEY")
        client = YelpClient(api_key=self.api_key)
        output = client.search_phone(phone=input.phone, locale=input.locale)

        if output is not None:
            return ActionResponse(
                result=EnrichBusinessByPhoneOutput(result=output),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichBusinessByPhoneOutput(result=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
