from typing import Any
from action.base import BaseActionInput, BaseActionOutput, BaseAction
from action.types import ActionResponse, ActionUsage
from lib.yelp import YelpClient
from lib.yelp.types import Business
import config


class EnrichBusinessDetailsInput(BaseActionInput):
    business_id_or_alias: str
    locale: str | None = None
    device_platform: str | None = None
    api_key: str | None = None


class EnrichBusinessDetailsOutput(BaseActionOutput):
    result: Business | None


class EnrichBusinessDetailsAction(
    BaseAction[EnrichBusinessDetailsInput, EnrichBusinessDetailsOutput]
):
    id = "enrich-yelp-business-details-action"
    name = "Enrich Business Details with Yelp"
    description = "Enrich business information using Yelp's API based on a business ID or alias. Optionally filter results by locale and device platform."
    icon = "https://s3-media0.fl.yelpcdn.com/assets/public/default.yji-0a2bf1d9c330d8747446.svg"
    default_output_path = "result"
    input_schema = EnrichBusinessDetailsInput
    output_schema = EnrichBusinessDetailsOutput
    usage_type = None
    tags = ["SMB"]

    def _run(
        self, input: EnrichBusinessDetailsInput, **kwargs: Any
    ) -> ActionResponse[EnrichBusinessDetailsOutput]:
        self.api_key = input.api_key or config.get_parameter("YELP_API_KEY")
        client = YelpClient(api_key=self.api_key)
        output = client.business_details(
            business_id_or_alias=input.business_id_or_alias,
            locale=input.locale,
            device_platform=input.device_platform,
        )

        if output is not None:
            return ActionResponse(
                result=EnrichBusinessDetailsOutput(result=output),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichBusinessDetailsOutput(result=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
