from typing import Any
from action.base import BaseActionInput, BaseActionOutput, BaseAction
from action.types import ActionResponse, ActionUsage
from lib.yelp import YelpClient
from lib.yelp.types import BusinessMatchResponse
import config


class EnrichBusinessMatchInput(BaseActionInput):
    name: str
    city: str
    state: str
    country: str
    address1: str
    address2: str | None = None
    address3: str | None = None
    postal_code: str | None = None
    latitude: int | None = None
    longitude: int | None = None
    phone: str | None = None
    yelp_business_id: int | None = None
    limit: int = 3
    match_threshold: str = "default"
    api_key: str | None = None


class EnrichBusinessMatchOutput(BaseActionOutput):
    result: BusinessMatchResponse | None


class EnrichBusinessMatchAction(
    BaseAction[EnrichBusinessMatchInput, EnrichBusinessMatchOutput]
):
    id = "enrich-yelp-business-match-action"
    name = "Enrich Business Match with Yelp"
    description = "Enrich and match business details using Yelp's API. Provide address and location details to find and enrich business information. Optionally, specify a match threshold and result limit."
    icon = "https://s3-media0.fl.yelpcdn.com/assets/public/default.yji-0a2bf1d9c330d8747446.svg"
    default_output_path = "result"
    input_schema = EnrichBusinessMatchInput
    output_schema = EnrichBusinessMatchOutput
    usage_type = None
    tags = ["SMB"]

    def _run(
        self, input: EnrichBusinessMatchInput, **kwargs: Any
    ) -> ActionResponse[EnrichBusinessMatchOutput]:
        self.api_key = input.api_key or config.get_parameter("YELP_API_KEY")
        client = YelpClient(api_key=self.api_key)
        output = client.business_match(
            name=input.name,
            city=input.city,
            state=input.state,
            country=input.country,
            address1=input.address1,
            address2=input.address2,
            address3=input.address3,
            postal_code=input.postal_code,
            latitude=input.latitude,
            longitude=input.longitude,
            phone=input.phone,
            yelp_business_id=input.yelp_business_id,
            limit=input.limit,
            match_threshold=input.match_threshold,
        )

        if output is not None:
            return ActionResponse(
                result=EnrichBusinessMatchOutput(result=output),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichBusinessMatchOutput(result=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
