from typing import Any
from action.base import BaseActionInput, BaseActionOutput, BaseAction
from action.types import ActionResponse, ActionUsage
from lib.yelp import YelpClient
from lib.yelp.types import (
    BusinessReviewsResponse,
)
import config


class EnrichBusinessReviewInput(BaseActionInput):
    business_id_or_alias: str
    locale: str | None = None
    offset: int | None = None
    limit: int = 20
    api_key: str | None = None


class EnrichBusinessReviewOutput(BaseActionOutput):
    result: BusinessReviewsResponse | None


class EnrichBusinessReviewAction(
    BaseAction[EnrichBusinessReviewInput, EnrichBusinessReviewOutput]
):
    id = "enrich_yelp_business_reviews"
    name = "Enrich Business Reviews with Yelp"
    description = "It retrieve business reviews from Yelp's API using a business ID or alias, with optional parameters for locale, offset, and limit"
    icon = "https://s3-media0.fl.yelpcdn.com/assets/public/default.yji-0a2bf1d9c330d8747446.svg"
    default_output_path = "result"
    input_schema = EnrichBusinessReviewInput
    output_schema = EnrichBusinessReviewOutput
    usage_type = None
    tags = ["SMB"]

    def _run(
        self, input: EnrichBusinessReviewInput, **kwargs: Any
    ) -> ActionResponse[EnrichBusinessReviewOutput]:
        self.api_key = input.api_key or config.get_parameter("YELP_API_KEY")
        client = YelpClient(api_key=self.api_key)
        output = client.business_reviews(
            business_id_or_alias=input.business_id_or_alias,
            locale=input.locale,
            offset=input.offset,
            limit=input.limit,
        )

        if output is not None:
            return ActionResponse(
                result=EnrichBusinessReviewOutput(result=output),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichBusinessReviewOutput(result=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
