from typing import Any
from action.base import BaseActionInput, BaseActionOutput, BaseAction
from action.types import ActionResponse, ActionUsage
from lib.yelp import YelpClient
from lib.yelp.types import (
    BusinessReviewsHighlightsResponse,
)
import config


class EnrichBusinessReviewsHighlightsInput(BaseActionInput):
    business_id_or_alias: str
    locale: str | None = None
    device_platform: str | None = None
    api_key: str | None = None


class EnrichBusinessReviewsHighlightsOutput(BaseActionOutput):
    result: BusinessReviewsHighlightsResponse | None


class EnrichBusinessReviewsHighlightsAction(
    BaseAction[
        EnrichBusinessReviewsHighlightsInput, EnrichBusinessReviewsHighlightsOutput
    ]
):
    id = "enrich_yelp_business_reviews_highlights"
    name = "Enrich Business Reviews Highlights with Yelp"
    description = "It retrieve business reviews highlights from Yelp's API using a business ID or alias, with optional parameters for locale, offset, and limit"
    icon = "https://s3-media0.fl.yelpcdn.com/assets/public/default.yji-0a2bf1d9c330d8747446.svg"
    default_output_path = "result"
    input_schema = EnrichBusinessReviewsHighlightsInput
    output_schema = EnrichBusinessReviewsHighlightsOutput
    usage_type = None
    tags = ["SMB"]

    def _run(
        self, input: EnrichBusinessReviewsHighlightsInput, **kwargs: Any
    ) -> ActionResponse[EnrichBusinessReviewsHighlightsOutput]:
        self.api_key = input.api_key or config.get_parameter("YELP_API_KEY")
        client = YelpClient(api_key=self.api_key)
        output = client.business_reviews_highlights(
            business_id_or_alias=input.business_id_or_alias,
            locale=input.locale,
            device_platform=input.device_platform,
        )

        if output is not None:
            return ActionResponse(
                result=EnrichBusinessReviewsHighlightsOutput(result=output),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichBusinessReviewsHighlightsOutput(result=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
