from typing import Any
from action.base import BaseActionInput, BaseActionOutput, BaseAction
from action.types import ActionResponse, ActionUsage
from lib.yelp import YelpClient
from lib.yelp.types import BusinessSearchResponse
import config


class EnrichBusinessSearchInput(BaseActionInput):
    location: str | None = None
    latitude: int | None = None
    longitude: int | None = None
    term: str | None = None
    radius: int | None = None
    categories: list | None = None
    locale: str | None = None
    price: list[int] | None = None
    open_now: bool = False
    open_at: int | None = None
    attributes: list[str] | None = None
    sort_by: str = "best_match"
    device_platform: str | None = None
    reservation_date: str | None = None
    reservation_time: str | None = None
    reservation_covers: int | None = None
    matches_party_size_param: bool = False
    limit: int = 20
    offset: int | None = None
    api_key: str | None = None


class EnrichBusinessSearchOutput(BaseActionOutput):
    result: BusinessSearchResponse | None


class EnrichBusinessSearchAction(
    BaseAction[EnrichBusinessSearchInput, EnrichBusinessSearchOutput]
):
    id = "yelp-business-search-action"
    name = "Search and Enrich Businesses with Yelp"
    description = "Search for businesses with Yelp’s API by using detailed parameters including location, categories, and more. Optionally, refine results with reservation details and various filters."
    icon = "https://s3-media0.fl.yelpcdn.com/assets/public/default.yji-0a2bf1d9c330d8747446.svg"
    default_output_path = "result"
    input_schema = EnrichBusinessSearchInput
    output_schema = EnrichBusinessSearchOutput
    usage_type = None
    tags = ["SMB"]

    def _run(
        self, input: EnrichBusinessSearchInput, **kwargs: Any
    ) -> ActionResponse[EnrichBusinessSearchOutput]:
        self.api_key = input.api_key or config.get_parameter("YELP_API_KEY")
        client = YelpClient(api_key=self.api_key)
        output = client.business_search(
            location=input.location,
            latitude=input.latitude,
            longitude=input.longitude,
            term=input.term,
            radius=input.radius,
            categories=input.categories,
            locale=input.locale,
            price=input.price,
            open_now=input.open_now,
            open_at=input.open_at,
            attributes=input.attributes,
            sort_by=input.sort_by,
            device_platform=input.device_platform,
            reservation_date=input.reservation_date,
            reservation_time=input.reservation_time,
            reservation_covers=input.reservation_covers,
            matches_party_size_param=input.matches_party_size_param,
            limit=input.limit,
            offset=input.offset,
        )

        if output is not None:
            return ActionResponse(
                result=EnrichBusinessSearchOutput(result=output),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichBusinessSearchOutput(result=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
