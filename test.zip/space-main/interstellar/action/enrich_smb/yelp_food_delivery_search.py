from typing import Any
from action.base import BaseActionInput, BaseActionOutput, BaseAction
from action.types import ActionResponse, ActionUsage
from lib.yelp import YelpClient
from lib.yelp.types import (
    FoodDeliverySearchResponse,
)
import config


class EnrichFoodDeliverySearchInput(BaseActionInput):
    transaction_type: str
    latitude: int | None = None
    longitude: int | None = None
    location: str | None = None
    term: str | None = None
    categories: list[str] | None = None
    price: list[int] | None = None
    api_key: str | None = None


class EnrichFoodDeliverySearchOutput(BaseActionOutput):
    result: FoodDeliverySearchResponse | None


class EnrichFoodDeliverySearchAction(
    BaseAction[EnrichFoodDeliverySearchInput, EnrichFoodDeliverySearchOutput]
):
    id = "enrich-yelp-food-delivery-search-action"
    name = "Enrich Food Delivery Search with Yelp"
    description = "Enrich your search for food delivery businesses using Yelp's API by filtering based on transaction type, location, and other criteria. Optionally refine your search with terms, categories, and price levels."
    icon = "https://s3-media0.fl.yelpcdn.com/assets/public/default.yji-0a2bf1d9c330d8747446.svg"
    default_output_path = "result"
    input_schema = EnrichFoodDeliverySearchInput
    output_schema = EnrichFoodDeliverySearchOutput
    usage_type = None
    tags = ["SMB"]

    def _run(
        self, input: EnrichFoodDeliverySearchInput, **kwargs: Any
    ) -> ActionResponse[EnrichFoodDeliverySearchOutput]:
        self.api_key = input.api_key or config.get_parameter("YELP_API_KEY")
        client = YelpClient(api_key=self.api_key)
        output = client.food_delivery_search(
            transaction_type=input.transaction_type,
            latitude=input.latitude,
            longitude=input.longitude,
            location=input.location,
            term=input.term,
            categories=input.categories,
            price=input.price,
        )

        if output is not None:
            return ActionResponse(
                result=EnrichFoodDeliverySearchOutput(result=output),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=EnrichFoodDeliverySearchOutput(result=None),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
