import base64
from mimetypes import MimeTypes
import os
import re
from typing import Annotated, Any, Union
import uuid
import pydantic
import pydash
import fitz
import requests
from action.base import BaseAction
from action.types import ActionResponse, ActionUsage, BaseActionInput, BaseActionOutput
import config
from util.files import DEFAULT_USER_AGENT, delete_file
from util.http import get_redirect_url_from_html


# TODO: Do this better for .bin (octet-stream)
SUPPORTED_FILE_TYPES = [".pdf", ".bin"]


class Position(pydantic.BaseModel):
    x0: int
    y0: int
    x1: int
    y1: int


class Condition(pydantic.BaseModel):
    match_text: str
    position: Position


class PageRange(pydantic.BaseModel):
    start_page: int
    end_page: int


class FileObject(pydantic.BaseModel):
    url: str
    headers: Annotated[
        dict[str, Any],
        pydantic.WithJsonSchema({"additionalProperties": True, "type": "object"}),
    ]
    timeout: int | None = None
    has_browser_based_redirection: bool = False


class PdfInfoExtractorInput(BaseActionInput):
    file: FileObject
    conditions: list[Condition] | None = None
    text_positions: list[Position]
    page_range: PageRange | None = None
    extract_as_png_base64: bool = False


class ExtractedTextPng(pydantic.BaseModel):
    page_num: int
    extracted_text: list[str] = []
    extracted_png_base64: list[str] = []


class Metadata(pydantic.BaseModel):
    content_type: str
    title: str


class PdfInfoExtractorOutput(BaseActionOutput):
    message: str
    data: list[ExtractedTextPng] = []
    metadata: Metadata


class PdfInfoExtractorAction(BaseAction[PdfInfoExtractorInput, PdfInfoExtractorOutput]):
    id = "ad950dd2-5213-40c4-8fdb-aa0725c09449"
    name = "PDF Info Extraction"
    description = (
        "Extract info from certain areas of PDF with support for condition matching"
    )
    icon = "IconFileTypePdf"
    default_output_path = "result.message"
    input_schema = PdfInfoExtractorInput
    output_schema = PdfInfoExtractorOutput
    usage = ActionUsage(units=0, unit_type="credit")
    tags = ["Documents"]

    downloaded_files: list[str] = []
    supported_file_types = SUPPORTED_FILE_TYPES
    content_type: str = ""

    def _run(
        self, input: PdfInfoExtractorInput
    ) -> ActionResponse[PdfInfoExtractorOutput]:
        try:
            self._download_file(input.file)
        except Exception as e:
            return self._delete_and_return(
                message=f"DOWNLOAD_FAILED: Failed to download file! Error = {e}",
            )

        self.doc = fitz.open(self.downloaded_files[len(self.downloaded_files) - 1])
        page_count = self.doc.page_count
        if input.page_range:
            validation = self._validate_page_range(
                input.page_range.start_page, input.page_range.end_page, page_count
            )
            if not validation[0]:
                return self._delete_and_return(
                    message=f"PAGE_RANGE_VALIDATION_FAILED: {str(validation[1])}",
                )

        start_index = input.page_range.start_page - 1 if input.page_range else 0
        stop_index = (
            input.page_range.end_page
            if input.page_range and input.page_range.end_page <= page_count
            else page_count
        )

        data: list[ExtractedTextPng] = []
        for page in range(start_index, stop_index):
            condition_satisfied = True
            if input.conditions:
                for condition in input.conditions:
                    cnd_text = self._extract_text(page, condition.position)
                    if cnd_text != condition.match_text:
                        condition_satisfied = False
            if condition_satisfied:
                extracted_text_object = ExtractedTextPng(page_num=page + 1)
                for pos in input.text_positions:
                    text = self._extract_text(page, pos)
                    png = (
                        self._extract_png(page) if input.extract_as_png_base64 else None
                    )
                    extracted_text_object.extracted_text.append(text)
                    if png:
                        extracted_text_object.extracted_png_base64.append(png)
                data.append(extracted_text_object)

        if hasattr(self, "doc"):
            self.doc.close()
        self._delete_files()

        return ActionResponse(
            result=PdfInfoExtractorOutput(
                data=data,
                metadata=Metadata(
                    title=pydash.get(self.doc.metadata, "title", ""),
                    content_type=self.content_type,
                ),
                message=f"Extracted {len(data)} element(s)",
            )
        )

    def _make_request(
        self, url: str, headers: dict[str, Any], timeout: int | None = None
    ):
        headers = headers
        keys = [x.lower().strip() for x in list(headers.keys())]
        if "user-agent" not in keys:
            headers["User-Agent"] = DEFAULT_USER_AGENT

        response = requests.get(
            url=url,
            headers=headers,
            timeout=timeout or 300,
            allow_redirects=True,
        )

        return response

    def _download_file(self, file: FileObject):
        url = file.url.strip()
        gdrive_id_match = re.match(".*drive.google.com/file/d/(.*?)(?:/|$)", url)
        if gdrive_id_match:
            url = f"https://drive.usercontent.google.com/download?id={gdrive_id_match.group(1)}&export=download"
            file.headers["User-Agent"] = (
                "bot/downloader-agent"  # this is an arbitrary user-agent, DEFAULT_USER_AGENT is not working for gdrive
            )

        if not url.startswith("http"):
            url = "https://" + url
        response = self._make_request(url, file.headers, file.timeout)
        if response.status_code == 200:
            if file.has_browser_based_redirection:
                redirected_url = get_redirect_url_from_html(response.content)
                if redirected_url:
                    response = self._make_request(
                        redirected_url, file.headers, file.timeout
                    )
                else:
                    raise Exception(f"Failed to find redirect url in {file.url}")
            self.content_type = (
                pydash.get(response.headers, "Content-Type", "")
                .strip()
                .split(";")[0]
                .strip()
            )
            file_type = MimeTypes().guess_extension(self.content_type)
            if file_type not in self.supported_file_types:
                raise Exception(
                    f"Unsupported content type: {self.content_type}! Should be a PDF / BIN url only"
                )
            file_name = f"{config.get_tmp_dir()}/{str(uuid.uuid4())}.pdf"
            with open(file_name, "wb") as f:
                f.write(response.content)
            self.downloaded_files.append(file_name)
        else:
            raise Exception(
                f"Failed to fetch url: {file.url}. Response Code = {response.status_code}"
            )

    def _validate_page_range(
        self, start_page: int, end_page: int, page_count: int
    ) -> list[Union[bool, str, None]]:
        if start_page <= 0:
            return [False, "Start Page cannot be negative or zero"]
        if end_page <= 0:
            return [False, "End Page cannot be negative or zero"]
        if start_page > end_page:
            return [False, "Start Page cannot be more than End Page"]
        if start_page > page_count:
            return [False, "Start Page cannot be more than PDF page count"]

        return [True, None]

    def _extract_text(self, page_num: int, position: Position):
        page = self.doc.load_page(page_num)
        text_array = page.get_textbox(
            fitz.Rect(position.x0, position.y0, position.x1, position.y1)
        ).split("\n")
        # This extract text has some placeholder text along with the text we are extracting so filtering it out eg: "123456789 ABCDEFGHI ABCDEFGHI ABCDE" (Placeholder text) for word: "Animal Healthcare Department"
        final_text = ""
        for text in text_array:
            text = text.strip()
            if len(text) and (not "ABCD" in text):
                final_text += text + "\n"

        final_text = pydash.clean(final_text)

        return final_text if len(final_text) else "NA"

    def _extract_png(self, page_num: int):
        page = self.doc.load_page(page_num)
        pix = page.get_pixmap()  # type: ignore
        to_base64 = base64.encodebytes(pix.tobytes()).decode("ascii")
        return to_base64

    def _delete_files(self):
        # Delete files from local
        for file in self.downloaded_files:
            if os.path.exists(file):
                delete_file(file)
        self.downloaded_files = []

    def _delete_and_return(self, message: str):
        title = ""
        if hasattr(self, "doc"):
            title = pydash.get(self.doc.metadata, "title", "")
            self.doc.close()
        self._delete_files()

        return ActionResponse(
            result=PdfInfoExtractorOutput(
                data=[],
                message=message,
                metadata=Metadata(title=title, content_type=self.content_type),
            )
        )
