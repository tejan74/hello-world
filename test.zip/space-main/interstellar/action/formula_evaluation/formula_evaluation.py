from typing import Any
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
import execjs
from provider._classes import ProviderResponseError
from util.logger import interstellar_logger
import signal

logger = interstellar_logger(__name__)


class JavascriptFormulaExecutionInput(BaseActionInput):
    formula: str


class JavascriptFormulaExecutionOutput(BaseActionOutput):
    # TODO: Add more datatypes here or support custom return types
    output: str | dict[str, Any] | list[Any] | None | int | float


class TimeoutException(Exception):
    pass


class JavascriptFormulaExecutionAction(
    BaseAction[JavascriptFormulaExecutionInput, JavascriptFormulaExecutionOutput]
):
    """
    JavaScript Formula Executor.
    """

    id = "ag5669240-9ddf-456e-a270-3abdf39b5928"
    name = "Formula"
    description = "JavaScript Formula"
    icon = "https://www.javascript.com/etc.clientlibs/pluralsight/clientlibs/clientlib-main/resources/images/favicons/favicon.ico"
    default_output_path = "result.output"
    input_schema = JavascriptFormulaExecutionInput
    output_schema = JavascriptFormulaExecutionOutput
    usage = ActionUsage(units=0, unit_type="credit")
    tags = ["Formulas"]

    def _run(
        self, input: JavascriptFormulaExecutionInput
    ) -> ActionResponse[JavascriptFormulaExecutionOutput]:
        """
        Execute a Javascript Formula.
        """
        try:
            output = self._get_result(input.formula)
            return ActionResponse(
                result=JavascriptFormulaExecutionOutput(output=output)
            )
        except Exception as e:
            return ActionResponse(error=ActionError(code="ERROR", message=str(e), e=e))

    def _get_result(self, js_expression, timeout=2):
        def timeout_handler(signum, frame):
            raise TimeoutException("Timeout expired")

        # Register the signal handler
        signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(timeout)  # Set the timeout
        try:
            # Execute your function or code here
            js_code = """
                    function evaluateExp(expression) {
                        let result;
                        try {
                            result = eval(expression);
                        } catch (error) {
                            result = 'Error evaluating expression: ' + error;
                        }
                        return result;
                    }
                    """
            ctx = execjs.compile(js_code)
            result = ctx.call("evaluateExp", js_expression)
            return result
        except TimeoutException as e:
            logger.exception(
                f"Timeout error for the expression {js_expression} and the exception is {e}"
            )
            return f"Timeout Error: {e}"
        except Exception as e:
            logger.exception(
                f"Something went wrong while compiling the expression {js_expression} and the exception is {e}"
            )
            return "Invalid Formula"
        finally:
            signal.alarm(0)  # Cancel the alarm
