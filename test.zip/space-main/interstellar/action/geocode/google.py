import pydash
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import google_maps
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class GoogleGeocodeInput(BaseActionInput):
    api_key: str | None = None
    address: str


class GoogleGeocodeOutput(BaseActionOutput):
    address: str
    lat: float
    lng: float


class GoogleGeocodeAction(BaseAction[GoogleGeocodeInput, GoogleGeocodeOutput]):

    id = "d4f05e80-484c-4bb8-9ff4-26870b635e20"
    name = "Geocode Address"
    description = "Get the latitude and longitude of an address."
    icon = "https://www.google.com/images/branding/product/ico/maps15_bnuw3a_32dp.ico"
    default_output_path = "result.address"
    input_schema = GoogleGeocodeInput
    output_schema = GoogleGeocodeOutput
    usage = ActionUsage(units=1, unit_type="credit")  # I don't know the correct credits
    tags = ["Maps & Locations"]

    def _run(self, input: GoogleGeocodeInput) -> ActionResponse[GoogleGeocodeOutput]:
        try:
            client = google_maps.ApiClient(input.api_key)
            results = client.geocode(input.address)

            if results is None or len(results) == 0:
                logger.error("No results found.", extra={"address": input.address})
                return ActionResponse(
                    error=ActionError(
                        code="NOT_FOUND", message="No results found.", e=None
                    )
                )

            return ActionResponse(
                result=GoogleGeocodeOutput(
                    address=pydash.get(results[0], "formatted_address"),
                    lat=pydash.get(results[0], "geometry.location.lat"),
                    lng=pydash.get(results[0], "geometry.location.lng"),
                )
            )

        except Exception as e:
            logger.exception(
                "Error geocoding address.", extra={"address": input.address}
            )
            return ActionResponse(
                error=ActionError(
                    code="ERROR", message="Error geocoding address - " + str(e), e=e
                )
            )
