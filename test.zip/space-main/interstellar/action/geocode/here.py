from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import here_maps
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class HereGeocodeInput(BaseActionInput):
    api_key: str | None = None
    address: str


class HereGeocodeOutput(BaseActionOutput):
    address: str
    lat: float
    lng: float


class HereGeocodeAction(BaseAction[HereGeocodeInput, HereGeocodeOutput]):

    id = "c8477695-fe36-4134-a998-1b59b08d5716"
    name = "Geocode Address"
    description = "Get the latitude and longitude of an address."
    icon = "https://www.here.com/themes/custom/here_com_theme/favicon.ico"
    default_output_path = "result.address"
    input_schema = HereGeocodeInput
    output_schema = HereGeocodeOutput
    usage = ActionUsage(units=1, unit_type="credit")  # I don't know the correct credits
    tags = ["Maps & Locations"]

    def _run(self, input: HereGeocodeInput) -> ActionResponse[HereGeocodeOutput]:
        try:
            self.api = here_maps.ApiClient(input.api_key)
            output = self.api.geocode(input.address)
            items = output.get("items")

            if items is None or len(items) == 0:
                logger.error("No results found.", extra={"address": input.address})
                return ActionResponse(
                    error=ActionError(
                        code="NOT_FOUND", message="No results found.", e=None
                    )
                )

            logger.info(
                "Found address.", extra={"address": input.address, "count": len(items)}
            )
            result = HereGeocodeOutput(
                address=items[0]["address"]["label"],
                lat=items[0]["position"]["lat"],
                lng=items[0]["position"]["lng"],
            )

            return ActionResponse(result=result)

        except Exception as e:
            logger.exception(
                "Error geocoding address.", extra={"address": input.address}
            )
            return ActionResponse(
                error=ActionError(
                    code="ERROR", message="Error geocoding address - " + str(e), e=e
                )
            )
