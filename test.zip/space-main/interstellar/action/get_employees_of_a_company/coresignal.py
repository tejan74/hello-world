from typing import Any, cast
from more_itertools import interleave_longest, unique_everseen
import pydantic

from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import coresignal, gis
from lib.coresignal.constant import SupportedCountries
from lib.coresignal.helper import (
    CoreSignalDBCache,
    CoreSignalMaxQueryCountExceedException,
    build_coresignal_search_query,
    split_query_if_long,
    surface_leads_current_exp,
)

from util.gis import parse_zipcode
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class CoresignalTitlesInput(pydantic.BaseModel):
    required_titles: list[str] | None = None
    optional_titles: list[str] | None = None
    titles_weight: list[dict[str, str | int]] | None = None
    filter_titles: list[str] | None = None


class RequestGetByZip(CoresignalTitlesInput):
    company_linkedin: str
    lead_count: int
    zip: str
    region_code: str
    radius: int | None = 50
    model_config = {"json_schema_extra": {"title": "Zipcode"}}


class RequestGetGlobal(CoresignalTitlesInput):
    company_linkedin: str
    lead_count: int
    model_config = {"json_schema_extra": {"title": "Globally"}}


class RequestGetByCountry(CoresignalTitlesInput):
    company_linkedin: str
    country: set[SupportedCountries] | str
    lead_count: int

    model_config = {"json_schema_extra": {"title": "Country"}}


class CoresignalGetEmployeesOfACompanyInput(BaseActionInput):
    api_key: str | None = None
    input_type: RequestGetGlobal | RequestGetByZip | RequestGetByCountry = (
        pydantic.Field(
            ...,
            title="Get employees by",
            description="Choose how you want to find the employees either by zip or country or globally",
        )
    )


class RequestGetByCityState(CoresignalTitlesInput):
    company_linkedin: str
    locations: list[dict[str, str]] = []
    lead_count: int
    country: set[SupportedCountries] | str | None = None


# Unified model for lead
class Job(pydantic.BaseModel):
    title: str | None = None
    date_to: str | None = None
    date_from: str | None = None
    duration: str | int | None = None
    location: str | None = None
    company_url: str | None = None
    company_name: str | None = None


class Lead(pydantic.BaseModel):
    name: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    title: str | None = None
    url: str | None = None
    location: str | None = None
    industry: str | None = None
    summary: str | None = None
    country: str | None = None
    connections_count: int | None = None
    experience_count: int | None = None
    job: Job | None = None


# Result as part of response
class CoresignalGetEmployeesOfACompanyOutput(BaseActionOutput):
    leads: list[Lead]
    count: int


class CoresignalGetEmployeesOfACompanyAction(
    BaseAction[
        CoresignalGetEmployeesOfACompanyInput, CoresignalGetEmployeesOfACompanyOutput
    ]
):
    id = "078b5ad0-8ce5-4a91-86e3-5d80b8b0d839"
    name = "Get Company Employees with Coresignal"
    description = "Find Company Leads from Linkedin by Coresignal"
    icon = "https://www.linkedin.com/favicon.ico"
    default_output_path = "result.count"
    input_schema = CoresignalGetEmployeesOfACompanyInput
    output_schema = CoresignalGetEmployeesOfACompanyOutput
    usage = ActionUsage(units=1, unit_type="credit")  # I don't know the correct credits
    tags = ["Companies"]

    def _run(
        self, input: CoresignalGetEmployeesOfACompanyInput
    ) -> ActionResponse[CoresignalGetEmployeesOfACompanyOutput]:
        self.cs = coresignal.ApiClient(input.api_key, CoreSignalDBCache())
        self.gis = gis.GIS()

        input_class = input.input_type.__class__.__name__

        if input_class == "RequestGetByZip":
            req = cast(RequestGetByZip, input.input_type)
            return self._get_by_zip(req)
        elif input_class == "RequestGetByCountry":
            req = cast(RequestGetByCountry, input.input_type)
            return self._get_by_country(req)
        else:
            req = cast(RequestGetGlobal, input.input_type)
            return self._get_global(req)

    def _get_by_zip(
        self, req: RequestGetByZip
    ) -> ActionResponse[CoresignalGetEmployeesOfACompanyOutput]:
        pzip = parse_zipcode(req.zip)
        radius = req.radius or 50

        if not req.zip or req.zip == "NA" or req.zip == "#N/A":
            logger.debug("NO_ZIP_CODE")
            return ActionResponse(
                error=ActionError(code="NO_ZIP_CODE", message="No zip code provided")
            )

        locations = self.gis.locations_near_zip(pzip["zip"], req.region_code, radius)

        if not locations:
            logger.debug("ZIP_NOT_FOUND")
            return ActionResponse(
                error=ActionError(code="ZIP_NOT_FOUND", message="Zip not found")
            )

        logger.debug("location count %s", len(locations))

        leads = self._get_by_city_state(
            req=RequestGetByCityState(
                company_linkedin=req.company_linkedin,
                locations=locations,
                lead_count=req.lead_count,
                country=None,
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                titles_weight=req.titles_weight,
                filter_titles=req.filter_titles,
            )
        )
        return leads

    def _get_global(
        self, req: RequestGetGlobal
    ) -> ActionResponse[CoresignalGetEmployeesOfACompanyOutput]:
        leads = self._get_by_city_state(
            req=RequestGetByCityState(
                company_linkedin=req.company_linkedin,
                locations=[],
                lead_count=req.lead_count,
                country=None,
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                titles_weight=req.titles_weight,
                filter_titles=req.filter_titles,
            )
        )
        return leads

    def _get_by_country(
        self, req: RequestGetByCountry
    ) -> ActionResponse[CoresignalGetEmployeesOfACompanyOutput]:
        if not req.country:
            logger.error("Invalid param: country")
            return ActionResponse(
                error=ActionError(code="VALUE_E", message="Invalid param: country")
            )

        leads = self._get_by_city_state(
            req=RequestGetByCityState(
                company_linkedin=req.company_linkedin,
                locations=[],
                lead_count=req.lead_count,
                country=req.country,
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                titles_weight=req.titles_weight,
                filter_titles=req.filter_titles,
            )
        )
        return leads

    def _get_by_city_state(
        self, req: RequestGetByCityState
    ) -> ActionResponse[CoresignalGetEmployeesOfACompanyOutput]:
        """Get leads for a company."""

        try:
            company = self.cs.get_company_by_linkedin(req.company_linkedin)
        except coresignal.CoreSignalException as e:
            logger.exception("Core signal, company error", e)
            # Rate limit exceeded
            if e.status_code == 429 or e.status_code == 503:
                logger.info(f"Rate limit exceeded while getting members: {e}")
                return ActionResponse(
                    error=ActionError(
                        code=f"CORESIGNAL_COMPANY_ERROR_{e.status_code}",
                        message="Core signal member search rate limit exceeded error",
                        retryable=True,
                        e=e,
                    )
                )

            return ActionResponse(
                error=ActionError(
                    code=f"CORESIGNAL_COMPANY_ERROR_{e.status_code}",
                    message="Core signal, company error",
                    e=e,
                )
            )
        except Exception as e:
            logger.exception("Unknown Error when calling coresignal company", e)
            return ActionResponse(
                error=ActionError(
                    code="UNKNOWN_ERROR",
                    message="Unknown Error when calling coresignal company",
                    e=e,
                )
            )
        if not company:
            return ActionResponse(
                error=ActionError(code="COMPANY_NOT_FOUND", message="Company not found")
            )

        # Convert the string to SupportedCountries Literal and create a set
        try:
            if isinstance(req.country, str):
                if req.country in SupportedCountries.__args__:
                    countries: set[SupportedCountries] | None = {
                        cast(SupportedCountries, req.country)
                    }
                else:
                    raise ValueError(
                        f"Country '{req.country}' is not in supported format"
                    )
            else:
                countries = req.country
        except ValueError as ve:
            logger.error("Country conversion error: %s", ve)
            return ActionResponse(
                error=ActionError(
                    code="INVALID_COUNTRY",
                    message=str(ve),
                    e=ve,
                )
            )
        except Exception as e:
            logger.exception("Unknown error during country conversion", exc_info=True)
            return ActionResponse(
                error=ActionError(
                    code="COUNTRY_CONVERSION_ERROR",
                    message="Unknown error during country conversion",
                    e=e,
                )
            )

        try:
            query_builder = lambda l: build_coresignal_search_query(
                company,
                l,
                countries,
                req.required_titles,
                req.optional_titles,
                req.titles_weight,
                req.filter_titles,
            )
            queries = split_query_if_long(req.locations, query_builder)
            logger.debug("Query count %s", len(queries))
        except CoreSignalMaxQueryCountExceedException:
            logger.exception("Query Split error")
            return ActionResponse(
                error=ActionError(code="QUERY_SPLIT_ERROR", message="Query Split error")
            )

        try:
            lead_ids = list(
                unique_everseen(
                    interleave_longest(
                        *map(lambda q: self.cs.search_members_es(q)[0], queries)
                    )
                )
            )
            logger.debug("lead_ids count %s", len(lead_ids))
            logger.debug("lead_ids %s", lead_ids)
        except coresignal.CoreSignalException as e:
            logger.exception("Core signal, search error", e)
            # Rate limit exceeded
            if e.status_code == 429 or e.status_code == 503:
                logger.info(f"Rate limit exceeded while getting members: {e}")
                return ActionResponse(
                    error=ActionError(
                        code=f"CORESIGNAL_MEMBER_ERROR_{e.status_code}",
                        message="Core signal member search rate limit exceeded error",
                        retryable=True,
                        e=e,
                    )
                )

            return ActionResponse(
                error=ActionError(
                    code=f"CORESIGNAL_MEMBER_ERROR_{e.status_code}",
                    message="Core signal member search error",
                    e=e,
                )
            )
        except Exception as e:
            logger.exception("Unknown Error when calling coresignal search", e)
            return ActionResponse(
                error=ActionError(
                    code="CORESIGNAL_MEMBER_SEARCH_UNKNOWN_ERROR",
                    message="Unknown Error when calling coresignal search",
                    e=e,
                )
            )

        leads: list[dict[str, Any]] = []
        for i in range(0, min(req.lead_count, len(lead_ids))):
            error_count = 0
            try:
                lead = self.cs.get_member_by_id(lead_ids[i])
                surface_leads_current_exp(lead, company["id"])
                leads.append(lead)
            except coresignal.CoreSignalException as e:
                logger.exception("Core signal, member collect error", e)
                error_count += 1
                if error_count >= 3:
                    # TODO: anktih: Need you help in understanding this
                    # leads.extend(
                    #     lead_error_result(
                    #         f"CONTINUES_CORESIGNAL_ERROR_{e.status_code} | CORESIGNAL-MEMBER-COLLECT"
                    #     )
                    # )
                    break
            except Exception as e:
                logger.exception(
                    "Unknown Error when calling coresignal memeber collect", e
                )
                return ActionResponse(
                    error=ActionError(
                        code="CORESIGNAL_MEMBER_COLLECT_UNKNOWN_ERROR",
                        message="Unknown Error when calling coresignal member collect",
                        e=e,
                    )
                )

        return ActionResponse(
            result=CoresignalGetEmployeesOfACompanyOutput(
                leads=[
                    Lead(
                        name=l.get("name"),
                        first_name=l.get("first_name"),
                        last_name=l.get("last_name"),
                        title=l.get("title"),
                        url=l.get("url"),
                        location=l.get("location"),
                        industry=l.get("industry"),
                        summary=l.get("summary"),
                        country=l.get("country"),
                        connections_count=l.get("connections_count"),
                        experience_count=l.get("experience_count"),
                        job=l.get("current_experience"),
                    )
                    for l in leads
                ],
                count=len(leads),
            )
        )
