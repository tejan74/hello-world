from typing import cast
from more_itertools import unique_everseen
import pydantic

from action.base import BaseAction
from action.types import ActionError, ActionResponse, BaseActionInput, BaseActionOutput
from engine._classes import ActionUsage
from lib import coresignal
from lib import gis
from lib.coresignal.constant import SupportedCountries
from lib.coresignal.helper import CoreSignalDBCache
from lib.coresignal.helper import (
    CoreSignalMaxQueryCountExceedException,
    build_coresignal_search_query,
    split_query_if_long,
)


from util.gis import parse_zipcode
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class CoresignalTitlesInput(pydantic.BaseModel):
    required_titles: list[str] | None = None
    optional_titles: list[str] | None = None
    titles_weight: list[dict[str, str | int]] | None = None
    filter_titles: list[str] | None = None


# Interfaces for request
class RequestHeadcountByZip(CoresignalTitlesInput):
    linkedin: str
    zip: str
    region_code: str
    radius: int | None = 50
    model_config = {"json_schema_extra": {"title": "Zipcode"}}


class RequestHeadcountByCountry(CoresignalTitlesInput):
    linkedin: str
    country: set[SupportedCountries] | SupportedCountries
    model_config = {"json_schema_extra": {"title": "Country"}}


class RequestHeadcountGlobal(CoresignalTitlesInput):
    linkedin: str
    model_config = {"json_schema_extra": {"title": "Globally"}}


class CoresignalGetHeadcountOfACompanyInput(BaseActionInput):
    api_key: str | None = None
    input_type: (
        RequestHeadcountGlobal | RequestHeadcountByZip | RequestHeadcountByCountry
    ) = pydantic.Field(
        ...,
        title="Get headcount by",
        description="Choose how you want to find the headcount either by zip or country or globally",
    )


class RequestHeadcountByLocation(CoresignalTitlesInput):
    linkedin: str
    locations: list[dict]
    country: set[SupportedCountries] | SupportedCountries | None = None


# Build the result from running this provider
class CoresignalGetHeadcountOfACompanyOutput(BaseActionOutput):
    count: int


class CoresignalGetHeadcountOfACompanyAction(
    BaseAction[
        CoresignalGetHeadcountOfACompanyInput, CoresignalGetHeadcountOfACompanyOutput
    ]
):

    id = "8df10c5f-11d9-4353-a34d-357055e5d4ee"
    name = "Get Company Size with Coresignal"
    description = "Find Company Headcount by Coresignal"
    icon = "https://www.linkedin.com/favicon.ico"
    default_output_path = "result.count"
    input_schema = CoresignalGetHeadcountOfACompanyInput
    output_schema = CoresignalGetHeadcountOfACompanyOutput
    tags = ["Companies"]

    def _run(
        self, input: CoresignalGetHeadcountOfACompanyInput
    ) -> ActionResponse[CoresignalGetHeadcountOfACompanyOutput]:
        self.api_key = input.api_key

        input_class = input.input_type.__class__.__name__

        if input_class == "RequestGetByZip":
            req = cast(RequestHeadcountByZip, input.input_type)
            return self._headcount_by_zip(req)
        elif input_class == "RequestGetByCountry":
            req = cast(RequestHeadcountByCountry, input.input_type)
            return self._headcount_by_country(req)
        else:
            req = cast(RequestHeadcountGlobal, input.input_type)
            return self._headcount_global(req)

    # Get headcount by zip code
    def _headcount_by_zip(
        self, req: RequestHeadcountByZip
    ) -> ActionResponse[CoresignalGetHeadcountOfACompanyOutput]:

        _gis = gis.GIS()

        # strip domain in place
        req.linkedin = req.linkedin.strip()

        # validations
        if not req.linkedin or req.linkedin in ["NA", "#N/A"]:
            return ActionResponse(
                error=ActionError(code="NO_LINKEDIN", message="No linkedin provided")
            )

        if (req.zip and not req.region_code) or (req.region_code and not req.zip):
            return ActionResponse(
                error=ActionError(
                    code="ZIP_REGION_CODE_MISMATCH",
                    message="Both Zip and region code must be provided",
                )
            )

        # get locations from zip and region if provided
        locations = []
        if req.zip and req.region_code:
            parsed_zip = parse_zipcode(req.zip)
            locations = _gis.locations_near_zip(
                parsed_zip["zip"], req.region_code, req.radius or 50
            )

            if not locations:
                return ActionResponse(
                    error=ActionError(
                        code="ZIP_NOT_FOUND", message="No locations found for zip code"
                    )
                )

        # get headcount from locations
        return self._headcount_by_locations(
            RequestHeadcountByLocation(
                linkedin=req.linkedin,
                locations=locations,
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                filter_titles=req.filter_titles,
                titles_weight=req.titles_weight,
            )
        )

    # Get headcount by country
    def _headcount_by_country(
        self, req: RequestHeadcountByCountry
    ) -> ActionResponse[CoresignalGetHeadcountOfACompanyOutput]:
        # strip domain in place
        req.linkedin = req.linkedin.strip()

        # validations
        if not req.linkedin or req.linkedin in ["NA", "#N/A"]:
            return ActionResponse(
                error=ActionError(code="NO_LINKEDIN", message="No linkedin provided")
            )

        # get headcount from locations
        return self._headcount_by_locations(
            RequestHeadcountByLocation(
                linkedin=req.linkedin,
                locations=[],
                country=req.country,
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                filter_titles=req.filter_titles,
                titles_weight=req.titles_weight,
            )
        )

    # Get global headcount
    def _headcount_global(
        self, req: RequestHeadcountGlobal
    ) -> ActionResponse[CoresignalGetHeadcountOfACompanyOutput]:
        # strip domain in place
        req.linkedin = req.linkedin.strip()

        # validations
        if not req.linkedin or req.linkedin in ["NA", "#N/A"]:
            return ActionResponse(
                error=ActionError(code="NO_LINKEDIN", message="No linkedin provided")
            )

        # get headcount from locations
        return self._headcount_by_locations(
            RequestHeadcountByLocation(
                linkedin=req.linkedin,
                locations=[],
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                filter_titles=req.filter_titles,
                titles_weight=req.titles_weight,
            )
        )

    # Get headcount by locations
    def _headcount_by_locations(
        self, req: RequestHeadcountByLocation
    ) -> ActionResponse[CoresignalGetHeadcountOfACompanyOutput]:
        search_credits = 0
        collect_credits = 0

        def get_usage() -> ActionUsage:
            if search_credits + collect_credits == 0:
                return ActionUsage(units=0, unit_type="credit")
            return ActionUsage(
                units=collect_credits * 4 + search_credits,
                unit_type="credit",
                extra_data={
                    "collect_credits": collect_credits,
                    "search_credits": search_credits,
                    "collect_multiplier": 4,
                },
            )

        # get company from linkedin
        try:
            cs = coresignal.ApiClient(self.api_key, CoreSignalDBCache())
            company = cs.get_company_by_linkedin(req.linkedin)
            collect_credits += 1
        except coresignal.CoreSignalException as e:
            logger.exception("Core signal, company error", e)
            # Rate limit exceeded
            if e.status_code == 429 or e.status_code == 503:
                logger.info(f"Rate limit exceeded while getting members: {e}")
                return ActionResponse(
                    error=ActionError(
                        code=str(e.status_code),
                        message="Core signal member search rate limit exceeded error",
                        retryable=True,
                        e=e,
                    )
                )

            return ActionResponse(
                error=ActionError(
                    code=f"CORESIGNAL_COMPANY_ERROR_{e.status_code}",
                    message=str(e),
                    e=e,
                ),
                usage=get_usage(),
            )
        except Exception as e:
            logger.exception("Unknown Error when calling coresignal company", e)
            return ActionResponse(
                error=ActionError(
                    code="CORESIGNAL_COMPANY_UNKNOWN_ERROR", message=str(e), e=e
                ),
                usage=get_usage(),
            )

        # validate if coresignal company exists
        if not company:
            return ActionResponse(
                error=ActionError(
                    code="CORESIGNAL_COMPANY_ERROR",
                    message=f"Company not found for linkedin: {req.linkedin}",
                ),
                usage=get_usage(),
            )

        try:
            if isinstance(req.country, str):
                if req.country in SupportedCountries.__args__:
                    countries: set[SupportedCountries] | None = {
                        cast(SupportedCountries, req.country)
                    }
                else:
                    raise ValueError(
                        f"Country '{req.country}' is not in supported format"
                    )
            else:
                countries = req.country
        except ValueError as ve:
            logger.error("Country conversion error: %s", ve)
            return ActionResponse(
                error=ActionError(
                    code="INVALID_COUNTRY",
                    message=str(ve),
                    e=ve,
                )
            )
        except Exception as e:
            logger.exception("Unknown error during country conversion", exc_info=True)
            return ActionResponse(
                error=ActionError(
                    code="COUNTRY_CONVERSION_ERROR",
                    message="Unknown error during country conversion",
                    e=e,
                )
            )

        # build search query and split into multiple queries if too long
        try:
            query_builder = lambda l: build_coresignal_search_query(
                company,
                l,
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                filter_titles=req.filter_titles,
                titles_weight=req.titles_weight,
                countries=countries,
            )
            queries = split_query_if_long(req.locations, query_builder)
        except CoreSignalMaxQueryCountExceedException:
            logger.exception("Query Split error")
            return ActionResponse(
                error=ActionError(
                    code="CORESIGNAL_SPLIT_ERROR_422", message="Query split error"
                ),
                usage=get_usage(),
            )

        # run queries and get headcount
        try:
            count = 0
            if len(queries) == 1:
                [_, _count] = cs.search_members_es(queries[0])
                count = _count
                search_credits += 1
            else:
                allIds: list[int] = []
                # this runs through split queries and counts unique ids
                for query in queries:
                    [ids, count] = cs.search_members_es(query)
                    if count >= cs.MAX_PAGE_SIZE:
                        # TODO: ankith - can't we paginate here?
                        return ActionResponse(
                            error=ActionError(
                                code="CORESIGNAL_SPLIT_ERROR_422",
                                message=f"Implied 422 - sub query has count {count} ",
                            )
                        )
                    allIds.extend(ids)
                count = len(list(unique_everseen(allIds)))

            return ActionResponse(
                result=CoresignalGetHeadcountOfACompanyOutput(count=count),
                usage=get_usage(),
            )
        except coresignal.CoreSignalException as e:
            logger.exception("Core signal, search error", e)
            # Rate limit exceeded
            if e.status_code == 429 or e.status_code == 503:
                logger.info(f"Rate limit exceeded while getting members: {e}")
                return ActionResponse(
                    error=ActionError(
                        code=str(e.status_code),
                        message="Core signal member search rate limit exceeded error",
                        retryable=True,
                        e=e,
                    )
                )

            # TODO: Do we always get status code?
            return ActionResponse(
                error=ActionError(
                    code=f"CORESIGNAL_MEMBER_SEARCH_ERROR_{e.status_code}",
                    message=str(e),
                    e=e,
                ),
                usage=get_usage(),
            )
        except Exception as e:
            logger.exception("Unknown Error when calling coresignal search", e)
            return ActionResponse(
                error=ActionError(
                    code="CORESIGNAL_MEMBER_SEARCH_UNKNOWN_ERROR", message=str(e), e=e
                ),
                usage=get_usage(),
            )
