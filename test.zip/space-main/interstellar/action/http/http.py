import pydantic
import requests
from typing import Any, Literal
from action.base import BaseAction
from action.types import ActionResponse, ActionUsage, BaseActionInput, BaseActionOutput
from util.http import HttpMethods


class HttpInput(BaseActionInput):
    # TODO (ankith): support authentications like Oauth, login cookie, jwt etc.
    method: HttpMethods
    url: str
    query: dict[str, str] = {}
    headers: dict[str, str] = {}
    body_type: Literal["json", "other"] = "json"
    body: str | None = None
    timeout: int = pydantic.Field(
        title="Timeout (seconds)", default=3 * 60, lt=10 * 60, gt=10
    )  # default 3 minutes, max 10 minutes, min 10 seconds


class HttpOutput(BaseActionOutput):
    status_code: int
    headers: dict[str, str]
    body: str | dict[str, Any] | list[Any] | str | int | float | None


class HttpAction(BaseAction[HttpInput, HttpOutput]):

    id = "f2bac9c7-3725-43c2-aa38-745cc427e94c"
    name = "HTTP Request"
    description = "Make an http request"
    icon = "IconApi"
    default_output_path = "result.status_code"
    input_schema = HttpInput
    output_schema = HttpOutput
    usage = ActionUsage(units=0, unit_type="credit")
    tags = ["Web"]

    def _run(self, input: HttpInput) -> ActionResponse[HttpOutput]:
        req = requests.Request(
            method=input.method,
            url=input.url,
            params=input.query,
            headers=input.headers,
            data=input.body,
        ).prepare()

        if (
            req.method in ["POST", "PUT", "PATCH"]
            and req.body
            and input.body_type == "json"
        ):
            req.headers["Content-Type"] = "application/json"

        session = requests.Session()
        res = session.send(req, timeout=input.timeout)
        session.close()

        return ActionResponse(
            result=HttpOutput(
                status_code=res.status_code,
                headers=dict(res.headers),
                body=(
                    res.json()
                    if res.headers.get("Content-Type") == "application/json"
                    else res.text
                ),
            )
        )
