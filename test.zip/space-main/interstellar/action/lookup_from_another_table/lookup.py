from typing import Any
import pydantic
from action.base import BaseAction
from action.types import ActionResponse, ActionUsage, BaseActionInput, BaseActionOutput
import json
from prisma import Prisma, models
import pydash
import config
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class TableLookupInput(BaseActionInput):
    source_table: str = pydantic.Field(json_schema_extra={"format": "table-select"})
    source_column: str = pydantic.Field(
        title="Source Match Column", json_schema_extra={"format": "column-select-table"}
    )
    source_pull_column: str = pydantic.Field(
        title="Source Data Column", json_schema_extra={"format": "column-select-table"}
    )
    destination_table: str = pydantic.Field(
        title="Destination Table (do not change)",
        default="{{__TABLE_UUID__}}",
        json_schema_extra={"hidden": True, "format": "hidden"},
    )
    destination_row: str = pydantic.Field(
        title="Destination Row (do not change)",
        default="{{__ROW_UUID__}}",
        json_schema_extra={"hidden": True, "format": "hidden"},
    )
    destination_column: str = pydantic.Field(
        title="Destination Match Column",
        json_schema_extra={"format": "column-select-self"},
    )


class TableLookupOutput(BaseActionOutput):
    raw_value: Any
    displayed_value: Any


class TableLookupAction(BaseAction[TableLookupInput, TableLookupOutput]):
    id = "0acce83f-d892-4d3b-bce4-35148d7a5c56"
    name = "Read from another Table"
    description = "Read / import a column from another table by matching a column value"
    icon = "IconTableFilled"
    default_output_path = "result.displayed_value"
    input_schema = TableLookupInput
    output_schema = TableLookupOutput
    usage = ActionUsage(units=0, unit_type="credit")
    tags = ["Custom"]

    _static_type = ["TEXT", "NUMBER", "BOOL", "DATE"]

    def _run(self, input: TableLookupInput) -> ActionResponse[TableLookupOutput]:
        with Prisma(datasource={"url": config.get_parameter("DATABASE_URL")}) as prisma:
            dest_value = self._get_dest_value(prisma, input)
            if dest_value is None:
                logger.warning("Destination value is None, skipping")
                return ActionResponse(
                    result=TableLookupOutput(raw_value=None, displayed_value=None)
                )

            pull_row = self._get_pull_row(prisma, input, dest_value)
            if pull_row is None:
                logger.warning("Pull row is None, skipping")
                return ActionResponse(
                    result=TableLookupOutput(raw_value=None, displayed_value=None)
                )

            pulled_data, pulled_data_path = self._get_pulled_data(
                prisma, input, pull_row
            )

            return ActionResponse(
                result=TableLookupOutput(
                    raw_value=pulled_data,
                    displayed_value=(
                        pydash.get(pulled_data, pulled_data_path)
                        if pulled_data_path
                        else pulled_data
                    ),
                )
            )

    def _get_dest_value(self, prisma: Prisma, input: TableLookupInput) -> Any:
        dest_column = prisma.ui_column.find_first(
            where={
                "tableUuid": input.destination_table,
                "uuid": input.destination_column,
            },
            include={"DynamicColumnConfig": True},
        )
        if dest_column is None:
            raise ValueError("Destination column not found")

        dest_value = None
        if dest_column.type in self._static_type:
            stat = prisma.ui_staticdata.find_first(
                where={
                    "columnUuid": input.destination_column,
                    "rowUuid": input.destination_row,
                }
            )
            if stat:
                dest_value = stat.data
        elif dest_column.type == "DYNAMIC":
            if dest_column.DynamicColumnConfig is None:
                raise ValueError("Dynamic column config not found")
            dyn = prisma.query_first(
                """
                select distinct on ("instanceId","stepId") * from "WF_StepState" 
                where "instanceId" = $1 and "stepId" = $2
                order by "instanceId", "stepId", "createdAt" desc limit 1
            """,
                input.destination_row,
                dest_column.internalId,
                model=models.WF_StepState,
            )
            if dyn:
                dest_value = pydash.get(
                    dyn.output, dest_column.DynamicColumnConfig.outputPath
                )
        elif dest_column.type == "DERIVED":
            raise NotImplementedError("Derived columns not supported yet")
        else:
            raise ValueError("Destination column type not recognized")

        return dest_value

    def _get_pull_row(
        self, prisma: Prisma, input: TableLookupInput, dest_value: str
    ) -> str | None:
        src_column = prisma.ui_column.find_first(
            where={
                "tableUuid": input.source_table,
                "uuid": input.source_column,
            },
            include={"DynamicColumnConfig": True},
        )

        if src_column is None:
            raise ValueError("Source column not found")

        pull_row = None
        str_dest_value = (
            dest_value if type(dest_value) == str else json.dumps(dest_value)
        )
        if src_column.type in self._static_type:
            stat = prisma.ui_staticdata.find_first(
                where={
                    "columnUuid": input.source_column,
                    "data": str_dest_value,
                }
            )
            if stat:
                pull_row = stat.rowUuid
        elif src_column.type == "DYNAMIC":
            if src_column.DynamicColumnConfig is None:
                raise ValueError("Dynamic column config not found")
            dyn = prisma.query_first(
                """
                select * from (
                    select distinct on ("instanceId","stepId") * from "WF_StepState" 
                    where "stepId" = $1 and "workflowId" = $2
                    order by "instanceId", "stepId", "createdAt" desc
                ) sq
                where "output" #>> $3 = $4 limit 1
            """,
                src_column.internalId,
                input.source_table,
                (
                    src_column.DynamicColumnConfig.outputPath.split(".")
                    if src_column.DynamicColumnConfig.outputPath
                    else []
                ),
                str_dest_value,
                model=models.WF_StepState,
            )

            if dyn:
                pull_row = dyn.instanceId
        elif src_column.type == "DERIVED":
            raise NotImplementedError("Derived columns not supported yet")
        else:
            raise ValueError("Source column type not recognized")

        return pull_row

    def _get_pulled_data(
        self, prisma: Prisma, input: TableLookupInput, pull_row: str
    ) -> Any:
        pull_column = prisma.ui_column.find_first(
            where={
                "uuid": input.source_pull_column,
                "tableUuid": input.source_table,
            },
            include={"DynamicColumnConfig": True},
        )

        if pull_column is None:
            raise ValueError("Pull column not found")

        pulled_data = None
        pulled_data_path = None
        if pull_column.type in self._static_type:
            stat = prisma.ui_staticdata.find_first(
                where={
                    "columnUuid": input.source_pull_column,
                    "rowUuid": pull_row,
                }
            )
            if stat:
                pulled_data = stat.data
                pulled_data_path = None
        elif pull_column.type == "DYNAMIC":
            if pull_column.DynamicColumnConfig is None:
                raise ValueError("Dynamic column config not found")
            dyn = prisma.query_first(
                """
                select distinct on ("instanceId","stepId") * from "WF_StepState" 
                where "instanceId" = $1 and "stepId" = $2
                order by "instanceId", "stepId", "createdAt" desc limit 1
            """,
                pull_row,
                pull_column.internalId,
                model=models.WF_StepState,
            )
            if dyn:
                pulled_data = dyn.output
                pulled_data_path = pull_column.DynamicColumnConfig.outputPath
        elif pull_column.type == "DERIVED":
            raise NotImplementedError("Derived columns not supported yet")
        else:
            raise ValueError("Pull column type not recognized")

        return pulled_data, pulled_data_path
