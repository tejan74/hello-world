import pydantic
import pydash
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import google_maps

from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class GoogleNearbyInput(BaseActionInput):
    api_key: str | None = None
    query: str
    lat: float
    lng: float
    radius: int | None = None
    limit: int | None = None


class Location(pydantic.BaseModel):
    name: str
    address: str | None = None
    lat: float
    lng: float


class GoogleNearbyOutput(BaseActionOutput):
    items: list[Location]
    count: int


class GoogleNearbyAction(BaseAction[GoogleNearbyInput, GoogleNearbyOutput]):

    id = "c88be9c4-593c-4de4-b9ff-b51e37427631"
    name = "Find nearby places (Google Maps)"
    description = "Find nearby places based on the given location"
    icon = "https://www.google.com/images/branding/product/ico/maps15_bnuw3a_32dp.ico"
    default_output_path = "result.count"
    input_schema = GoogleNearbyInput
    output_schema = GoogleNearbyOutput
    usage = ActionUsage(units=1, unit_type="credit")  # I don't know the correct credits
    tags = ["Maps & Locations"]

    def _run(self, input: GoogleNearbyInput) -> ActionResponse[GoogleNearbyOutput]:
        client = google_maps.ApiClient(input.api_key)
        query, lat, lng, radius, limit = (
            input.query,
            input.lat,
            input.lng,
            input.radius,
            input.limit,
        )

        try:
            response = client.places_nearby(
                lat=lat,
                lng=lng,
                radius=radius,
                keyword=query,
            )

            results = response["results"]

            if results is None or len(results) == 0:
                logger.error("No results found.", extra={"query": query})
                results = []

            logger.info(
                "Found nearby places.", extra={"query": query, "count": len(results)}
            )
            items = [
                Location(
                    name=pydash.get(item, "name", None),
                    address=pydash.get(item, "vicinity", None),
                    lat=pydash.get(item, "geometry.location.lat", None),
                    lng=pydash.get(item, "geometry.location.lng", None),
                )
                for item in results
            ]

            return ActionResponse(
                result=GoogleNearbyOutput(items=items, count=len(items))
            )
        except Exception as e:
            logger.exception("Error getting nearby places.", extra={"query": query})
            return ActionResponse(
                error=ActionError(
                    code="ERROR", message="Error getting nearby places - " + str(e), e=e
                )
            )
