import pydantic
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import here_maps
from pydash import get
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class HereNearbyInput(BaseActionInput):
    api_key: str | None = None
    query: str
    lat: float
    lng: float
    radius: int | None = None
    limit: int | None = None


class Location(pydantic.BaseModel):
    name: str
    address: str | None = None
    lat: float
    lng: float


class HereNearbyOutput(BaseActionOutput):
    items: list[Location]
    count: int


class HereNearbyAction(BaseAction[HereNearbyInput, HereNearbyOutput]):
    id = "4cba682f-3cc2-49bc-9ad2-ae777034c020"
    name = "Find nearby places (Here Maps)"
    description = "Find nearby places based on the given location"
    icon = "https://www.here.com/themes/custom/here_com_theme/favicon.ico"
    default_output_path = "result.count"
    input_schema = HereNearbyInput
    output_schema = HereNearbyOutput
    usage = ActionUsage(units=1, unit_type="credit")  # I don't know the correct credits
    tags = ["Maps & Locations"]

    def _run(self, input: HereNearbyInput) -> ActionResponse[HereNearbyOutput]:
        try:
            self.api = here_maps.ApiClient(input.api_key)
            query, lat, lng, radius, limit = (
                input.query,
                input.lat,
                input.lng,
                input.radius,
                input.limit,
            )

            output = self.api.discover(
                query=query, latitude=lat, longitude=lng, radius=radius, limit=limit
            )

            items = output.get("items")

            # If no results found, return error.
            if items is None or len(items) == 0:
                logger.error("No results found.", extra={"query": query})
                items = []

            # transform results into NearbyItem objects
            logger.info(
                "Found nearby places.", extra={"query": query, "count": len(items)}
            )
            items = [
                Location(
                    name=get(item, "title", None),
                    address=get(item, "address.label", None),
                    lat=get(item, "position.lat", None),
                    lng=get(item, "position.lng", None),
                )
                for item in items
            ]

            return ActionResponse(
                result=HereNearbyOutput(items=items, count=len(items))
            )

        except Exception as e:
            logger.exception("Error getting nearby places.", extra={"query": query})
            return ActionResponse(
                error=ActionError(
                    code="ERROR", message="Error getting nearby places - " + str(e), e=e
                )
            )
