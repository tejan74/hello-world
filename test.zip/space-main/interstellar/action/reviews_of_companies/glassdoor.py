import datetime
import re
import pydantic
import pydash
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
import config
from util.db import get_db_connection
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class GlassdoorReviewsInput(BaseActionInput):
    company_website: str
    keywords: list[str]
    from_date: datetime.date | None = None
    to_date: datetime.date | None = None
    limit: int | None = None


class Review(pydantic.BaseModel):
    link: str | None
    review: str | None
    date: str | None
    keywords_match: str | None
    location: str | None


class GlassdoorReviewsOutput(BaseActionOutput):
    reviews: list[Review]
    count: int


class GlassdoorReviewsAction(BaseAction[GlassdoorReviewsInput, GlassdoorReviewsOutput]):
    id = "14429869-7a70-4313-b607-6eccc81c7f3f"
    name = "Employee Reviews"
    description = "Get employee reviews for a company"
    icon = "https://www.glassdoor.com/favicon.ico"
    default_output_path = "result.count"
    input_schema = GlassdoorReviewsInput
    output_schema = GlassdoorReviewsOutput
    usage = ActionUsage(units=0, unit_type="credit")
    tags = ["Companies"]

    _db_url = config.get_parameter("TOOLS_DB_URL")

    def _run(
        self, input: GlassdoorReviewsInput
    ) -> ActionResponse[GlassdoorReviewsOutput]:
        try:
            self._db = get_db_connection(self._db_url)

            # extract domain from url
            domain_match = re.match(
                r"(?:.*://)?(?:www\.)?([^/?]*)", input.company_website
            )
            if not domain_match or not domain_match.group(1):
                return ActionResponse(
                    error=ActionError(
                        message="Invalid domain",
                        code="INVALID_DOMAIN",
                    )
                )

            domain = domain_match.group(1)
            reviews: list[Review] = []
            with self._db.cursor() as cur:
                # find company with given domain
                cur.execute(
                    """SELECT "sourceId" FROM "EDS_GlassdoorCompany" WHERE "domain" = %s order by "sourceId" asc """,
                    [domain],
                )

                if cur.rowcount == 0:
                    logger.info("Didn't find any company with domain '%s'", domain)
                    return ActionResponse(
                        error=ActionError(
                            message="No company found with given domain",
                            code="NO_COMPANY_FOUND",
                        )
                    )

                # sometimes there are multiple companies with same domain and only one of them will
                # have review, since its hard determine which is real. we will get all their reviews
                company_ids = pydash.flatten(cur.fetchall())
                logger.debug("Found company with id %s", company_ids)

                # create tsquery for keywords
                keyword_tsq = self._generate_ts_query(input.keywords)
                results = []

                company_ids = list(company_ids)
                # find reviews for each company
                # TODO find company with most reviews and use that as main company
                for company_id in company_ids:
                    query = """
                        SELECT "sourceId", "pros", "date", "authorLocation", 
                            ts_rank(ts_pros, to_tsquery('english', %s)) as rank,
                            ts_headline('english', pros, to_tsquery('english', %s)) as headline
                        from "EDS_GlassdoorReview" where "companyId" = %s and "ts_pros" @@ to_tsquery('english', %s)
                    """
                    if input.from_date or input.to_date:
                        date_condition = ' and "date" between %s and %s'
                        query += date_condition
                        params = [
                            keyword_tsq,
                            keyword_tsq,
                            company_id,
                            keyword_tsq,
                            (
                                input.from_date.strftime("%Y-%m-%d")
                                if input.from_date
                                else "0001-01-01"
                            ),
                            (
                                input.to_date.strftime("%Y-%m-%d")
                                if input.to_date
                                else "9999-12-31"
                            ),
                        ]
                    else:
                        params = [keyword_tsq, keyword_tsq, company_id, keyword_tsq]

                    query += ' order by "rank", "date"'

                    if input.limit:
                        query += " limit %s"
                        params = [*params, input.limit]

                    cur.execute(query, params)

                    if cur.rowcount == 0:
                        logger.info(
                            "Cannot find any reviews for company '%s' with keywords_tsq '%s'",
                            company_id,
                            keyword_tsq,
                        )
                    else:
                        results.append(cur.fetchall())

                # sort by rank and by date
                results = pydash.sort_by(
                    pydash.flatten(results), lambda x: (x[4], x[2]), reverse=True
                )
                # create response
                for result in results:
                    keywords_match_list = re.findall(r"<b>(.*?)<\/b>", result[5])
                    reviews.append(
                        Review(
                            link="https://www.glassdoor.com/Reviews/Employee-Review-"
                            + result[0]
                            + ".htm",
                            review=result[1],
                            keywords_match=str(keywords_match_list),
                            date=result[2].strftime("%Y-%m-%d %H:%M:%S"),
                            location=result[3],
                        )
                    )

            self._db.close()
            return ActionResponse(
                result=GlassdoorReviewsOutput(reviews=reviews, count=len(reviews))
            )

        except Exception as e:
            logger.exception(
                "Error while getting reviews for company '%s' with keywords '%s'",
                input.company_website,
                input.keywords,
            )
            return ActionResponse(
                error=ActionError(
                    message="Error while getting reviews",
                    code="ERROR_GETTING_REVIEWS",
                    e=e,
                )
            )

    def _generate_ts_query(self, keywords: list[str]):
        # Transform to ts_query format from the given keywords. Example keywords = ["free food", "snacks", "unlimited sick leaves"] will be converted to "(free <-> food) | (snacks) | (unlimited <-> sick <-> leaves)" and then the final query will look something like to_tsquery('english', (free <-> food) | (snacks) | (unlimited <-> sick <-> leaves))
        updated_keywords: list[str] = []
        for keyword in keywords:
            ck = self._clean_keywords(pydash.clean(keyword))
            updated_keywords.append(f'({" <-> ".join(ck.split())})')

        return " | ".join(updated_keywords)

    def _clean_keywords(self, s: str) -> str:
        # TODO: Revisit this to make sure this is the best strategy
        return re.sub(r"[^\w ]", " ", s)
