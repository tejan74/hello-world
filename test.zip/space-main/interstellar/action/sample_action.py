from typing import Any, override
from action import (
    ActionResponse,
    ActionResumeState,
    BaseAction,
    BaseResumableAction,
    ResumableActionResponse,
)
from action.types import ActionUsage, BaseActionInput, BaseActionOutput


class TestInput(BaseActionInput):
    input: str


class TestOutput(BaseActionOutput):
    output: str


class TestActionWithStaticUsage(BaseAction[TestInput, TestOutput]):
    id = "test-action-static-usage"
    name = "test"
    description = "Test action with static usage"
    icon = "test"
    default_output_path = "result.output"
    input_schema = TestInput
    output_schema = TestOutput
    usage = ActionUsage(units=1, unit_type="credit")

    @override
    def _run(self, input: TestInput, **kwargs: Any) -> ActionResponse[TestOutput]:
        return ActionResponse(
            result=TestOutput(output=f"{input.input}-{self.run_id}"),
        )


class TestAction(BaseAction[TestInput, TestOutput]):
    id = "test-action"
    name = "test"
    description = "Test action"
    icon = "test"
    default_output_path = "result.output"
    input_schema = TestInput
    output_schema = TestOutput

    @override
    def _run(self, input: TestInput, **kwargs: Any) -> ActionResponse[TestOutput]:
        id = kwargs.get("run_id")
        return ActionResponse(
            result=TestOutput(output=f"{input.input}-{id}"),
            usage=ActionUsage(units=1, unit_type="credit"),
        )


class TestResumeAction(BaseResumableAction[TestInput, TestOutput, TestOutput]):
    id = "test-resume-action"
    name = "test-resume"
    description = "Test action with resume"
    icon = "test"
    default_output_path = "result.output"
    input_schema = TestInput
    output_schema = TestOutput
    partial_state_schema = TestOutput
    usage_type = "test"

    def _run(self, input: TestInput) -> ResumableActionResponse[TestOutput, TestOutput]:
        return ResumableActionResponse(
            resume=ActionResumeState(poll_time=30, state=TestOutput(output="resume")),
            usage=ActionUsage(units=1, unit_type="credit"),
        )

    def _resume(
        self,
        type: str,
        input: TestInput,
        state: TestOutput,
        webhook_data: dict[str, Any] | None = None,
    ) -> ResumableActionResponse[TestOutput, TestOutput]:
        print(f"Resuming action with state: {state.output}, type {type}")

        return ResumableActionResponse(
            result=TestOutput(output=f"{input.input}-{self.run_id}"),
            usage=ActionUsage(units=1, unit_type="credit"),
        )


a = TestAction()
b = TestResumeAction()
