from typing import Any

import pydantic
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionError, ActionResponse, ActionUsage
import config
from lib.zenrows import ZenRowsClient
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class WebScrapeInput(BaseActionInput):
    url: str
    premium_proxy: bool = (
        False  # Use premium proxies to make the request harder to detect.
    )
    proxy_country: str | None = pydantic.Field(
        None,
        description="The country code of the proxy to use. Default is US when proxy_country is enabled.",
        title="Proxy Country",
    )
    api_key: str | None = None
    parse_html: bool = True
    get_images: bool = False
    remove_styles_script_svg: bool = pydantic.Field(
        True,
        description="Remove styles, scripts, and svg tags from the html content",
        title="Remove Styles, Scripts, SVG",
    )


class Link(pydantic.BaseModel):
    link: str | None = None
    text: str | None = None


class Image(pydantic.BaseModel):
    src: str | None = None
    alt: str | None = None


class WebScrapeOutput(BaseActionOutput):
    text_content: str = ""
    links: list[Link]
    images: list[Image] | None = []
    title: str | None = ""
    description: str | None = ""
    url: str
    base_uri: str | None = None


class WebScrapeAction(BaseAction[WebScrapeInput, WebScrapeOutput]):
    id = "zenrows-enrich-web-scrapper"
    name = "Scrape a website with Zenrows"
    description = "Fetches and enriches web data using Zenrows with customizable options."  # premium proxies, CSS extraction, and a wait time of 10 milliseconds
    icon = "https://cdn.zenrows.com/images/favicon.ico"
    default_output_path = "result"
    input_schema = WebScrapeInput
    output_schema = WebScrapeOutput
    usage_type = None
    tags = ["Web"]

    def _run(
        self, input: WebScrapeInput, **kwargs: Any
    ) -> ActionResponse[WebScrapeOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("ZENROWS_API_KEY")
        )
        client = ZenRowsClient(api_key=self.api_key)
        status_code = client.web_scraper(
            url=input.url,
            premium_proxy=input.premium_proxy,
            proxy_country=(
                "us"  # Default to US
                if input.premium_proxy and (input.proxy_country is None)
                else input.proxy_country
            ),
            wait="10",
            js_render=True,
        )
        # Rate limit exceeded
        if status_code == 429:
            logger.info(f"Rate limit exceeded while scraping url: {input.url}")
            return ActionResponse(
                error=ActionError(
                    code=f"{client.response.status_code}",
                    message=client.response.text,
                    retryable=True,
                ),
                usage=ActionUsage(
                    units=1,
                    unit_type="credit",
                ),
            )

        # Any other errors
        # TODO: Do this better and handle each error separately
        if status_code != 200:
            logger.info(
                f"Failed to scrape url: {input.url}, status code: {status_code}, content: {client.get_raw()}"
            )
            return ActionResponse(
                result=WebScrapeOutput(
                    text_content=f"FAILED_TO_SCRAPE, error code: {status_code}. content: {client.get_raw()}",
                    links=[],
                    images=[],
                    url=input.url,
                    title=None,
                    description=None,
                ),
                usage=ActionUsage(
                    units=0,
                    unit_type="credit",
                ),
            )

        content = (
            client.scrape_full_text()
            if input.parse_html
            else client.get_raw(input.remove_styles_script_svg)
        )
        links = client.scrape_links()
        images = client.scrape_images() if input.get_images else []
        meta = client.get_meta()
        logger.info(
            f"Scraped {input.url} successfully. Found {len(links)} links and text with length {len(content)}."
        )

        return ActionResponse(
            result=WebScrapeOutput(
                text_content=content,
                links=links,
                images=images,
                url=input.url,
                title=meta.get("title"),
                description=meta.get("description"),
                base_uri=client.get_base_uri(),
            ),
            usage=ActionUsage(
                units=1,
                unit_type="credit",
            ),
        )
