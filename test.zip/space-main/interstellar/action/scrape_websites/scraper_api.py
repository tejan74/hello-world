from typing import Any
import pydantic
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionError, ActionResponse, ActionUsage
from lib import scraper_api
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class ScraperApiWebScraperInput(BaseActionInput):
    url: str
    headers: dict[str, Any] | None = None
    parse_html: bool = True
    get_images: bool = False
    enable_proxy: bool = False
    proxy_country: str | None = None
    advanced_bypass: bool = False
    disable_redirects: bool = False
    remove_styles_script_svg: bool = pydantic.Field(
        True,
        description="Remove styles, scripts, and svg tags from the html content",
        title="Remove Styles, Scripts, SVG",
    )


class Link(pydantic.BaseModel):
    link: str | None = None
    text: str | None = None


class Image(pydantic.BaseModel):
    src: str | None = None
    alt: str | None = None


class ScraperApiWebScraperOutput(BaseActionOutput):
    text_content: str = ""
    links: list[Link]
    images: list[Image] | None = []
    title: str | None = ""
    description: str | None = ""
    url: str
    base_uri: str | None = None


class ScraperApiWebScraperAction(
    BaseAction[ScraperApiWebScraperInput, ScraperApiWebScraperOutput]
):
    id = "7c5ddca9-d940-497b-8d18-2e1749f94e3c"
    name = "Web Page Scraper (Scraper Api)"
    description = "Scrape web page and get data"
    icon = "https://logo.clearbit.com/scraperapi.com"
    default_output_path = "result.url"
    input_schema = ScraperApiWebScraperInput
    output_schema = ScraperApiWebScraperOutput
    usage = ActionUsage(units=1, unit_type="credit")
    tags = ["Web"]

    def _run(
        self, input: ScraperApiWebScraperInput
    ) -> ActionResponse[ScraperApiWebScraperOutput]:
        scraper = scraper_api.ApiClient()
        logger.info(f"Scraping {input.url}")
        try:
            status_code = scraper.load_url(
                input.url,
                input.headers,
                input.enable_proxy,
                input.proxy_country,
                input.advanced_bypass,
                input.disable_redirects,
            )

            # Rate limit exceeded
            if status_code == 429:
                logger.info(f"Rate limit exceeded while scraping url: {input.url}")
                return ActionResponse(
                    error=ActionError(
                        code=f"{scraper.response.status_code}",
                        message=scraper.response.text,
                        retryable=True,
                    )
                )

            # Any other errors
            # TODO: Do this better and handle each error separately
            if status_code != 200:
                logger.info(
                    f"Failed to scrape url: {input.url}, status code: {status_code}, content: {scraper.get_raw()}"
                )
                return ActionResponse(
                    result=ScraperApiWebScraperOutput(
                        text_content=f"FAILED_TO_SCRAPE, error code: {status_code}. content: {scraper.get_raw()}",
                        links=[],
                        images=[],
                        url=input.url,
                        title=None,
                        description=None,
                    )
                )

            content = (
                scraper.scrape_full_text()
                if input.parse_html
                else scraper.get_raw(input.remove_styles_script_svg)
            )
            links = scraper.scrape_links()
            images = scraper.scrape_images() if input.get_images else []
            meta = scraper.get_meta()

            logger.info(
                f"Scraped {input.url} successfully. Found {len(links)} links and text with length {len(content)}."
            )

            return ActionResponse(
                result=ScraperApiWebScraperOutput(
                    text_content=content,
                    links=links,
                    images=images,
                    url=input.url,
                    title=meta.get("title"),
                    description=meta.get("description"),
                    base_uri=scraper.get_base_uri(),
                )
            )
        except Exception as e:
            logger.exception(f"Error occurred while scraping {input.url}")
            return ActionResponse(
                error=ActionError(
                    code="SCRAPER_ERROR", message="Error while scraping", e=e
                )
            )
