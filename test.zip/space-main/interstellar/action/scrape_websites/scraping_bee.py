from typing import Any

import pydantic
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import scraping_bee
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class ScrapingBeeWebScraperInput(BaseActionInput):
    url: str
    headers: dict[str, Any] | None = None
    parse_html: bool = True
    get_images: bool = False
    remove_styles_script_svg: bool = pydantic.Field(
        True,
        description="Remove styles, scripts, and svg tags from the html content",
        title="Remove Styles, Scripts, SVG",
    )


class Link(pydantic.BaseModel):
    link: str | None = None
    text: str | None = None


class Image(pydantic.BaseModel):
    src: str | None = None
    alt: str | None = None


class ScrapingBeeWebScraperOutput(BaseActionOutput):
    text_content: str = ""
    links: list[Link]
    images: list[Image] | None = []
    title: str | None = ""
    description: str | None = ""
    url: str
    base_uri: str | None = None


class ScrapingBeeWebScraperAction(
    BaseAction[ScrapingBeeWebScraperInput, ScrapingBeeWebScraperOutput]
):
    id = "e5f6c278-59ac-4d00-be1f-2299d61645a1"
    name = "Web Page Scraper (ScrapingBee)"
    description = "Scrape web page and get data"
    icon = "https://logo.clearbit.com/scrapingbee.com"
    default_output_path = "result.url"
    input_schema = ScrapingBeeWebScraperInput
    output_schema = ScrapingBeeWebScraperOutput
    usage = ActionUsage(units=1, unit_type="credit")
    tags = ["Web"]

    def _run(
        self, input: ScrapingBeeWebScraperInput
    ) -> ActionResponse[ScrapingBeeWebScraperOutput]:
        url = input.url.strip()
        if not url.startswith("http"):
            url = "https://" + url

        scraper = scraping_bee.ApiClient()
        logger.info(f"Scraping {url}")
        try:
            status_code = scraper.load_url(url, input.headers or {})

            # Rate limit exceeded
            if status_code == 429:
                logger.info(f"Rate limit exceeded while scraping url: {url}")
                return ActionResponse(
                    error=ActionError(
                        code=f"{scraper.response.status_code}",
                        message=scraper.response.text,
                        retryable=True,
                    )
                )

            # Any other errors
            # TODO: Do this better and handle each error separately
            if status_code != 200:
                logger.info(
                    f"Failed to scrape url: {url}, status code: {status_code}, content: {scraper.get_raw()}"
                )
                return ActionResponse(
                    result=ScrapingBeeWebScraperOutput(
                        text_content=f"FAILED_TO_SCRAPE, error code: {status_code}. content: {scraper.get_raw()}",
                        links=[],
                        images=[],
                        url=url,
                        title=None,
                        description=None,
                    )
                )

            content = (
                scraper.scrape_full_text() if input.parse_html else scraper.get_raw()
            )
            links = scraper.scrape_links()
            images = scraper.scrape_images() if input.get_images else []
            meta = scraper.get_meta()

            logger.info(
                f"Scraped {url} successfully. Found {len(links)} links and text with length {len(content)}."
            )

            return ActionResponse(
                result=ScrapingBeeWebScraperOutput(
                    text_content=content,
                    links=links,
                    images=images,
                    url=url,
                    title=meta.get("title"),
                    description=meta.get("description"),
                    base_uri=scraper.get_base_uri(),
                )
            )
        except Exception as e:
            logger.exception(f"Error occurred while scraping {url}")
            return ActionResponse(
                error=ActionError(
                    code="SCRAPER_ERROR", message="Error while scraping", e=e
                )
            )
