import pydantic
import pydash
from action.base import BaseAction
from action.types import ActionResponse, ActionUsage, BaseActionInput, BaseActionOutput
from lib import google_search
from lib.google_search import FILE_TYPE_ALLOW_LIST
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class GoogleWebSearchInput(BaseActionInput):
    query: str
    limit: int | None = None
    file_type: FILE_TYPE_ALLOW_LIST | None = None


class Item(pydantic.BaseModel):
    title: str | None
    link: str | None
    displayLink: str | None
    snippet: str | None
    fileFormat: str | None = None
    mime: str | None = None
    position: int | None = None


class GoogleWebSearchOutput(BaseActionOutput):
    items: list[Item]
    count: int


class GoogleWebSearchAction(BaseAction[GoogleWebSearchInput, GoogleWebSearchOutput]):
    id = "e076aaee-039f-4ecf-8d83-91a33c37eeb6"
    name = "Google Search"
    description = "Search the web using Google"
    icon = "https://www.google.com/favicon.ico"
    default_output_path = "result.items.0"
    input_schema = GoogleWebSearchInput
    output_schema = GoogleWebSearchOutput
    usage = ActionUsage(units=1, unit_type="credit")
    tags = ["Web"]

    def _run(
        self, input: GoogleWebSearchInput
    ) -> ActionResponse[GoogleWebSearchOutput]:
        self.client = google_search.ApiClient()

        query, limit, file_type = input.query, input.limit, input.file_type
        logger.info(f"Searching for {query}")

        # Run the search query using Google Search API
        try:
            response = self.client.search(query, limit, file_type)
            logger.info(f"Google response =========== {response}")
            items = response.get("items") or []

            if response is None or len(items) == 0:
                logger.error(f"No results for {query}")
                return ActionResponse(result=GoogleWebSearchOutput(items=[], count=0))

            return ActionResponse(
                result=GoogleWebSearchOutput(
                    items=[
                        Item(
                            title=pydash.get(item, "title", None),
                            link=pydash.get(item, "link", None),
                            displayLink=pydash.get(item, "displayLink", None),
                            snippet=pydash.get(item, "snippet", None),
                            fileFormat=pydash.get(item, "fileFormat", None),
                            mime=pydash.get(item, "mime", None),
                        )
                        for item in response["items"]
                    ],
                    count=len(response["items"]),
                )
            )
        except Exception as e:
            logger.exception(f"Error searching for {query}")
            return ActionResponse(
                result=GoogleWebSearchOutput(items=[], count=-1),
            )
