import pydantic
import pydash
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import google_search, scraper_api
from lib.google_search import FILE_TYPE_ALLOW_LIST
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class ScraperApiGoogleWebSearchInput(BaseActionInput):
    query: str
    limit: int | None = None
    file_type: FILE_TYPE_ALLOW_LIST | None = None


class Item(pydantic.BaseModel):
    title: str | None
    link: str | None
    displayLink: str | None
    snippet: str | None
    fileFormat: str | None = None
    mime: str | None = None
    position: int | None = None


class ScraperApiGoogleWebSearchOutput(BaseActionOutput):
    items: list[Item]
    count: int


class ScraperApiGoogleWebSearchAction(
    BaseAction[ScraperApiGoogleWebSearchInput, ScraperApiGoogleWebSearchOutput]
):
    id = "b8920108-2c1e-41cf-a028-3382465df9dd"
    name = "Google Search V2 (Scraper API)"
    description = "Search the web using Google"
    icon = "https://logo.clearbit.com/scraperapi.com"
    default_output_path = "result.count"
    input_schema = ScraperApiGoogleWebSearchInput
    output_schema = ScraperApiGoogleWebSearchOutput
    usage = ActionUsage(units=1, unit_type="credit")
    tags = ["Web"]

    def _run(
        self, input: ScraperApiGoogleWebSearchInput
    ) -> ActionResponse[ScraperApiGoogleWebSearchOutput]:
        scraper = scraper_api.ApiClient()
        logger.info(f"Google search {input.query}")

        try:
            status, res = scraper.google_search(input.query, input.limit)

            # Rate limit exceeded
            if status == 429:
                logger.info(
                    f"Rate limit exceeded while google searching: {input.query}"
                )
                return ActionResponse(
                    error=ActionError(
                        code=f"{scraper.response.status_code}",
                        message=scraper.response.text,
                        retryable=True,
                    )
                )

            # Any other errors
            # TODO: Do this better and handle each error separately
            if status != 200:
                logger.error(
                    f"Error occurred while google searching {input.query}. Status code: {status}"
                )
                return ActionResponse(
                    result=ScraperApiGoogleWebSearchOutput(items=[], count=-1)
                )

            results = res["organic_results"] if "organic_results" in res else []
            logger.info(
                f"Google search {input.query} successfully. Found {len(results)} links."
            )

            return ActionResponse(
                result=ScraperApiGoogleWebSearchOutput(
                    items=[
                        Item(
                            title=pydash.get(item, "title", None),
                            link=pydash.get(item, "link", None),
                            displayLink=pydash.get(item, "displayed_link", None),
                            snippet=pydash.get(item, "snippet", None),
                            position=pydash.get(item, "position", None),
                        )
                        for item in results
                    ],
                    count=len(results),
                )
            )
        except Exception as e:
            logger.exception(f"Error occurred while google searching {input.query}")
            return ActionResponse(
                result=ScraperApiGoogleWebSearchOutput(items=[], count=-1),
            )
