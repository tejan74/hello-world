from typing import Any
from pysitemap import crawler
from pysitemap.parsers.lxml_parser import Parser
import pydantic
from action.base import BaseAction
from action.types import ActionResponse, ActionUsage, BaseActionInput, BaseActionOutput
import xml.etree.ElementTree as ET
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class GenerateSitemapInput(BaseActionInput):
    url: str
    http_request_options: dict[str, Any] = {"ssl": False}
    xml_path: str = "store/sitemap.xml"


class GenerateSitemapOutput(BaseActionOutput):
    # Only the links in the xml file without any tags
    links: list[str]
    # Count of the links in the xml file
    count: int
    # The raw content of the xml file without any cleanup
    raw_xml: str | None = None
    # The path where the xml file is stored
    xml_path: pydantic.json_schema.SkipJsonSchema[str | None] = None


class GenerateSitemapAction(BaseAction[GenerateSitemapInput, GenerateSitemapOutput]):
    id = "13333bbc-7b1b-424a-b146-958fc8eca4f0"
    name = "Generate Sitemap"
    description = "Generate a sitemap for a website"
    icon = "IconSitemap"
    default_output_path = "result.count"
    input_schema = GenerateSitemapInput
    output_schema = GenerateSitemapOutput
    usage = ActionUsage(units=0, unit_type="credit")
    tags = ["Web"]

    def _run(
        self, input: GenerateSitemapInput
    ) -> ActionResponse[GenerateSitemapOutput]:
        url, http_requests_options, xml_path = (
            input.url,
            input.http_request_options,
            input.xml_path,
        )
        # Generate the sitemap
        crawler(
            url,
            out_file=xml_path,
            http_request_options=http_requests_options,
            parser=Parser,
        )

        links = self._extract_links(xml_path)

        with open(xml_path, "r") as f:
            raw_xml = f.read()

        return ActionResponse(
            result=GenerateSitemapOutput(
                links=links, raw_xml=raw_xml, xml_path=xml_path, count=len(links)
            )
        )

    def _extract_links(self, xml_path: str):
        links: list[str] = []

        try:
            tree = ET.parse(xml_path)
            root = tree.getroot()
            for child in root:
                if child.tag.endswith("url"):
                    for sub_child in child:
                        if sub_child.tag.endswith("loc"):
                            text = sub_child.text
                            if isinstance(text, str):
                                links.append(text)
        except Exception as e:
            logger.exception(e)

        return links
