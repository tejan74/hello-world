import pydantic
import requests
from action.base import BaseAction
from action.types import ActionResponse, ActionUsage, BaseActionInput, BaseActionOutput
import xml.etree.ElementTree as ET
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class ParseSitemapInput(BaseActionInput):
    link: str
    user_agent: pydantic.json_schema.SkipJsonSchema[str] = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    )


class ParseSitemapOutput(BaseActionOutput):
    # Only the links in the xml file without any tags
    links: list[str]
    # Count of the links in the xml file
    count: int
    # The raw content of the xml file without any cleanup
    raw_xml: str | None = None
    # The path where the xml file is stored
    xml_path: pydantic.json_schema.SkipJsonSchema[str | None] = None


class ParseSitemapAction(BaseAction[ParseSitemapInput, ParseSitemapOutput]):
    id = "683772d6-d379-47ca-b38c-7e19df46bd63"
    name = "Sitemap Generator"
    description = "Generate a sitemap for a website and parse it to get all the links"
    icon = "https://app.withorbital.dev/favicon.ico"
    default_output_path = "result.count"
    input_schema = ParseSitemapInput
    output_schema = ParseSitemapOutput
    usage = ActionUsage(units=0, unit_type="credit")
    tags = ["Web"]

    def _run(self, input: ParseSitemapInput) -> ActionResponse[ParseSitemapOutput]:
        """
        Parse a sitemap URL and return a list of URLs.
        Recursively parses sub-sitemaps.
        """
        link, user_agent = input.link, input.user_agent
        try:
            urls = self._parse_sitemap(link, user_agent)
            return ActionResponse(
                result=ParseSitemapOutput(links=urls, count=len(urls))
            )
        except Exception as e:
            logger.exception(e)
            # !!! this change is for a poc, it should be reverted
            return ActionResponse(result=ParseSitemapOutput(links=[], count=0))
            # return Response(error=ProviderResponseError(code="", message = f"Failed to parse sitemap for {link}: {e}"))

    def _parse_sitemap(self, url: str, user_agent: str):
        """
        Parse a sitemap URL and return a list of URLs.
        Recursively parses sub-sitemaps.
        """
        headers = {"User-Agent": user_agent}
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            logger.error(f"Failed to retrieve {url}")
            raise Exception(f"Failed to retrieve {url}")
        urls = []
        try:
            root = ET.fromstring(response.content)
        except ET.ParseError:
            logger.error(f"Failed to parse XML from {url}")
            raise Exception(f"Failed to parse XML from {url}")
        # Check if there is a sitemap index
        if root.tag.endswith("sitemapindex"):
            logger.info(f"Found sitemap index at {url}")
            for child in root:
                if child.tag.endswith("sitemap"):
                    loc_elem = child.find("{*}loc")
                    sub_sitemap_url = loc_elem.text if loc_elem is not None else None
                    if sub_sitemap_url:
                        urls.extend(self._parse_sitemap(sub_sitemap_url, user_agent))
        else:
            for child in root:
                if child.tag.endswith("url"):
                    loc_elem = child.find("{*}loc")
                    if loc_elem is not None:
                        loc = loc_elem.text
                        urls.append(loc)
        return urls
