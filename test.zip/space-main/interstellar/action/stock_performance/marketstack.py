from datetime import date
from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.marketstack import MarketstackClient


class StockPerformanceInput(BaseActionInput):
    company_symbol: str
    from_date: date
    to_date: date
    api_key: str | None = None


class StockPerformanceOutput(BaseActionOutput):
    output: str


class StockPerformanceAction(BaseAction[StockPerformanceInput, StockPerformanceOutput]):
    id = "stock_performance_with_marketstack"
    name = "Stock Performance With MarketStack"
    description = "Retrieve stock performance data for a given company symbol within a specified date range using MarketStack."
    icon = "https://marketstack.com/site_images/marketstack_shortcut_icon.ico"
    default_output_path = "result.output"
    input_schema = StockPerformanceInput
    output_schema = StockPerformanceOutput
    usage_type = None
    tags = ["Stock"]

    def _run(
        self, input: StockPerformanceInput, **kwargs: Any
    ) -> ActionResponse[StockPerformanceOutput]:
        api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("MARKETSTACK_API_KEY")
        )
        client = MarketstackClient(api_key)
        from_date_str = input.from_date.strftime("%Y-%m-%d")
        to_date_str = input.to_date.strftime("%Y-%m-%d")
        response = client.calculate_percentage_change(
            symbol=input.company_symbol, from_date=from_date_str, to_date=to_date_str
        )

        if response is not None:
            return ActionResponse(
                result=StockPerformanceOutput(output=response),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=StockPerformanceOutput(output=""),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
