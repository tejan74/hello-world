import random
from typing import Any, Literal
from prisma import Json, Prisma
import pydantic
import pydash

from action.base_resume import BaseResumableAction, ResumeTriggerType
from action.types import (
    ActionError,
    ActionResumeState,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
    ResumableActionResponse,
)
import config
from lib.crm.hubspot._classes import AccessTokenExpired, Hubspot, HubspotParams
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Input(BaseActionInput):
    integration_uuid: str = pydantic.Field(
        title="Integration",
        description="Hubspot integration to use for syncing",
        json_schema_extra={"format": "IntegrationSelect", "integrationType": "hubspot"},
    )
    object_name: str = pydantic.Field(
        title="Hubspot Object",
        description="Hubspot crm object to sync",
        json_schema_extra={
            "format": "CrmObjectSelect",
            "integrationUuidField": "integration_uuid",
        },
    )
    field_mapping: list["FieldMap"] = pydantic.Field(
        title="Object fields",
        description="Fields in the object to sync",
        json_schema_extra={
            "format": "CrmObjectMapper",
            # setting type manually to render the format widget instead of fields inferred from type
            "type": "string",
            "integrationUuidField": "integration_uuid",
            "crmObjectIdField": "object_name",
        },
    )
    object_id: str | None = pydantic.Field(
        title="Update by object ID",
        description="ID of the object to update (highest priority)",
        default=None,
    )
    match_condition: list["MatchCondition"] | None = pydantic.Field(
        title="Update by match",
        description="Match conditions to find the object to update",
        default=None,
        json_schema_extra={
            "format": "CrmMatchCriteria",
            # setting type manually to render the format widget instead of fields inferred from type
            "type": "string",
            "integrationUuidField": "integration_uuid",
            "crmObjectIdField": "object_name",
            # unsetting anyof, so that rjsf doesn't show this field twice, cuz anyof and type doesn't go together
            "anyOf": None,
        },
    )


class FieldMap(pydantic.BaseModel):
    id: str
    label: str
    value: str | int | float | bool | None


class MatchCondition(pydantic.BaseModel):
    booleanOperator: Literal["AND", "OR"]
    conditions: list["Condition"]


class Condition(pydantic.BaseModel):
    fieldId: str
    label: str
    operator: Literal["EQ", "NEQ", "GT", "GTE", "LT", "LTE", "LIKE"]
    value: str | int | float | bool | None


class Output(BaseActionOutput):
    model_config = pydantic.ConfigDict(extra="allow")


class ResumeState(BaseActionOutput):
    token_retry_count: int
    old_access_token_checksum: str


class HubspotSyncAction(BaseResumableAction[Input, Output, ResumeState]):
    id = "sync-hubspot"
    name = "Hubspot Sync"
    description = "Sync data to Hubspot CRM"
    icon = "https://logo.clearbit.com/hubspot.com"
    default_output_path = "result.id"
    input_schema = Input
    output_schema = Output
    usage = ActionUsage(units=1, unit_type="credit")
    partial_state_schema = ResumeState
    tags = ["crm", "sync"]

    def _run(self, input: Input) -> ResumableActionResponse[Output, ResumeState]:
        if input.match_condition:
            return ResumableActionResponse(
                error=ActionError(
                    message="Match condition not supported in this version",
                    code="UNSUPPORTED",
                )
            )
        hs_params = self._get_integration_params(input.integration_uuid)
        api = Hubspot(
            HubspotParams(
                access_token=hs_params["access_token"],
                refresh_token=hs_params["refresh_token"],
                client_id=config.get_parameter("HUBSPOT_CLIENT_ID"),
                client_secret=config.get_parameter("HUBSPOT_CLIENT_SECRET"),
            )
        )
        object_data = (
            pydash.chain(input.field_mapping)
            .map_(lambda x: [x.id, x.value])
            .from_pairs()
            .value()
        )

        try:
            object_id = None
            if input.object_id:
                object_id = input.object_id

            if object_id:
                updated_obj = api._update_object(
                    input.object_name,
                    object_id,
                    object_data,
                )

                return ResumableActionResponse(
                    result=Output.model_validate(updated_obj)
                )
            else:
                created_obj = api._create_object(input.object_name, object_data)
                return ResumableActionResponse(
                    result=Output.model_validate(created_obj)
                )
        except AccessTokenExpired:
            logger.info("Access token expired, retrying")
            return ResumableActionResponse(
                resume=ActionResumeState(
                    poll_time=random.randint(5, 40),
                    state=ResumeState(
                        token_retry_count=1,
                        old_access_token_checksum=self._access_token_checksum(
                            hs_params["access_token"]
                        ),
                    ),
                )
            )

    def _resume(
        self,
        type: ResumeTriggerType,
        input: Input,
        state: ResumeState,
        webhook_data: dict[str, Any] | None = None,
    ):
        if input.match_condition:
            raise ValueError("Match condition not supported in this version")
        if type != "schedule":
            raise ValueError("Unsupported resume type")
        if state.token_retry_count > 3:
            raise ValueError("Token retry limit exceeded")

        self._update_access_token(
            input.integration_uuid, state.old_access_token_checksum
        )

        out = self._run(input)
        if out.resume:
            if out.resume.state:
                out.resume.state.token_retry_count = state.token_retry_count + 1
            else:
                raise ValueError("Resume state not found")
        return out

    def _get_integration_params(self, integration_uuid: str):
        with Prisma(datasource={"url": config.get_parameter("DATABASE_URL")}) as prisma:
            integration = prisma.tenantintegration.find_first(
                where={"uuid": integration_uuid}
            )
            if not integration:
                raise ValueError(f"Integration with uuid {integration_uuid} not found")

            integration_data = IntegrationData.model_validate(integration.data)

            return {
                "access_token": integration_data.accessToken,
                "refresh_token": integration_data.refreshToken,
            }
        pass

    def _update_access_token(
        self, integration_uuid: str, old_access_token_checksum: str
    ):
        hs_params = self._get_integration_params(integration_uuid)
        if (
            self._access_token_checksum(hs_params.get("access_token", ""))
            != old_access_token_checksum
        ):
            # Access token already updated by another within
            # the gap it took this resume instance to run so
            # assuming that it's a new token and no need to update
            logger.info(
                "Access token already updated by another instance, skipping update, old: '%s' new: '%s'",
                old_access_token_checksum,
                self._access_token_checksum(hs_params["access_token"]),
            )
            return

        api = Hubspot(
            HubspotParams(
                access_token=hs_params["access_token"],
                refresh_token=hs_params["refresh_token"],
                client_id=config.get_parameter("HUBSPOT_CLIENT_ID"),
                client_secret=config.get_parameter("HUBSPOT_CLIENT_SECRET"),
            )
        )
        token = api.refresh_access_token()
        access_token = token.get("access_token")
        if not access_token:
            raise ValueError("Failed to refresh access token, got empty access token")

        with Prisma(datasource={"url": config.get_parameter("DATABASE_URL")}) as prisma:
            integration = prisma.tenantintegration.find_first(
                where={"uuid": integration_uuid}
            )
            if not integration:
                raise ValueError(f"Integration with uuid {integration_uuid} not found")
            if not isinstance(integration.data, dict):
                raise ValueError(
                    f"Integration data is not a dict, got {type(integration.data)}"
                )
            integration.data["accessToken"] = access_token
            prisma.tenantintegration.update(
                where={"uuid": integration_uuid},
                data={"data": Json(integration.data)},
            )
            logger.info(
                "Updated access token for integration '%s'; old:'%s' new: '%s'",
                integration_uuid,
                self._access_token_checksum(hs_params["access_token"]),
                self._access_token_checksum(access_token),
            )

    def _access_token_checksum(self, access_token: str):
        return access_token[::3]


class IntegrationData(pydantic.BaseModel):
    # has more fields than this
    accessToken: str
    refreshToken: str
