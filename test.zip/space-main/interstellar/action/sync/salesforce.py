import random
import re
from typing import Any, Literal
from prisma import Json, Prisma
import pydantic
import pydash


from action.base_resume import BaseResumableAction, ResumeTriggerType
from action.types import (
    ActionResumeState,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
    ResumableActionResponse,
)
import config
from lib.crm.salesforce._classes import AccessTokenExpired, Salesforce
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Input(BaseActionInput):
    integration_uuid: str = pydantic.Field(
        title="Integration",
        description="Salesforce integration to use for syncing",
        json_schema_extra={"format": "IntegrationSelect"},
    )
    object_name: str = pydantic.Field(
        title="Salesforce Object",
        description="Salesforce crm object to sync",
        json_schema_extra={
            "format": "CrmObjectSelect",
            "integrationUuidField": "integration_uuid",
        },
    )
    field_mapping: list["FieldMap"] = pydantic.Field(
        title="Object fields",
        description="Fields in the object to sync",
        json_schema_extra={
            "format": "CrmObjectMapper",
            # setting type manually to render the format widget instead of fields inferred from type
            "type": "string",
            "integrationUuidField": "integration_uuid",
            "crmObjectIdField": "object_name",
        },
    )
    object_id: str | None = pydantic.Field(
        title="Update by object ID",
        description="ID of the object to update (highest priority)",
        default=None,
    )
    match_condition: list["MatchCondition"] | None = pydantic.Field(
        title="Update by match",
        description="Match conditions to find the object to update",
        default=None,
        json_schema_extra={
            "format": "CrmMatchCriteria",
            # setting type manually to render the format widget instead of fields inferred from type
            "type": "string",
            "integrationUuidField": "integration_uuid",
            "crmObjectIdField": "object_name",
            # unsetting anyof, so that rjsf doesn't show this field twice, cuz anyof and type doesn't go together
            "anyOf": None,
        },
    )


class FieldMap(pydantic.BaseModel):
    id: str
    label: str
    value: str | int | float | bool | None


class MatchCondition(pydantic.BaseModel):
    booleanOperator: Literal["AND", "OR"]
    conditions: list["Condition"]


class Condition(pydantic.BaseModel):
    fieldId: str
    label: str
    operator: Literal["EQ", "NEQ", "GT", "GTE", "LT", "LTE", "LIKE"]
    value: str | int | float | bool | None


class Output(BaseActionOutput):
    model_config = pydantic.ConfigDict(extra="allow")


class ResumeState(BaseActionOutput):
    token_retry_count: int
    old_access_token_checksum: str


class SalesforceSyncAction(BaseResumableAction[Input, Output, ResumeState]):
    id = "sync-salesforce"
    name = "Salesforce Sync"
    description = "Sync data to Salesforce CRM"
    icon = "https://www.salesforce.com/c2/public/app/favicon.ico"
    default_output_path = "result.id"
    input_schema = Input
    output_schema = Output
    usage = ActionUsage(units=1, unit_type="credit")
    partial_state_schema = ResumeState
    tags = ["crm", "sync"]

    def _run(self, input: Input) -> ResumableActionResponse[Output, ResumeState]:
        sf_params = self._get_integration_params(input.integration_uuid)
        api = Salesforce(sf_params["domain"], sf_params["access_token"])
        object_data = (
            pydash.chain(input.field_mapping)
            .map_(lambda x: [x.id, x.value])
            .from_pairs()
            .value()
        )

        try:
            object_id = None
            if input.object_id:
                object_id = input.object_id
            elif input.match_condition:
                object_id = self._find_object_id_from_match_conditions(
                    api, input.object_name, input.match_condition
                )

            if object_id:
                updated_obj = api.update_object(
                    input.object_name,
                    object_id,
                    object_data,
                )
                return ResumableActionResponse(
                    result=Output.model_validate(updated_obj)
                )
            else:
                created_obj = api.create_object(input.object_name, object_data)
                return ResumableActionResponse(
                    result=Output.model_validate(created_obj)
                )
        except AccessTokenExpired:
            logger.info("Access token expired, retrying")
            return ResumableActionResponse(
                resume=ActionResumeState(
                    poll_time=random.randint(5, 40),
                    state=ResumeState(
                        token_retry_count=1,
                        old_access_token_checksum=self._access_token_checksum(
                            sf_params["access_token"]
                        ),
                    ),
                )
            )

    def _resume(
        self,
        type: ResumeTriggerType,
        input: Input,
        state: ResumeState,
        webhook_data: dict[str, Any] | None = None,
    ):
        if type != "schedule":
            raise ValueError("Unsupported resume type")
        if state.token_retry_count > 3:
            raise ValueError("Token retry limit exceeded")

        self._update_access_token(
            input.integration_uuid, state.old_access_token_checksum
        )

        out = self._run(input)
        if out.resume:
            if out.resume.state:
                out.resume.state.token_retry_count = state.token_retry_count + 1
            else:
                raise ValueError("Resume state not found")
        return out

    def _find_object_id_from_match_conditions(
        self, api: Salesforce, object_name: str, match_conditions: list[MatchCondition]
    ):
        op_map = {
            "EQ": "=",
            "NEQ": "!=",
            "GT": ">",
            "GTE": ">=",
            "LT": "<",
            "LTE": "<=",
            "LIKE": "LIKE",
        }
        for match_condition in match_conditions:
            query = (
                f"SELECT Id FROM {Salesforce.sanitize_identifier(object_name)} WHERE "
            )
            conditions = []
            for condition in match_condition.conditions:
                conditions.append(
                    f"{Salesforce.sanitize_identifier(condition.fieldId)} "
                    + f"{Salesforce.sanitize_operator(op_map[condition.operator])} "
                    + f"{self._to_soql_value(condition.value)}"
                )
            query += f" {match_condition.booleanOperator} ".join(conditions)
            res = api.query(query)
            records = pydash.get(res, "records")
            if records and isinstance(records, list) and len(records):
                return pydash.get(records[0], "Id")

    def _to_soql_value(self, value: str | int | float | bool | None):
        if isinstance(value, str):
            return f"'{Salesforce.sanitize_str_value(value)}'"
        elif isinstance(value, bool):
            return str(value).lower()
        elif isinstance(value, (int, float)):
            return str(value)
        elif value is None:
            return "null"
        else:
            raise ValueError(f"Unsupported value type: {type(value)}")

    def _get_integration_params(self, integration_uuid: str):
        with Prisma(datasource={"url": config.get_parameter("DATABASE_URL")}) as prisma:
            integration = prisma.tenantintegration.find_first(
                where={"uuid": integration_uuid}
            )
            if not integration:
                raise ValueError(f"Integration with uuid {integration_uuid} not found")
            data = integration.data
            integration_data = IntegrationData.model_validate(data)
            match = re.match(
                "https://(.*?).my.salesforce.com", integration_data.instance_url
            )
            if not match:
                raise ValueError("Invalid Salesforce instance URL")
            domain = match.group(1)
            return {
                "domain": domain,
                "access_token": integration_data.access_token,
                "refresh_token": integration_data.refresh_token,
            }
        pass

    def _update_access_token(
        self, integration_uuid: str, old_access_token_checksum: str
    ):
        sf_params = self._get_integration_params(integration_uuid)
        if (
            self._access_token_checksum(sf_params["access_token"])
            != old_access_token_checksum
        ):
            # Access token already updated by another within
            # the gap it took this resume instance to run so
            # assuming that it's a new token and no need to update
            logger.info(
                "Access token already updated by another instance, skipping update, old: '%s' new: '%s'",
                old_access_token_checksum,
                self._access_token_checksum(sf_params["access_token"]),
            )
            return

        api = Salesforce(sf_params["domain"], sf_params["access_token"])
        token = api.refresh_oauth2_access_token(
            config.get_parameter("SALESFORCE_CLIENT_ID"),
            config.get_parameter("SALESFORCE_CLIENT_SECRET"),
            sf_params["refresh_token"],
        )
        if not token.access_token:
            raise ValueError("Failed to refresh access token, got empty access token")

        with Prisma(datasource={"url": config.get_parameter("DATABASE_URL")}) as prisma:
            integration = prisma.tenantintegration.find_first(
                where={"uuid": integration_uuid}
            )
            if not integration:
                raise ValueError(f"Integration with uuid {integration_uuid} not found")
            if not isinstance(integration.data, dict):
                raise ValueError(
                    f"Integration data is not a dict, got {type(integration.data)}"
                )
            integration.data["access_token"] = token.access_token
            prisma.tenantintegration.update(
                where={"uuid": integration_uuid},
                data={"data": Json(integration.data)},
            )
            logger.info(
                "Updated access token for integration '%s'; old:'%s' new: '%s'",
                integration_uuid,
                self._access_token_checksum(sf_params["access_token"]),
                self._access_token_checksum(token.access_token),
            )

    def _access_token_checksum(self, access_token: str):
        return access_token[::3]


class IntegrationData(pydantic.BaseModel):
    # has more fields than this
    instance_url: str
    access_token: str
    refresh_token: str
