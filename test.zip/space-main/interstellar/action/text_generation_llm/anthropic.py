import json
from typing import Literal

import pydantic
from pydash import get
import pydash
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import anthropic, open_ai
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class GenerateTextAnthropicInput(BaseActionInput):
    api_key: str | None = None
    model: anthropic.ClaudeModel | None = None
    query: str
    output_format: Literal["text", "json_object"] = "text"
    temperature: float | None = None


class LLMUsage(pydantic.BaseModel):
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None


class GenerateTextAnthropicOutput(BaseActionOutput):
    message: str | dict | None
    usage: LLMUsage | None


class GenerateTextAnthropicAction(
    BaseAction[GenerateTextAnthropicInput, GenerateTextAnthropicOutput]
):
    id = "88e19893-2fc4-4b38-9b37-537e4145dfa0"
    name = "Claude"
    description = "Anthropic Claude"
    icon = "https://www.anthropic.com/favicon.ico"
    default_output_path = "result.output"
    input_schema = GenerateTextAnthropicInput
    output_schema = GenerateTextAnthropicOutput
    tags = ["AI"]

    def _run(
        self, input: GenerateTextAnthropicInput
    ) -> ActionResponse[GenerateTextAnthropicOutput]:
        self.client = anthropic.ApiClient(input.model, input.api_key)

        if input.output_format == "json_object":
            raise Exception(
                "json_object output format is not supported by this provider"
            )

        try:
            response = self.client.completion(input.query)

            tokens = response.tokens
            message = response.completion

            logger.info(
                "Completion: ",
                extra={
                    "query": input.query,
                    "completion": response.id,
                    "tokens": tokens,
                },
            )

            if message is None or not len(message):
                logger.error("No response from API", extra={"query": input.query})
                return ActionResponse(
                    error=ActionError(
                        code="EMPTY_OUTPUT", message="No response from API"
                    ),
                )

            return ActionResponse(
                result=GenerateTextAnthropicOutput(
                    message=message[0].text,
                    usage=LLMUsage(
                        prompt_tokens=tokens.prompt_tokens,
                        completion_tokens=tokens.completion_tokens,
                        total_tokens=tokens.total_tokens,
                    ),
                ),
                usage=ActionUsage(
                    units=tokens.total_tokens,
                    unit_type="token",
                    extra_data={
                        "prompt_tokens": tokens.prompt_tokens,
                        "completion_tokens": tokens.completion_tokens,
                        "total_tokens": tokens.total_tokens,
                    },
                ),
            )
        except Exception as e:
            # TODO: Find all possible errors and handle them after testing
            logger.exception(
                "Error while calling Anthropic API", extra={"query": input.query}
            )
            return ActionResponse(
                error=ActionError(
                    # TODO: Should we use the error code from the API? Ideally we should have our own error codes
                    code=pydash.get(e, "status_code", "API_ERROR"),
                    message=pydash.get(
                        e, "response", "Error while calling Anthropic API"
                    ),
                    e=e,
                ),
            )
