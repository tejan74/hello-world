import json
from typing import Literal

import pydantic
from pydash import get
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import open_ai
from lib.open_ai import SupportedModel
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class GenerateTextOpenAiInput(BaseActionInput):
    api_key: str | None = None
    model: SupportedModel | None = None
    query: str
    output_format: Literal["text", "json_object"] = "text"
    temperature: float | None = None


class LLMUsage(pydantic.BaseModel):
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None


class GenerateTextOpenAiOutput(BaseActionOutput):
    message: str | dict | None
    usage: LLMUsage | None


class GenerateTextOpenAiAction(
    BaseAction[GenerateTextOpenAiInput, GenerateTextOpenAiOutput]
):
    id = "37706f1b-5966-44fc-8f8d-3ebae70fdd1d"
    name = "OpenAI"
    description = "OpenAI LLM"
    icon = "https://openai.com/favicon.ico"
    default_output_path = "result.message"
    input_schema = GenerateTextOpenAiInput
    output_schema = GenerateTextOpenAiOutput
    tags = ["AI"]

    def _run(
        self, input: GenerateTextOpenAiInput
    ) -> ActionResponse[GenerateTextOpenAiOutput]:
        self.client = open_ai.ApiClient(input.model or "gpt-4o-mini", input.api_key)

        try:
            response = self.client.chat(
                input.query,
                output_format=input.output_format,
                model=input.model,
                temperature=input.temperature,
            )

            choice = response.choices[0] if len(response.choices) > 0 else None
            if choice is None:
                logger.error(
                    "No Choice returned from API", extra={"query": input.query}
                )
                return ActionResponse(
                    error=ActionError(
                        code="EMPTY_OUTPUT", message="No Choice returned from API"
                    )
                )

            message = choice.message.content
            if message is None:
                logger.error("No response from API", extra={"query": input.query})
                return ActionResponse(
                    error=ActionError(
                        code="EMPTY_OUTPUT", message="No response from API"
                    )
                )

            # Extract JSON from the response for an extra layer of protection
            # this only works with json_object, not json_array.
            # openai API only supports json_object
            # TODO: lets do this for other providers as well
            if input.output_format == "json_object":
                if "{" not in message or "}" not in message:
                    logger.error(
                        "No JSON found in response", extra={"query": input.query}
                    )
                else:
                    message = message[message.index("{") : message.rindex("}") + 1]
                    try:
                        message = json.loads(message)
                    except Exception as e:
                        logger.error(
                            "Error while parsing JSON", extra={"query": input.query}
                        )

            logger.info(
                "Usage: ", extra={"query": input.query, "usage": response.usage}
            )
            return ActionResponse(
                result=GenerateTextOpenAiOutput(
                    message=message,
                    usage=LLMUsage(
                        prompt_tokens=get(response, "usage.prompt_tokens", None),
                        completion_tokens=get(
                            response, "usage.completion_tokens", None
                        ),
                        total_tokens=get(response, "usage.total_tokens", None),
                    ),
                ),
                usage=ActionUsage(
                    units=get(response, "usage.total_tokens", None),
                    unit_type="token",
                    extra_data={
                        "prompt_tokens": get(response, "usage.prompt_tokens", None),
                        "completion_tokens": get(
                            response, "usage.completion_tokens", None
                        ),
                        "total_tokens": get(response, "usage.total_tokens", None),
                    },
                ),
            )
        except open_ai.BadRequestError as e:
            logger.error("Bad Request", extra={"query": input.query})
            return ActionResponse(
                error=ActionError(
                    code="BAD_REQUEST", message=f"Bad Request {e.message}", e=e
                ),
            )
        except Exception as e:
            logger.exception("Error calling OpenAI", extra={"query": input.query})
            return ActionResponse(
                error=ActionError(
                    code="API_ERROR", message="Error calling OpenAI", e=e
                ),
            )
