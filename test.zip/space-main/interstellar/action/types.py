from enum import Enum
from typing import Any, Generic, Literal, TypeVar
import pydantic


class BaseActionInput(pydantic.BaseModel):
    pass


class BaseActionOutput(pydantic.BaseModel):
    pass


class ActionError(pydantic.BaseModel):
    """
    GENERIC INTERFACES FOR PROVIDERS

    Providers provide Responses.
    Each response contains two attributes:
    - a *result*
    - an *error*
    """

    model_config = pydantic.ConfigDict(arbitrary_types_allowed=True)

    code: str
    message: str
    retryable: bool = False
    e: Exception | None = None

    def to_dict(self):
        return {
            "code": self.code,
            "message": self.message,
            "retryable": self.retryable,
            "e": str(self.e) if self.e else None,
        }


IsBaseActionInput = TypeVar("IsBaseActionInput", bound=BaseActionInput)
IsBaseActionOutput = TypeVar("IsBaseActionOutput", bound=BaseActionOutput)
IsPartialState = TypeVar("IsPartialState", bound=BaseActionOutput)


class ActionUsage(pydantic.BaseModel):
    # number of provider specific units used by the provider
    units: int
    # types like token, credit, etc.
    unit_type: Literal["token", "credit"]

    extra_data: dict[str, Any] | None = None


class ActionResumeState(pydantic.BaseModel, Generic[IsPartialState]):
    webhook_url: str | None = None
    # There is a chance that webhook might be recieved before the action execution is completed, so always better to setup poll aswell
    # poll time in seconds
    poll_time: int | None = None
    state: IsPartialState | None = None


class ActionResponse(pydantic.BaseModel, Generic[IsBaseActionOutput]):
    result: IsBaseActionOutput | None = None
    error: ActionError | None = None
    usage: ActionUsage | None = None


class ResumableActionResponse(
    ActionResponse[IsBaseActionOutput], Generic[IsBaseActionOutput, IsPartialState]
):
    resume: ActionResumeState[IsPartialState] | None = None


class ProviderType(Enum):
    GOOGLE_MAPS = "google_maps"
    APOLLO = "apollo"
