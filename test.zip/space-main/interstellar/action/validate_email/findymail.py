from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.findymail import FindymailClient


class ValidateEmailInput(BaseActionInput):
    email: str
    api_key: str | None = None


class ValidateEmailOutput(BaseActionOutput):
    validated: bool | None


class ValidateEmailAction(BaseAction[ValidateEmailInput, ValidateEmailOutput]):
    id = "findymail-validate-email-action"
    name = "Validate email with Findymail"
    description = "Findymail helps you to validate the email"
    icon = "https://www.findymail.com/images/favicon.ico"
    default_output_path = "result.validated"
    input_schema = ValidateEmailInput
    output_schema = ValidateEmailOutput
    usage_type = None
    tags = ["People"]

    def _run(
        self, input: ValidateEmailInput, **kwargs: Any
    ) -> ActionResponse[ValidateEmailOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("FINDYMAIL_API_KEY")
        )
        self.client = FindymailClient(api_key=self.api_key)
        response = self.client.verify_email(email=input.email)

        if response is not None:
            return ActionResponse(
                result=ValidateEmailOutput(validated=response.verified),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=ValidateEmailOutput(validated=False),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
