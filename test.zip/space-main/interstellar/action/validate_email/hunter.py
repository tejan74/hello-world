from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.hunter import HunterClient


class ValidateEmailInput(BaseActionInput):
    email: str
    api_key: str | None = None


class ValidateEmailOutput(BaseActionOutput):
    validated: bool | None


class ValidateEmailAction(BaseAction[ValidateEmailInput, ValidateEmailOutput]):
    id = "hunter-validate-email-action"
    name = "Validate email with Hunter.io"
    description = "Hunter helps you to validate the email"
    icon = "https://hunter.io/assets/favicon/favicon-35c267ca9f2a39f1c9d7118c8533e74385d9e7a4fad1ced75fd51442ecfbceb2.ico"
    default_output_path = "result.validated"
    input_schema = ValidateEmailInput
    output_schema = ValidateEmailOutput
    usage_type = None
    tags = ["People"]

    def _run(
        self, input: ValidateEmailInput, **kwargs: Any
    ) -> ActionResponse[ValidateEmailOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("HUNTER_API_KEY")
        )
        self.client = HunterClient(api_key=self.api_key)
        output = self.client.email_verifier(input.email)

        if (
            output is not None
            and output.data is not None
            and output.data.result == "deliverable"
        ):
            return ActionResponse(
                result=ValidateEmailOutput(validated=True),
                usage=ActionUsage(units=1, unit_type="credit"),
            )
        else:
            return ActionResponse(
                result=ValidateEmailOutput(validated=False),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
