from typing import Any
from action.base import BaseAction, BaseActionInput, BaseActionOutput
from action.types import ActionResponse, ActionUsage
import config
from lib.prospeo import ProspeoClient


class ValidateEmailInput(BaseActionInput):
    email: str
    email_anon_id: str
    api_key: str | None = None


class ValidateEmailOutput(BaseActionOutput):
    validated: bool | None


class ValidateEmailAction(BaseAction[ValidateEmailInput, ValidateEmailOutput]):
    id = "prospeo-validate-email-action"
    name = "Validate email with Prospeo"
    description = "Prospeo helps you to validate the email"
    icon = "https://lh3.googleusercontent.com/ZnecyuZStWFBHS3436Db5_BMOYXh6_pmlaNUR7zzf-BfE26eLdnmMmGefsxS5EQBmKF6KUKVsUQjCqIZXfOxYFJPOg=s60"
    default_output_path = "result.validated"
    input_schema = ValidateEmailInput
    output_schema = ValidateEmailOutput
    usage_type = None
    tags = ["People"]

    def _run(
        self, input: ValidateEmailInput, **kwargs: Any
    ) -> ActionResponse[ValidateEmailOutput]:
        self.api_key = (
            input.api_key
            if input.api_key is not None
            else config.get_parameter("PROSPEO_API_KEY")
        )
        self.client = ProspeoClient(api_key=self.api_key)
        output = self.client.email_verifier(input.email, input.email_anon_id)

        if (
            output is not None
            and output.response is not None
            and output.response.email_status == "VALID"
        ):
            return ActionResponse(
                result=ValidateEmailOutput(validated=True),
                usage=ActionUsage(
                    units=0, unit_type="credit", extra_data={"multiple": "10"}
                ),
            )
        else:
            return ActionResponse(
                result=ValidateEmailOutput(validated=False),
                usage=ActionUsage(units=0, unit_type="credit"),
            )
