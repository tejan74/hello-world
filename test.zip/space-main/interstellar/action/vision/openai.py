from typing import Literal
import pydantic
from pydash import get
from action.base import BaseAction
from action.types import (
    ActionError,
    ActionResponse,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
)
from lib import open_ai
from util.logger import interstellar_logger
import json

logger = interstellar_logger(__name__)

# TODO: @chitti make it more configurable to accept images


class OpenAiVisionInput(BaseActionInput):
    api_key: str | None = None
    model: open_ai.SupportedModel = "gpt-4o-mini"
    vision_prompt: str
    image_urls: list[str] | str
    is_base64: bool = False
    max_tokens: int | None = None
    output_format: Literal["text", "json_object"] = "text"
    resolution: Literal["low", "high"] = "low"


# Types and classes
class VisionUsage(pydantic.BaseModel):
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None


class OpenAiVisionOutput(BaseActionOutput):
    message: str | dict | None
    usage: VisionUsage | None


class OpenAiVisionAction(BaseAction[OpenAiVisionInput, OpenAiVisionOutput]):

    id = "3a8d25d7-fa49-456c-89aa-1b8f4b7faa3a"
    name = "OpenAI Vision"
    description = "OpenAI Vision"
    icon = "https://openai.com/favicon.ico"
    default_output_path = "result.message"
    input_schema = OpenAiVisionInput
    output_schema = OpenAiVisionOutput
    tags = ["AI"]

    """Parameter - image_url can be base64 image url or any image url."""

    def _run(self, input: OpenAiVisionInput) -> ActionResponse[OpenAiVisionOutput]:
        self.client = open_ai.ApiClient(model=input.model, key=input.api_key)
        vision_prompt, image_urls, max_tokens = (
            input.vision_prompt,
            input.image_urls,
            input.max_tokens,
        )

        try:
            if isinstance(image_urls, str):
                image_urls = json.loads(image_urls)
                if not isinstance(image_urls, list):
                    logger.error(f"Errored Images: {image_urls}")
                    raise Exception("Image string should be a valid JSON array string")

            if input.is_base64:
                image_urls = [
                    (
                        f"data:image/jpeg;base64,{base64_image}"
                        if "data:image/jpeg;base64," not in base64_image
                        else base64_image
                    )
                    for base64_image in image_urls
                ]

            # Preparing message content for query
            message_content = [{"type": "text", "text": vision_prompt}] + [
                {
                    "type": "image_url",
                    "image_url": {"url": url, "detail": input.resolution},
                }
                for url in image_urls
            ]

            response = self.client.chat_vision(
                user_message_content=message_content,
                max_tokens=max_tokens,
                model=input.model,
                output_format=input.output_format,
            )

            choice = response.choices[0] if len(response.choices) > 0 else None
            if choice is None:
                logger.error(
                    "No Choice returned from API", extra={"query": message_content}
                )
                return ActionResponse(
                    error=ActionError(
                        code="EMPTY_OUTPUT", message="No Choice returned from API"
                    )
                )

            message = choice.message.content
            if message is None:
                logger.error("No response from API", extra={"query": message_content})
                return ActionResponse(
                    error=ActionError(
                        code="EMPTY_OUTPUT", message="No response from API"
                    )
                )

            # Extract JSON from the response for an extra layer of protection
            # this only works with json_object, not json_array.
            # openai API only supports json_object
            # TODO: lets do this for other providers as well
            if input.output_format == "json_object":
                if "{" not in message or "}" not in message:
                    logger.error(
                        "No JSON found in response",
                        extra={"query": input.vision_prompt},
                    )
                else:
                    message = message[message.index("{") : message.rindex("}") + 1]
                    try:
                        message = json.loads(message)
                    except Exception as e:
                        logger.error(
                            "Error while parsing JSON",
                            extra={"query": input.vision_prompt},
                        )

            logger.info(
                "Usage: ", extra={"query": message_content, "usage": response.usage}
            )
            return ActionResponse(
                result=OpenAiVisionOutput(
                    message=message,
                    usage=VisionUsage(
                        prompt_tokens=get(response, "usage.prompt_tokens", None),
                        completion_tokens=get(
                            response, "usage.completion_tokens", None
                        ),
                        total_tokens=get(response, "usage.total_tokens", None),
                    ),
                ),
                usage=ActionUsage(
                    units=get(response, "usage.total_tokens", None),
                    unit_type="token",
                    extra_data={
                        "prompt_tokens": get(response, "usage.prompt_tokens", None),
                        "completion_tokens": get(
                            response, "usage.completion_tokens", None
                        ),
                        "total_tokens": get(response, "usage.total_tokens", None),
                    },
                ),
            )
        except Exception as e:
            logger.exception("Error while calling GPT4V API")
            return ActionResponse(
                error=ActionError(
                    code="API_ERROR", message="Error while calling GPT4V API", e=e
                ),
            )
