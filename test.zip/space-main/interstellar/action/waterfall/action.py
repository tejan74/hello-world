from typing import Any
import pydantic
import pydash
from action.base_resume import BaseResumableAction, ResumeTriggerType
from action.types import (
    ActionResumeState,
    ActionUsage,
    BaseActionInput,
    BaseActionOutput,
    ResumableActionResponse,
)
from engine._classes import ActionRunMetadata, TemplateError
from engine.action_resolver import UIActionResolver
from engine.providers.jinja_input_template_engine import JinjaInputTemplateEngine
from engine.providers.table_config_manager import (
    get_special_input_from_templated_input,
    is_templated_input,
)
from util.logger import interstellar_logger


logger = interstellar_logger(__name__)


class Input(BaseActionInput):
    actions: "list[Action]" = pydantic.Field(
        title="Actions",
        json_schema_extra={"format": "WaterfallActionSelector", "type": "string"},
    )


class Action(pydantic.BaseModel):
    actionUuid: str
    # name: str
    input: dict[str, Any]
    # inputSchema: dict[str, Any]
    # outputSchema: dict[str, Any]
    validityCondition: str
    outputPath: str


class Output(BaseActionOutput):
    output: Any


class ResumeState(BaseActionOutput):
    is_action_resume: bool = False
    # filled if is_action_resume is True
    action_resume_state: BaseActionOutput | None = None
    # filled if is_action_resume is False
    current_action_index: int
    # action_runs: list["ActionRuns"]


# class ActionRuns(pydantic.BaseModel):
#     actionUuid: str
#     output: Any


class WaterfallAction(BaseResumableAction[Input, Output, ResumeState]):
    id = "waterfall-action-v1"
    name = "Waterfall"
    description = "Run a waterfall across actions"
    icon = "waterfall"
    default_output_path = "result.output"
    input_schema = Input
    output_schema = Output
    usage = ActionUsage(units=1, unit_type="credit")
    partial_state_schema = ResumeState

    def _run(self, input: Input) -> ResumableActionResponse[Output, ResumeState]:
        output, meta, resume_state = self._run_single_action(input.actions[0])
        return self._compile_output(input, 0, output, meta, resume_state)

    def _resume(
        self,
        type: ResumeTriggerType,
        input: Input,
        state: ResumeState,
        webhook_data: dict[str, Any] | None = None,
    ) -> ResumableActionResponse[Output, ResumeState]:
        if state.is_action_resume:
            output, meta, resume_state = self._resume_single_action(
                input.actions[state.current_action_index],
                type,
                state.action_resume_state and state.action_resume_state.model_dump(),
                webhook_data,
            )

        else:
            output, meta, resume_state = self._run_single_action(
                input.actions[state.current_action_index]
            )

        return self._compile_output(
            input, state.current_action_index, output, meta, resume_state
        )

    def _run_single_action(
        self, action: Action
    ) -> tuple[
        Any, ActionRunMetadata | None, ActionResumeState[BaseActionOutput] | None
    ]:
        if not self.run_id:
            raise ValueError("run_id is required")

        ar = UIActionResolver()
        output, meta, resume_state = ar.run(
            self.run_id, action.actionUuid, action.input
        )

        return (output, meta, resume_state)

    def _resume_single_action(
        self,
        action: Action,
        action_resume_type: ResumeTriggerType,
        action_state: dict[str, Any] | None = None,
        action_webhook_data: dict[str, Any] | None = None,
    ) -> tuple[Any, ActionRunMetadata, ActionResumeState[BaseActionOutput] | None]:
        if not self.run_id:
            raise ValueError("run_id is required")

        ar = UIActionResolver()
        out, meta, resume_state = ar.resume(
            self.run_id,
            action.actionUuid,
            action_resume_type,
            action.input,
            action_state,
            action_webhook_data,
        )

        return (out, meta, resume_state)

    # TODO (ankith): support meta
    def _compile_output(
        self,
        input: Input,
        current_action_index: int,
        output: Any,
        meta: ActionRunMetadata | None,
        resume_state: ActionResumeState | None,
    ):
        logger.info(f"Compiling output {output}")
        if resume_state:
            logger.info(f"Has resume state {resume_state}")
            return ResumableActionResponse(
                resume=ActionResumeState(
                    webhook_url=resume_state.webhook_url,
                    poll_time=resume_state.poll_time,
                    state=ResumeState(
                        is_action_resume=True,
                        action_resume_state=resume_state.state,
                        current_action_index=current_action_index,
                    ),
                )
            )

        current_action = input.actions[current_action_index]
        condition_result, condition_error = self._eval_validity_condition(
            output, current_action.validityCondition
        )
        # TODO (ankith): handle condition_error
        logger.info(f"condition result {condition_result}, {condition_error}")

        if condition_result:
            logger.info(f"condition success Output {output}")
            return ResumableActionResponse(
                result=Output(output=pydash.get(output, current_action.outputPath))
            )
        elif current_action_index < len(input.actions) - 1:
            logger.info(f"condition failed, moving to next action")
            return ResumableActionResponse(
                resume=ActionResumeState(
                    poll_time=0,
                    state=ResumeState(
                        is_action_resume=False,
                        current_action_index=current_action_index + 1,
                    ),
                )
            )
        else:
            logger.info(f"condition failed, no more actions")
            return ResumableActionResponse(result=Output(output=None))

    def _eval_validity_condition(
        self, output: Any, validity_condition: str
    ) -> tuple[bool, TemplateError | None]:
        if is_templated_input(validity_condition):
            special_input = get_special_input_from_templated_input(validity_condition)
            template = ""
            for item in special_input:
                if item["type"] == "text":
                    template += item["text"]
                elif item["type"] == "slash-variable":
                    path = item["value"]
                    template += "result" + "".join(
                        pydash.map_(
                            path[1:],
                            lambda x: f"[{x}]" if type(x) == int else f"['{x}']",
                        )
                    )
                else:
                    raise Exception("Bad special input format")
            validity_condition = "{{ " + template + " }}"
        logger.info(f"validity condition '{validity_condition}'")

        ite = JinjaInputTemplateEngine(output)
        condition_result, condition_error = ite.eval_pre_check(validity_condition)
        return condition_result, condition_error
