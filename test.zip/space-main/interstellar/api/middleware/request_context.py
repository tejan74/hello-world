from fastapi import Request

from util import request_context


async def request_context_middleware(request: Request, call_next):
    """This Middleware set the url path of currently serving endpoint in the request context."""
    r_ctx = request_context.request_context.get()
    r_ctx["path"] = request.url.path
    request_context.request_context.set(r_ctx)
    response = await call_next(request)
    return response
