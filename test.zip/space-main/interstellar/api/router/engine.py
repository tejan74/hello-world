from fastapi import APIRouter

from engine.v1.aws import lambda_handler
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

router = APIRouter(prefix="/engine", tags=["integration"])


# TODO: This is for local development only
# Find a better way to do this
@router.post("/local_sqs")
async def local_sqs(data: dict):
    logger.info("Received local SQS event: %s", data)

    lambda_handler.handle(data, None)
    return {"status": "success"}
