from fastapi import APIRouter
import fastapi
from prisma import Prisma, fields

import config
from lib.crm.hubspot.oauth import HubSpotOAuth
from lib.crm.salesforce.oauth import SalesforceOAuth
from lib.crm import OAuth
from util.http import get_host_from_url
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

OAUTH_SECRETE_MAP = {
    "hubspot": {
        "client_id": "HUBSPOT_CLIENT_ID",
        "client_secret": "HUBSPOT_CLIENT_SECRET"
    },
    "salesforce": {
        "client_id": "SALESFORCE_CLIENT_ID",
        "client_secret": "SALESFORCE_CLIENT_SECRET"
    }
}

OAUTH_IMPL_MAP: dict[str,type[OAuth]] = {
    "hubspot": HubSpotOAuth,
    "salesforce": SalesforceOAuth
}

router = APIRouter(prefix="/integration", tags=["integration"])

_prisma = Prisma(datasource = {"url": config.get_parameter("DATABASE_URL")})

async def space_database():
    if not _prisma.is_connected():
        _prisma.connect()
    return _prisma

# Mount oauth callback
# Gives back the code and state code is used to get the access token
# state is used to identify the integration/tenant that is being authorized
@router.get("/oauth/callback")
def oauth_authorize_callback(code: str, state: str, request: fastapi.Request, prisma: Prisma = fastapi.Depends(space_database)):
    tenant_integration = prisma.tenantintegration.find_first(where={"uuid": state})

    if not tenant_integration:
        raise fastapi.HTTPException(status_code=404, detail="Not found")
    
    if tenant_integration.status != "pending":
        raise fastapi.HTTPException(status_code=400, detail="Integration already completed")

    if tenant_integration.integration not in OAUTH_IMPL_MAP:
        raise fastapi.HTTPException(status_code=400, detail="Integration not supported")
    
    integration = tenant_integration.integration
    
    client_id = config.get_parameter(OAUTH_SECRETE_MAP[integration]["client_id"])
    client_secret = config.get_parameter(OAUTH_SECRETE_MAP[integration]["client_secret"])

    if not client_id or not client_secret:
        logger.error(f"{OAUTH_SECRETE_MAP[integration]["client_id"]} or {OAUTH_SECRETE_MAP[integration]["client_secrete"]} not set")
        raise fastapi.HTTPException(status_code=500, detail="Internal server error")
    
    redirect_uri = str(request.url_for("oauth_authorize_callback"))
    redirect_url = redirect_uri if get_host_from_url(redirect_uri) == "localhost" else redirect_uri.replace("http://", "https://")
    tokens = OAUTH_IMPL_MAP[integration]().get_access_token(
        client_id=client_id,
        client_secret=client_secret,
        code=code,
        redirect_uri=redirect_url
    )
        
    prisma.tenantintegration.update(where={"uuid": state}, data={"status": "connected", "data": fields.Json(tokens)})
    return fastapi.Response("Integration completed")

# this needs be below /oauth/callback see: https://fastapi.tiangolo.com/tutorial/path-params/#order-matters
@router.get("/oauth/{uuid}")
def oauth_integration(uuid: str, request: fastapi.Request, prisma: Prisma = fastapi.Depends(space_database)):
    tenant_integration = prisma.tenantintegration.find_first(where={"uuid": uuid})

    if not tenant_integration:
        return 404, "Integration not initiated"

    if tenant_integration.status != "pending":
        return 400, "Integration already completed"

    if tenant_integration.integration not in OAUTH_IMPL_MAP:
        return 400, "Integration not supported"
    
    integration = tenant_integration.integration
    client_id = config.get_parameter(OAUTH_SECRETE_MAP[integration]["client_id"])
    redirect_uri = str(request.url_for("oauth_authorize_callback"))
    redirect_url = redirect_uri if get_host_from_url(redirect_uri) == "localhost" else redirect_uri.replace("http://", "https://")
    url = OAUTH_IMPL_MAP[integration]().generate_authorization_url(
        client_id=client_id,
        redirect_uri=redirect_url,
        state=uuid
    )

    return fastapi.responses.RedirectResponse(url)
