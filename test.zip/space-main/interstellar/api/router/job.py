from fastapi import APIRouter
from job import job_executer
from util.logger import interstellar_logger


logger = interstellar_logger(__name__)

router = APIRouter(tags=["misc"])


@router.get("/job/{job_name}")
def job(job_name: str):
    try:
        job_executer(job_name)
        return 200, {"detail": "ok"}
    except Exception:
        logger.exception("Job Execution Failed: %s", job_name)
        return 500, {"error": "job error, see logs for more details"}
