from typing import Annotated, Any
from fastapi import APIRouter
import fastapi
import pydantic
from provider.scraper._helper import ApifyStepStateManager
from lib.apollo._classes import PersonEnrichWebhookRevealPhoneNumbers
from lib.apollo.helper import ApolloDbCache
from util.logger import interstellar_logger
from prisma import Prisma

logger = interstellar_logger(__name__)

router = APIRouter(tags=["misc"])

prisma = Prisma()


class ApifyEventDataType(pydantic.BaseModel):
    actorId: str
    actorRunId: str


class ApifyResourceType(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra="allow", arbitrary_types_allowed=True)
    status: str


class ApifyPayload(pydantic.BaseModel):
    userId: str
    createdAt: str
    eventType: str
    eventData: ApifyEventDataType
    resource: ApifyResourceType


# Mount apollo webhook endpoint for enriching phone number
@router.post("/webhooks/person_enrich_reveal_phone/{uuid}")
def person_enrich_webhook_reveal_phone(
    uuid: Annotated[str, fastapi.Path(title="UUID of the process being responded to")],
    data: PersonEnrichWebhookRevealPhoneNumbers | None = None,
):

    if not uuid or not data:
        raise fastapi.HTTPException(
            status_code=400, detail="Process ID or data to process not provided"
        )

    try:
        ApolloDbCache().add(uuid, data.model_dump_json())
    except Exception as e:
        logger.exception(f"failed to store response: {e}")
        raise fastapi.HTTPException(status_code=500, detail="Failed to store response")

    return 200, {"detail": "ok"}


# Mount apify webhook endpoint for actor signal
@router.post("/webhooks/apify_actor_run_signal")
def apify_actor_run_signal(payload: ApifyPayload):
    try:
        ApifyStepStateManager(prisma=prisma).update_wf_step_state(
            run_id=payload.eventData.actorRunId,
            actor_id=payload.eventData.actorId,
            status=payload.resource.status,
        )
    except Exception as e:
        logger.exception(f"Failed to update workflow step state: {e}")
        raise fastapi.HTTPException(
            status_code=500, detail="Failed to update workflow step state"
        )

    return 200, {"detail": "ok"}


# Coresignal webhook
# TODO: Do this better
@router.post("/webhooks/coresignal")
def coresignal(payload: Any):
    logger.info(f"Received signal from coresignal: {payload}")
    return 200, {"detail": "ok"}
