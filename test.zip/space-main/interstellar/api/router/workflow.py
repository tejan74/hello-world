from typing import Any
from fastapi import APIRouter
import pydantic
from engine.baby_groot import Groot


from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

router = APIRouter(prefix="/workflow", tags=["workflow"])


class PredictPayload(pydantic.BaseModel):
    prompt: str
    config: list[dict]


# TODO: This is not the right place :D
@router.post("/predict")
async def recommend_column(payload: PredictPayload):
    logger.info(
        f"Predicting next column api request received {payload.prompt}, {payload.config}"
    )
    return Groot().recommend_column(payload.prompt, payload.config)


class RunCellPayload(pydantic.BaseModel):
    row_uuids: list[str]
