from uuid import uuid4
import fastapi
from api.constant import X_REQUEST_ID_HEADER
from api.router import engine, integration, job, misc, workflow
from util.logger import interstellar_logger
from asgi_correlation_id import correlation_id

logger = interstellar_logger(__name__)

app = fastapi.FastAPI()


@app.middleware("http")
async def auth(request: fastapi.Request, call_next):
    # no auth for now
    return await call_next(request)


@app.middleware("http")
async def catch_error(request: fastapi.Request, call_next):
    try:
        return await call_next(request)
    except Exception:
        logger.exception(f"Error occurred in request path {request.url.path}")
        c_id = correlation_id.get()
        return fastapi.Response(
            content="Something went wrong",
            status_code=500,
            headers={X_REQUEST_ID_HEADER: c_id} if c_id else {},
        )


app.include_router(integration.router)
app.include_router(workflow.router)
app.include_router(misc.router)
app.include_router(engine.router)
app.include_router(job.router)
