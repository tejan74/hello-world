from config import param

class Configuration:
    # Initial setup
    broker_url = param.get_parameter("REDIS_URL")
    result_backend = param.get_parameter("REDIS_URL")
    enable_utc = True                               # Report times in UTC
    broker_connection_retry_on_startup = True
    result_expires = 60 * 60 * 24 * 30              # Store results for 30 days

    # Task setup
    include = ['launcher.health']
