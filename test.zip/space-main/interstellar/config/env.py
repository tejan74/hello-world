import os

# Only local environments need to be setup here since
# everything else will be fetched from Google Secret Manager
LOCAL = {
    "project_id": None,
    "DATABASE_URL": "postgresql://postgres:postgres@localhost/space",
    "TOOLS_DB_URL": "postgresql://postgres:postgres@localhost/space",
    "APIFY_WEBHOOK_URL": "http://localhost:8080/v1/webhooks/apify_actor_run_signal",
    "AWS_REGION": "",
    "ACTION_SQS_URL": "",
    "LONG_ACTION_SQS_URL": "",
}

DEVELOPMENT = {
    "project_id": "orbital-development-2",
}

PRODUCTION = {
    "project_id": "orbital-production-1",
}


def get_env_var(env_var: str) -> str | None:
    return os.getenv(env_var)


def get_env() -> str:
    # Default to development if no env is set
    environment = os.getenv("ENV") or os.getenv("ENVIRONMENT") or "dev"

    # Standardize environment
    return environment.lower().strip()


def get_static_var(env_var: str) -> str | None:
    """
    Get a static environment variable based on the current environment
    """
    environment = get_env()

    if environment == "prod" or environment == "production":
        return PRODUCTION.get(env_var, None)

    elif environment == "dev" or environment == "DEV" or environment == "development":
        return DEVELOPMENT.get(env_var, None)

    # Return local config if no config is set
    return LOCAL.get(env_var, None)
