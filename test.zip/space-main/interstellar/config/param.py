from config import env, secret


def get_parameter(parameter_id: str) -> str:
    # First get it from environment
    env_var = env.get_env_var(parameter_id)
    if env_var is not None:
        return env_var

    # If you can't get it, fall back to static environment vars
    env_var = env.get_static_var(parameter_id)
    if env_var is not None:
        return env_var

    # If you can't get it, fall back to secret
    secret_var = secret.get_secret(parameter_id)
    if secret_var is not None:
        return secret_var

    # Default otherwise behavior is to error
    raise EnvironmentError(f"Requested parameter is not available '{parameter_id}'")


def safe_get_parameter(parameter_id: str, default_value: str) -> str:
    try:
        return get_parameter(parameter_id)
    except Exception:
        return default_value


def get_tmp_dir() -> str:
    import os

    tmp_dir = safe_get_parameter("INTERSTELLAR_TMP_DIR", "/tmp/interstellar")

    if not os.path.exists(tmp_dir):
        os.makedirs(tmp_dir)

    return tmp_dir
