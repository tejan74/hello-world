import json
import time
from google.cloud import secretmanager
from sqlalchemy import func
from config import env
from util.logger import interstellar_logger
import boto3
from botocore.exceptions import ClientError

logger = interstellar_logger(__name__)


def memoize_func(func):
    memory = {}
    # TODO (ankith): support time-based expiry of memoized funcs later
    # cache_expiry_interval = -1  # represents infinite time

    def wrapper(*args):
        key = tuple(args)

        if key not in memory:
            value = func(*args)
            memory[key] = {"value": value, "timestamp": time.time()}

        return memory[key]["value"]

    return wrapper


def get_secret(secret_id: str) -> str | None:
    cloud_env = env.get_env_var("CLOUD_ENV")
    cloud_secret = env.get_env_var("CLOUD_SECRET")

    get_cloud_secret = {
        "AWS": _get_aws_secret,
        "GCP": _get_gcp_secret,
        None: _get_gcp_secret,
    }[cloud_env]

    # Fetch the cloud secret
    data = None
    try:
        data = json.loads(get_cloud_secret(cloud_secret))
    except Exception:
        logger.exception(
            f"Error occurred in getting the secret blob in {cloud_env} for blob {cloud_secret} to get secret {secret_id}"
        )

    # Find and return the cloud secret whether it is in JSON or flat
    if data and data.get(secret_id):
        return data.get(secret_id)
    else:
        return get_cloud_secret(secret_id)


@memoize_func
def _get_gcp_secret(secret_id: str) -> str:
    project_id = env.get_static_var("project_id")

    if project_id is None:
        raise Exception("Catastrophic error: no cloud project to get secrets")

    client = secretmanager.SecretManagerServiceClient()

    # Build the resource name of the secret version.
    name = f"projects/{project_id}/secrets/{secret_id}/versions/latest"

    response = client.access_secret_version(name=name)
    return response.payload.data.decode("UTF-8")


@memoize_func
def _get_aws_secret(secret_name: str):
    region_name = env.get_env_var("AWS_REGION")
    client = boto3.client(
        "secretsmanager",
        region_name=region_name,
    )

    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except ClientError as e:
        raise e

    secret = get_secret_value_response["SecretString"]
    return secret
