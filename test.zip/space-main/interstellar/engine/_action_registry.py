from typing import Callable, Type


from action.base import BaseAction
from engine.action_resolver import ActionEntry, ActionDefinition, ActionEntryV2


registry: list[ActionEntry] = []

# TODO: Can make this by storing class as a string and using importlib, but will make it when we do pre-push checks and pr builds
registry_v2: list[ActionEntryV2] = []


def register_action(uuid: str):
    def not_implemented():
        raise NotImplementedError(
            "If u see this, it means the action registration had some issue"
        )

    def_func = not_implemented

    entry: ActionEntry = {
        "uuid": uuid,
        "definition": lambda: def_func(),
    }
    registry.append(entry)

    def decorator(func: Callable[[], ActionDefinition]):
        nonlocal def_func
        def_func = func

    return decorator


def register_action_v2(uuid: str):
    def not_implemented():
        raise NotImplementedError(
            "If u see this, it means the action registration had some issue"
        )

    def_func = not_implemented

    entry: ActionEntryV2 = {
        "uuid": uuid,
        "definition": lambda: def_func(),
    }
    registry_v2.append(entry)

    def decorator(func: Callable[[], Type[BaseAction]]):
        nonlocal def_func
        def_func = func

    return decorator


@register_action_v2(uuid="test-action")
def _test_action() -> Type[BaseAction]:
    from action.sample_action import TestAction

    return TestAction


@register_action_v2(uuid="test-resume-action")
def _test_resume_action() -> Type[BaseAction]:
    from action.sample_action import TestResumeAction

    return TestResumeAction


@register_action_v2(uuid="d0fa8218-d3e8-4795-aeff-b6b674d53284")
def _data_research() -> Type[BaseAction]:
    from action.analyze_documents.openai import OpenAiDocumentSearchAction

    return OpenAiDocumentSearchAction


@register_action_v2(uuid="2799ab51-bd82-4536-862c-12900d5dfd16")
def _address_validation_google_maps() -> Type[BaseAction]:
    from action.address_validation.google import GoogleAddressValidationAction

    return GoogleAddressValidationAction


@register_action_v2(uuid="d4369b3b-207f-4c15-8c9b-05ed2b2cf8d9")
def _company_enrich_apollo() -> Type[BaseAction]:
    from action.enrich_company.apollo import ApolloCompanyEnrichAction

    return ApolloCompanyEnrichAction


@register_action_v2(uuid="7c5ddca9-d940-497b-8d18-2e1749f94e3c")
def _web_page_scraper_scraper_api() -> Type[BaseAction]:
    from action.scrape_websites.scraper_api import ScraperApiWebScraperAction

    return ScraperApiWebScraperAction


@register_action_v2(uuid="1e275d44-d38f-4d40-8c5c-5d5e1a158078")
def _playwright_browser_with_script_execution() -> Type[BaseAction]:
    from action.browsers.playwright import PlaywrightBrowserAction

    return PlaywrightBrowserAction


@register_action_v2(uuid="findymail-enrich-all-valid-emails-with-domain")
def _enrich_all_valid_emails_with_domain_by_findymail() -> Type[BaseAction]:
    from action.enrich_all_emails_from_domain.findymail import (
        EnrichAllEmailsFromDomainAction,
    )

    return EnrichAllEmailsFromDomainAction


@register_action_v2(uuid="hunter-enrich-all-valid-emails-with-domain")
def _enrich_all_valid_emails_with_domain_by_hunter() -> Type[BaseAction]:
    from action.enrich_all_emails_from_domain.hunter import (
        EnrichAllEmailsFromDomainAction,
    )

    return EnrichAllEmailsFromDomainAction


@register_action_v2(uuid="prospeo-enrich-all-valid-emails-with-domain")
def _enrich_all_valid_emails_with_domain_by_prospeo() -> Type[BaseAction]:
    from action.enrich_all_emails_from_domain.prospeo import (
        EnrichAllEmailsFromDomainAction,
    )

    return EnrichAllEmailsFromDomainAction


@register_action_v2(uuid="hunter-enrich-email-action")
def _enrich_email_by_hunter() -> Type[BaseAction]:
    from action.enrich_email.hunter import (
        EnrichEmailAction,
    )

    return EnrichEmailAction


@register_action_v2(uuid="leadmagic-enrich-email-action")
def _enrich_email_by_leadmagic() -> Type[BaseAction]:
    from action.enrich_email.leadmagic import (
        EnrichEmailAction,
    )

    return EnrichEmailAction


@register_action_v2(uuid="prospeo-enrich-email-action")
def _enrich_email_by_prospeo() -> Type[BaseAction]:
    from action.enrich_email.prospeo import (
        EnrichEmailAction,
    )

    return EnrichEmailAction


@register_action_v2(uuid="pdl-enrich-ip-address-data")
def _enrich_ip_by_peopledatalabs() -> Type[BaseAction]:
    from action.enrich_ip.peopledatalabs import (
        EnrichIPAddressAction,
    )

    return EnrichIPAddressAction


@register_action_v2(uuid="leadmagic-enrich-mobile-action")
def _enrich_mobile_by_leadmagic() -> Type[BaseAction]:
    from action.enrich_mobile.leadmagic import (
        EnrichMobileAction,
    )

    return EnrichMobileAction


@register_action_v2(uuid="findymail-enrich-linkedin-profile-data")
def _enrich_linkedin_profile_data_by_findymail() -> Type[BaseAction]:
    from action.enrich_profile.findymail import (
        EnrichLinkedInProfileDataAction,
    )

    return EnrichLinkedInProfileDataAction


@register_action_v2(uuid="leadmagic-enrich-linkedin-profile-data")
def _enrich_linkedin_profile_data_by_leadmagic() -> Type[BaseAction]:
    from action.enrich_profile.leadmagic import (
        EnrichLinkedInProfileDataAction,
    )

    return EnrichLinkedInProfileDataAction


@register_action_v2(uuid="prospeo-enrich-linkedin-profile-data")
def _enrich_linkedin_profile_data_by_prospeo() -> Type[BaseAction]:
    from action.enrich_profile.prospeo import (
        EnrichLinkedInProfileDataAction,
    )

    return EnrichLinkedInProfileDataAction


@register_action_v2(uuid="findymail-enrich-profiles")
def _enrich_profiles_by_findymail() -> Type[BaseAction]:
    from action.enrich_profiles_from_company.findymail import (
        EnrichProfilesFromCompanyAction,
    )

    return EnrichProfilesFromCompanyAction


@register_action_v2(uuid="peopledatalabs-enrich-profiles")
def _enrich_profiles_by_peopledatalabs() -> Type[BaseAction]:
    from action.enrich_profiles_from_company.peopledatalabs import (
        EnrichProfilesFromCompanyAction,
    )

    return EnrichProfilesFromCompanyAction


@register_action_v2(uuid="enrich_yelp_business_by_phone")
def _enrich_yelp_business_by_phone() -> Type[BaseAction]:
    from action.enrich_smb.yelp_business_by_phone import (
        EnrichBusinessByPhoneAction,
    )

    return EnrichBusinessByPhoneAction


@register_action_v2(uuid="enrich-yelp-business-details-action")
def _enrich_yelp_business_details_action() -> Type[BaseAction]:
    from action.enrich_smb.yelp_business_enrich import (
        EnrichBusinessDetailsAction,
    )

    return EnrichBusinessDetailsAction


@register_action_v2(uuid="enrich-yelp-business-match-action")
def _enrich_yelp_business_match_action() -> Type[BaseAction]:
    from action.enrich_smb.yelp_business_match import (
        EnrichBusinessMatchAction,
    )

    return EnrichBusinessMatchAction


@register_action_v2(uuid="enrich_yelp_business_reviews_highlights")
def _enrich_yelp_business_reviews_highlights() -> Type[BaseAction]:
    from action.enrich_smb.yelp_business_reviews_highlights import (
        EnrichBusinessReviewsHighlightsAction,
    )

    return EnrichBusinessReviewsHighlightsAction


@register_action_v2(uuid="enrich_yelp_business_reviews")
def _enrich_yelp_business_reviews() -> Type[BaseAction]:
    from action.enrich_smb.yelp_business_reviews import (
        EnrichBusinessReviewAction,
    )

    return EnrichBusinessReviewAction


@register_action_v2(uuid="yelp-business-search-action")
def _yelp_business_search_action() -> Type[BaseAction]:
    from action.enrich_smb.yelp_business_search import (
        EnrichBusinessSearchAction,
    )

    return EnrichBusinessSearchAction


@register_action_v2(uuid="enrich-yelp-food-delivery-search-action")
def _enrich_yelp_food_delivery_search_action() -> Type[BaseAction]:
    from action.enrich_smb.yelp_food_delivery_search import (
        EnrichFoodDeliverySearchAction,
    )

    return EnrichFoodDeliverySearchAction


@register_action_v2(uuid="serpapi_enrich_business_search_action")
def _serpapi_enrich_business_search_action() -> Type[BaseAction]:
    from action.enrich_business_search.serp_api import (
        FindBusinessDetailsUsingGoogleSearchAction,
    )

    return FindBusinessDetailsUsingGoogleSearchAction


@register_action_v2(uuid="findymail-validate-email-action")
def _validate_email_with_findymail() -> Type[BaseAction]:
    from action.validate_email.findymail import (
        ValidateEmailAction,
    )

    return ValidateEmailAction


@register_action_v2(uuid="hunter-validate-email-action")
def _validate_email_with_hunter() -> Type[BaseAction]:
    from action.validate_email.hunter import (
        ValidateEmailAction,
    )

    return ValidateEmailAction


@register_action_v2(uuid="prospeo-validate-email-action")
def _validate_email_with_prospeo() -> Type[BaseAction]:
    from action.validate_email.prospeo import (
        ValidateEmailAction,
    )

    return ValidateEmailAction


@register_action_v2(uuid="zenrows-enrich-web-scrapper")
def _web_scraper_action() -> Type[BaseAction]:
    from action.scrap_website.zenrows import WebScrapeAction

    return WebScrapeAction


@register_action_v2(uuid="google_maps_business_locator_action")
def _google_maps_business_locator_action() -> Type[BaseAction]:
    from action.enrich_google_maps.serp_api import LocateBusinessUsingGoogleMapsAction

    return LocateBusinessUsingGoogleMapsAction


@register_action_v2(uuid="stock_performance_with_marketstack")
def _stock_performance_with_marketstack() -> Type[BaseAction]:
    from action.stock_performance.marketstack import StockPerformanceAction

    return StockPerformanceAction


@register_action_v2(uuid="e5f6c278-59ac-4d00-be1f-2299d61645a1")
def _web_page_scraper_scrapingbee() -> Type[BaseAction]:
    from action.scrape_websites.scraping_bee import ScrapingBeeWebScraperAction

    return ScrapingBeeWebScraperAction


@register_action_v2(uuid="ag5669240-9ddf-456e-a270-3abdf39b5928")
def _formula() -> Type[BaseAction]:
    from action.formula_evaluation.formula_evaluation import (
        JavascriptFormulaExecutionAction,
    )

    return JavascriptFormulaExecutionAction


@register_action_v2(uuid="8df10c5f-11d9-4353-a34d-357055e5d4ee")
def _get_company_headcount_by_coresignal() -> Type[BaseAction]:
    from action.headcount.coresignal import CoresignalGetHeadcountOfACompanyAction

    return CoresignalGetHeadcountOfACompanyAction


@register_action_v2(uuid="078b5ad0-8ce5-4a91-86e3-5d80b8b0d839")
def _get_company_employees_by_coresignal() -> Type[BaseAction]:
    from action.get_employees_of_a_company.coresignal import (
        CoresignalGetEmployeesOfACompanyAction,
    )

    return CoresignalGetEmployeesOfACompanyAction


@register_action_v2(uuid="f2bac9c7-3725-43c2-aa38-745cc427e94c")
def _http_request() -> Type[BaseAction]:
    from action.http.http import HttpAction

    return HttpAction


@register_action_v2(uuid="ad950dd2-5213-40c4-8fdb-aa0725c09449")
def _pdf_text_extraction() -> Type[BaseAction]:
    from action.extract_information_from_pdf.extractor import PdfInfoExtractorAction

    return PdfInfoExtractorAction


# This is experimental action
@register_action_v2(uuid="74592751-d1d6-4960-8685-296e088cbae9")
def _orbai() -> Type[BaseAction]:
    from action.agents.orb_agent import OrbAgentAction

    return OrbAgentAction


@register_action_v2(uuid="e076aaee-039f-4ecf-8d83-91a33c37eeb6")
def _google_search() -> Type[BaseAction]:
    from action.search_web.google import GoogleWebSearchAction

    return GoogleWebSearchAction


@register_action_v2(uuid="b8920108-2c1e-41cf-a028-3382465df9dd")
def _google_search_v2_scraper_api() -> Type[BaseAction]:
    from action.search_web.google_scraper_api import ScraperApiGoogleWebSearchAction

    return ScraperApiGoogleWebSearchAction


@register_action_v2(uuid="c88be9c4-593c-4de4-b9ff-b51e37427631")
def _find_nearby_places_google_maps() -> Type[BaseAction]:
    from action.nearby.google import GoogleNearbyAction

    return GoogleNearbyAction


@register_action_v2(uuid="d4f05e80-484c-4bb8-9ff4-26870b635e20")
def _geocode_address() -> Type[BaseAction]:
    from action.geocode.google import GoogleGeocodeAction

    return GoogleGeocodeAction


@register_action_v2(uuid="683772d6-d379-47ca-b38c-7e19df46bd63")
def _sitemap_generator() -> Type[BaseAction]:
    from action.sitemap.parse_sitemap import ParseSitemapAction

    return ParseSitemapAction


# !!!! don't change this uuid, its used in other places, change all if need to be changed  !!!!
@register_action_v2(uuid="0acce83f-d892-4d3b-bce4-35148d7a5c56")
def _read_from_another_table() -> Type[BaseAction]:
    from action.lookup_from_another_table.lookup import TableLookupAction

    return TableLookupAction


@register_action_v2(uuid="14429869-7a70-4313-b607-6eccc81c7f3f")
def _employee_reviews() -> Type[BaseAction]:
    from action.reviews_of_companies.glassdoor import GlassdoorReviewsAction

    return GlassdoorReviewsAction


@register_action_v2(uuid="67c46b8d-cab7-41ca-bc72-f4cbf7ab666f")
def _custom_python_code() -> Type[BaseAction]:
    from action.code.python import PythonCodeAction

    return PythonCodeAction


@register_action_v2(uuid="0c480600-db39-40e4-a9a7-ec358b15db1a")
def _custom_python_code_no_dependency_check() -> Type[BaseAction]:
    from action.code.python import PythonCodeNoDependencyAction

    return PythonCodeNoDependencyAction


@register_action_v2(uuid="f80428ba-b869-41cf-ab1f-0b70271580c9")
def _person_enrich_lead() -> Type[BaseAction]:
    from action.enrich_profile.apollo import ApolloEnrichProfileAction

    return ApolloEnrichProfileAction


@register_action_v2(uuid="4bd017c3-332c-4df7-9f9f-9de4c6fbb857")
def _lead_enrich_coresignal() -> Type[BaseAction]:
    from action.enrich_profile.coresignal import CoresignalEnrichProfileAction

    return CoresignalEnrichProfileAction


@register_action_v2(uuid="37706f1b-5966-44fc-8f8d-3ebae70fdd1d")
def _openai() -> Type[BaseAction]:
    from action.text_generation_llm.openai import GenerateTextOpenAiAction

    return GenerateTextOpenAiAction


@register_action_v2(uuid="88e19893-2fc4-4b38-9b37-537e4145dfa0")
def _claude() -> Type[BaseAction]:
    from action.text_generation_llm.anthropic import GenerateTextAnthropicAction

    return GenerateTextAnthropicAction


@register_action_v2(uuid="3a8d25d7-fa49-456c-89aa-1b8f4b7faa3a")
def _openai_vision() -> Type[BaseAction]:
    from action.vision.openai import OpenAiVisionAction

    return OpenAiVisionAction


@register_action_v2(uuid="76c3b63c-390d-4d0c-83a0-9290ad9ec1e1")
def _technographics() -> Type[BaseAction]:
    from action.enrich_company_technologies.built_with import (
        EnrichCompanyTechnologiesBuiltWithAction,
    )

    return EnrichCompanyTechnologiesBuiltWithAction


@register_action_v2(uuid="6f297407-8339-4986-85f1-a8a2edcac2ec")
def _company_using_technology() -> Type[BaseAction]:
    from action.companies_from_technologies.built_with import (
        GetCompanyUsingTechnologyBuiltWithAction,
    )

    return GetCompanyUsingTechnologyBuiltWithAction


@register_action_v2(uuid="69c90d10-d796-46a6-943c-0cece8ca0f42")
def _find_nearby_places_here_map() -> Type[BaseAction]:
    from action.nearby.here import HereNearbyAction

    return HereNearbyAction


@register_action_v2(uuid="759358df-61bc-4dd7-b804-6f81e8a8648d")
def _company_enrich_clearbit() -> Type[BaseAction]:
    from action.enrich_company.clearbit import ClearbitCompanyEnrichAction

    return ClearbitCompanyEnrichAction


@register_action_v2(uuid="32815ab8-6b9f-4bcf-8411-547a023d3b19")
def _company_enrich_coresignal() -> Type[BaseAction]:
    from action.enrich_company.coresignal import CoresignalCompanyEnrichAction

    return CoresignalCompanyEnrichAction


@register_action_v2(uuid="azure-openai-action")
def _azure_openai() -> Type[BaseAction]:
    from action.azure.openai import AzureOpenAiAction

    return AzureOpenAiAction


@register_action_v2(uuid="waterfall-action-v1")
def _waterfall_action_v1() -> Type[BaseAction]:
    from action.waterfall import WaterfallAction

    return WaterfallAction


@register_action_v2(uuid="sync-salesforce")
def _sync_salesforce() -> Type[BaseAction]:
    from action.sync.salesforce import SalesforceSyncAction

    return SalesforceSyncAction


@register_action_v2(uuid="sync-hubspot")
def _hubspot_sync_integration() -> Type[BaseAction]:
    from action.sync.hubspot import HubspotSyncAction

    return HubspotSyncAction


# -- Simple actions used for testing --
@register_action(uuid="add")
def _add() -> ActionDefinition:
    import provider.simple_provider

    return {
        "name": "Add",
        "description": "Add two numbers",
        "icon": "",
        "defaultOutputPath": "result.result",
        "inputSchema": provider.simple_provider.Request.model_json_schema(),
        "outputSchema": provider.simple_provider.Result.model_json_schema(),
        "class_": provider.simple_provider.Provider,
        "method": provider.simple_provider.Provider.add,
        "request_class": provider.simple_provider.Request,
    }


@register_action(uuid="subtract")
def _subtract() -> ActionDefinition:
    import provider.simple_provider

    return {
        "name": "Subtract",
        "description": "Subtract two numbers",
        "icon": "",
        "defaultOutputPath": "result.result",
        "inputSchema": provider.simple_provider.Request.model_json_schema(),
        "outputSchema": provider.simple_provider.Result.model_json_schema(),
        "class_": provider.simple_provider.Provider,
        "method": provider.simple_provider.Provider.subtract,
        "request_class": provider.simple_provider.Request,
    }


@register_action(uuid="multiply")
def _multiply() -> ActionDefinition:
    import provider.simple_provider

    return {
        "name": "Multiply",
        "description": "Multiply two numbers",
        "icon": "",
        "defaultOutputPath": "result.result",
        "inputSchema": provider.simple_provider.Request.model_json_schema(),
        "outputSchema": provider.simple_provider.Result.model_json_schema(),
        "class_": provider.simple_provider.Provider,
        "method": provider.simple_provider.Provider.multiply,
        "request_class": provider.simple_provider.Request,
    }


# -- End simple actions used for testing --


# TODO: Merge these three actions in v2
@register_action(uuid="ea33e162-c101-4027-a2fb-0ed8658a1b68")
def _find_company_leads() -> ActionDefinition:
    import provider.lead

    return {
        "name": "Find Company Leads (Deprecated)",
        "description": "Find Company Leads from Linkedin",
        "icon": "https://www.linkedin.com/favicon.ico",
        "defaultOutputPath": "result.count",
        "inputSchema": provider.lead.RequestGetGlobal.model_json_schema(),
        "outputSchema": provider.lead.Result.model_json_schema(),
        "class_": provider.lead.coresignal.Provider,
        "method": provider.lead.coresignal.Provider.get_global,
        "request_class": provider.lead.RequestGetGlobal,
    }


@register_action(uuid="ff208d89-cb17-49d3-b917-bbed96301d5f")
def _find_company_leads_by_country() -> ActionDefinition:
    import provider.lead

    return {
        "name": "Find Company Leads by Country (Deprecated)",
        "description": "Find Company Leads from Linkedin by Country",
        "icon": "https://www.linkedin.com/favicon.ico",
        "defaultOutputPath": "result.count",
        "inputSchema": provider.lead.RequestGetByCountry.model_json_schema(),
        "outputSchema": provider.lead.Result.model_json_schema(),
        "class_": provider.lead.coresignal.Provider,
        "method": provider.lead.coresignal.Provider.get_by_country,
        "request_class": provider.lead.RequestGetByCountry,
    }


@register_action(uuid="2fd44fa3-7289-4819-ab0f-c780a51df476")
def _find_company_leads_by_zip() -> ActionDefinition:
    import provider.lead

    return {
        "name": "Find Company Leads By Zip (Deprecated)",
        "description": "Find Company Leads at a Zip code",
        "icon": "https://www.linkedin.com/favicon.ico",
        "defaultOutputPath": "result.count",
        "inputSchema": provider.lead.RequestGetByZip.model_json_schema(),
        "outputSchema": provider.lead.Result.model_json_schema(),
        "class_": provider.lead.coresignal.Provider,
        "method": provider.lead.coresignal.Provider.get_by_zip,
        "request_class": provider.lead.RequestGetByZip,
    }


# TODO: Merge the following headcount actions into one in v2
@register_action(uuid="d22a9d23-87b9-4004-9ae7-f167e1531594")
def _company_headcount_by_zip() -> ActionDefinition:
    import provider.headcount

    return {
        "name": "Company Headcount by Zip (Deprecated)",
        "description": "Get company headcount by Zip code",
        "icon": "https://www.linkedin.com/favicon.ico",
        "defaultOutputPath": "result.count",
        "inputSchema": provider.headcount.RequestHeadcountByZip.model_json_schema(),
        "outputSchema": provider.headcount.Result.model_json_schema(),
        "class_": provider.headcount.Provider,
        "method": provider.headcount.Provider.headcount_by_zip,
        "request_class": provider.headcount.RequestHeadcountByZip,
    }


@register_action(uuid="d49892fb-8be0-4139-a944-16058121266f")
def _company_headcount_by_country() -> ActionDefinition:
    import provider.headcount

    return {
        "name": "Company Headcount by Country (Deprecated)",
        "description": "Get company headcount by Country",
        "icon": "https://www.linkedin.com/favicon.ico",
        "defaultOutputPath": "result.count",
        "inputSchema": provider.headcount.RequestHeadcountByCountry.model_json_schema(),
        "outputSchema": provider.headcount.Result.model_json_schema(),
        "class_": provider.headcount.Provider,
        "method": provider.headcount.Provider.headcount_by_country,
        "request_class": provider.headcount.RequestHeadcountByCountry,
    }


@register_action(uuid="5f1459ab-3479-4d2a-9756-baacc3d238a2")
def _company_headcount_global() -> ActionDefinition:
    import provider.headcount

    return {
        "name": "Company Headcount Global (Deprecated)",
        "description": "Get global company headcount",
        "icon": "https://www.linkedin.com/favicon.ico",
        "defaultOutputPath": "result.count",
        "inputSchema": provider.headcount.RequestHeadcountGlobal.model_json_schema(),
        "outputSchema": provider.headcount.Result.model_json_schema(),
        "class_": provider.headcount.Provider,
        "method": provider.headcount.Provider.headcount_global,
        "request_class": provider.headcount.RequestHeadcountGlobal,
        "chargeable_units_calculator": provider.headcount.Provider.chargeable_units_calculator,
    }


# {
#     "uuid": "73037d5b-169e-4735-b37d-6617adaf7e90",
#     "name": "Apify Scraper",
#     "description": "Scrape using Apify",
#     "icon": "https://apify.com/favicon.ico",
#     "inputSchema": provider.scraper.Request.model_json_schema(),
#     "outputSchema": provider.scraper.Result.model_json_schema(),
#     "defaultOutputPath": "result.data",
#     "class_": provider.scraper.apify.Provider,
#     "method": provider.scraper.apify.Provider.run,
#     "request_class": provider.scraper.Request,
#


@register_action(uuid="f5669240-9ddf-456e-a270-3abdf39b5928")
def _webpage_screenshot() -> ActionDefinition:
    import provider.web_capture

    return {
        "name": "Webpage Screenshot",
        "description": "Captures screenshot of a webpage",
        "icon": "https://app.withorbital.dev/favicon.ico",
        "defaultOutputPath": "result.image_count",
        "inputSchema": provider.web_capture.Request.model_json_schema(),
        "outputSchema": provider.web_capture.Result.model_json_schema(),
        "class_": provider.web_capture.Provider,
        "method": provider.web_capture.Provider.capture_web_page,
        "request_class": provider.web_capture.Request,
    }


@register_action(uuid="c2252bd6-8f26-42cd-bb67-2b646065a5c9")
def _derived() -> ActionDefinition:
    import provider.derived

    return {
        "name": "Derived",
        "description": "Derived data from other field",
        "icon": "",
        "defaultOutputPath": "result.data",
        "inputSchema": provider.derived.Request.model_json_schema(),
        "outputSchema": provider.derived.Result.model_json_schema(),
        "class_": provider.derived.Provider,
        "method": provider.derived.Provider.derive,
        "request_class": provider.derived.Request,
    }


"""

{
        "uuid": "c2252bd6-8f26-42cd-bb67-2b646065a5c9",
        "name": "Derived",
        "description": "Derived data from other field",
        "icon": None,
        "inputSchema": {
            "type": "object",
            "properties": {"input": {"type": "string"}},
            "required": ["input"],
        },
        "outputSchema": {
            "type": "object",
            "properties": {"data": {"type": "string"}},
            "required": ["data"],
        },
        "defaultOutputPath": "result.data",
        "callback": lambda input: {"result": {"data": input["input"]}},
    },



"""
