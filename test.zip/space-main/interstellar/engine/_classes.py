import abc
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, TypedDict


import pydantic

from action.types import ActionResumeState, ActionUsage


class StepStatus:
    QUEUED = "queued"
    RUNNING = "running"
    WAITING = "waiting"
    SUCCESSFUL = "successful"
    FAILED = "failed"
    CANCELED = "canceled"
    PRE_CHECK_FAILED = "pre_check_failed"
    SKIPPED = "skipped"


class StepState(TypedDict):
    uuid: str
    instance_id: str
    step_id: str
    action_id: str
    status: str  # TODO (adi): make this StepStatus
    pre_check: bool
    input: Any
    output: Any
    created_at: datetime
    updated_at: datetime | None


class StepAction(TypedDict):
    step_id: str
    action_id: str


class ActionRunMetadata(pydantic.BaseModel):
    usage: ActionUsage | None = None
    run_duration: int


class StepStateManagerInterface(abc.ABC):
    @abc.abstractmethod
    def get_by_uuid(self, uuid: str) -> StepState:
        pass

    @abc.abstractmethod
    def get_latest_by_step_id(self, instance_id: str, step_id: str) -> StepState:
        pass

    @abc.abstractmethod
    def get_all_latest_by_instance_id(self, instance_id: str) -> List[StepState]:
        pass

    @abc.abstractmethod
    def get_all_queued_by_instance_id(self, instance_id: str) -> List[StepState]:
        pass

    @abc.abstractmethod
    def queue_many_steps(self, instance_id: str, data: list[StepAction]):
        pass

    @abc.abstractmethod
    def create(
        self,
        instance_id: str,
        step_id: str,
        action_id: str,
        status: str,
        pre_check_output: bool,
        input: Any,
        output: Any = None,
    ) -> str:
        pass

    @abc.abstractmethod
    def set_output(self, uuid: str, output: Any, status: str):
        pass

    @abc.abstractmethod
    def set_pre_check_failed(self, uuid: str):
        pass

    @abc.abstractmethod
    def set_step_failed_by_instance(
        self, instance_id: str, step_id: str, error_msg: str
    ):
        pass

    @abc.abstractmethod
    def set_status(self, uuid: str, status: str):
        pass

    @abc.abstractmethod
    def update(
        self,
        uuid: str,
        status: str,
        action_id: str,
        input: Any,
    ):
        pass

    @abc.abstractmethod
    def store_usage(self, uuid: str, meta: "ActionRunMetadata"):
        pass


@dataclass
class ActionTriggerParams(TypedDict):
    state_uuid: str
    step_id: str


class ConfigProvider(abc.ABC):
    @abc.abstractmethod
    def get_config(self) -> Dict[str, Any]:
        # get workflow config from the instance id
        pass

    def get_static_values(self) -> Dict[str, Any]:
        # Return static input values for the instance
        return {}


class TemplateError(TypedDict):
    message: str


class TemplateEngine(abc.ABC):
    @abc.abstractmethod
    def eval_input(
        self, input: Dict[str, Any]
    ) -> tuple[Dict[str, Any], TemplateError | None]:
        pass

    @abc.abstractmethod
    def eval_pre_check(self, formula: str) -> tuple[bool, TemplateError | None]:
        pass


class ConfigStep(pydantic.BaseModel):
    id: str
    action_id: str
    disable_auto_run: bool
    pre_check: str | None = None
    input: Dict[str, Any]
    dependency: List[str] | None = []
    skip_dependency_check: bool = False


class ConfigSchema(pydantic.BaseModel):
    instance_id: str
    steps: List[ConfigStep]

    # TODO (ankith): add more complex validations


class ActionException(Exception):
    """Base class for exceptions in this module."""

    def __init__(self, message, data, error_code, *args: object) -> None:
        super().__init__(*args)
        self.message = message
        self.data = data
        self.error_code = error_code


class ActionResolver(abc.ABC):
    @abc.abstractmethod
    def run(
        self, run_id: str, action_id: str, input: Dict[str, Any]
    ) -> tuple[Any, "ActionRunMetadata | None", "ActionResumeState | None"]:
        pass

    @abc.abstractmethod
    def resume(
        self,
        run_id: str,
        action_id: str,
        trigger_type: str,
        input: Dict[str, Any],
        state: Dict[str, Any] | None = None,
        payload: Dict[str, Any] | None = None,
    ) -> tuple[Any, "ActionRunMetadata | None", "ActionResumeState | None"]:
        pass
