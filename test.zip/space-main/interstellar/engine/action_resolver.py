import time
from typing import Any, Callable, Dict, Type, TypedDict, NotRequired

import pydantic
import pydash

from action.base_resume import BaseResumableAction
from action.types import ActionResumeState, BaseActionOutput
from action.base import BaseAction

from engine._classes import ActionResolver, ActionRunMetadata, ActionUsage
from provider._classes import ProviderResponse
from util.logger import interstellar_logger


logger = interstellar_logger(__name__)


class ActionEntry(TypedDict):
    uuid: str
    definition: Callable[[], "ActionDefinition"] | "ActionDefinition"


class ActionEntryV2(TypedDict):
    uuid: str
    definition: Callable[[], Type["BaseAction"]]


class ActionDefinition(TypedDict):
    name: str
    description: str
    icon: str
    defaultOutputPath: str
    inputSchema: dict
    outputSchema: dict
    class_: type
    method: Callable[..., ProviderResponse]
    request_class: Type[pydantic.BaseModel]
    chargeable_units_calculator: NotRequired[Callable[[ActionUsage], int]]


class UIActionResolver(ActionResolver):
    def resume(
        self,
        run_id: str,
        action_id: str,
        trigger_type: str,
        input: Dict[str, Any],
        state: Dict[str, Any] | None = None,
        payload: Dict[str, Any] | None = None,
    ) -> tuple[Any, ActionRunMetadata, ActionResumeState[BaseActionOutput] | None]:
        from engine._action_registry import registry_v2

        action_def = pydash.find(registry_v2, lambda x: x["uuid"] == action_id)

        if action_def is None:
            raise ValueError(f"Action with id {action_id} not found")
        action_class = action_def["definition"]()

        # TODO: get state_uuid and initialize action with it
        action = action_class(run_id)

        if not isinstance(action, BaseResumableAction):
            raise ValueError(f"Action with id {action_id} is not resumable")

        start_time = time.time_ns()
        result, error, usage, resume = action.resume(
            trigger_type, input, state, payload
        )
        duration_ms = (time.time_ns() - start_time) // 1000  # in microseconds

        if (error) and (not error.retryable):
            # TODO: make this better, copied from above
            raise Exception(error.message) from error.e

        # TODO: For backward compatibility, cleanup this once all actions are migrated to v2
        return (
            {
                "result": result.model_dump() if result else None,
                "error": error.model_dump() if error else None,
            },
            ActionRunMetadata(usage=usage, run_duration=duration_ms),
            resume,
        )

    def run(
        self, run_id: str, action_id: str, input: dict[str, Any]
    ) -> tuple[
        Any, ActionRunMetadata | None, ActionResumeState[BaseActionOutput] | None
    ]:
        from engine._action_registry import registry

        action = pydash.find(registry, lambda x: x["uuid"] == action_id)
        if action is not None:
            if callable(action["definition"]):
                action_def = action["definition"]()
            else:
                action_def = action["definition"]

            obj = action_def["class_"]()
            method = getattr(obj, action_def["method"].__name__)
            req = action_def["request_class"](**input)
            out: ProviderResponse = method(req)
            usage = None
            if (out.error) and (not out.error.retryable):
                # TODO: make this better
                raise Exception(out.error.message) from out.error.e
            return out.model_dump(), usage, None
        else:
            from engine._action_registry import registry_v2

            action_def = pydash.find(registry_v2, lambda x: x["uuid"] == action_id)

            if action_def is None:
                raise ValueError(f"Action with id {action_id} not found")
            action_class = action_def["definition"]()

            # TODO: get state_uuid and initialize action with it
            action = action_class(run_id)

            start_time = time.time_ns()
            result, error, usage, resume = action.run(input)
            duration_ms = (time.time_ns() - start_time) // 1000  # in microseconds

            if (error) and (not error.retryable):
                # TODO: make this better, copied from above
                raise Exception(error.message) from error.e

            # TODO: For backward compatibility, cleanup this once all actions are migrated to v2
            return (
                {
                    "result": result.model_dump() if result else None,
                    "error": error.model_dump() if error else None,
                },
                ActionRunMetadata(usage=usage, run_duration=duration_ms),
                resume,
            )


from prisma import Prisma, Json


def update_action_list(prisma: "Prisma"):
    from engine._action_registry import registry
    from engine._action_registry import registry_v2

    if not prisma.is_connected():
        prisma.connect()

    for entry in registry:
        uuid = entry["uuid"]
        if callable(entry["definition"]):
            action_definition = entry["definition"]()
        else:
            action_definition = entry["definition"]

        print(f"Upserting action: {action_definition['name']}")
        prisma.ui_action.upsert(
            data={
                "create": {
                    "uuid": uuid,
                    "name": action_definition["name"],
                    "description": action_definition["description"],
                    "icon": action_definition["icon"] or "",
                    "inputSchema": Json(action_definition["inputSchema"]),
                    "outputSchema": Json(action_definition["outputSchema"]),
                    "defaultOutputPath": action_definition["defaultOutputPath"],
                },
                "update": {
                    "name": action_definition["name"],
                    "description": action_definition["description"],
                    "icon": action_definition["icon"] or "",
                    "inputSchema": Json(action_definition["inputSchema"]),
                    "outputSchema": Json(action_definition["outputSchema"]),
                    "defaultOutputPath": action_definition["defaultOutputPath"],
                },
            },
            where={"uuid": uuid},
        )

    for entry in registry_v2:
        action = entry["definition"]()
        print(f"Upserting action: {action.name}")
        prisma.ui_action.upsert(
            data={
                "create": {
                    "uuid": action.id,
                    "name": action.name,
                    "description": action.description,
                    "icon": action.icon or "",
                    "inputSchema": Json(action.input_schema.model_json_schema()),  # type: ignore
                    "outputSchema": Json(action.output_schema.model_json_schema()),
                    "defaultOutputPath": action.default_output_path,
                    "tags": action.tags,
                },
                "update": {
                    "name": action.name,
                    "description": action.description,
                    "icon": action.icon or "",
                    "inputSchema": Json(action.input_schema.model_json_schema()),  # type: ignore
                    "outputSchema": Json(action.output_schema.model_json_schema()),
                    "defaultOutputPath": action.default_output_path,
                    "tags": action.tags,
                },
            },
            where={"uuid": action.id},
        )


if __name__ == "__main__":
    with Prisma() as prisma:
        update_action_list(prisma)
