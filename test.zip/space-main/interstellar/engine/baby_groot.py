import json
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import JsonOutputParser
import config

from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

# TODO: take supported actions as variable
template = """
you are a workflow assistant, below are the all the actions our workflow generator support. name, input format and output format
2799ab51-bd82-4536-862c-12900d5dfd16, Address Validation (Google Maps), input schema -	{"type": "object", "title": "Request", "required": ["raw_address"], "properties": {"raw_address": {"type": "string", "title": "Raw Address"}, "region_code": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Region Code", "default": null}}} {"type": "object", "title": "Result", "properties": {"lat": {"anyOf": [{"type": "number"}, {"type": "null"}], "title": "Lat", "default": null}, "lng": {"anyOf": [{"type": "number"}, {"type": "null"}], "title": "Lng", "default": null}, "city": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "City", "default": null}, "state": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "State", "default": null}, "street": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Street", "default": null}, "country": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Country", "default": null}, "state_id": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "State Id", "default": null}, "zip_code": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Zip Code", "default": null}, "country_iso": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Country Iso", "default": null}, "raw_address": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Raw Address", "default": null}, "region_code": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Region Code", "default": null}, "formatted_address": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Formatted Address", "default": null}}}
37706f1b-5966-44fc-8f8d-3ebae70fdd1d, openai, input schema-	{"type": "object", "title": "OpenAIRequest", "required": ["model", "query"], "properties": {"model": {"enum": ["gpt-4-turbo", "gpt-4o-mini", "gpt-4-0125-preview", "gpt-4-1106-preview", "gpt-4-vision-preview", "gpt-4", "gpt-4-32k"], "type": "string", "title": "Model"}, "query": {"type": "string", "title": "Query"}, "output_format": {"enum": ["text", "json_object"], "type": "string", "title": "Output Format", "default": "text"}}} output schema-	{"type": "object", "$defs": {"LLMUsage": {"type": "object", "title": "LLMUsage", "required": ["prompt_tokens", "completion_tokens", "total_tokens"], "properties": {"total_tokens": {"anyOf": [{"type": "integer"}, {"type": "null"}], "title": "Total Tokens"}, "prompt_tokens": {"anyOf": [{"type": "integer"}, {"type": "null"}], "title": "Prompt Tokens"}, "completion_tokens": {"anyOf": [{"type": "integer"}, {"type": "null"}], "title": "Completion Tokens"}}}}, "title": "Result", "required": ["message", "usage"], "properties": {"usage": {"anyOf": [{"$ref": "#/$defs/LLMUsage"}, {"type": "null"}]}, "message": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Message"}}}
67c46b8d-cab7-41ca-bc72-f4cbf7ab666f, Custom Python code, input schema-	{"type": "object", "title": "Request", "required": ["code", "input"], "properties": {"code": {"type": "string", "title": "Code", "format": "code-editor"}, "input": {"input": "object", "title": "Input", "additionalProperties": true}}} output schema-	{"type": "object", "title": "Result", "required": ["output"], "properties": {"output": {"type": "object", "title": "Output"}}}
7c5ddca9-d940-497b-8d18-2e1749f94e3c, Web Page Scraper, input schema-	{"type": "object", "title": "Request", "required": ["url"], "properties": {"url": {"type": "string", "title": "Url"}}} output schema-	{"type": "object", "title": "Result", "required": ["text_content", "links", "url"], "properties": {"url": {"type": "string", "title": "Url"}, "links": {"type": "array", "items": {"type": "string"}, "title": "Links"}, "text_content": {"type": "string", "title": "Text Content"}}}
d4369b3b-207f-4c15-8c9b-05ed2b2cf8d9, Company Enrich, input schema-	{"type": "object", "title": "Request", "required": ["domain"], "properties": {"domain": {"type": "string", "title": "Domain"}}} output schema-	{"type": "object", "title": "Result", "required": ["name", "domain", "website"], "properties": {"blog": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Blog", "default": null}, "city": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "City", "default": null}, "logo": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Logo", "default": null}, "name": {"type": "string", "title": "Name"}, "phone": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Phone", "default": null}, "state": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "State", "default": null}, "domain": {"type": "string", "title": "Domain"}, "country": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Country", "default": null}, "twitter": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Twitter", "default": null}, "website": {"type": "string", "title": "Website"}, "facebook": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Facebook", "default": null}, "industry": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Industry", "default": null}, "linkedin": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Linkedin", "default": null}, "angellist": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Angellist", "default": null}, "crunchbase": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Crunchbase", "default": null}, "postal_code": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Postal Code", "default": null}, "raw_address": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Raw Address", "default": null}, "founded_year": {"anyOf": [{"type": "integer"}, {"type": "null"}], "title": "Founded Year", "default": null}, "total_funding": {"anyOf": [{"type": "integer"}, {"type": "null"}], "title": "Total Funding", "default": null}, "annual_revenue": {"anyOf": [{"type": "integer"}, {"type": "null"}], "title": "Annual Revenue", "default": null}, "street_address": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Street Address", "default": null}, "no_of_employees": {"anyOf": [{"type": "integer"}, {"type": "null"}], "title": "No Of Employees", "default": null}, "technology_names": {"type": "array", "items": {"type": "string"}, "title": "Technology Names", "default": []}, "short_description": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Short Description", "default": null}, "latest_funding_stage": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Latest Funding Stage", "default": null}, "latest_funding_round_date": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Latest Funding Round Date", "default": null}}}
e076aaee-039f-4ecf-8d83-91a33c37eeb6, Google Search, input schema-	{"type": "object", "title": "Request", "required": ["query"], "properties": {"limit": {"anyOf": [{"type": "integer"}, {"type": "null"}], "title": "Limit", "default": null}, "query": {"type": "string", "title": "Query"}, "file_type": {"anyOf": [{"enum": ["pdf", "doc", "docx", "xls", "xlsx"], "type": "string"}, {"type": "null"}], "title": "File Type", "default": null}}} output schema-	{"type": "object", "$defs": {"Item": {"type": "object", "title": "Item", "required": ["title", "link", "displayLink", "snippet", "fileFormat", "mime"], "properties": {"link": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Link"}, "mime": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Mime"}, "title": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Title"}, "snippet": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Snippet"}, "fileFormat": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Fileformat"}, "displayLink": {"anyOf": [{"type": "string"}, {"type": "null"}], "title": "Displaylink"}}}}, "title": "Result", "required": ["items"], "properties": {"items": {"type": "array", "items": {"$ref": "#/$defs/Item"}, "title": "Items"}}}
74592751-d1d6-4960-8685-296e088cbae9, OrbAI(AI Agent), input schema- {"type": "object", "$defs": {"LLMInput": {"type": "object", "title": "LLMInput", "properties": {"llm": {"enum": ["OpenAI", "MistralAI", "Anthropic"], "type": "string", "title": "Llm", "default": "OpenAI"}, "model": {"enum": ["gpt-4-turbo-2024-04-09", "gpt-4o-mini", "open-mistral-7b", "open-mixtral-8x7b", "open-mixtral-8x22b", "claude-3-opus-20240229", "claude-3-sonnet-20240229", "claude-3-haiku-20240307"], "type": "string", "title": "Model", "default": "gpt-4o-mini"}}}}, "title": "Request", "required": ["input"], "properties": {"llm": {"allOf": [{"$ref": "#/$defs/LLMInput"}], "default": {"llm": "OpenAI", "model": "gpt-3.5-turbo-0125"}}, "input": {"type": "string", "title": "Input"}}} output schema-	{"type": "object", "title": "Result", "required": ["input", "output"], "properties": {"input": {"type": "string", "title": "Input"}, "output": {"type": "string", "title": "Output"}}}

our workflow also can have static TEXT fields if there is data input needed. 
example config array - [{"uuid":"123","type":"TEXT", "name":"name"},{"uuid":"234","type": "action", "name":"search_1", "action_type": "Google Search", "action_uuid":"e076aaee-039f-4ecf-8d83-91a33c37eeb6", "output_path":"result.items.0.title", "input_config":{"limit":null,"query":{"$":[{"type":"slash-variable","label":"name","value":["123"]}]},"file_type":null}},{"uuid":"345","name":"search_2","type":"action","action_type":"Google Search", "action_uuid":"e076aaee-039f-4ecf-8d83-91a33c37eeb6", "output_path":"result.items.0.link", "input_config": {"limit":1,"query":{"$":[{"type":"slash-variable","label":"search_1.items.0.title","value":["234","result","items",0,"title"]},{"text":" news","type":"text"}]},"file_type":null}}]

so we can map output of one column to input of other column. that is done in input_config with below format
{"limit":1,"query":{"$":[{"type":"slash-variable","label":"search_1.items.0.title","value":["234","result","items",0,"title"]},{"text":" news","type":"text"}]},"file_type":null}
the above example interprets the output to 234.items.0.title and appends news to it.
mapped inputs should always be in the above format

output_path is the path of the data needed in the actions output. output_path should be mapped to the proper path as per required data point.
config of a column should be in below format. don't return uuid
{"name":"", "type":"TEXT/action", "action_type": "", action_uuid:"", "input_config": {}, "output_path": ""}

custom python code is always in the below format. name is the input to the function. if there are two inputs, the function should have two inputs.
def func(name):
    # Write your code here
    return name
result = func(name)

the python code should always contain the last line as result = func(name) and the function should return the result.
python code will have json, pydash, math libs available by default. feel free to use them when needed.

Now prepare a workflow config. 
column name should be pythonic and should not have spaces.
the output should be in the format just the one column config, output in strict json format
Make sure to add proper output path based on the below prompt

Now given this information, as a workflow expert give a workflow config for the new column to be created.
{{prompt}}

below columns are already available in the workflow table. create workflow columns needed for the above tasks don't add the below columns again in the config.
*****our columns config array*****
{{config}}
*****our columns config array*****
"""
prompt_template = PromptTemplate(
    template=template, input_variables=["prompt", "config"], template_format="jinja2"
)


class Groot:
    def recommend_column(self, prompt: str, existing_config: list[dict]):
        llm = ChatOpenAI(
            api_key=config.get_parameter("OPENAI_API_KEY"),  # type: ignore
            model="gpt-4o-mini",
            model_kwargs={"response_format": {"type": "json_object"}},
        )

        # TODO: create pydantic model and send to output parser
        parser = JsonOutputParser()

        chain = prompt_template | llm | parser

        response = chain.invoke(
            {"prompt": prompt, "config": json.dumps(existing_config)}
        )
        logger.info(f"openai column suggestion response - {response}")
        return response
