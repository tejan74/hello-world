from copy import deepcopy
import json
from typing import Any, Dict
from jinja2 import TemplateError as JinjaTemplateError
import jinja2
import pydash

from engine._classes import TemplateEngine, TemplateError
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class JinjaInputTemplateEngine(TemplateEngine):
    def __init__(self, variables: Dict[str, Any]) -> None:
        super().__init__()

        # TODO (ankith): limit the available features of jinja
        self._env = jinja2.Environment(
            finalize=self._finalize,
            # This is so that undefined variables can be accessed further and not throw an error
            # see: https://jinja.palletsprojects.com/en/3.1.x/api/#jinja2.ChainableUndefined
            undefined=jinja2.ChainableUndefined,
        )
        self._env.globals = deepcopy(variables)

    def eval_input(
        self, input: Dict[str, Any]
    ) -> tuple[Dict[str, Any], TemplateError | None]:
        input_copy = deepcopy(input)
        try:
            pydash.map_values_deep(
                input_copy, lambda x: self._apply_template(x) if type(x) == str else x
            )
            return input_copy, None
        except JinjaTemplateError as e:
            logger.exception("Error while evaluating input {%s}", input)
            return {}, {"message": str(e)}

    def eval_pre_check(self, formula: str) -> tuple[bool, TemplateError | None]:
        try:
            out = self._env.from_string(formula).render().strip()
            if out not in ["true", "false", "null"]:
                return False, {
                    "message": "The formula should evaluate to a boolean value"
                }
            else:
                return out == "true", None
        except Exception as e:
            logger.exception("Error while evaluating pre-check formula {%s}", formula)
            return False, {"message": str(e)}

    # Converts python types to their JSON equivalent
    def _finalize(self, value):
        if type(value) == bool:
            return "true" if value else "false"
        if type(value) == dict:
            return json.dumps(value)
        if type(value) == list:
            return json.dumps(value)
        if value == None:
            return "null"
        return value

    def _apply_template(self, template: str):
        logger.debug("template input:", template)
        rendered_value = self._env.from_string(template).render()
        logger.debug("evaluated value", rendered_value)

        final_value = None
        # If the rendered value is the same as the template, then it is not a jinja template. Its a static value
        if rendered_value == template:
            final_value = template
        else:
            try:
                # Try to parse the rendered value as JSON to convert it to expected data types
                final_value = json.loads(rendered_value)
            except json.JSONDecodeError:
                final_value = rendered_value

        logger.debug("final value", final_value)
        return final_value
