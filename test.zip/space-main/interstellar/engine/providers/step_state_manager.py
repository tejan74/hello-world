from datetime import datetime
import time
from typing import Any, List

from engine._classes import (
    ActionRunMetadata,
    StepStateManagerInterface,
    StepState,
    StepStatus,
    StepAction,
)

from prisma import Prisma, fields, actions

from engine.providers.table_config_manager import UIConfigProvider
from engine.v1 import event
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class StepStateManager(StepStateManagerInterface):
    def __init__(self, prisma: Prisma, config_provider: UIConfigProvider) -> None:
        self.config_provider = config_provider
        self._prisma = prisma

    def _get_workflow_id(self) -> str:
        if not hasattr(self, "workflow_id"):
            self.workflow_id = self.config_provider.get_workflow_id()
        return self.workflow_id

    def get_by_uuid(self, uuid: str) -> StepState:
        start_time = time.time()
        state = self._prisma.wf_stepstate.find_unique(where={"uuid": uuid})
        logger.info(
            f"[time-log] Got step state for uuid {uuid} in {time.time() - start_time} seconds"
        )

        if not state:
            raise ValueError(f"Agent state with uuid {uuid} not found")

        return {
            "uuid": state.uuid,
            "instance_id": state.instanceId,
            "step_id": state.stepId,
            "action_id": state.actionId,
            "status": state.status,
            "pre_check": state.preCheck,
            "input": state.input,
            "output": state.output,
            "created_at": state.createdAt,
            "updated_at": state.updatedAt,
        }

    def get_latest_by_step_id(self, instance_id: str, step_id: str) -> StepState:
        start_time = time.time()
        state = self._prisma.wf_stepstate.find_first(
            where={
                "workflowId": self._get_workflow_id(),
                "instanceId": instance_id,
                "stepId": step_id,
            },
            order={"createdAt": "desc"},
        )
        logger.info(
            f"[time-log] Got latest step state for instance {instance_id} and step {step_id} in {time.time() - start_time} seconds"
        )

        if not state:
            raise ValueError(
                f"Agent state with instance_id {instance_id} and step_id {step_id} not found"
            )

        return {
            "uuid": state.uuid,
            "instance_id": state.instanceId,
            "step_id": state.stepId,
            "action_id": state.actionId,
            "status": state.status,
            "pre_check": state.preCheck,
            "input": state.input,
            "output": state.output,
            "created_at": state.createdAt,
            "updated_at": state.updatedAt,
        }

    def get_all_latest_by_instance_id(self, instance_id: str) -> List[StepState]:
        start_time = time.time()
        states = self._prisma.wf_stepstate.find_many(
            where={"workflowId": self._get_workflow_id(), "instanceId": instance_id},
            order={"createdAt": "desc"},
        )
        logger.info(
            f"[time-log] Got all latest step states for instance {instance_id} in {time.time() - start_time} seconds"
        )

        if not states:
            return []

        # find latest state for each fieldUuid
        latest_states = {}

        for state in states:
            if state.stepId not in latest_states:
                latest_states[state.stepId] = state

        return [
            {
                "uuid": state.uuid,
                "instance_id": state.instanceId,
                "step_id": state.stepId,
                "action_id": state.actionId,
                "status": state.status,
                "pre_check": state.preCheck,
                "input": state.input,
                "output": state.output,
                "created_at": state.createdAt,
                "updated_at": state.updatedAt,
            }
            for state in latest_states.values()
        ]

    def get_all_queued_by_instance_id(self, instance_id: str) -> List[StepState]:
        start_time = time.time()
        queued_states = self._prisma.wf_stepstate.find_many(
            where={
                "workflowId": self._get_workflow_id(),
                "instanceId": instance_id,
                "status": StepStatus.QUEUED,
            },
            order={"createdAt": "asc"},
        )
        logger.info(
            f"[time-log] Got all queued step states for instance {instance_id} in {time.time() - start_time} seconds"
        )
        return [
            {
                "uuid": state.uuid,
                "instance_id": state.instanceId,
                "step_id": state.stepId,
                "action_id": state.actionId,
                "status": state.status,
                "pre_check": state.preCheck,
                "input": state.input,
                "output": state.output,
                "created_at": state.createdAt,
                "updated_at": state.updatedAt,
            }
            for state in queued_states
        ]

    def queue_many_steps(self, instance_id: str, data: list[StepAction]):
        start_time = time.time()
        self._prisma.wf_stepstate.create_many(
            data=[
                {
                    "stepId": step["step_id"],
                    "instanceId": instance_id,
                    "actionId": step["action_id"],
                    "status": StepStatus.QUEUED,
                    "input": fields.Json({}),
                    "output": fields.Json({}),
                    "preCheck": True,
                    "createdAt": datetime.now(),
                    "updatedAt": datetime.now(),
                    "workflowId": self._get_workflow_id(),
                }
                for step in data
            ]
        )
        logger.info(
            f"[time-log] Queued steps for instance {instance_id} in {time.time() - start_time} seconds"
        )

    def create(
        self,
        instance_id: str,
        step_id: str,
        action_id: str,
        status: str,
        pre_check: bool,
        input: Any,
        output: Any = {},
    ) -> str:
        start_time = time.time()
        state = self._prisma.wf_stepstate.create(
            data={
                "stepId": step_id,
                "instanceId": instance_id,
                "actionId": action_id,
                "status": status,
                "input": fields.Json(input),
                "output": fields.Json(output),
                "preCheck": pre_check,
                "createdAt": datetime.now(),
                "updatedAt": datetime.now(),
                "workflowId": self._get_workflow_id(),
            }
        )
        logger.info(
            f"[time-log] Created step state for instance {instance_id} and step {step_id} in {time.time() - start_time} seconds"
        )
        self._publish_update_cell_event(step_id, instance_id)
        return state.uuid

    def update(
        self,
        uuid: str,
        status: str,
        action_id: str,
        input: Any,
    ):
        start_time = time.time()
        state = self._prisma.wf_stepstate.update(
            where={"uuid": uuid},
            data={
                "actionId": action_id,
                "status": status,
                "input": fields.Json(input),
                "updatedAt": datetime.now(),
            },
        )
        logger.info(
            f"[time-log] Updated step state for uuid {uuid} in {time.time() - start_time} seconds"
        )

        if not state:
            raise ValueError(f"Agent state with uuid {uuid} not found")

        return state

    def set_pre_check_failed(self, uuid: str):
        start_time = time.time()
        state = self._prisma.wf_stepstate.update(
            where={"uuid": uuid},
            data=(
                {
                    "preCheck": False,
                    "output": fields.Json({"error": {"message": "Pre-check failed"}}),
                    "updatedAt": datetime.now(),
                    "status": StepStatus.PRE_CHECK_FAILED,
                }
            ),
        )
        logger.info(
            f"[time-log] Set pre-check failed for uuid {uuid} in {time.time() - start_time} seconds"
        )

        if not state:
            raise ValueError(f"Agent state with uuid {uuid} not found")

        self._publish_update_cell_event(state.stepId, state.instanceId)
        return state

    def set_output(self, uuid: str, output: Any, status: str):
        start_time = time.time()
        state = self._prisma.wf_stepstate.update(
            where={"uuid": uuid},
            data={
                "output": fields.Json(output),
                "status": status,
                "updatedAt": datetime.now(),
            },
        )
        logger.info(
            f"[time-log] Set output for uuid {uuid} in {time.time() - start_time} seconds"
        )

        if not state:
            raise ValueError(f"Agent state with uuid {uuid} not found")

        self._publish_update_cell_event(state.stepId, state.instanceId)
        return state

    def set_step_failed_by_instance(
        self, instance_id: str, step_id: str, error_msg: str
    ):
        start_time = time.time()
        state = self._prisma.wf_stepstate.update_many(
            where={
                "workflowId": self._get_workflow_id(),
                "instanceId": instance_id,
                "stepId": step_id,
                "status": StepStatus.QUEUED,
            },
            data={
                "status": StepStatus.FAILED,
                "updatedAt": datetime.now(),
                "output": fields.Json(
                    {"error": {"message": "Failed to send message to SQS"}}
                ),
            },
        )
        logger.info(
            f"[time-log] Set step failed for instance {instance_id} and step {step_id} in {time.time() - start_time} seconds"
        )

        self._publish_update_cell_event(step_id, instance_id)

    def set_status(self, uuid: str, status: str):
        start_time = time.time()
        state = self._prisma.wf_stepstate.update(
            where={"uuid": uuid},
            data={
                "status": status,
                "updatedAt": datetime.now(),
            },
        )
        logger.info(
            f"[time-log] Set status for uuid {uuid} in {time.time() - start_time} seconds"
        )

        return state

    def _publish_update_cell_event(self, column_internal_id: str, row_uuid: str):
        start_time = time.time()
        column = self._prisma.ui_column.find_first(
            where={
                "internalId": column_internal_id,
                "tableUuid": self._get_workflow_id(),
            }
        )
        logger.info(
            f"[time-log] Got column for step {column_internal_id} in {time.time() - start_time} seconds"
        )
        if column:
            self._publish_event(
                event.events.UpdateCell.type_str,
                {
                    "table_uuid": column.tableUuid,
                    "row_uuid": row_uuid,
                    "column_uuid": column.uuid,
                },
            )
        else:
            logger.error(
                f"Failed to publish update cell event: Column not found for step {column_internal_id}"
            )

    def _publish_event(self, event_type: str, event: dict):
        # this is to remove circular import, causing 'partially initialized module' error
        from engine.v1.engine_sqs_client import EngineSQSClient

        etc = EngineSQSClient()
        return etc.publish_event(event_type, event)

    def store_usage(self, uuid: str, meta: ActionRunMetadata):
        data = {
            "runDuration": meta.run_duration,
            "stateUuid": uuid,
            "tableUuid": self._get_workflow_id(),
        }

        if meta.usage:
            data["units"] = meta.usage.units
            data["unitType"] = meta.usage.unit_type
            data["extraData"] = (
                fields.Json(meta.usage.extra_data)
                if meta.usage.extra_data
                else fields.Json({})
            )

        self._prisma.actionusage.create(
            data=data,
        )
