import json
import time
from typing import Any, Dict
from pydash import clone_deep, map_, map_values, map_values_deep
from prisma import Json, Prisma, enums
import pydash
from engine._classes import ConfigProvider
from util.logger import interstellar_logger

# todo (ankith): remove this and do this properly later
actions_with_loose_dependency = ["0c480600-db39-40e4-a9a7-ec358b15db1a"]

logger = interstellar_logger(__name__)


def uuid_to_id(uuid: str) -> str:
    return uuid


class UIConfigProvider(ConfigProvider):
    def __init__(self, prisma: Prisma, row_uuid: str):
        self._row_uuid = row_uuid
        self._prisma = prisma

    def get_workflow_id(self) -> str:
        start_time = time.time()
        row = self._prisma.ui_row.find_unique(where={"uuid": self._row_uuid})
        if not row:
            raise ValueError(f"Row with uuid {self._row_uuid} not found")
        logger.info(f"[time-log] Got workflow id for row {self._row_uuid} in {time.time() - start_time} seconds")
        return row.tableUuid

    def get_config(self) -> Dict[str, Any]:
        start_time = time.time()
        config = {"instance_id": uuid_to_id(self._row_uuid), "steps": []}

        row = self._prisma.ui_row.find_unique(where={"uuid": self._row_uuid})
        logger.info(f"[time-log] Got row for row {self._row_uuid} in {time.time() - start_time} seconds")

        if not row:
            raise ValueError(f"Row with uuid {self._row_uuid} not found")

        start_time = time.time()
        columns = self._prisma.ui_column.find_many(
            where={"tableUuid": row.tableUuid, "deletedAt": None},
            include={"DynamicColumnConfig": {"include": {"Action": True}}},
        )
        logger.info(f"[time-log] Got columns for row {self._row_uuid} in {time.time() - start_time} seconds")

        uuid_internal_id_map = dict(map_(columns, lambda x: [x.uuid, x.internalId]))

        for column in columns:
            if column.type != enums.UI_ColumnType.DYNAMIC:
                continue
            if not column.DynamicColumnConfig:
                raise ValueError(f"Dynamic field with uuid {column.uuid} has no config")

            if not column.DynamicColumnConfig.Action:
                raise ValueError(f"Dynamic field with uuid {column.uuid} has no action")

            # TODO: (ankith) fix this as part of Agent resolver
            action_id = column.DynamicColumnConfig.Action.uuid
            input_config = column.DynamicColumnConfig.inputConfig
            if not isinstance(input_config, dict):
                logger.error(
                    "input config not a dictionary, overriding: %s", input_config
                )
                input_config = {}

            config["steps"].append(
                {
                    "id": column.internalId,
                    "action_id": action_id,
                    "disable_auto_run": column.DynamicColumnConfig.disableAutoRun,
                    "pre_check": (
                        self._pre_process_pre_check_formula(
                            column.DynamicColumnConfig.preCheckFormula,
                            uuid_internal_id_map,
                        )
                        if column.DynamicColumnConfig.preCheckFormula
                        else None
                    ),
                    "input": self._pre_process_input_config(
                        input_config, uuid_internal_id_map
                    ),
                    "dependency": [u for u in column.dependencies or []],
                    # todo (ankith): remove this and do this properly later
                    "skip_dependency_check": action_id in actions_with_loose_dependency,
                }
            )
        return config

    def get_static_values(self) -> Dict[str, Any]:
        start_time = time.time()
        # get all non dynamic columns
        static_columns = self._prisma.ui_column.find_many(
            where={
                "tableUuid": self.get_workflow_id(),
                "NOT": [{"type": enums.UI_ColumnType.DYNAMIC}],
                "deletedAt": None,
            }
        )
        logger.info(f"[time-log] Got static columns for row {self._row_uuid} in {time.time() - start_time} seconds")

        start_time = time.time()
        static_values = self._prisma.ui_staticdata.find_many(
            where={"rowUuid": self._row_uuid}, include={"Column": True}
        )
        logger.info(f"[time-log] Got static values for row {self._row_uuid} in {time.time() - start_time} seconds")

        missing_columns = [
            col
            for col in static_columns
            if not any(v.Column and v.Column.uuid == col.uuid for v in static_values)
        ]

        data = dict(map(lambda v: (v.Column.internalId, v.data), static_values))  # type: ignore

        if missing_columns:
            logger.info("Appending missing static columns")
            for col in missing_columns:
                data[col.internalId] = None  # type: ignore

        return {
            **data,
            # magic variables
            "__TABLE_UUID__": self.get_workflow_id(),
            "__ROW_UUID__": self._row_uuid,
        }

    def _pre_process_input_config(
        self, config: dict, uuid_internal_id_map: dict[str, str]
    ):
        """Iterate through each value in the input config and apply
        jinja2 conversion on templated values"""
        config = clone_deep(config)

        def fu(a: dict | list):
            if not (isinstance(a, dict) or isinstance(a, list)):
                return

            for key in pydash.keys(a):
                # TODO (ankith): do this properly
                if key == "validityCondition":
                    continue
                if is_templated_input(a[key]):
                    a[key] = self._special_input_to_jinja2_template(
                        get_special_input_from_templated_input(a[key]),
                        uuid_internal_id_map,
                    )
                elif isinstance(a[key], list) or isinstance(a[key], dict):
                    fu(a[key])

        fu(config)
        return config

    def _special_input_to_jinja2_template(
        self, special_input: list[dict[str, Any]], uuid_internal_id_map: dict[str, str]
    ):
        """Replaces all slash-variable in special input with jinja2 template string.
        first get s-v value and replace column uuid with internal id and then convert the whole
        path into jinja2 format like {{ colId['p1']['...']['pn'] }}"""
        template = ""
        for item in special_input:
            if item["type"] == "text":
                template += item["text"]
            elif item["type"] == "slash-variable":
                path = item["value"]
                # todo (ankith): this is a hack to handle the case where the column is not found
                # like when the column is deleted but other columns still have the reference
                if path[0] not in uuid_internal_id_map:
                    logger.error(
                        "Column '%s' not found in uuid_internal_id_map", path[0]
                    )
                colId = uuid_internal_id_map.get(path[0], "_unresolved__column_")
                template += "{{ "
                template += colId + "".join(
                    map_(path[1:], lambda x: f"[{x}]" if type(x) == int else f"['{x}']")
                )
                template += " }}"
            else:
                raise Exception("Bad special input format")
        return template

    def _pre_process_pre_check_formula(
        self, pre_check: str, uuid_internal_id_map: dict[str, str]
    ):
        if is_templated_input(pre_check):
            special_input = get_special_input_from_templated_input(pre_check)
            template = ""
            for item in special_input:
                if item["type"] == "text":
                    template += " " + item["text"].strip() + " "
                elif item["type"] == "slash-variable":
                    path = item["value"]
                    colId = uuid_internal_id_map.get(path[0], "_unresolved__column_")
                    template += colId + "".join(
                        map_(
                            path[1:],
                            lambda x: f"[{x}]" if type(x) == int else f"['{x}']",
                        )
                    )
                else:
                    raise Exception("Bad special input format")
            return "{{ " + template + " }}"
        return pre_check


def is_templated_input(value: Any):
    if is_templated_input_old(value):
        return True  # backward compatibility code

    if pydash.is_string(value) and "$" in value:
        jo = pydash.attempt(lambda: json.loads(value))
        if isinstance(jo, Exception):
            return False
        return "$" in jo and pydash.is_list(jo["$"])
    return False


def is_templated_input_old(value: str):
    if pydash.is_dict(value) and "$" in value:
        return True
    return False


def get_special_input_from_templated_input(value: str):
    if is_templated_input_old(value):
        return get_special_input_from_templated_input_old(
            value
        )  # backward compatibility code

    jo = json.loads(value)
    return jo["$"]


def get_special_input_from_templated_input_old(value: Any):
    return value["$"]
