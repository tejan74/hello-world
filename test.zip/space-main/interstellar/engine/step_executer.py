from engine._classes import (
    StepStateManagerInterface,
    StepStatus,
    ActionResolver,
    ActionException,
)
from util import exception
from util import function
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class StepExecuter:
    _retry_options = {"base_delay": 1.5, "jitter": 1}

    def __init__(
        self,
        state_manager: StepStateManagerInterface,
        action_resolver: ActionResolver,
    ) -> None:
        self._state_manager = state_manager
        self._action_resolver = action_resolver

    def execute(self, state_uuid: str):
        state = self._state_manager.get_by_uuid(state_uuid)
        function.retry_callback(
            lambda: self._state_manager.set_status(state_uuid, StepStatus.RUNNING),
            **self._retry_options,
        )
        action_id = state["action_id"]
        input = state["input"]
        status = None

        try:
            output = self._action_resolver.run(action_id, input)
            status = StepStatus.SUCCESSFUL
        except BaseException as e:
            logger.exception(f"Action {action_id} failed with error")
            output = (
                {
                    "error": {
                        "message": e.message,
                        "data": e.data,
                        "error_code": e.error_code,
                        "full_error": exception.to_dict(e),
                    }
                }
                if isinstance(e, ActionException)
                else {"error": exception.to_dict(e)}
            )
            status = StepStatus.FAILED

        try:
            function.retry_callback(
                lambda: self._state_manager.set_output(state_uuid, output, status),
                **self._retry_options,
            )
        except BaseException as e:
            logger.info("********* output Start **********")
            logger.info(output)
            logger.info("******* output End ********")
            raise e
