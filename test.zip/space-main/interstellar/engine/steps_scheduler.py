from typing import TypedDict
import pydash

from engine._classes import (
    StepStateManagerInterface,
    StepStatus,
    ConfigProvider,
    ConfigSchema,
    TemplateEngine,
    ConfigStep,
    StepState,
)
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


# TODO (ankith): add more logs
class StepsScheduler:
    def __init__(
        self,
        config_provider: ConfigProvider,
        state_manager: StepStateManagerInterface,
        template_engine_class: type[TemplateEngine],
        rerun_steps: list | None = None,
    ):
        self._config_provider = config_provider
        self._state_manager = state_manager
        self._template_engine_class = template_engine_class
        self._rerun_steps = rerun_steps or []
        # TODO (ankith): support a flag to re-run failed tasks.

    def schedule(self)->"SchedulerStatus":
        config_dict = self._config_provider.get_config()
        config = ConfigSchema(**config_dict)
        states = self._state_manager.get_all_latest_by_instance_id(config.instance_id)
        states_lt: dict[str,StepState] = pydash.key_by(states, "step_id")  # states lookup table

        # preliminary step partitioning
        prelim_completed_steps: list[ConfigStep] = []
        prelim_pending_steps: list[ConfigStep] = []
        static_values = self._config_provider.get_static_values()
        results = static_values.copy()
        for step in config.steps:
            state = states_lt.get(step.id)
            if state is None:
                prelim_pending_steps.append(step)
            elif step.id in self._rerun_steps:
                prelim_pending_steps.append(step)
            elif state["status"] == StepStatus.FAILED:
                prelim_completed_steps.append(step)
            elif state["status"] == StepStatus.SUCCESSFUL:
                prelim_completed_steps.append(step)
                results[step.id] = state["output"]
            elif state["status"] == StepStatus.PRE_CHECK_FAILED:
                prelim_completed_steps.append(step)
                results[step.id] = state["output"]
        logger.info(
            f"prelim_completed_steps({len(prelim_completed_steps)}){pydash.pluck(prelim_completed_steps,'id')}, prelim_pending_steps({len(prelim_pending_steps)}){pydash.pluck(prelim_pending_steps,'id')}"
        )

        # advanced step partitioning that finds steps that needs
        # to be re-run due to config changes
        prior_ite = self._template_engine_class(results)
        completed_steps: list[ConfigStep] = []
        pending_steps: list[ConfigStep] = [*prelim_pending_steps]
        for step in prelim_completed_steps:
            new_input, _ = prior_ite.eval_input(step.input)
            old_input = states_lt[step.id]["input"]
            if step.pre_check is not None:
                new_pre_check, _ = prior_ite.eval_pre_check(step.pre_check)
            else:
                new_pre_check, _ = True, None
            old_pre_check = states_lt[step.id].get("pre_check")

            input_changed = not (pydash.matches(new_input)(old_input) and pydash.matches(old_input)(new_input))
            pre_check_changed = new_pre_check != old_pre_check

            if (input_changed and new_pre_check) or pre_check_changed:
                pending_steps.append(step)
                # TODO: check why del results[step.id] is not working
                # del results[step.id]
                results = {k: v for k, v in results.items() if k != step.id}
            else:
                completed_steps.append(step)
        logger.info(
            f"completed_steps({len(completed_steps)}){pydash.pluck(completed_steps,'id')}, pending_steps({len(pending_steps)}){pydash.pluck(pending_steps,'id')}"
        )

        # find runnable steps
        runnable_steps: list[ConfigStep] = []
        successful_step_ids:list[str] = (
            pydash.chain(completed_steps)
            .pluck("id")
            .filter(lambda x: states_lt[x]["status"] == StepStatus.SUCCESSFUL)
            .value()
        )
        available_static_values = list(static_values.keys())
        for step in pending_steps:
            incomplete_dep = (
                pydash.chain(step.dependency or [])
                .find(lambda x: x not in successful_step_ids and x not in available_static_values)
                .value()
            )
            if incomplete_dep is None:
                runnable_steps.append(step)
        logger.info(
            f"runnable_steps({len(runnable_steps)}){pydash.pluck(runnable_steps,'id')}"
        )

        # trigger runnable steps
        queued_steps: list[ConfigStep] = []
        ite = self._template_engine_class(results)
        for step in runnable_steps:
            if step.pre_check is not None:
                pre_check, pc_error = ite.eval_pre_check(step.pre_check)
            else:
                pre_check, pc_error = True, None

            if pc_error is not None:
                logger.error(f"failed {step.id} due to pre-check error: {pc_error}")
                self._state_manager.create(
                    config.instance_id,
                    step.id,
                    step.action_id,
                    StepStatus.FAILED,
                    False,
                    {},
                    {"pre_check_error": pc_error},
                )
                completed_steps.append(step)
                continue

            if not pre_check:
                logger.info(f"skipped {step.id} due to pre-check failure")
                self._state_manager.create(
                    config.instance_id,
                    step.id,
                    step.action_id,
                    StepStatus.PRE_CHECK_FAILED,
                    False,
                    {},
                    {},
                )
                completed_steps.append(step)
                continue

            input, i_error = ite.eval_input(step.input)
            if i_error is not None:
                logger.error(f"failed {step.id} due to input error: {i_error}")
                self._state_manager.create(
                    config.instance_id,
                    step.id,
                    step.action_id,
                    StepStatus.FAILED,
                    True,
                    input,
                    {"input_error": i_error},
                )
                completed_steps.append(step)
                continue

            uuid = self._state_manager.create(
                config.instance_id, step.id, step.action_id, StepStatus.QUEUED, True, input
            )
            queued_steps.append(step)

        return {
            "all_steps": config.steps,
            "completed_steps": completed_steps,
            "pending_steps": pending_steps,
            "runnable_steps": runnable_steps,
            "queued_steps": queued_steps,
        }

class SchedulerStatus(TypedDict):
    all_steps: list[ConfigStep]
    completed_steps: list[ConfigStep]
    pending_steps: list[ConfigStep]
    runnable_steps: list[ConfigStep]
    queued_steps: list[ConfigStep]
