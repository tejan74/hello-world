import unittest
from unittest.mock import Mock, patch
from engine._classes import StepStatus
from engine.step_executer import StepExecuter


class TestAgentRunner(unittest.TestCase):

    def test_simple(self):
        as_mock = Mock()
        as_mock.get_by_uuid.return_value = {
            "action_id": "StaticAgent",
            "input": {"data": "test"},
        }

        ae_mock = Mock()
        ae_mock.run.side_effect = lambda an, i: i

        ar = StepExecuter(
            state_manager=as_mock,
            action_resolver=ae_mock,
        )
        ar.execute("test_uuid")

        as_mock.set_output.assert_called_once_with(
            "test_uuid", {"data": "test"}, StepStatus.SUCCESSFUL
        )
        as_mock.set_status.assert_called_once_with("test_uuid", StepStatus.RUNNING)

    def test_error(self):
        as_mock = Mock()
        as_mock.get_by_uuid.return_value = {
            "action_id": "StaticAgent",
            "input": {"data": "test"},
        }

        ae_mock = Mock()
        ae_mock.run.side_effect = Exception("test")

        ar = StepExecuter(
            state_manager=as_mock,
            action_resolver=ae_mock,
        )
        ar.execute("test_uuid")

        expected_output = {
            "error": {
                "type": "Exception",
                "message": "test",
                "__cause__": None,
                "__context__": None,
            }
        }
        as_mock.set_output.assert_called_once_with(
            "test_uuid", expected_output, StepStatus.FAILED
        )
        as_mock.set_status.assert_called_once_with("test_uuid", StepStatus.RUNNING)


if __name__ == "__main__":
    unittest.main()
