from datetime import datetime
import unittest
from unittest.mock import Mock
import uuid

from pydash import chain, clone_deep, map_, omit
from engine._classes import StepStatus

from engine.steps_scheduler import SchedulerStatus, StepsScheduler
from engine.providers.jinja_input_template_engine import JinjaInputTemplateEngine
from engine._classes import ConfigStep, StepState


class TestConfigRunner(unittest.TestCase):
    base_config_w_op = {
        "instance_id": "simple-test",
        "steps": [
            {
                "id": "step0",
                "action_id": "agent0",
                "input": {},
                "dependency": [],
                "_output": {"val_int": 34},
                "_status": StepStatus.SUCCESSFUL,
                "_expected_input": {},
            },
            {
                "id": "step1",
                "action_id": "agent1",
                "input": {},
                "_output": {"val_str": "Hi"},
                "_status": StepStatus.SUCCESSFUL,
                "_expected_input": {},
            },
            {
                "id": "step2",
                "action_id": "agent2",
                "input": {
                    "val_int": "{{step0.val_int}}",
                    "val_str": "{{step1.val_str}}, Godzilla",
                },
                "dependency": ["step0", "step1"],
                "_output": {
                    "val_bool": True,
                },
                "_status": StepStatus.SUCCESSFUL,
                "_expected_input": {
                    "val_int": 34,
                    "val_str": "Hi, Godzilla",
                },
            },
            {
                "id": "step3",
                "action_id": "agent3",
                "input": {
                    "val_int2": "{{step0.val_int * 10}}",
                },
                "dependency": ["step0"],
                "_output": {
                    "val_this": "this",
                },
                "_status": StepStatus.SUCCESSFUL,
                "_expected_input": {},
            },
            {
                "id": "step4",
                "action_id": "agent4",
                "input": {},
                "dependency": ["step2"],
                "_output": {
                    "val_something": "something",
                },
                "_status": StepStatus.SUCCESSFUL,
                "_expected_input": {},
            },
            {
                "id": "step5",
                "action_id": "agent5",
                "input": {
                    "val": "{{step0.val_int}} {{step4.val_something}}",
                },
                "dependency": ["step0", "step4"],
                "_output": {},
                "_status": StepStatus.SUCCESSFUL,
                "_expected_input": {
                    "val": "34 something",
                },
            },
        ],
    }
    bootstrap_params = {"some_config": {"some_key": "some_value"}}

    def test_simple(self):
        config_w_op = clone_deep(self.base_config_w_op)

        cp_mock, as_mock, trigger_steps, states = self.get_mocks(config_w_op)

        cr = StepsScheduler(
            config_provider=cp_mock,
            state_manager=as_mock,
            template_engine_class=JinjaInputTemplateEngine,
        )

        prev_state_stepIds = []
        run_sequence = []
        for _ in range(0, 5):
            scheduler_stats = cr.schedule()
            trigger_steps(scheduler_stats)
            cur_state_stepIds = chain(states).map(lambda x: x["step_id"]).value()
            new_stepIds = cur_state_stepIds[len(prev_state_stepIds) :]
            print(new_stepIds)
            prev_state_stepIds = cur_state_stepIds
            run_sequence.append(new_stepIds)

        expected_run_sequence = [
            ["step0", "step1"],
            ["step2", "step3"],
            ["step4"],
            ["step5"],
            [],
        ]
        self.assertEqual(
            map_(run_sequence, lambda x: x.sort() or x),
            map_(expected_run_sequence, lambda x: x.sort() or x),
        )
        print(states)

    def test_failed(self):
        config_w_op = clone_deep(self.base_config_w_op)
        config_w_op["steps"][2]["_status"] = StepStatus.FAILED

        cp_mock, as_mock, trigger_steps, states = self.get_mocks(config_w_op)

        cr = StepsScheduler(
            config_provider=cp_mock,
            state_manager=as_mock,
            template_engine_class=JinjaInputTemplateEngine,
        )

        prev_state_stepIds = []
        run_sequence = []
        for _ in range(0, 5):
            scheduler_stats = cr.schedule()
            trigger_steps(scheduler_stats)
            cur_state_stepIds = chain(states).map(lambda x: x["step_id"]).value()
            new_stepIds = cur_state_stepIds[len(prev_state_stepIds) :]
            print(new_stepIds)
            prev_state_stepIds = cur_state_stepIds
            run_sequence.append(new_stepIds)

        expected_run_sequence = [["step0", "step1"], ["step2", "step3"], [], [], []]
        self.assertEqual(
            map_(run_sequence, lambda x: x.sort() or x),
            map_(expected_run_sequence, lambda x: x.sort() or x),
        )

        print(states)

    def test_rerun(self):
        config_w_op = clone_deep(self.base_config_w_op)

        cp_mock, as_mock, trigger_steps, states = self.get_mocks(config_w_op)

        cr = StepsScheduler(
            config_provider=cp_mock,
            state_manager=as_mock,
            template_engine_class=JinjaInputTemplateEngine,
        )

        prev_state_stepIds = []
        run_sequence = []
        for i in range(0, 5):
            scheduler_stats = cr.schedule()
            trigger_steps(scheduler_stats)
            if i == 1:
                config_w_op["steps"][0]["input"] = {"val_idk": "idk"}
                config_w_op["steps"][0]["_expected_input"] = config_w_op["steps"][0][
                    "input"
                ]

            cur_state_stepIds = chain(states).map(lambda x: x["step_id"]).value()
            new_stepIds = cur_state_stepIds[len(prev_state_stepIds) :]
            print(new_stepIds)
            prev_state_stepIds = cur_state_stepIds
            run_sequence.append(new_stepIds)

        expected_run_sequence = [
            ["step1", "step0"],
            ["step2", "step3"],
            ["step4", "step0"],
            ["step5"],
            [],
        ]
        self.assertEqual(
            map_(run_sequence, lambda x: x.sort() or x),
            map_(expected_run_sequence, lambda x: x.sort() or x),
        )

        print(states)

    def test_rerun_with_op_change(self):
        config_w_op = clone_deep(self.base_config_w_op)
        config_w_op["steps"].append(
            {
                "id": "step6",
                "action_id": "agent6",
                "input": {
                    "val_from_0": "{{step0.val_int}}",
                    "val_from_3": "{{step3.val_this}}",
                    "val_from_0_3": "{{step0.val_int}} {{step3.val_this}}",
                },
                "dependency": ["step0", "step3"],
                "_output": {},
                "_status": StepStatus.SUCCESSFUL,
                "_expected_input": {
                    "val_from_0": 34,
                    "val_from_3": "this",
                    "val_from_0_3": "34 this",
                },
            },
        )

        cp_mock, as_mock, trigger_steps, states = self.get_mocks(config_w_op)

        cr = StepsScheduler(
            config_provider=cp_mock,
            state_manager=as_mock,
            template_engine_class=JinjaInputTemplateEngine,
        )
        prev_state_stepIds = []
        run_sequence = []
        for _ in range(0, 7):
            scheduler_stats = cr.schedule()
            trigger_steps(scheduler_stats)
            cur_state_stepIds = chain(states).map(lambda x: x["step_id"]).value()
            new_stepIds = cur_state_stepIds[len(prev_state_stepIds) :]
            print(new_stepIds)

            if "step6" in new_stepIds and "step6" not in prev_state_stepIds:
                config_w_op["steps"][0]["input"] = {"val_idk": "idk"}
                config_w_op["steps"][0]["_expected_input"] = config_w_op["steps"][0][
                    "input"
                ]
                # op change as result of ip change
                config_w_op["steps"][0]["_output"]["val_int"] = 68

            if "step0" in new_stepIds and "step6" in prev_state_stepIds:
                config_w_op["steps"][3]["_expected_input"]["val_int2"] = 680
                config_w_op["steps"][6]["_expected_input"]["val_from_0"] = 68
                config_w_op["steps"][6]["_expected_input"]["val_from_0_3"] = "68 this"
                # op change as result of ip change
                config_w_op["steps"][3]["_output"]["val_this"] = "new this"

            if "step3" in new_stepIds and "step6" in new_stepIds:
                config_w_op["steps"][6]["_expected_input"]["val_from_3"] = "new this"
                config_w_op["steps"][6]["_expected_input"][
                    "val_from_0_3"
                ] = "68 new this"

            prev_state_stepIds = cur_state_stepIds
            run_sequence.append(new_stepIds)

        expected_run_sequence = [
            ["step1", "step0"],
            ["step2", "step3"],
            ["step6", "step4"],
            ["step0"],
            ["step5", "step2", "step3"],
            ["step6"],
            [],
        ]
        self.assertEqual(
            map_(run_sequence, lambda x: x.sort() or x),
            map_(expected_run_sequence, lambda x: x.sort() or x),
        )

        print(states)

    def test_manual_rerun(self):
        config_w_op = clone_deep(self.base_config_w_op)
        config_w_op["steps"] = config_w_op["steps"][0:1]

        cp_mock, as_mock, trigger_steps, states = self.get_mocks(config_w_op)

        cr = StepsScheduler(
            config_provider=cp_mock,
            state_manager=as_mock,
            template_engine_class=JinjaInputTemplateEngine,
        )

        prev_state_stepIds = []
        run_sequence = []
        for i in range(0, 4):
            scheduler_stats = cr.schedule()
            trigger_steps(scheduler_stats)

            if i == 1:
                cr = StepsScheduler(
                    config_provider=cp_mock,
                    state_manager=as_mock,
                    template_engine_class=JinjaInputTemplateEngine,
                    rerun_steps=["step0"],
                )
            if i == 2:
                cr = StepsScheduler(
                    config_provider=cp_mock,
                    state_manager=as_mock,
                    template_engine_class=JinjaInputTemplateEngine,
                )

            cur_state_stepIds = chain(states).map(lambda x: x["step_id"]).value()
            new_stepIds = cur_state_stepIds[len(prev_state_stepIds) :]
            print(new_stepIds)
            prev_state_stepIds = cur_state_stepIds
            run_sequence.append(new_stepIds)

        expected_run_sequence = [["step0"], [], ["step0"], []]
        self.assertEqual(
            map_(run_sequence, lambda x: x.sort() or x),
            map_(expected_run_sequence, lambda x: x.sort() or x),
        )

        print(states)

    def test_input_error(self):
        config_w_op = clone_deep(self.base_config_w_op)
        config_w_op["steps"] = config_w_op["steps"][0:1]
        config_w_op["steps"][0]["input"] = {"val_int": "{{step0.val_int}}"}

        cp_mock, as_mock, trigger_steps, states = self.get_mocks(config_w_op)

        cr = StepsScheduler(
            config_provider=cp_mock,
            state_manager=as_mock,
            template_engine_class=JinjaInputTemplateEngine,
        )

        scheduler_stats = cr.schedule()
        trigger_steps(scheduler_stats)
        self.assertEqual(states[0]["status"], StepStatus.FAILED)
        self.assertEqual(
            states[0]["output"], {"input_error": {"message": "'step0' is undefined"}}
        )

    def test_pre_check_error(self):
        config_w_op = clone_deep(self.base_config_w_op)
        config_w_op["steps"] = config_w_op["steps"][0:1]
        config_w_op["steps"][0]["pre_check"] = "{{ a.v == b }}"

        cp_mock, as_mock, trigger_steps, states = self.get_mocks(config_w_op)

        cr = StepsScheduler(
            config_provider=cp_mock,
            state_manager=as_mock,
            template_engine_class=JinjaInputTemplateEngine,
        )

        scheduler_stats = cr.schedule()
        trigger_steps(scheduler_stats)
        self.assertEqual(states[0]["status"], StepStatus.FAILED)
        self.assertEqual(
            states[0]["output"], {"pre_check_error": {"message": "'a' is undefined"}}
        )

    def get_mocks(self, config_w_op):

        cp_mock = Mock()

        def get_config():
            config = clone_deep(config_w_op)
            config["steps"] = (
                chain(config["steps"])
                .map(lambda x: omit(x, ["_output", "_status", "_expected_input"]))
                .shuffle()
                .value()
            )
            return config

        cp_mock.get_config.side_effect = get_config
        cp_mock.get_static_values.return_value = {}

        states:list[StepState] = []
        as_mock = Mock()
        as_mock.get_all_latest_by_instance_id.side_effect = (
            lambda rid: chain(states)
            .filter(lambda x: x["instance_id"] == rid)
            .group_by("step_id")
            .map_values(lambda x: max(x, key=lambda y: y["created_at"]))
            .values()
            .value()
        )
        as_mock.create.side_effect = (
            lambda rid, aid, aname, status, pco, input, op=None: states.append(
                {
                    "uuid": str(uuid.uuid4()),
                    "instance_id": rid,
                    "step_id": aid,
                    "action_id": aname,
                    "status": status,
                    "pre_check": pco,
                    "input": input,
                    "output": op,
                    "updated_at": datetime.now(),
                    "created_at": datetime.now(),
                }
            )
            or states[-1]["uuid"]
        )

        at_mock = Mock()

        def trigger_step(step:ConfigStep):
            state = (
                chain(states).find_last(lambda x: x["step_id"] == step.id).value()
            )
            if not state: raise Exception(f"Step {step.id} not found in states")
            
            config_step = (
                chain(config_w_op["steps"])
                .find(lambda x: x["id"] == state["step_id"])
                .value()
            )
            if not config_step: raise Exception(f"Step {step.id} not found in config")

            state["output"] = config_step["_output"]
            state["status"] = config_step["_status"]
            state["updated_at"] = datetime.now()

        def trigger_steps(scheduler_stats:SchedulerStatus):
            for step in scheduler_stats["queued_steps"]:
                trigger_step(step)

        return cp_mock, as_mock, trigger_steps, states


if __name__ == "__main__":
    unittest.main()
