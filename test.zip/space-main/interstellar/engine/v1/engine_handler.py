# TODO: clean up this code!!!!!!
import time
from asgi_correlation_id import correlation_id
from prisma import Prisma
from pydantic import BaseModel
import pydantic
import pydash

import config
from engine import action_resolver
from engine._classes import ConfigSchema
from engine.providers import (
    jinja_input_template_engine,
    step_state_manager,
    table_config_manager,
)
from engine.v1.engine_sqs_client import EngineSQSClient
from engine.v1.event import publisher
from engine.v1.step_runner import StepRunner
from util.logger import interstellar_logger
from util.logs import generate_request_id_with_parent

logger = interstellar_logger(__name__)


def run_step(instance_id: str, step_id: str):
    logger.info(f"Running step {step_id} for instance {instance_id}")
    start_time = time.time()
    with Prisma(
        datasource={"url": config.get_parameter("DATABASE_URL")}, use_dotenv=False
    ) as prisma:
        logger.info(
            f"[time-log] Got prisma connection for instance for running step {step_id} and instance {instance_id} in {time.time() - start_time} seconds"
        )
        config_provider = table_config_manager.UIConfigProvider(
            prisma=prisma, row_uuid=instance_id
        )
        state_manager = step_state_manager.StepStateManager(prisma, config_provider)
        resolver = action_resolver.UIActionResolver()
        template_engine = jinja_input_template_engine.JinjaInputTemplateEngine
        handler = StepRunner(
            config_provider, state_manager, template_engine, resolver, step_id
        )
        handler.run()
    logger.info(f"Finished running step {step_id} for instance {instance_id}")
    return {"status": "success"}


def resume_step(
    instance_id: str,
    step_id: str,
    trigger_type: str,
    payload: dict | None = None,
):
    logger.info(f"Resuming step {step_id} for instance {instance_id}")
    start_time = time.time()
    with Prisma(
        datasource={"url": config.get_parameter("DATABASE_URL")}, use_dotenv=False
    ) as prisma:
        logger.info(
            f"[time-log] Got prisma connection for instance for running step {step_id} and instance {instance_id} in {time.time() - start_time} seconds"
        )
        config_provider = table_config_manager.UIConfigProvider(
            prisma=prisma, row_uuid=instance_id
        )
        state_manager = step_state_manager.StepStateManager(prisma, config_provider)
        resolver = action_resolver.UIActionResolver()
        template_engine = jinja_input_template_engine.JinjaInputTemplateEngine
        handler = StepRunner(
            config_provider, state_manager, template_engine, resolver, step_id
        )
        handler.resume(trigger_type, payload)
    logger.info(f"Finished resuming step {step_id} for instance {instance_id}")
    return {"status": "success"}


def step_notification(instance_id: str, step_id: str):
    logger.info(f"Received notification for step {step_id} for instance {instance_id}")
    start_time = time.time()
    with Prisma(
        datasource={"url": config.get_parameter("DATABASE_URL")}, use_dotenv=False
    ) as prisma:
        logger.info(
            f"[time-log] Got prisma connection for instance for running step {step_id} and instance {instance_id} in {time.time() - start_time} seconds"
        )
        config_provider = table_config_manager.UIConfigProvider(
            prisma=prisma, row_uuid=instance_id
        )
        state_manager = step_state_manager.StepStateManager(prisma, config_provider)
        resolver = action_resolver.UIActionResolver()
        template_engine = jinja_input_template_engine.JinjaInputTemplateEngine
        handler = StepRunner(
            config_provider, state_manager, template_engine, resolver, step_id
        )
        handler.run_dependency()

    return {"status": "success"}


def schedule_step(step_id: str, instance_ids: list[str]):
    engine_task_client = EngineSQSClient()

    logger.info(f"Scheduling step {step_id} for instances {instance_ids}")
    start_time = time.time()
    with Prisma(
        datasource={"url": config.get_parameter("DATABASE_URL")},
        use_dotenv=False,
    ) as prisma:
        logger.info(
            f"[time-log] Got prisma connection for scheduling step {step_id} for instances {instance_ids} in {time.time() - start_time} seconds"
        )
        config_provider = table_config_manager.UIConfigProvider(
            prisma=prisma, row_uuid=instance_ids[0]
        )
        configs = ConfigSchema(**config_provider.get_config())

    step = pydash.find(configs.steps, lambda x: x.id == step_id)
    if not step:
        logger.error(f"Step {step_id} not found in the config")
        return {
            "status": "failed",
            "message": f"Step {step_id} not found in the config",
        }
    action_id = step.action_id

    c_id = correlation_id.get()
    for row_uuid in instance_ids:
        # TODO: Move this to a separate wrapper function
        correlation_id.set(
            generate_request_id_with_parent(c_id or "", row_uuid, is_uuid=True)
        )
        engine_task_client.run_a_step(row_uuid, step_id, action_id)
        correlation_id.set(c_id)

    logger.info(f"Finished scheduling step {step_id} for instances {instance_ids}")

    return {"status": "success"}


# ------------- event routers ----------------
class EventPayload(BaseModel):
    model_config = pydantic.ConfigDict(extra="allow")


def publish_event(event_type: str, payload: EventPayload):
    logger.info("Publishing event %s: %s", event_type, payload)
    publisher.publish_event(event_type, payload.model_dump())
    return {"status": "success"}
