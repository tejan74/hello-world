import json
import time
from prisma import Prisma
import pydash
import config.param
from engine.providers import (
    step_state_manager,
    table_config_manager,
)
import config
from asgi_correlation_id import correlation_id

from engine.v1.aws import lambda_handler
from lib.aws_sqs import SQSClient
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


# The list of actions that are considered long running and should be sent to a different SQS queue
# These should always be in sync with mission_control/services/workflow/engineSqs.ts
ACTION_TO_SQS_MAP = {
    "7c5ddca9-d940-497b-8d18-2e1749f94e3c": "ACTION_SCRAPER_API_SQS_URL",  # Scraper API
    "b8920108-2c1e-41cf-a028-3382465df9dd": "ACTION_SCRAPER_API_SQS_URL",  # Google Search with Scraper API
    "74592751-d1d6-4960-8685-296e088cbae9": "LONG_ACTION_SQS_URL",  # OrbAI
    "991fd96d-3451-4562-98e2-2d050e5d0b53": "LONG_ACTION_SQS_URL",  # OrbAI (Adi - POC)
    "0acce83f-d892-4d3b-bce4-35148d7a5c56": "LONG_ACTION_SQS_URL",  # Read from another Table
    "1e275d44-d38f-4d40-8c5c-5d5e1a158078": "LONG_ACTION_SQS_URL",  # Playwright Browser with Script Execution
}


class LocalSQSClient:
    def __init__(self, queue_url: str, region_name: str) -> None:
        pass

    def send_message(
        self,
        message_body: str,
        group_id: str,
        queue_url: str | None = None,
        delay_seconds: int = 0,
    ) -> str:
        if delay_seconds:
            time.sleep(delay_seconds)

        logger.info("Running in local mode")
        # Remove leading slash if present
        lambda_handler.handle(json.loads(message_body), None)
        return group_id


class EngineSQSClient:
    def __init__(self):
        self.region_name = config.get_parameter("AWS_REGION")
        self.queue_url = config.get_parameter("ACTION_SQS_URL")

        if config.get_parameter("ENV") == "local":
            self.sqs_client = LocalSQSClient(
                queue_url=self.queue_url,
                region_name=self.region_name,
            )
        else:
            self.sqs_client = SQSClient(
                queue_url=self.queue_url,
                region_name=self.region_name,
            )

    def resume_a_step(
        self,
        instance_id: str,
        step_id: str,
        action_id: str,
        trigger_type: str,
        payload: dict | None = None,
        delay_seconds: int = 0,
    ):
        logger.info(f"Resuming step {step_id} for instance {instance_id}")
        self._send_step_event(
            event_type="resume_a_step",
            instance_id=instance_id,
            step_id=step_id,
            action_id=action_id,
            payload=payload,
            trigger_type=trigger_type,
            delay_seconds=delay_seconds,
        )

    def run_a_step(
        self,
        instance_id: str,
        step_id: str,
        action_id: str,
        delay_seconds: int = 0,
    ):
        logger.info(f"Running step {step_id} for instance {instance_id}")
        self._send_step_event(
            event_type="run_a_step",
            instance_id=instance_id,
            step_id=step_id,
            action_id=action_id,
            delay_seconds=delay_seconds,
        )

    def _send_step_event(
        self,
        event_type: str,
        instance_id: str,
        step_id: str,
        action_id: str,
        payload: dict | None = None,
        trigger_type: str | None = None,
        delay_seconds: int = 0,
    ):
        action_specific_queue = None
        action_specific_queue_key = ACTION_TO_SQS_MAP.get(action_id)
        if action_specific_queue_key:
            action_specific_queue = config.get_parameter(action_specific_queue_key)

        try:
            data = self._construct_event_data(
                event_type,
                {
                    "instance_id": instance_id,
                    "step_id": step_id,
                    "action_id": action_id,
                    "payload": payload,
                    "trigger_type": trigger_type,
                },
            )
            self.sqs_client.send_message(
                message_body=json.dumps(data),
                group_id=pydash.get(data, "event.request_id", default=time.time()),
                queue_url=(action_specific_queue or self.queue_url),
                delay_seconds=delay_seconds,
            )
        except Exception as e:
            logger.exception(
                f"Failed to {event_type} - {step_id} for instance {instance_id}"
            )
            with Prisma(
                datasource={"url": config.get_parameter("DATABASE_URL")},
                use_dotenv=False,
            ) as prisma:
                config_provider = table_config_manager.UIConfigProvider(
                    prisma=prisma, row_uuid=instance_id
                )
                state_manager = step_state_manager.StepStateManager(
                    prisma, config_provider
                )
                state_manager.set_step_failed_by_instance(
                    instance_id, step_id, "Failed to send message to SQS"
                )

    # TODO: this can be a generic notify
    def notify_step_completion(self, instance_id: str, step_id: str):
        data = self._construct_event_data(
            "notify_a_step", {"instance_id": instance_id, "step_id": step_id}
        )
        return self.sqs_client.send_message(
            message_body=json.dumps(data),
            group_id=pydash.get(data, "event.request_id", default=time.time()),
            queue_url=self.queue_url,
        )

    def schedule_steps(self, step_id: str, row_uuids: list[str]):
        data = self._construct_event_data(
            "schedule_steps", {"step_id": step_id, "row_uuids": row_uuids}
        )
        return self.sqs_client.send_message(
            message_body=json.dumps(data),
            group_id=pydash.get(data, "event.request_id", default=time.time()),
            queue_url=self.queue_url,
        )

    def publish_event(self, event_type: str, event: dict):
        return

    def run_table_import(self, uuid: str, cursor: str | None = None):
        data = self._construct_event_data(
            "run_table_import", {"uuid": uuid, "cursor": cursor}
        )
        return self.sqs_client.send_message(
            message_body=json.dumps(data),
            group_id=pydash.get(data, "event.request_id", default=time.time()),
            queue_url=self.queue_url,
        )

    def _construct_event_data(self, event: str, data: dict):
        return {
            "event": {"type": event, "request_id": correlation_id.get()},
            "data": data,
        }
