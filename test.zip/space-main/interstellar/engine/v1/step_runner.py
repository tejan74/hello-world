from typing import Any
import pydash
from action.types import ActionResumeState, BaseActionOutput
from engine._classes import (
    ActionRunMetadata,
    ActionUsage,
    StepStateManagerInterface,
    ActionResolver,
    StepStatus,
    ConfigProvider,
    ConfigSchema,
    TemplateEngine,
    StepState,
    ActionException,
    ConfigStep,
)
from engine.v1.engine_sqs_client import EngineSQSClient
from util import exception
from util.logger import interstellar_logger
from util import function

logger = interstellar_logger(__name__)


DERIVED_ACTION_ID = "c2252bd6-8f26-42cd-bb67-2b646065a5c9"


class StepRunner:
    _retry_options = {"base_delay": 1.5, "jitter": 1}

    def __init__(
        self,
        config_provider: ConfigProvider,
        state_manager: StepStateManagerInterface,
        template_engine_class: type[TemplateEngine],
        action_resolver: ActionResolver,
        step_id: str,
    ):
        self._config_provider = config_provider
        self._state_manager = state_manager
        self._template_engine_class = template_engine_class
        self._action_resolver = action_resolver
        self._step_id = step_id
        self.engine_task_client = EngineSQSClient()
        self.is_setup = False

    def setup(self):
        if self.is_setup:
            return

        config_dict = self._config_provider.get_config()
        config = ConfigSchema(**config_dict)
        self.config = config

        # check if step exists in config
        step = pydash.find(config.steps, lambda x: x.id == self._step_id)
        if step is None:
            raise ValueError(f"Step {self._step_id} not found in config")
        self.step = step

        self.instance_id = config.instance_id
        self.action_id = step.action_id

        latest_state = self._state_manager.get_latest_by_step_id(
            config.instance_id, self._step_id
        )
        self.latest_state = latest_state

        self.static_values = self._config_provider.get_static_values()
        self.states = self._state_manager.get_all_latest_by_instance_id(
            config.instance_id
        )

        self.is_setup = True

    def _update_state(self, status: str, input: Any):
        self._state_manager.update(
            self.latest_state["uuid"],
            status,
            self.latest_state["action_id"],
            input,
        )

    def resume(self, trigger_type: str, payload: dict[str, Any] | None = None):
        self.setup()

        if self.latest_state and self.latest_state["status"] not in [
            StepStatus.WAITING,
        ]:
            logger.error(f"Step {self._step_id} is not in waiting state")
            return

        input = pydash.get(self.latest_state, "input", {})
        output = pydash.get(self.latest_state, "output", {})

        # update state to running
        self._update_state(StepStatus.RUNNING, input)

        try:
            output, meta, resume = self._action_resolver.resume(
                self.latest_state["uuid"],
                self.latest_state["action_id"],
                trigger_type,
                input,
                output,
                payload,
            )

            if resume:
                self._handle_resume(resume)
            elif pydash.get(output, "error.retryable", False):
                return self._rerun()
            elif output.get("error"):
                self._handle_failure(output)
            else:
                self._handle_success(output)

            if meta:
                self._handle_meta(meta)
        except BaseException as e:
            logger.exception(f"Action {self.step.action_id} failed with error")
            output = (
                {
                    "error": {
                        "message": e.message,
                        "data": e.data,
                        "error_code": e.error_code,
                        "full_error": exception.to_dict(e),
                    }
                }
                if isinstance(e, ActionException)
                else {"error": exception.to_dict(e)}
            )
            self._handle_failure(output)

    def _is_pre_check_success(self, template_engine: TemplateEngine):
        if self.step.pre_check:
            pre_check, pc_error = template_engine.eval_pre_check(self.step.pre_check)
            if pc_error is not None:
                logger.error(
                    f"failed {self.step.id} due to pre-check error: {pc_error}"
                )
                self._state_manager.set_output(
                    self.latest_state["uuid"],
                    {"error": {"message": f"Pre-check execution failed"}},
                    StepStatus.FAILED,
                )
                return False

            if not pre_check:
                logger.info(f"skipped {self.step.id} due to pre-check failure")
                self._state_manager.set_pre_check_failed(self.latest_state["uuid"])
                return False

        return True

    def _all_dependencies_executed(self, states_lt: dict[str, StepState]):
        # check if all dependencies are successful and get their outputs
        dependency_values: dict[str, Any] = {}
        if self.step.dependency and not self.step.skip_dependency_check:
            for step_id in self.step.dependency:
                # find static values dependencies
                if step_id in self.static_values:
                    static_value = self.static_values[step_id]
                    if static_value is None:
                        logger.info(
                            f"skipping {step_id} as inputs are missing - {static_value}"
                        )
                        self._state_manager.set_output(
                            self.latest_state["uuid"],
                            {"error": f"Inputs missing", "data": {"missing": step_id}},
                            StepStatus.SKIPPED,
                        )
                        return False

                    dependency_values[step_id] = self.static_values[step_id]
                else:
                    # find dynamic values dependencies
                    _state = states_lt.get(step_id)
                    if _state is None or _state["status"] != StepStatus.SUCCESSFUL:
                        logger.info(
                            f"skipping {step_id} as inputs are missing - {_state}"
                        )
                        self._state_manager.set_output(
                            self.latest_state["uuid"],
                            {"error": f"Inputs missing", "data": {"missing": step_id}},
                            StepStatus.SKIPPED,
                        )
                        return False
                    dependency_values[step_id] = _state["output"]

        return True

    def _get_all_step_results(self):
        states_lt: dict[str, StepState] = pydash.key_by(self.states, "step_id")

        results = self.static_values.copy()
        for _step in self.config.steps:
            state = states_lt.get(_step.id)
            if state is None:
                continue
            elif state["status"] == StepStatus.SUCCESSFUL:
                results[_step.id] = state["output"]
        return results

    def run(self):
        self.setup()

        # if step is already in progress or finished, do nothing
        if self.latest_state and self.latest_state["status"] not in [
            StepStatus.QUEUED,
        ]:
            logger.error(f"Step {self.step.id} is not in queued state")
            return

        self._update_state(StepStatus.RUNNING, {})

        states_lt: dict[str, StepState] = pydash.key_by(
            self.states, "step_id"
        )  # states lookup table

        # Temporary fix to handle pre-checks as we are not storing dependencies from pre-check formula
        results = self._get_all_step_results()

        template_engine = self._template_engine_class(results)  # type: ignore

        if not self._all_dependencies_executed(
            states_lt
        ) or not self._is_pre_check_success(template_engine):
            return

        # Evaluate input
        input, i_error = template_engine.eval_input(self.step.input)
        if i_error is not None:
            logger.error(f"failed {self.step.id} due to input error: {i_error}")
            self._state_manager.set_output(
                self.latest_state["uuid"],
                {"input_error": f"Input evaluation failed"},
                StepStatus.FAILED,
            )
            return

        self._update_state(StepStatus.RUNNING, input)

        # Execute action
        try:
            output, meta, resume = self._action_resolver.run(
                self.latest_state["uuid"], self.step.action_id, input
            )

            if resume:
                self._handle_resume(resume)
            elif pydash.get(output, "error.retryable", False):
                return self._rerun()
            elif output.get("error"):
                self._handle_failure(output)
            else:
                self._handle_success(output)

            if meta:
                self._handle_meta(meta)
        except BaseException as e:
            logger.exception(f"Action {self.step.action_id} failed with error")
            output = (
                {
                    "error": {
                        "message": e.message,
                        "data": e.data,
                        "error_code": e.error_code,
                        "full_error": exception.to_dict(e),
                    }
                }
                if isinstance(e, ActionException)
                else {"error": exception.to_dict(e)}
            )
            self._handle_failure(output)

    def _handle_resume(self, resume: "ActionResumeState[BaseActionOutput]"):
        # update state with waiting state
        try:
            function.retry_callback(
                lambda: self._state_manager.set_output(
                    self.latest_state["uuid"],
                    resume.state.model_dump() if resume.state else {},
                    StepStatus.WAITING,
                ),
                **self._retry_options,
            )
        except BaseException as e:
            logger.info("********* output Start **********")
            logger.info(resume.state)
            logger.info("******* output End ********")
            raise e

        # Register poll if required
        if resume.poll_time is not None:
            self.engine_task_client.resume_a_step(
                self.instance_id,
                self._step_id,
                self.step.action_id,
                "schedule",
                delay_seconds=resume.poll_time,
            )

    def _handle_meta(self, meta: "ActionRunMetadata"):
        try:
            function.retry_callback(
                lambda: self._state_manager.store_usage(
                    self.latest_state["uuid"], meta
                ),
                **self._retry_options,
            )
        except BaseException as e:
            logger.info("********* usage Start **********")
            logger.info(meta)
            logger.info("******* usage End ********")

    def _handle_failure(self, output: Any):
        # update state with output and status
        try:
            function.retry_callback(
                lambda: self._state_manager.set_output(
                    self.latest_state["uuid"], output, StepStatus.FAILED
                ),
                **self._retry_options,
            )
        except BaseException as e:
            logger.info("********* output Start **********")
            logger.info(output)
            logger.info("******* output End ********")
            raise e

    def _handle_success(self, output: Any):
        # update state with output and status
        # Notify engine of step completion
        # Run derived steps
        try:
            function.retry_callback(
                lambda: self._state_manager.set_output(
                    self.latest_state["uuid"], output, StepStatus.SUCCESSFUL
                ),
                **self._retry_options,
            )
        except BaseException as e:
            logger.info("********* output Start **********")
            logger.info(output)
            logger.info("******* output End ********")
            raise e

        # TODO: Running the dependency steps directly here, if its good remove the notify_step_completion
        # self.engine_task_client.notify_step_completion(
        #     self.instance_id, step_id=self._step_id
        # )

        # TODO: check if the current action ran for <12min and then run the derived steps and if not notify the engine to run the dependent steps
        self.run_dependency()
        try:
            logger.info(f"Running derived steps for {self._step_id}")
            self._run_derived()
            logger.info(f"Finished running derived steps for {self._step_id}")
        except BaseException as e:
            logger.exception(f"Failed to run derived steps for {self._step_id}")

    def _rerun(self):
        # schedule a retry
        rerun_delay = 5

        logger.info(
            f"Scheduling retry for step_id: {self._step_id}, instance_id: {self.instance_id}"
        )
        function.retry_callback(
            lambda: self._state_manager.set_status(
                self.latest_state["uuid"],
                StepStatus.QUEUED,
            ),
            **self._retry_options,
        )
        self.engine_task_client.run_a_step(
            self.instance_id, self._step_id, self.action_id, delay_seconds=rerun_delay
        )

    def run_dependency(self):
        config_dict = self._config_provider.get_config()
        config = ConfigSchema(**config_dict)
        dependent_steps: list[ConfigStep] = []
        for step in config.steps:
            if (
                step.dependency
                and step.action_id != DERIVED_ACTION_ID
                and self._step_id in step.dependency
                and not step.disable_auto_run  # TODO: Log this or unify the logic
            ):
                dependent_steps.append(step)

        engine_task_client = EngineSQSClient()

        dependent_step_ids = [step.id for step in dependent_steps]
        logger.info(
            f"Found dependencies for step {self._step_id} for instance {config.instance_id} - {dependent_step_ids}"
        )

        # queue all the derived dependencies
        # !!! handle multi-rerun here
        self._state_manager.queue_many_steps(
            config.instance_id,
            [
                {"step_id": step.id, "action_id": step.action_id}
                for step in dependent_steps
            ],
        )

        for dep in dependent_steps:
            logger.info(f"Running step {dep.id} for instance {config.instance_id}")
            engine_task_client.run_a_step(config.instance_id, dep.id, dep.action_id)

        logger.info(
            f"Scheduled steps {dependent_step_ids} for instance {config.instance_id} after step {self._step_id}"
        )

    def _run_derived(self):
        config_dict = self._config_provider.get_config()
        config = ConfigSchema(**config_dict)

        dependent_derived_step_ids = []
        for step in config.steps:
            if (
                step.dependency
                and step.action_id == DERIVED_ACTION_ID
                and self._step_id in step.dependency
                and not step.disable_auto_run  # TODO: Log this or unify the logic
            ):
                dependent_derived_step_ids.append(step.id)

        # queue all the derived dependencies
        self._state_manager.queue_many_steps(
            config.instance_id,
            [
                {"step_id": step_id, "action_id": DERIVED_ACTION_ID}
                for step_id in dependent_derived_step_ids
            ],
        )

        # run all the derived dependencies
        for dep in dependent_derived_step_ids:
            StepRunner(
                self._config_provider,
                self._state_manager,
                self._template_engine_class,
                self._action_resolver,
                dep,
            ).run()
