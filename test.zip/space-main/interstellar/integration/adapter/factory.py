import pydash
from integration.adapter.interface import BaseDataAdapter
from integration.adapter.types import Integration
from integration.csv.adapter import CsvAdapter, CsvS3Adapter, CsvS3Config
from integration.hubspot.adapter import HubspotAdapter
from integration.orbital.tenant_data.adapter import TenantDataAdapter
from integration.salesforce.adapter import SalesforceAdapter
from integration.snowflake.adapter import SnowflakeAdapter
from integration.test.adapter import TestDataAdapter
from lib.crm.hubspot import _classes
from lib.crm.salesforce.crm import CompanyLocationParams, SalesforceCrmParams
import config


def get_adapter(integration: Integration) -> BaseDataAdapter:
    if integration.type == "hubspot":
        # TODO: Fetch Hubspot credentials from tenant_uuid
        client_id = config.get_parameter("HUBSPOT_CLIENT_ID")
        client_secret = config.get_parameter("HUBSPOT_CLIENT_SECRET")
        hubspot_config = _classes.HubspotParams(
            client_id=client_id,
            client_secret=client_secret,
            access_token=pydash.get(integration.config, "access_token"),
            refresh_token=pydash.get(integration.config, "refresh_token"),
        )
        return HubspotAdapter(hubspot_config)
    elif integration.type == "test":
        return TestDataAdapter()
    elif integration.type == "tenant-data":
        tenant_uuid = pydash.get(integration.config, "tenant_uuid")
        return TenantDataAdapter(tenant_uuid)
    elif integration.type == "snowflake":
        return SnowflakeAdapter()
    elif integration.type == "salesforce":
        # TODO: Fetch Salesforce credentials from tenant_uuid
        sf_config = SalesforceCrmParams(
            domain="",
            client_id="",
            client_secret="",
            access_token="",
            refresh_token="",
            company_location=CompanyLocationParams(object_type=""),
            associations=[],
        )
        return SalesforceAdapter(sf_config)
    elif integration.type == "csv":
        return CsvAdapter()
    elif integration.type == "csv-s3":
        return CsvS3Adapter(
            CsvS3Config(
                bucket_name=pydash.get(integration.config, "bucket_name"),
                path=pydash.get(integration.config, "path"),
                files=pydash.get(integration.config, "files"),
            )
        )
    else:
        raise ValueError(f"Provider {integration.type} not supported")
