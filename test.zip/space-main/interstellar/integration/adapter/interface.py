import abc
from typing import Any

from integration.adapter.types import (
    CreateObjectResponse,
    Page,
    ProviderSchema,
    SearchParamsGroupWithValue,
)
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


# TODO: Better to split to Reader and Writer Interfaces
class BaseDataAdapter(abc.ABC):
    @abc.abstractmethod
    def get_objects(
        self,
        object_name: str,
        associations: list[str] | None = None,
        filters: dict | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ) -> Page | None:
        pass

    @abc.abstractmethod
    def create_object(
        self, object_name: str, object: dict, associations: list[dict]
    ) -> CreateObjectResponse:
        pass

    @abc.abstractmethod
    def update_object(
        self, object_name: str, object_id: str, object: dict, associations: list[dict]
    ) -> str:
        pass

    @abc.abstractmethod
    def get_object(self, object_name: str, object_id: str):
        pass

    @abc.abstractmethod
    def map_object(
        self,
        object_name: str,
        object_id: str,
        object_destination_id: str,
        status_field: str | None = None,
    ):
        pass

    @abc.abstractmethod
    def search_object(self, object_name: str, search_params: Any) -> Page | None:
        pass

    @abc.abstractmethod
    def get_schema(self, object_name: str) -> ProviderSchema:
        pass
