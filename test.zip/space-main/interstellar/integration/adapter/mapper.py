from typing import Any, Callable

import pydash
from integration.adapter.types import (
    FieldMapping,
    ObjectMapping,
    SourceFieldSchema,
)
from pydash import flow


class Mapper:
    def __init__(self, config: ObjectMapping):
        self.config = config
        self.parse()

    def parse(self):
        self.field_mappers = schema_parser(self.config.fields)
        self.assoc_mappers = [
            {"object_type": k, "mapper": schema_parser(v)}
            for i, (k, v) in enumerate(self.config.dest_associations.items())
        ]

    def map(self, row: dict[str, Any]):
        fields = transform_dict(
            {
                key: mapper(row)
                for key, mapper in self.field_mappers.items()
                # This is to avoid sending empty fields
                if mapper(row) != ""
            },
            True,
        )
        associations = [
            transform_dict(
                {
                    "object_type": assoc["object_type"],
                    "data": {
                        **{key: mapper(row) for key, mapper in assoc["mapper"].items()}
                    },
                },
                True,
            )
            for assoc in self.assoc_mappers
        ]

        return fields, associations


def schema_parser(mappings: list[FieldMapping]):
    mappers: dict[str, Callable[[dict[str, Any]], str]] = {}

    for field_map in mappings:
        source_field = field_map.source_field
        mappers[field_map.destination.path] = complex_mapper(
            field_map.destination.path, source_field
        )
    return mappers


lambda_dict = {
    "path": {
        "lambda": lambda obj, config: pydash.get(obj, config["path"]),
        "validator": lambda config: "path" in config,
    },
    "constant": lambda obj, config: config["constant"],
    "type": lambda obj, config: convert_type(config["type"])(
        lambda_dict["path"](obj, config)
    ),
    "default": lambda obj, config: (
        lambda_dict["path"](obj, config)
        if lambda_dict["path"](obj, config)
        else config["default"]
    ),
    "transform": lambda obj, config: get_transformer(config["transform"], lambda x: x)(
        obj
    ),
}


def simple_mapper(key: str, value: str):
    if value:
        return lambda object: object if value == "$" else pydash.get(object, value)
    else:
        raise Exception(f"Invalid mapping '{key}' -> '{value}', '{value}' is not valid")


def complex_mapper(key: str, schema: SourceFieldSchema):
    func_chain = []
    if schema.path is not None:
        func_chain.append(simple_mapper(f"{key}.column", schema.path))
    elif schema.constant:
        func_chain.append((lambda c: lambda _: c)(schema.constant))
    else:
        raise Exception(
            f"Invalid mapping config for '{key}', config should contain either 'column' or 'generate' or 'constant'"
        )

    if schema.type:
        func_chain.append(convert_type(schema.type))

    if schema.default:
        func_chain.append((lambda dv: lambda v: v if v else dv)(schema.default))

    val_func = flow(*func_chain)

    if schema.transform:
        return get_transformer(schema.transform, val_func)
    else:
        return val_func


def get_transformer(
    transform: str,
    value_func: Callable[[dict[str, Any]], Any],
):
    builtin_dict = {key: getattr(__builtins__, key) for key in dir(__builtins__)}

    def raise_error(msg: str):
        raise Exception(msg)

    builtin_dict["__import__"] = lambda *a, **k: raise_error(
        "import statements are not allowed"
    )

    def fu(row: dict[str, Any]):
        value = value_func(row)
        globals = {
            "row": row,
            "__builtins__": builtin_dict,
            "str": str,
            "pydash": pydash,
            "len": len,
        }
        locals = {"value": value}
        exec(transform, globals, locals)
        return locals["value"]

    return fu


def convert_type(_type: str):
    import re

    return {
        "int": lambda x: int(re.sub(r"[^\d.-]", "", x)) if type(x) == str else int(x),
        # TODO: This float regex is wrong. It removes which is not supposed to be removed from float
        "float": lambda x: (
            float(re.sub(r"[^\d.-]", "", x)) if type(x) == str else float(x)
        ),
        "bool": lambda x: bool(x.strip()) if type(x) == str else bool(x),
    }[_type]


def transform_dict(d: dict[str, Any], format_to_string: bool = False) -> dict[str, Any]:
    result = {}
    for key, value in d.items():
        pydash.set_(result, key, value)
    return result
