import datetime
import pydantic
from typing import Any, List, Literal, Optional


SearchOperators = Literal["EQ", "ILIKE"]


class RateLimit(pydantic.BaseModel):
    limit: int
    interval: int


class SourceFilter(pydantic.BaseModel):
    type: str
    value: str


class CustomAssociation(pydantic.BaseModel):
    id: str
    association_object_type: str
    source_fk_id: str


class SourceFieldSchema(pydantic.BaseModel):
    path: str | None = None
    constant: str | int | None = None
    type: str | None = None
    default: str | None = None
    transform: str | None = None


class DestinationSchema(pydantic.BaseModel):
    path: str


class FieldMapping(pydantic.BaseModel):
    source_field_id: str
    type: str
    source_field: SourceFieldSchema
    destination: DestinationSchema
    updatable: Optional[bool] = None
    source_primary_key: Optional[bool] = None
    destination_primary_key: Optional[bool] = None


class SearchParams(pydantic.BaseModel):
    destination_key: str
    operator: SearchOperators
    match_pattern: Literal["START", "BETWEEN", "END"] | None = None


class SearchParamsGroup(pydantic.BaseModel):
    params: list[
        SearchParams
    ]  # To apply "AND" logic, include the list of "SearchParams" object inside this "params" list.


class ObjectMapping(pydantic.BaseModel):
    order: int
    source_object_type: str
    destination_object_type: str
    source_filters: List[SourceFilter] = []
    src_associations: List[str] = []
    src_custom_associations: List[CustomAssociation] = []
    dest_associations: dict[str, list[FieldMapping]] = {}
    dest_search_params: list[SearchParamsGroup] | None = (
        None  # To apply "OR" logic, include multiple "SearchParamsGroup" within this "dest_search_params".
    )
    limit: int | None = None
    page_size: int | None = None
    status_field: str | None = None
    fields: List[FieldMapping]
    map_to_source: bool = False


class Integration(pydantic.BaseModel):
    type: str
    config: dict | None = None
    rate_limit: RateLimit | None = None


class MapperSchema(pydantic.BaseModel):
    objects: List[ObjectMapping]


class IntegrationModel(pydantic.BaseModel):
    id: str
    source: Integration
    mapper: MapperSchema
    destination: Integration


class Pagination(pydantic.BaseModel):
    cursor: str | None


class Page(pydantic.BaseModel):
    results: list[dict]
    pagination: Pagination


class CreateObjectResponse(pydantic.BaseModel):
    id: str
    object: dict


class SearchParamsWithValue(SearchParams):
    value: Any


class SearchParamsGroupWithValue(pydantic.BaseModel):
    params: list[SearchParamsWithValue]


class ProviderProperty(pydantic.BaseModel):
    name: str
    type: str
    allowed_values: list[Any] = []


class ProviderSchema(pydantic.BaseModel):
    properties: list[ProviderProperty]
    last_fetched_on: datetime.datetime
