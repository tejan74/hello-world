from typing import Any
from integration.adapter.interface import BaseDataAdapter
from integration.adapter.types import (
    CreateObjectResponse,
    Page,
    Pagination,
    ProviderSchema,
)

from util.logger import interstellar_logger
from lib import apollo
from lib.apollo._classes import CompanySearchCriteria

logger = interstellar_logger(__name__)


class ApolloAdapter(BaseDataAdapter):
    def __init__(self):
        self.apollo_api = apollo.ApiClient()

    def get_objects(
        self,
        object_name: str,
        associations: list[str] | None = None,
        filters: dict | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ) -> Page | None:
        response = self.apollo_api.get_companies_list(
            CompanySearchCriteria(
                company_name=object_name,
                page_size=page_size,
                page_number=int(cursor) if cursor else None,
                company_locations=(
                    filters["company_locations"]
                    if filters and filters["company_locations"]
                    else None
                ),
                company_employees_number_ranges=(
                    filters["company_employees_number_ranges"]
                    if filters and filters["company_employees_number_ranges"]
                    else None
                ),
            )
        )
        if len(response["breadcrumbs"]) == 0:
            return None
        if len(response["breadcrumbs"]) < page_size:
            new_cursor = None
        elif cursor:
            new_cursor = str(int(cursor) + 1)
        return Page(
            results=response["breadcrumbs"], pagination=Pagination(cursor=new_cursor)
        )

    def create_object(
        self, object_name: str, object: dict, associations: list[dict] | None = None
    ) -> CreateObjectResponse | None:
        raise NotImplementedError

    def map_object(self, object_name: str, object_id: str, object_destination_id: str):
        raise NotImplementedError

    def update_object(
        self,
        object_name: str,
        object_id: str,
        object: dict,
        associations: list[dict] | None = None,
    ):
        raise NotImplementedError

    def get_object(self, object_name: str, object_id: str):
        raise NotImplementedError

    def search_object(self, object_name: str, search_params: Any) -> Page | None:
        raise NotImplementedError    

    def get_schema(self, object_name: str) -> ProviderSchema:
        raise NotImplementedError
