import stat
from typing import Any

import pydantic
from integration.adapter.interface import BaseDataAdapter
from integration.adapter.types import (
    CreateObjectResponse,
    Page,
    Pagination,
    ProviderProperty,
    ProviderSchema,
    SearchParamsGroupWithValue,
)
import csv
from lib.aws.s3.__init_ import S3Client
from util.logger import interstellar_logger
import datetime

logger = interstellar_logger(__name__)    

class CsvS3Config(pydantic.BaseModel):
    bucket_name: str
    path: str
    files: list[str]

class CsvAdapter(BaseDataAdapter):
    def _is_valid_csv(self, file_path):
        logger.info(f"Validating csv file: {file_path}")
        try:
            # Attempt to open the file with the csv.reader
            with open(file_path, newline="") as csvfile:
                csv_reader = csv.reader(csvfile)
                columns = next(csv_reader)
                if ("UUID" not in columns) and ("Sync_ID" not in columns):
                    return False

                # Read the first few lines to detect CSV format
                for _ in range(1):  # Read the first 5 lines
                    next(csv_reader)
                csvfile.close()
                # If successful, assume it's a valid CSV file
                return True

        except Exception as e:
            # Handle any exceptions (e.g., file not found, permission denied, etc.)
            logger.exception(f"Failed to validate csv file")
            return False

    def _read_csv_file(
        self, file_path: str, start_row: int | None = None, page_size: int | None = None
    ):
        """
        Here first we are checking csv is valid or not
        if it is valid then we are getting data based on the start_row and
        page_size and we are uuid is present in each row or not, if it is '' in one row also we will return None
        """
        if not file_path.endswith(".csv"):
            file_path = file_path + ".csv"
        if self._is_valid_csv(file_path):
            selected_rows = []
            with open(file_path, "r", newline="") as file:
                csv_reader = csv.reader(file)
                columns = next(csv_reader)
                if start_row:
                    for _ in range(start_row - 1):
                        next(csv_reader)

                # Read rows from start_row to page_size (inclusive)
                current_row = 1
                for row in csv_reader:
                    if page_size and current_row > page_size:
                        break
                    each_row = dict(list(zip(columns, row)))
                    if not each_row["UUID"]:
                        return {
                            "status": "failure",
                            "message": f"UUID value is empty in row {current_row}",
                        }
                    selected_rows.append(each_row)
                    current_row += 1
            file.close()
            return {"status": "success", "data": selected_rows}
        else:
            return {"status": "failure", "message": "Invalid CSV File"}

    def _write_csv_file(self, file_name, new_row_data):
        """
        opening the file in write mode
        and appending the new row data in csv file
        """
        if not file_name.endswith(".csv"):
            file_name = file_name + ".csv"
        try:
            row = self._row_updation(file_name=file_name, row_data=new_row_data)
            with open(file_name, "a", newline="") as file:
                writer = csv.writer(file)
                writer.writerow(row)
                file.close()
                return {"status": "success", "data": new_row_data["UUID"]}
        except Exception as e:
            logger.exception(f"Failed to append the data in csv file: {e}")
            return {
                "status": "error",
                "message": f"Failed to append the data in csv file: {e}",
            }

    def _add_new_csv_file(
        self, filepath, output_file: str, uuid: str, destination_id
    ) -> None:
        """
        Here we are updating filepath, destination id and uuid in new file
        """
        with open(output_file, "a", newline="") as ofile:
            writer = csv.writer(ofile)
            columns = ["CSV File Name", "UUID", "destination Id"]
            writer.writerow(columns)
            writer.writerow([filepath, uuid, destination_id])

    def _row_updation(self, file_name, row_data):
        """
        opened the file in read mode
        and creating a new row by comparing with the already existing columns
        """
        with open(file_name, "r", newline="") as file:
            reader = csv.reader(file)
            row = next(reader)
        new_row = []
        for header in row:
            if header in row_data:
                new_row.append(row_data[header])
            else:
                new_row.append("")
        file.close()
        return new_row

    def get_objects(
        self,
        object_name: str,
        associations: list[str] | None = None,
        filters: dict | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ) -> Page | None:
        response: dict | None = self._read_csv_file(
            file_path=object_name,
            start_row=int(cursor) if cursor else 0,
            page_size=page_size,
        )
        if response["status"] == "failure":
            return None
        new_cursor = None
        if len(response["data"]) < page_size:
            new_cursor = None
        elif cursor:
            new_cursor = str(int(cursor) + page_size)
        return Page(
            results=response["data"], pagination=Pagination(cursor=new_cursor)
        )

    def create_object(
        self, object_name: str, object: dict, associations: list[dict] | None = None
    ) -> CreateObjectResponse | None:
        result = self._write_csv_file(file_name=object_name, new_row_data=object)
        if result["status"] == "success":
            return CreateObjectResponse(id=object["UUID"], object=object)
        else:
            return None

    def map_object(self, object_name: str, object_id: str, object_destination_id: str, status_field: str | None = None):
        logger.info(f"Mapping object: {object_id} to {object_destination_id}")
        response = self._read_csv_file(file_path=object_name)
        if response["status"] == "success":
            data: list[dict] = response["data"]  # type: ignore
            columns = list(data[0].keys())
            values = []
            found = False

            for x in data:
                if (x.get("UUID") == object_id) and (not found):
                    x["Sync_ID"] = object_destination_id
                    found = True
                    logger.info(f"Found object: {object_id} to map with {object_destination_id}")

                    if status_field:
                        # check if the status_field is present in the columns
                        if status_field in columns:
                            x[status_field] = "synced"
                            logger.info(f"Updated status field of {object_id}: {status_field} to 'synced'")
                        else:
                            logger.error(f"Status field: {status_field} not found in csv file of object {object_name}")
                            
                values.append(list(x.values()))

            if found:
                with open(object_name+".csv", "w") as f:
                    writer = csv.writer(f)
                    writer.writerows([columns, *values])
            else:
                logger.error(f"Object: {object_id} not found in csv file of object {object_name}")

    def update_object(
        self,
        object_name: str,
        object_id: str,
        object: dict,
        associations: list[dict] | None = None,
    ):
        raise NotImplementedError

    def get_object(self, object_name: str, object_id: str):
        response = self._read_csv_file(file_path=object_name)
        if response["status"] == "success":
            data: list[dict] = response["data"]  # type: ignore
            for x in data:
                if x.get("UUID") == object_id:
                    return x

    def search_object(
        self, object_name: str, search_params: list[SearchParamsGroupWithValue]
    ):
        raise NotImplementedError

    def get_schema(self, object_name: str) -> ProviderSchema:
        logger.info(f"Getting schema of object: {object_name} for csv_provider")
        response = self._read_csv_file(file_path=object_name, page_size=1)
        if response["status"] == "failure":
            logger.error(f"Failed to read CSV: {object_name} Error: {response["message"]}")
            return ProviderSchema(properties=[], last_fetched_on=datetime.datetime.now())
        else:
            data = response["data"][0] if len(response["data"]) else {}
            result: list[ProviderProperty] = []
            headers = list(data.keys())  # type: ignore
            for x in headers:
                result.append(ProviderProperty(name=x, type="string"))

            return ProviderSchema(properties=result, last_fetched_on=datetime.datetime.now())


class CsvS3Adapter(CsvAdapter):
    def __init__(self, config: CsvS3Config):
        self.bucket_name = config.bucket_name
        self.path = config.path
        self.files = config.files
        self.s3client = S3Client(region_name="us-west-2")

        if not self.path:
            raise ValueError("object_name is required")
        
        if not self.bucket_name:
            raise ValueError("bucket_name is required")
        
        for file in self.files:
            self.download_file(file_name=file,local_file_path=file)

    def download_file(self, file_name: str, local_file_path: str):
        if not self.path:
            raise ValueError("object_name is required")
        
        if not self.bucket_name:
            raise ValueError("bucket_name is required")
        
        
        is_downlaoded = self.s3client.download_file(
            self.bucket_name,
            self.path+"/"+file_name,
            local_file_path,
        )

        if is_downlaoded:
            return local_file_path
        else:
            return None
    
    def map_object(self, object_name: str, object_id: str, object_destination_id: str):
        super().map_object(object_name, object_id, object_destination_id)
        self.s3client.upload_file(object_name+".csv", self.bucket_name, self.path+"/"+object_name+".csv")
