import datetime
import json
from typing import Any

import pydantic

from integration.adapter.interface import BaseDataAdapter
from integration.adapter.types import CreateObjectResponse, Page, Pagination, ProviderProperty, ProviderSchema, SearchParamsGroupWithValue
from lib.crm.hubspot import _classes
from lib.crm._classes import Association as HubspotAssociation
from integration.hubspot.interface import Hubspot
import pydash
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

class HubspotAdapter(BaseDataAdapter):
    def __init__(self, params: _classes.HubspotParams):
        self.hubspot = Hubspot(params)

    def get_object(self, object_name: str, object_id: str):
        logger.info(f"Fetching {object_name} object with ID: {object_id}")
        print(f"Fetching {object_name} object with ID: {object_id}")
        #TODO: Implement this
        return None

    def map_object(self, object_name: str, object_id: str, object_destination_id: str):
        logger.info("Not Applicable")
        pass

    def get_objects(
        self,
        object_name: str,
        associations: list[str] | None = None,
        filters: list[dict] | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ) -> Page | None:
        self.hubspot.refresh_access_token()
        modified_after = None

        if filters:
            modified_after = pydash.get(
                pydash.find(filters, lambda x: x.get("name") == "modified_after"),
                "value",
            )

        response = self.hubspot._get_objects_with_pagination(
            object_name=object_name,
            associations=associations,
            modified_after=modified_after,
            page_size=page_size,
            cursor=cursor,
        )

        results = response.get("results")
        pagination = response.get("pagination")

        if not results:
            return None

        return Page(
            results=results, pagination=Pagination(cursor=pagination.get("cursor"))
        )

    def create_object(
        self, object_name: str, object: dict, associations: list[dict]
    ) -> CreateObjectResponse:
        self.hubspot.refresh_access_token()
        # Explanation: Hubspot don't support JSON fields so converting it to string JSON
        for key, value in object.items():
            if isinstance(value, dict):
                object[key] = json.dumps(value)

        hubspot_associations = []
        for assoc in associations:
            object_type = str(pydash.get(assoc, "object_type"))
            assoc_object_id = str(pydash.get(assoc, "data.object_id"))
            type_id = int(pydash.get(assoc, "data.type_id"))
            category = str(pydash.get(assoc, "data.category"))

            if not object_type or not assoc_object_id:
                logger.error(
                    f"Invalid association object: {assoc}, skipping association"
                )

            hubspot_associations.append(
                HubspotAssociation(
                    object_id=assoc_object_id,
                    object_type=object_type,
                    category=category,
                    type_id=type_id,
                )
            )
        logger.info(f"Associations: {hubspot_associations}")

        logger.info(f"Creating {object_name} object")
        response = None
        if object_name == "company":
            response = self.hubspot.create_company(object)
        elif object_name == "contact":
            response = self.hubspot.create_contact(
                object, associations=hubspot_associations
            )
        elif object_name == "deal":
            response = self.hubspot.create_opportunity(object)
        elif object_name == "company_location":
            response = self.hubspot.create_company_location(object)
        else:
            logger.info(
                f"Not a standard object, creating as custom object: {object_name}"
            )
            response = self.hubspot._create_object(
                object_name=object_name, properties=object
            )

        # TODO: Handle response and return id in fixed format
        return CreateObjectResponse(id=pydash.get(response, "id"), object=response)

    def update_object(
        self, object_name: str, object_id: str, object: dict, associations: list[dict]
    ):

        # Explanation: Hubspot don't support JSON fields so converting it to string JSON
        for key, value in object.items():
            if isinstance(value, dict):
                object[key] = json.dumps(value)
        hubspot_associations = []
        logger.info(f"Updating object with ID: {object_id}, {object}")
        for assoc in associations:
            assoc_object_type = str(pydash.get(assoc, "object_type"))
            assoc_object_id = str(pydash.get(assoc, "data.object_id"))
            assoc_type_id = int(pydash.get(assoc, "data.type_id"))
            assoc_category = str(pydash.get(assoc, "data.category"))

            if not assoc_object_type or not assoc_object_id:
                logger.error(
                    f"Invalid association object: {assoc}, skipping association"
                )

            hubspot_associations.append(
                HubspotAssociation(
                    object_id=assoc_object_id,
                    object_type=assoc_object_type,
                    type_id=assoc_type_id,
                    category=assoc_category,
                )
            )
        logger.info(f"Associations: {hubspot_associations}")

        self.hubspot.refresh_access_token()
        if object_name == "company":
            response = self.hubspot.update_company(object_id, object)
        elif object_name == "contact":
            response = self.hubspot.update_contact(object_id, object)
        elif object_name == "deal":
            response = self.hubspot.update_opportunity(object_id, object)
        elif object_name == "company_location":
            response = self.hubspot.update_company_location(object_id, object)
        else:
            logger.info(
                f"Not a standard object, updating as custom object: {object_name}"
            )
            response = self.hubspot._update_object(
                object_name=object_name, record_id=object_id, properties=object
            )
            return response

        # Create associations
        logger.info(f"Total associations to create {len(hubspot_associations)}")
        for assoc in hubspot_associations:
            logger.info(f"Creating association: {assoc}")
            self.hubspot.create_association(
                source=object_name, source_id=object_id, association=assoc
            )

        # TODO: Handle response and return id in fixed format
        return response

    def search_object(
        self, object_name: str, search_params: list[SearchParamsGroupWithValue]
    ) -> Page | None:
        self.hubspot.refresh_access_token()
        logger.info(f"Searching object of type: {object_name} with search params: {search_params}")

        params = [
            _classes.HubspotSearchGroup(
                params=[
                    _classes.HubspotSearchParams(
                        property_name=y.destination_key,
                        operator=(
                            "CONTAINS_TOKEN" if y.operator == "ILIKE" else y.operator
                        ),
                        value=y.value if y.operator == "EQ" else f"{"*" if y.match_pattern == "START" or y.match_pattern == "BETWEEN" else ""}{y.value}{"*" if y.match_pattern == "END" or y.match_pattern == "BETWEEN" else ""}",
                    )
                    for y in x.params
                ]
            )
            for x in search_params
        ]

        response = self.hubspot._search_objects(
            object_name=object_name, search_params=params, page_size=1
        )

        results = response.get("results")
        pagination = response.get("pagination")

        if not results:
            return None

        return Page(
            results=results, pagination=Pagination(cursor=pagination.get("cursor"))
        )

    def get_schema(self, object_name: str) -> ProviderSchema:
        self.hubspot.refresh_access_token()
        logger.info(f"Getting schema of object: {object_name} for hubspot data provider")

        response = self.hubspot._get_properties_by_object_name(object_name)

        # Adding id manually because every object has primary key as "id" and they don't add it when we describe a object
        # Doc: https://developers.hubspot.com/docs/api/crm/properties
        result: list[ProviderProperty] = [ProviderProperty(name="id", type="string")]
        for x in response:
            result.append(ProviderProperty(name=pydash.get(x, "name"), type=pydash.get(x, "type"), allowed_values=pydash.get(x, "options", [])))

        return ProviderSchema(properties=result, last_fetched_on=datetime.datetime.now())
