import pydantic

from hubspot import HubSpot
from hubspot.auth.oauth.models.token_response_if import TokenResponseIF

from integration.oauth import OAuth
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

class OAuthTokenResponse(pydantic.BaseModel):
    access_token: str
    refresh_token: str
    expires_in: int
    token_type: str
    id_token: str

class HubSpotOAuth(OAuth):
    AUTHORIZE_URL = "https://app.hubspot.com/oauth/authorize"
    DEFAULT_SCOPES = ["crm.lists.read","crm.objects.contacts.read","settings.users.write","crm.objects.contacts.write","crm.schemas.custom.read",
                      "crm.objects.custom.read","crm.objects.custom.write","crm.objects.companies.write","settings.users.read",
                      "crm.schemas.contacts.read","crm.lists.write","crm.objects.companies.read","crm.objects.deals.read","crm.objects.deals.write",
                      "crm.schemas.companies.read","crm.schemas.companies.write","crm.schemas.contacts.write","crm.schemas.deals.read",
                      "crm.schemas.deals.write","crm.objects.owners.read"]

    def generate_authorization_url(
        self, client_id: str, redirect_uri: str, state: str, scopes: list[str] = DEFAULT_SCOPES
    ) -> str:
        """Generate a URL for the user to authorize the app."""
        return f"{self.AUTHORIZE_URL}?client_id={client_id}&redirect_uri={redirect_uri}&state={state}&scope={" ".join(scopes)}"

    def get_access_token(self, client_id: str, client_secret: str, code: str, redirect_uri: str):
        """Get an access token from HubSpot."""
        api_client = HubSpot()
        tokens = api_client.auth.oauth.tokens_api.create(
            grant_type="authorization_code",
            client_id=client_id,
            client_secret=client_secret,
            redirect_uri=redirect_uri,
            code=code,
        )
        
        if not tokens:
            logger.error("Failed to get access token from HubSpot")
            raise Exception("Failed to get access token from HubSpot")

        if not isinstance(tokens, TokenResponseIF):
            logger.error(f"Unexpected response from HubSpot: {tokens}")
            raise Exception(f"Unexpected response from HubSpot: {tokens}")

        return {
            "access_token": tokens.access_token,
            "refresh_token": tokens.refresh_token,
            "expires_in": tokens.expires_in,
            "token_type": tokens.token_type,
            "id_token": tokens.id_token,
        }
