from lib.crm.hubspot import _classes
from lib.crm import CRM, Association


class Hubspot(CRM, _classes.Hubspot):
    def __init__(self, params: _classes.HubspotParams):
        super().__init__(params)

    def list_company(
        self,
        modified_after: str | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ):
        return super()._get_objects_with_pagination(
            object_name="company",
            modified_after=modified_after,
            page_size=page_size,
            cursor=cursor,
        )

    def list_contact(
        self,
        modified_after: str | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ):
        return super()._get_objects_with_pagination(
            object_name="contact",
            modified_after=modified_after,
            page_size=page_size,
            cursor=cursor,
        )

    def list_deal(
        self,
        modified_after: str | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ):
        return super()._get_objects_with_pagination(
            object_name="deal",
            modified_after=modified_after,
            page_size=page_size,
            cursor=cursor,
        )

    def list_company_location(
        self,
        modified_after: str | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ):
        return super()._get_objects_with_pagination(
            object_name="company_location",
            modified_after=modified_after,
            page_size=page_size,
            cursor=cursor,
        )

    def _to_hubspot_associations(self, associations: list[Association] | None = None):
        return (
            [
                _classes.AssociationWithCreate(
                    object_id=assoc.object_id,
                    object_type=assoc.object_type,
                    type=_classes.AssociationConfig(
                        type_id=assoc.type_id, category=assoc.category
                    ),
                )
                for assoc in associations
            ]
            if associations
            else None
        )

    def create_company(
        self, object: dict, associations: list[Association] | None = None
    ):
        return super()._create_object(
            object_name="company",
            properties=object,
            associations=self._to_hubspot_associations(associations),
        )

    def create_opportunity(
        self, object: dict, associations: list[Association] | None = None
    ):
        return super()._create_object(
            object_name="deal",
            properties=object,
            associations=self._to_hubspot_associations(associations),
        )

    def create_company_location(
        self, object: dict, associations: list[Association] | None = None
    ):
        return super()._create_object(
            object_name="company_location",
            properties=object,
            associations=self._to_hubspot_associations(associations),
        )

    def create_contact(
        self, object: dict, associations: list[Association] | None = None
    ):
        return super()._create_object(
            object_name="contact",
            properties=object,
            associations=self._to_hubspot_associations(associations),
        )

    def update_company(self, object_id: str, object: dict):
        return super()._update_object(
            object_name="company", record_id=object_id, properties=object
        )

    def update_opportunity(self, object_id: str, object: dict):
        return super()._update_object(
            object_name="deal", record_id=object_id, properties=object
        )

    def update_company_location(self, object_id: str, object: dict):
        return super()._update_object(
            object_name="company_location", record_id=object_id, properties=object
        )

    def update_contact(self, object_id: str, object: dict):
        return super()._update_object(
            object_name="contact", record_id=object_id, properties=object
        )

    def delete_company(self, id: str):
        return super()._delete_object(object_name="company", record_id=id)

    def delete_opportunity(self, id: str):
        return super()._delete_object(object_name="deal", record_id=id)

    def delete_company_location(self, id: str):
        return super()._delete_object(object_name="company_location", record_id=id)

    def delete_contact(self, id: str):
        return super()._delete_object(object_name="contact", record_id=id)

    def create_association(self, source: str, source_id: str, association: Association):
        return super()._create_association(
            from_object_name=source,
            record_id=source_id,
            association=_classes.AssociationWithCreate(
                object_id=association.object_id,
                object_type=association.object_type,
                type=_classes.AssociationConfig(
                    type_id=association.type_id, category=association.category
                ),
            ),
        )

    def delete_association(
        self, source: str, source_id: str, target: str, target_id: str
    ):
        return super()._delete_association(
            from_object_name=source,
            record_id=source_id,
            association=_classes.AssociationWithCreate(
                object_id=target_id, object_type=target
            ),
        )
