import abc


class OAuth(abc.ABC):
    """
    OAuth interface
    """

    @abc.abstractmethod
    def generate_authorization_url(
        self,
        client_id: str,
        redirect_uri: str,
        state: str,
        scopes: list[str] | None = None,
    ) -> str:
        pass

    @abc.abstractmethod
    def get_access_token(
        self, client_id: str, client_secret: str, code: str, redirect_uri: str
    ) -> dict:
        pass
