import datetime
from typing import Any
import pydash
from integration.adapter.interface import BaseDataAdapter
from integration.adapter.types import CreateObjectResponse, Page, Pagination, ProviderProperty, ProviderSchema
from lib.crm.salesforce.crm import SalesforceCrm, SalesforceCrmParams
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

class SalesforceAdapter(BaseDataAdapter):
    def __init__(self, params: SalesforceCrmParams):
        self.salesforce = SalesforceCrm(params)

    def get_object(self, object_name: str, object_id: str):
        logger.info(f"Not Applicable")
        pass

    def map_object(self, object_name: str, object_id: str, object_destination_id: str):
        logger.info(f"Not Applicable")
        pass

    def get_objects(
        self,
        object_name: str,
        associations: list[str] | None = None,
        filters: dict | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ) -> Page | None:
        self.salesforce.refresh_access_token()
        if filters:
            modified_after = pydash.get(
                pydash.find(filters, lambda x: x.get("name") == "modified_after"),
                "value",
            )

        response = self.salesforce._list_object(
            object_type=object_name,
            modified_after=modified_after,
            page_size=page_size,
            cursor=cursor,
        )

        results = response.get("results")
        pagination = response.get("pagination")

        if not results:
            return None

        return Page(
            results=results,
            pagination=Pagination(cursor=pydash.get(pagination, "cursor")),
        )

    def create_object(
        self, object_name: str, object: dict, associations: list[dict]
    ) -> CreateObjectResponse:
        self.salesforce.refresh_access_token()
        logger.info(f"Creating {object_name} object")
        response = None
        if object_name == "company":
            response = self.salesforce.create_company(object)
        elif object_name == "contact":
            response = self.salesforce.create_contact(object)
            # create associations
        elif object_name == "deal":
            response = self.salesforce.create_opportunity(object)
        elif object_name == "company_location":
            response = self.salesforce.create_company_location(object)
        else:
            logger.info(
                f"Not a standard object, creating as custom object: {object_name}"
            )
            response = self.salesforce._create_object(
                object_name=object_name, object=object
            )

        # TODO: Handle response and return id in fixed format
        return CreateObjectResponse(
            id=pydash.get(response, "id"), object=dict(response)
        )

    def update_object(
        self, object_name: str, object_id: str, object: dict, associations: list[dict]
    ):
        self.salesforce.refresh_access_token()
        logger.info(f"Updating object with ID: {object_id}")
        if object_name == "company":
            response = self.salesforce.update_company(object_id, object)
        elif object_name == "contact":
            response = self.salesforce.update_contact(object_id, object)
        elif object_name == "deal":
            response = self.salesforce.update_opportunity(object_id, object)
        elif object_name == "company_location":
            response = self.salesforce.update_company_location(object_id, object)
        else:
            logger.info(
                f"Not a standard object, updating as custom object: {object_name}"
            )
            response = self.salesforce._update_object(
                object_name=object_name, object_id=object_id, object=object
            )

        # TODO: Handle response and return id in fixed format
        return response

    def search_object(self, object_name: str, search_params: Any):
        raise NotImplementedError

    def get_schema(self, object_name: str) -> ProviderSchema:
        self.salesforce.refresh_access_token()
        logger.info(f"Getting schema of object: {object_name} for salesforce data provider")

        response = self.salesforce._get_all_fields(object_name)
        
        result: list[ProviderProperty] = []
        for x in response:
            result.append(ProviderProperty(name=pydash.get(x, "name"), type=pydash.get(x, "type"), allowed_values=pydash.get(x, "options", [])))

        return ProviderSchema(properties=result, last_fetched_on=datetime.datetime.now())

