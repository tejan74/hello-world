import datetime
from typing import Any
import pydash
from integration.adapter.interface import BaseDataAdapter
from lib.warehouse import snowflake as sf
from integration.adapter.types import (
    Page,
    Pagination,
    ProviderProperty,
    ProviderSchema,
    SearchParamsGroupWithValue,
)
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class SnowflakeAdapter(BaseDataAdapter):
    def __init__(self):
        self.integration = "snowflake"
        self.tenant_uuid = "070d5ba7-6a67-4689-9313-ecb56e60ffed"
        self.snowflake_api = sf.ApiClient(
            user="",
            password="",
            account="",
            role="",
            warehouse="",
            database="",
            schema="",
        )

    # get_objects_paginated her self, object_name is table name, filter is where as attribute and properties are select
    def get_objects(
        self,
        object_name: str,
        associations: list[str] | None = None,
        filters: dict[Any, Any] | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ):
        query = f"""DESCRIBE TABLE {object_name}"""
        describe_result = self.snowflake_api._execute_query(
            query=query, query_params=[], query_type="READ"
        )
        properties = (
            [column_info[0] for column_info in describe_result]
            if describe_result
            else []
        )
        data = self.snowflake_api.get_records_from_table(
            object_name,
            filters,
            properties,
            page_size,
            int(cursor) if cursor else None,
        )
        if data:
            finalresult = []
            for each_data in data:
                finalresult.append(dict(list(zip(properties, each_data))))
            if len(finalresult) < page_size:
                new_cursor = None
            elif cursor:
                new_cursor = str(int(cursor) + page_size)
            return Page(results=finalresult, pagination=Pagination(cursor=new_cursor))
        else:
            return None

    def create_object(
        self,
        object_name: str,
        object: dict[Any, Any],
        associations: list[dict] | None = None,
    ):
        self.snowflake_api.create_record(object_name, object)
        return object["UUID"]
        # TODO: we need to return UUID's to CreateObjectResponse

    def update_object(
        self,
        object_name: str,
        object_id: str,
        object: dict,
        associations: Any,
    ):
        self.snowflake_api.update_record(object_name, object, associations)

    def map_object(self, object_name: str, object_id: str, object_destination_id: str):
        raise NotImplementedError

    def get_object(self, object_name: str, object_id: str):
        raise NotImplementedError

    def search_object(
        self, object_name: str, search_params: list[SearchParamsGroupWithValue]
    ):
        raise NotImplementedError

    def get_schema(self, object_name: str) -> ProviderSchema:
        logger.info(
            f"Getting schema of object: {object_name} for snowflake data provider"
        )

        query = f"""DESCRIBE TABLE {object_name}"""
        response = (
            self.snowflake_api._execute_query(
                query=query, query_params=[], query_type="READ"
            )
            or []
        )

        result: list[ProviderProperty] = []
        # response = [["uuid", "string"], ["name", "string"], ["age", "integer"]]
        for x in response:
            result.append(
                ProviderProperty(name=pydash.get(x, "0"), type=pydash.get(x, "1"))
            )

        return ProviderSchema(
            properties=result,
            last_fetched_on=datetime.datetime.now(),
        )
