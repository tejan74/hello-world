import json
import time
from typing import Any

from pydantic.tools import parse_obj_as
import pydash

from integration.adapter.types import (
    IntegrationModel,
    ObjectMapping,
    SearchParamsGroup,
)
from integration.adapter import get_adapter
from integration.adapter.types import (
    CreateObjectResponse,
    Page,
    SearchParamsGroupWithValue,
    SearchParamsWithValue,
)
from integration.adapter.mapper import Mapper
from util.logger import interstellar_logger

# status
# tracking
# resumable
# errors

logger = interstellar_logger(__name__)


class DataSync:
    def __init__(self, config: IntegrationModel):
        self.config = config
        self.source_config = config.source
        self.destination_config = config.destination
        self.source = get_adapter(self.source_config)
        self.destination = get_adapter(self.destination_config)

        if not self.source:
            raise ValueError("Source adapter not initialized")
        if not self.destination:
            raise ValueError("Destination adapter not initialized")

    def run(self):
        mapper_objects = self.config.mapper.objects

        if len(mapper_objects) < 1:
            raise ValueError("No mapper objects found")

        objects = pydash.sort_by(mapper_objects, lambda x: x.order)
        logger.info(f"Running {len(objects)} objects")

        for obj in objects:
            logger.info(f"Running object {obj.source_object_type}")
            self.run_object(obj)

    def run_object(self, obj: ObjectMapping):
        source_object_type = obj.source_object_type
        destination_object_type = obj.destination_object_type

        source_primary_key = pydash.find(
            obj.fields, lambda x: x.source_primary_key == True
        )
        destination_primary_key = pydash.find(
            obj.fields, lambda x: x.destination_primary_key == True
        )
        destination_search_params = obj.dest_search_params

        association_obj_names = obj.src_associations

        if not source_primary_key:
            raise ValueError("No source primary key found or path is not set")

        if not destination_primary_key:
            raise ValueError("No destination primary key found or path is not set")

        mapper = Mapper(obj)

        status_field_key = obj.status_field

        cursor = None

        # TODO: Tracking and resumable
        # TODO: Currently everything fails if one object fails
        while True:
            logger.info(
                f"Fetching object {obj.source_object_type} page from source with cursor {cursor}"
            )
            page = self.get_page_from_source(
                source_object_type,
                page_size=obj.page_size,
                cursor=cursor,
                associations=association_obj_names,
            )

            if not page:
                break

            logger.info(
                f"Fetched {len(page.results)} objects for {obj.source_object_type}"
            )

            for object in page.results:
                # check if the object is already processed
                if status_field_key:
                    status = pydash.get(object, status_field_key)
                    if status == "synced":
                        logger.info(
                            f"Object {obj.source_object_type} with id {pydash.get(object, source_primary_key.source_field_id)} already processed"
                        )
                        continue

                logger.info(
                    f"Processing object {obj.source_object_type} with id {pydash.get(object, source_primary_key.source_field_id)}"
                )
                association_data = self.get_associated_objects(obj, object)
                obj_with_associations = {**object, **association_data}
                fields, associations = mapper.map(obj_with_associations)

                logger.info(
                    f"Writing object {obj.source_object_type} with id {pydash.get(object, source_primary_key.source_field_id)} to destination"
                )
                logger.info("Sleeping for 1 second")
                time.sleep(1)
                response = self.write_to_destination(
                    destination_object_type,
                    destination_primary_key.destination.path,
                    fields,
                    associations,
                    destination_search_params,
                    obj,
                )

                # TODO: This is to let source know about the destination id
                if (
                    obj.map_to_source
                    and (response is not None)
                    and (source_primary_key is not None)
                ):
                    logger.info(
                        f"Mapping source object {source_object_type} with id {pydash.get(object, source_primary_key.source_field.path)} to destination object {destination_object_type} with id {response.id}"
                    )
                    # TODO: Make sure pks only have paths in the mapper
                    source_obj_id = pydash.get(
                        object, source_primary_key.source_field.path
                    )
                    self.source.map_object(
                        source_object_type,
                        source_obj_id,
                        response.id,
                        status_field=status_field_key,
                    )

            cursor = page.pagination.cursor

            if not cursor:
                break

    def get_associated_objects(self, mapping: ObjectMapping, object: dict):
        associations = mapping.src_custom_associations

        association_data = {}
        for association in associations:
            data = self.source.get_object(
                association.association_object_type,
                pydash.get(object, association.source_fk_id),
            )
            if data is None:
                logger.error(
                    f"Associated object not found. association - {association}, object - {object}"
                )
                raise ValueError(
                    f"Associated object not found. association - {association}, object - {object}"
                )

            association_data[association.id] = data

        return association_data

    def get_page_from_source(
        self,
        object_name,
        page_size,
        cursor,
        associations: list[str],
    ) -> Page | None:
        return self.source.get_objects(
            object_name,
            page_size=page_size,
            cursor=cursor,
            associations=associations,
        )

    # This can be parallelized
    def write_to_destination(
        self,
        object_name: str,
        pk: str,
        object: dict,
        associations: list[dict],
        search_params: list[SearchParamsGroup] | None,
        object_config: ObjectMapping,
    ) -> CreateObjectResponse | None:
        pk_val = pydash.get(object, pk)
        # remove pk from object
        pydash.unset(object, pk)
        if pk_val and isinstance(pk_val, str) and len(pk_val.strip()):
            # TODO: find the key for id
            updatableObj = {}
            fields = pydash.get(object_config, "fields")
            if fields and isinstance(fields, list):
                for x in fields:
                    if pydash.get(x, "updatable"):
                        pydash.set_(
                            updatableObj,
                            pydash.get(x, "destination.path"),
                            pydash.get(object, pydash.get(x, "destination.path")),
                        )
            self.destination.update_object(
                object_name, pk_val, updatableObj, associations
            )
            return None
        elif search_params:
            params = self._get_values_of_search_params(object, search_params)

            if params is None or len(params) == 0:
                logger.error(
                    f"Search params not found for object {object_name} with object {object}, so creating a new object"
                )
                return self.destination.create_object(object_name, object, associations)

            response = self.destination.search_object(object_name, params)
            if response and len(response.results):
                # Getting the first result here because that's the first one that has matched our criteria with the latest updated state
                id = pydash.get(response.results[0], pk)
                if id:
                    # TODO: find the key for id
                    updatableObj = {}
                    fields = pydash.get(object_config, "fields")
                    if fields and isinstance(fields, list):
                        for x in fields:
                            if pydash.get(x, "updatable"):
                                pydash.set_(
                                    updatableObj,
                                    pydash.get(x, "destination.path"),
                                    pydash.get(
                                        object, pydash.get(x, "destination.path")
                                    ),
                                )
                    self.destination.update_object(
                        object_name, id, updatableObj, associations
                    )
                    return CreateObjectResponse(id=id, object={})
        return self.destination.create_object(object_name, object, associations)

    def _get_values_of_search_params(
        self, object: dict, search_params: list[SearchParamsGroup]
    ) -> list[SearchParamsGroupWithValue]:
        result: list[SearchParamsGroupWithValue] = []
        for x in search_params:
            values: list[SearchParamsWithValue] = []
            for y in x.params:
                # TODO: Think about this and fix it by next sync
                if (
                    pydash.get(object, y.destination_key) is None
                    or pydash.get(object, y.destination_key) == ""
                ):
                    logger.error(
                        f"Value not found for search param {y.destination_key} in object {object}"
                    )
                    return []
                values.append(
                    SearchParamsWithValue(
                        destination_key=y.destination_key,
                        operator=y.operator,
                        value=pydash.get(
                            object, y.destination_key
                        ),  # TODO: This should be source key
                        match_pattern=y.match_pattern,
                    )
                )
            result.append(SearchParamsGroupWithValue(params=values))

        return result

    def get_schema_for_config(self):
        source_schema = {}
        destination_schema = {}

        mapper_objects = self.config.mapper.objects

        if len(mapper_objects) < 1:
            raise ValueError("No mapper objects found")

        objects = pydash.sort_by(mapper_objects, lambda x: x.order)
        logger.info(f"Getting the schema of {len(objects)} mapped objects.")

        for obj in objects:
            logger.info(f"Getting schema for source: {obj.source_object_type}")
            tmp_src_schema = self.source.get_schema(obj.source_object_type)
            source_schema[obj.source_object_type] = tmp_src_schema.model_dump()

            logger.info(
                f"Getting schema for destination: {obj.destination_object_type}"
            )
            tmp_dest_schema = self.destination.get_schema(obj.destination_object_type)
            destination_schema[obj.destination_object_type] = (
                tmp_dest_schema.model_dump()
            )

        return {
            "source_schema": source_schema,
            "destination_schema": destination_schema,
        }


# ANkith review
# 1. Separate associations
# 2. Required fields
# 3. CRM specific information

if __name__ == "__main__":
    with open("integration/out.json") as f:
        config = json.load(f)

    integration = parse_obj_as(IntegrationModel, config)
    sync = DataSync(integration)
    sync.run()
