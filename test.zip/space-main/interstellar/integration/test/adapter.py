from integration.adapter.interface import BaseDataAdapter
from integration.adapter.types import Page, SearchParamsGroupWithValue


class TestDataAdapter(BaseDataAdapter):

    def get_objects(
        self,
        object_name: str,
        filters: list[dict] | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ) -> Page | None:
        print(f"Fetching {object_name} objects with pagination {cursor}")

    def create_object(self, object_name: str, object: dict, associations: list[dict]):
        print(f"Creating {object_name} object {object}")

    def update_object(
        self, object_name: str, object_id: str, object: dict, associations: list[dict]
    ):
        print(f"Updating {object_name} object with ID {object_id} {object}")

    def get_object(self, object_name: str, object_id: str):
        print(f"Fetching {object_name} object with ID {object_id}")

    def map_object(self, object_name: str, object_id: str, object_destination_id: str):
        print(
            f"Mapping {object_name} object with ID {object_id} to {object_destination_id}"
        )

    def search_object(
        self, object_name: str, search_params: list[SearchParamsGroupWithValue]
    ):
        print(f"Fetching {object_name} object with search_params {search_params}")

    def get_schema(self, object_name: str):
        print(f"Getting properties of object: {object_name}")
