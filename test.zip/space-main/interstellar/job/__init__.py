def job_executer(name: str):
    if name == "bevi_request_alert":
        from job.bevi_request_alert import run

        return run()
    else:
        raise Exception(f"Unknown Job Name: {name}")
