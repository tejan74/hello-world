import json
from prisma import Prisma
import config
from lib import slack
from lib.warehouse import snowflake
from util import cryptography


def run():
    tenant_uuid = "070d5ba7-6a67-4689-9313-ecb56e60ffed"  # bevi's tenant uuid from tenant table domain bevi.co
    integration = "snowflake"
    slack_channel_id = "C03FBUVF65Q"
    alert_prescripts = [
        {
            "table": "COMPANY_ENRICH_REQUEST",
            "where_clause_params": {"STATUS": None},
            "message": "New Company Enrich Request: ",
        },
        {
            "table": "COMPANY_ENRICH_REQUEST",
            "where_clause_params": {"STATUS": "pending"},
            "message": "Pending Company Enrich Request: ",
        },
        {
            "table": "REVERSE_ENRICH_REQUEST",
            "where_clause_params": {"STATUS": None},
            "message": "New Reverse Enrich Request: ",
        },
        {
            "table": "REVERSE_ENRICH_REQUEST",
            "where_clause_params": {"STATUS": "pending"},
            "message": "Pending Reverse Enrich Request: ",
        },
    ]

    with Prisma(datasource={"url": config.get_parameter("DATABASE_URL")}) as prisma:
        tenant_integration = prisma.tenantintegration.find_first(
            where={"tenantUuid": tenant_uuid, "integration": integration}
        )
        if not tenant_integration:
            raise Exception("TENANT_NOT_FOUND")
    
        tenant_snowflake_data = json.loads(json.dumps(tenant_integration.data))

    snowflake_api = _build_snowflake_api_client(tenant_snowflake_data)
    slack_client = slack.ApiClient()

    for alert_prescript in alert_prescripts:
        record_count = snowflake_api.get_record_count(
            table_name=alert_prescript["table"],
            where_clause_params=alert_prescript["where_clause_params"],
        )

        if record_count > 0:
            alert_message = f"{alert_prescript["message"]} {record_count}"
            slack_client.post_message(slack_channel_id, alert_message)

    return "Completed"


def _build_snowflake_api_client(tenant_snowflake_data):
    snowsql_user = tenant_snowflake_data.get("snowsql_user")
    snowsql_pwd = tenant_snowflake_data.get("snowsql_pwd")
    snowsql_account = tenant_snowflake_data.get("snowsql_account")

    if not (snowsql_user or snowsql_pwd or snowsql_account):
        raise Exception(
            "INVALID_SNOWFLAKE_DATA - Invalid snowflake tenant integration data"
        )

    # Get tenant encryption key
    key = config.get_parameter("TENANT_ENCRYPTION_KEY")
    if not key:
        raise Exception("TENANT_ENCRYPTION_KEY is not set.")

    # Build snowflake api client
    api = snowflake.ApiClient(
        user=snowsql_user,
        password=cryptography.decrypt_tenant_secret(snowsql_pwd),
        account=snowsql_account,
        role=tenant_snowflake_data.get("snowsql_role"),
        warehouse=tenant_snowflake_data.get("snowsql_warehouse"),
        database=tenant_snowflake_data.get("snowsql_database"),
        schema=tenant_snowflake_data.get("snowsql_schema"),
    )

    return api
