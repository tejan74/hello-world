import uuid
from prisma import Prisma, enums
import pydash
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Table:
    def __init__(self, prisma: Prisma, table_uuid: str):
        self.prisma = prisma
        self.table_uuid = table_uuid

    def get_rows(self, cursor: str | None = None, take: int = 1000):
        src_row_uuids = pydash.map_(
            self.prisma.query_raw(
                f"""SELECT "uuid" FROM "UI_Row" 
                WHERE "tableUuid" = $1 {'and "id" >= $2' if cursor != None else ''} and "deletedAt" IS NULL
                ORDER BY "id" LIMIT $3""",
                self.table_uuid,
                int(cursor if cursor != None else 0),  # the zero here doesn't matter
                take + 1,
            ),
            "uuid",
        )

        next_cursor = src_row_uuids[-1] if len(src_row_uuids) > take else None
        row_uuids = src_row_uuids[:take] if len(src_row_uuids) > take else src_row_uuids

        return row_uuids, next_cursor

    def create_many_rows_with_source_ids(
        self, source_ids: list[str], import_uuid: str
    ) -> dict[str, str]:
        # TODO: Make this queries readable
        num_of_rows = len(source_ids)
        row_upsert_count = self.prisma.execute_raw(
            f"""
            INSERT INTO "UI_Row" ("updatedAt", "tableUuid", "tableImportUuid", "tableImportSourceId", "uuid") 
            SELECT * FROM 
                UNNEST(
                    ARRAY_FILL( CURRENT_TIMESTAMP, ARRAY[{num_of_rows}] ),
                    ARRAY_FILL( $1::TEXT, ARRAY[{num_of_rows}] ),
                    ARRAY_FILL( $2::TEXT, ARRAY[{num_of_rows}] ),
                    $3,
                    $4
                ) as n(a,b,c,d,e)
            ON CONFLICT ("tableImportUuid", "tableImportSourceId") DO NOTHING""",
            self.table_uuid,
            import_uuid,
            source_ids if source_ids else [None] * num_of_rows,
            [str(uuid.uuid4()) for _ in range(num_of_rows)],
        )
        logger.info("row upsert, rows affected: %s", row_upsert_count)

        # TODO: check if we can optimize by not fetching all rows again
        dest_rows = self.prisma.query_raw(
            """SELECT "uuid", "tableImportSourceId" from "UI_Row" 
            WHERE "tableUuid" = $1 and "tableImportUuid" = $2 and "tableImportSourceId" = ANY($3)""",
            self.table_uuid,
            import_uuid,
            source_ids if source_ids else [None] * num_of_rows,
        )

        logger.info("dest rows count: %s", len(dest_rows))

        source_to_destination_mapping: dict[str, str] = (
            pydash.chain(dest_rows)
            .map(lambda x: [x["tableImportSourceId"], x["uuid"]])
            .from_pairs()
            .value()
        )

        return source_to_destination_mapping

    def bulk_insert_static_data(self, data: list[tuple[str, str, str]]):
        data_upsert_count = self.prisma.execute_raw(
            """INSERT INTO "UI_StaticData" ("data", "rowUuid", "columnUuid") 
            SELECT * FROM UNNEST($1::TEXT[], $2::TEXT[], $3::TEXT[]) 
            ON CONFLICT ("rowUuid", "columnUuid") DO UPDATE SET "data" = EXCLUDED."data" """,
            *pydash.unzip(data),
        )
        logger.info("Data upsert, rows affected: %s", data_upsert_count)
        return data_upsert_count

    def get_rows_data(self, row_uuids: list[str], column_uuids: list[str]):
        src_columns = self.prisma.ui_column.find_many(
            where={"tableUuid": self.table_uuid, "uuid": {"in": column_uuids}},
            include={"DynamicColumnConfig": True},
        )
        sub_query = []
        query_params = []
        for src_column in src_columns:
            if src_column.type == enums.UI_ColumnType.DERIVED:
                raise Exception("Derived columns are not supported")
            elif src_column.type == enums.UI_ColumnType.DYNAMIC:
                # TODO: check if this causes data type issues as we are casting to text
                # TODO: ankith to review - changed #> to #>> to avoid getting "" for all values
                sub_query.append(
                    f"""SELECT ("output" #>> ${len(query_params)+1})::text AS "data", "rowUuid", ${len(query_params)+2} "columnUuid" FROM "UI_DynamicData" 
                    where "columnInternalId" = ${len(query_params)+3} and "tableUuid" = ${len(query_params)+4} """,
                )
                output_path = pydash.get(src_column, "DynamicColumnConfig.outputPath")
                query_params.append(output_path.split(".") if output_path else "")
                query_params.append(src_column.uuid)
                query_params.append(src_column.internalId)
                query_params.append(self.table_uuid)
            else:
                sub_query.append(
                    f"""SELECT "data", "rowUuid", ${len(query_params)+1} "columnUuid" FROM "UI_StaticData" 
                    where "columnUuid" = ${len(query_params)+1}"""
                )
                query_params.append(src_column.uuid)
        query = f"""
                SELECT * FROM (
                    {"\n UNION ALL \n".join(sub_query)}     
                ) sq
                WHERE "rowUuid" = ANY(${len(query_params)+1}::text[])
            """
        query_params.append(row_uuids)
        src_data = self.prisma.query_raw(query, *query_params)
        logger.info("source data count: %s", len(src_data))
        return src_data


class TableImporter:
    def __init__(
        self,
        prisma: Prisma,
        source_table_uuid: str,
        dest_table_uuid: str,
        table_import_uuid: str,
        column_mapping: dict[str, str],
    ):
        self.prisma = prisma
        self.source_table = Table(prisma, source_table_uuid)
        self.dest_table = Table(prisma, dest_table_uuid)
        self.column_mapping = column_mapping
        self.table_import_uuid = table_import_uuid

    def run(
        self,
        row_uuids: list[str],
    ):
        # Get source rows
        logger.info("Running import for source rows with count: %s", len(row_uuids))

        # Create destination rows
        row_mapping = self.dest_table.create_many_rows_with_source_ids(
            row_uuids, self.table_import_uuid
        )
        logger.info("source to dest row uuid lut count: %s", len(row_mapping))

        src_column_uuids = list(self.column_mapping.keys())

        # Get source column data
        src_data = self.source_table.get_rows_data(row_uuids, src_column_uuids)
        logger.info("source data count: %s", len(src_data))

        # Create destination column data
        # Swap row and column uuids to destination row and column uuids
        dest_data = (
            pydash.chain(src_data)
            .map(
                lambda x: (
                    x["data"],
                    row_mapping[x["rowUuid"]],  # swap row uuid
                    self.column_mapping[x["columnUuid"]],  # swap column uuid
                )
            )
            .value()
        )
        logger.info("dest data count: %s", len(dest_data))

        # Insert destination column data
        self.dest_table.bulk_insert_static_data(dest_data)
