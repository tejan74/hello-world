from datetime import datetime
from prisma import Prisma
from prisma.enums import TableImportSource
import pydantic
import pydash

import config
from engine.v1.engine_sqs_client import EngineSQSClient
from job.table import TableImporter
from job.tenant_data import TableImportTenantDataSource, TenantDataToTableImporter
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


# TODO
# 1. Cleanup run function
# 2. Folders


# will follow js naming conventions for json field in DB
class TableImportConfig(pydantic.BaseModel):
    columnMapping: dict[str, list[str]]
    rowUuids: list[str] = []
    """
    example:
        # source is tenant data
        # "dest_table_column_uuid": ["source.dataType.jsonfieldName"]
        {
            "9b2da7a5-d146-4396-af45-942668d820a1": ["Salesforce.CrmCompany.Name", "Apollo.Company.Name"],
            "f1c49e91-d6f7-4b6c-8f5f-00163cf381c4": ["Salesforce.CrmCompany.Status"],
            "73b5ffa4-6365-4786-a6a7-ac9af3002294": ["Apollo.Company.Industry", "Salesforce.CrmCompany.Industry"]
        }

        # source is table
        # "dest_table_column_uuid": ["source_table_column_uuid"]
        {
            "9b2da7a5-d146-4396-af45-942668d820a1": ["4e08ba27-7d83-46c0-bdbb-a4066524945f"],
            "f1c49e91-d6f7-4b6c-8f5f-00163cf381c4": ["acc44603-d09f-461d-a3dc-944f5775c8fb"],
            "73b5ffa4-6365-4786-a6a7-ac9af3002294": ["e9b20368-bafd-483a-a343-b5db56c9628e"]
        }
    """


def run(uuid: str, cursor: str | None = None):
    with Prisma(datasource={"url": config.get_parameter("DATABASE_URL")}) as prisma:
        table_import = prisma.tableimport.find_unique_or_raise(where={"uuid": uuid})
        import_config = TableImportConfig(**table_import.config)  # type: ignore # there isn't anything we can do about this,
        logger.info(
            "Running table import on %s, cursor: %s, destination table: %s",
            uuid,
            cursor,
            table_import.destTableUuid,
        )

        prisma.tableimport.update(
            where={"uuid": uuid},
            data={"status": "running", "startedAt": datetime.now()},
        )

        try:
            if table_import.source == TableImportSource.TABLE:
                if table_import.srcTableUuid == None:
                    raise Exception(
                        "srcTableUuid is required for table import source type table"
                    )
                logger.info("Importing from table %s", table_import.srcTableUuid)
                next_cursor = import_from_table(
                    prisma,
                    uuid,
                    table_import.destTableUuid,
                    table_import.srcTableUuid,
                    import_config.columnMapping,
                    import_config.rowUuids,
                    int(cursor or "0"),
                )
            elif table_import.source == TableImportSource.TENANT_DATA:
                logger.info(
                    "Importing from tenant data %s", table_import.tenantDataSource
                )
                data_config = TableImportTenantDataSource(**table_import.tenantDataSource)  # type: ignore # there isn't anything we can do about this
                next_cursor = import_from_tenant_data(
                    prisma,
                    table_import.tenantUuid,
                    uuid,
                    table_import.destTableUuid,
                    data_config,
                    import_config.columnMapping,
                    import_config.rowUuids,
                    int(cursor or "0"),
                )
        except Exception as e:
            prisma.tableimport.update(
                where={"uuid": uuid},
                data={"status": "failed", "finishedAt": datetime.now()},
            )
            raise e

        if next_cursor != None:
            # trigger next page
            logger.info(
                "Table import %s not completed, triggering next batch %s",
                uuid,
                next_cursor,
            )
            try:
                EngineSQSClient().run_table_import(uuid, str(next_cursor))
            except Exception as e:
                prisma.tableimport.update(
                    where={"uuid": uuid},
                    data={"status": "failed", "finishedAt": datetime.now()},
                )
                raise e

        else:
            logger.info("Table import %s completed", uuid)
            prisma.tableimport.update(
                where={"uuid": uuid},
                data={"status": "successful", "finishedAt": datetime.now()},
            )


def import_from_table(
    prisma: Prisma,
    table_import_uuid: str,
    dest_table_uuid: str,
    src_table_uuid: str,
    column_mapping: dict[str, list[str]],
    row_uuids: list[str],
    cursor: int | None,
) -> int | None:
    _column_mapping = (
        pydash.chain(column_mapping).map(lambda v, k: [v[0], k]).from_pairs().value()
    )
    table_importer = TableImporter(
        prisma, src_table_uuid, dest_table_uuid, table_import_uuid, _column_mapping
    )

    page_size = 100
    max_run_time = 7 * 60
    num_of_rows = len(row_uuids)

    if cursor == None:
        cursor = 0
    else:
        cursor = int(cursor)

    # Run import for max_run_time or until all rows are imported
    import_start_time = datetime.now()
    while cursor < num_of_rows:
        page_import_start_time = datetime.now()
        logger.info(
            "Running import for source rows with count: %s, cursor: %s",
            page_size,
            cursor,
        )

        # Stop import if there is an error
        table_importer.run(row_uuids[cursor : cursor + page_size])

        logger.info(
            f"Page import time for {cursor}: {(datetime.now() - page_import_start_time).seconds}"
        )
        logger.info(
            f"Total import time: {(datetime.now() - import_start_time).seconds}"
        )

        cursor += page_size
        if (datetime.now() - import_start_time).seconds > max_run_time:
            logger.info("Time exceeded, returning cursor")
            return cursor

    if cursor >= num_of_rows:
        logger.info(f"Imported all rows for {table_import_uuid}")


def import_from_tenant_data(
    prisma: Prisma,
    tenant_uuid: str,
    table_import_uuid: str,
    dest_table_uuid: str,
    data_config: TableImportTenantDataSource,
    column_mapping: dict[str, list[str]],
    row_uuids: list[str],
    cursor: int | None,
) -> int | None:
    table_importer = TenantDataToTableImporter(
        prisma,
        tenant_uuid,
        table_import_uuid,
        dest_table_uuid,
        data_config,
        column_mapping,
    )

    page_size = 500
    max_run_time = 7 * 60
    num_of_rows = len(row_uuids)

    if cursor == None:
        cursor = 0

    # Run import for max_run_time or until all rows are imported
    import_start_time = datetime.now()
    while cursor < num_of_rows:
        page_import_start_time = datetime.now()
        logger.info(
            "Running import for source rows with count: %s, cursor: %s",
            page_size,
            cursor,
        )

        # Stop import if there is an error
        table_importer.run(row_uuids[cursor : cursor + page_size])

        logger.info(
            f"Page import time for {cursor}: {(datetime.now() - page_import_start_time).seconds}"
        )
        logger.info(
            f"Total import time: {(datetime.now() - import_start_time).seconds}"
        )

        cursor += page_size
        if (datetime.now() - import_start_time).seconds > max_run_time:
            logger.info("Time exceeded, returning cursor")
            return cursor
