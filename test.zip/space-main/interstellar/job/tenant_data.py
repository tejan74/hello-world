import random
import string
from typing import Tuple
from prisma import Prisma
import pydantic
import pydash

from job.table import Table
from util.logger import interstellar_logger


logger = interstellar_logger(__name__)


class TableImportTenantDataSource(pydantic.BaseModel):
    sources: list["TableImportTenantDataSourceSource"]
    """
    example:
        [
            { "source": "Salesforce", "dataType": "CrmCompany"},
            { "source": "Apollo", "dataType": "Company"}
        ]
    """
    dataFilters: str | None = None


class TableImportTenantDataSourceSource(pydantic.BaseModel):
    source: str
    dataType: str


# TODO: do another pass on this class
class TenantData:
    def __init__(
        self, prisma: Prisma, tenant_uuid: str, data_config: TableImportTenantDataSource
    ):
        self.prisma = prisma
        self.tenant_uuid = tenant_uuid
        self.data_config = data_config

    # Adds a where clause to the query to filter by source and data type for each source in the data config
    # Example:
    #   SELECT "uuid" FROM "TenantData" WHERE ("source" = $1::"TenantDataSources" and "type" = $2::"TenantDataType") OR ("source" = $3::"TenantDataSources" and "type" = $4::"TenantDataType")
    def _generate_source_where_clause(self, start_index: int) -> str:
        return (
            pydash.chain(self.data_config.sources)
            .map(
                lambda _, i: f"""("source" = ${start_index+(2*i)+0}::"TenantDataSources" and "type" = ${start_index+(2*i)+1}::"TenantDataType")""",
            )
            .join(" OR ")
            .value()
        )

    # Returns a list of source and data type values for each source in the data config to be used as parameters to prepared statements
    # Example:
    #   ["Salesforce", "CrmCompany", "Apollo", "Company"]
    def _get_source_where_params(self) -> list:
        return (
            pydash.chain(self.data_config.sources)
            .map(lambda x: [x.source, x.dataType])
            .flatten()
            .value()
        )

    def get_row_uuids(
        self, cursor: str | None, page_size: int
    ) -> Tuple[list[str], str | None]:
        source_where_clause = self._generate_source_where_clause(4)
        source_where_params = self._get_source_where_params()
        data = pydash.map_(
            self.prisma.query_raw(
                f"""SELECT "uuid" FROM "TenantData" 
                WHERE {source_where_clause} {f'and "uuid" >= $1' if cursor != None else ''} and "tenantUuid" = $2
                ORDER BY "createdAt" ASC , "uuid" LIMIT $3""",
                cursor if cursor != None else "",  # the "" here doesn't matter
                self.tenant_uuid,
                page_size + 1,
                *source_where_params,
            ),
            "uuid",
        )

        next_cursor = data[-1] if len(data) > page_size else None
        row_uuids = data[:page_size] if len(data) > page_size else data

        return row_uuids, next_cursor

    def get_rows_data(
        self, src_row_uuids: list, column_mapping: dict[str, list[str]]
    ) -> list[dict[str, str]]:
        select_clause, select_params = self._generate_column_select(column_mapping, 2)
        uuid_name = "".join(random.choices(string.ascii_lowercase, k=8))
        src_data_raw = self.prisma.query_raw(
            f"""SELECT uuid as {uuid_name}, {select_clause} FROM "TenantData" 
            WHERE "uuid" = ANY($1::text[])""",
            src_row_uuids,
            *select_params,
        )
        return pydash.flat_map(
            src_data_raw,
            lambda x: pydash.map_(
                pydash.omit(x, uuid_name),
                lambda v, k: {
                    "rowUuid": x[uuid_name],
                    "columnUuid": k,
                    "data": v,
                },
            ),
        )

    def _generate_column_select(
        self, column_mapping: dict[str, list[str]], start_index: int
    ) -> tuple:
        # Example:
        #   column_mapping = {
        #       "name": ["data.name"],
        #       "address": ["data.address.street", "data.address.city", "data.address.state"]
        #   }
        #   select_clause = "coalesce(jsonb_build_object(source,jsonb_build_object(type,data)) #>> $1) as "name", coalesce(jsonb_build_object(source,jsonb_build_object(type,data)) #>> $2) as "address""
        selects = []
        params = []
        augmented_identifier = (
            "jsonb_build_object(source,jsonb_build_object(type,data))"
        )

        for column in column_mapping:
            fields = column_mapping[column]
            sub_selects = []
            for field in fields:
                # split = field.split(".")
                # json_accessor = "->".join(split[:-1]) + "->>" + split[-1]
                sub_selects.append(augmented_identifier + f" #>> ${start_index}")
                params.append(field.split("."))
                start_index += 1

            # TODO: possible sql injection here?
            selects.append(f"""coalesce({" , ".join(sub_selects)}) as "{column}" """)

        return " , ".join(selects), params


class TenantDataToTableImporter:
    def __init__(
        self,
        prisma: Prisma,
        tenant_uuid: str,
        table_import_uuid: str,
        dest_table_uuid: str,
        data_config: TableImportTenantDataSource,
        column_mapping: dict[str, list[str]],
    ):
        self.prisma = prisma
        self.tenant_uuid = tenant_uuid
        self.table_import_uuid = table_import_uuid
        self.dest_table_uuid = dest_table_uuid
        self.data_config = data_config
        self.column_mapping = column_mapping

    def run(
        self,
        row_uuids: list[str],
    ):
        tenant_data = TenantData(self.prisma, self.tenant_uuid, self.data_config)
        table = Table(self.prisma, self.dest_table_uuid)

        # Step 1: get all src rows uuids in the page
        logger.info(
            f"Running import for source rows with count: {len(row_uuids)}, cursor: {row_uuids[0]}"
        )

        # Step 2: compile src import data
        src_data = tenant_data.get_rows_data(row_uuids, self.column_mapping)
        logger.info("source data count: %s", len(src_data))

        # Step 3: do an upsert on dest rows with src rows uuid set as table import source uuid
        src_to_dest_row_uuid_lut = table.create_many_rows_with_source_ids(
            row_uuids, self.table_import_uuid
        )

        # Step 4: upsert dest static data with src import data
        remapped_src_data = pydash.map_(
            src_data,
            lambda x: (
                x["data"] if x["data"] != None else "",
                src_to_dest_row_uuid_lut[x["rowUuid"]],
                x["columnUuid"],
            ),
        )

        data_upsert_count = table.bulk_insert_static_data(remapped_src_data)
        logger.info("Data upsert, rows affected: %s", data_upsert_count)
