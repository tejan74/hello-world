import json
import logging
from asgi_correlation_id import correlation_id
import pydash
from engine.v1.aws import lambda_handler
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

# Patch all supported libraries to be traced by X-Ray


def aws_lambda(request, context):
    # suppress httpx info logs cuz its flooding the logs (we (adi, ankith) think it originates from prisma)
    logging.getLogger("httpx").setLevel(logging.WARNING)

    records = pydash.get(request, "Records")
    if not records:
        logger.error("No records found in the request")
        raise Exception("No records found in the request")

    status = []

    # Process the records
    for record in records:
        messageId = pydash.get(record, "messageId")
        receiptHandle = pydash.get(record, "receiptHandle")
        logger.info(
            f"Processing message {messageId} with receipt handle {receiptHandle}"
        )

        body = pydash.get(record, "body")

        if not body:
            logger.error("No body found in the record")
            status.append(
                {
                    "messageId": messageId,
                    "status": "failed",
                    "reason": "No body found in the record",
                }
            )
            continue

        # Parse the body
        # TODO: This is a hack, need to clean this up. Throw an error if the process fails
        try:
            body = json.loads(body)
            lambda_handler.handle(body, None)
        except Exception as e:
            logger.exception(
                "Error occurred in parsing the body or processing the message"
            )
            status.append(
                {
                    "messageId": messageId,
                    "status": "failed",
                    "reason": f"Error occurred: {e}",
                }
            )
            continue

        status.append({"messageId": messageId, "status": "success"})

    logger.info(f"Processed all records with status {status}")
