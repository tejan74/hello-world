import os
import subprocess
from asgi_correlation_id import CorrelationIdMiddleware
import fastapi
import uvicorn
from api.constant import X_REQUEST_ID_HEADER
import api.middleware.request_context
import api.v1
import config

from util.logs import generate_request_id


app = fastapi.FastAPI()

app.add_middleware(
    CorrelationIdMiddleware,
    header_name=X_REQUEST_ID_HEADER,
    generator=lambda: generate_request_id(),
    validator=lambda x: len(x) > 0,
)

app.middleware("http")(api.middleware.request_context.request_context_middleware)

app.mount("/v1", api.v1.app)


@app.get("/health")
def health():
    return 200, {"detail": "houston, we are clear for take-off."}


if __name__ == "__main__":
    # Setup uvicorn to serve the api if invoked as main, because otherwise we
    # call this api using the `uvicorn` command line tool and this is ignored
    if config.get_parameter("ENV") == "local":
        subprocess.call(
            [
                "uvicorn",
                "launcher.api:app",
                "--workers",
                "8",
                "--host",
                "0.0.0.0",
                "--port",
                "8080",
            ]
        )

    else:
        uvicorn_config = uvicorn.Config(
            "launcher.api:app",
            port=8080,
            host="0.0.0.0",
            log_config={
                # subset of default log config for uvicorn
                # from: https://github.com/encode/uvicorn/blob/5bf788f0eb0fc771f5c4eed8f282c7ec256565d2/uvicorn/config.py#L66-L98
                # modified to propagate logs to parent logger and prevent double & triple uvicorn logs caused by propagation
                "version": 1,
                "disable_existing_loggers": False,  # should be False otherwise logger in other files will be disabled
                "loggers": {
                    "uvicorn": {
                        # "handlers": ["default"], # this is the default, commented out to prevent triple uvicorn logs
                        "level": "INFO",
                        "propagate": True,  # default is False, set to True to propagate to our logger
                    },
                    "uvicorn.error": {"level": "INFO"},
                    "uvicorn.access": {
                        # "handlers": ["access"],   # this is the default, commented out to prevent triple uvicorn logs
                        "level": "INFO",
                        "propagate": True,  # default is False, set to True to propagate to our logger
                    },
                },
            },
        )

        server = uvicorn.Server(uvicorn_config)
        server.run()
