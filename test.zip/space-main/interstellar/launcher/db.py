"""
DATABASE MIGRATIONS

This launcher migrates our databases automatically based on the schema. One day we should manage these in the db service itself but for now it's more work
to deploy a dedicated service for this so we're going to do it in the init container of interstellar. This is a bit of a hack but it's a good one.
"""

import os
import config

# Setup the runtime environment
SCHEMA_DIRECTORY = "/db"
os.chdir(SCHEMA_DIRECTORY)

# Grab all the Prisma managed schemas
os.environ["DATABASE_URL"] = config.get_parameter("DATABASE_URL")

# Break out to shell and run migrations
os.system(f"python3 -m prisma migrate deploy --schema=./schema.prisma")
