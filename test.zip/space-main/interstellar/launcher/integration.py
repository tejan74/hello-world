import json

from prisma import Prisma

import config
from integration.adapter.types import IntegrationModel
from integration.sync import DataSync
from lib.aws_sqs.receiver import SQSReceiver
import util.logger

logger = util.logger.interstellar_logger(__name__)


class IntegrationWorker(SQSReceiver):
    def __init__(self, **kwargs):
        queue_url = config.get_parameter("INTEGRATION_SQS_URL")
        super().__init__(queue_url, visibility_timeout=3600, **kwargs)

    def process_message(self, message):
        message_data = json.loads(message)

        uuid = message_data.get("uuid")

        integration_config = None
        with Prisma(
            datasource={"url": config.get_parameter("DATABASE_URL")},
            use_dotenv=False,
        ) as prisma:
            integration_config = prisma.warpconfig.find_unique(
                where={"uuid": uuid},
                include={"SourceIntegration": True, "DestinationIntegration": True},
            )

        if not integration_config:
            logger.error(f"Integration config not found for uuid: {uuid}")
            raise ValueError(f"Integration config not found for uuid: {uuid}")

        logger.info(f"Processing integration run: {integration_config.uuid}")
        if (
            not integration_config.SourceIntegration
            or not integration_config.DestinationIntegration
        ):
            logger.error(
                f"Source or Destination integration not found for config: {uuid}"
            )
            raise ValueError(
                f"Source or Destination integration not found for config: {uuid}"
            )

        # TODO: Add source and destination integration config to sync config or send these to DataSync
        source_config_from_integration = integration_config.SourceIntegration.data
        destination_config_from_integration = (
            integration_config.DestinationIntegration.data
        )

        # TODO: uncomment after testing
        integration_configmap = json.loads(json.dumps(integration_config.config))
        integration_source_config = integration_configmap["source"]["config"] or {}
        integration_destination_config = (
            integration_configmap["destination"]["config"] or {}
        )

        # merge static config with integration config of integrations
        integration_configmap["source"]["config"] = {
            **source_config_from_integration,
            **integration_source_config,
        }
        integration_configmap["destination"]["config"] = {
            **destination_config_from_integration,
            **integration_destination_config,
        }

        integration_configmap = IntegrationModel.model_validate(integration_configmap)

        logger.info(f"Starting processing for integration config: {uuid}")
        # TODO: Uncomment this line after testing is done
        DataSync(integration_configmap).run()
        logger.info(f"Finished processing for integration config: {uuid}")


if __name__ == "__main__":
    receiver = IntegrationWorker()
    receiver.start()
