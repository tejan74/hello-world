import json

import config
from engine.v1.aws import lambda_handler
from lib.aws_sqs.receiver import SQSReceiver
import util.logger

logger = util.logger.interstellar_logger(__name__)


class LongActionWorker(SQSReceiver):
    def __init__(self, **kwargs):
        queue_url = config.get_parameter("LONG_ACTION_SQS_URL")
        super().__init__(queue_url, visibility_timeout=3600, **kwargs)

    def process_message(self, message):
        body = json.loads(message)
        lambda_handler.handle(body, None)


if __name__ == "__main__":
    receiver = LongActionWorker()
    receiver.start()
