import config
from tracemalloc import stop
from unittest.mock import DEFAULT
import anthropic
from pydantic import BaseModel
from typing import Literal, Optional
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

ClaudeModel = Literal[
    "claude-3-5-sonnet-20240620",
    "claude-3-opus-20240229",
    "claude-3-sonnet-20240229",
    "claude-3-haiku-20240307",
    "claude-2.1",
    "claude-2.0",
    "claude-instant-1.2",
]


class AnthropicTokensUsage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class AnthropicCompletion(BaseModel):
    id: str
    completion: list = []
    stop_reason: str | None = None
    tokens: AnthropicTokensUsage


class ApiClient:

    def __init__(
        self,
        model: Optional[ClaudeModel] = "claude-2.1",
        api_key: Optional[str] = None,
    ) -> None:
        # Use the provided api key or get it from the environment
        api_key = api_key or config.get_parameter("ANTHROPIC_API_KEY")

        # If no api key is provided, raise an exception
        if api_key is None or model is None:
            raise Exception("No api key provided")

        self.model = model
        self.client = anthropic.Anthropic(api_key=api_key)

    # TODO: Add more options
    # params: prompt, max_tokens_to_sample, temperature
    # ref: https://github.com/anthropics/anthropic-sdk-python
    def completion(
        self,
        prompt: str,
        max_tokens_to_sample: int = 1024,
        temperature: float = 0.75,  # Lies in range of 0.0 - 1.0
    ):

        completion = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens_to_sample,
            messages=[{"role": "user", "content": prompt}],
            temperature=temperature,
        )

        return AnthropicCompletion(
            id=completion.id,
            completion=completion.content,
            stop_reason=completion.stop_reason,
            tokens=AnthropicTokensUsage(
                prompt_tokens=completion.usage.input_tokens,
                completion_tokens=completion.usage.output_tokens,
                total_tokens=completion.usage.input_tokens
                + completion.usage.output_tokens,
            ),
        )
