import unittest
from lib import anthropic

class TestClaude(unittest.TestCase):
    def test(self):
        claude = anthropic.ApiClient("claude-2.1")
        response = claude.completion("Who is the president of India?", 50, 0.9)
        print(response)

if __name__ == '__main__':
    unittest.main()
