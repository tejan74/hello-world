from typing import Any, TypedDict
import config
from apify_client import ApifyClient
from apify_shared.consts import WebhookEventType


class WebhookTypeWithoutPayload(TypedDict):
    event_types: list[WebhookEventType]
    request_url: str


class WebhookTypeWithPayload(WebhookTypeWithoutPayload):
    payload_template: str


class ApiClient:
    def __init__(self, key: str | None = None):
        self.key = key or config.get_parameter("APIFY_API_KEY")
        if self.key is None:
            raise ValueError(
                "APIFY_API_KEY environment variable must be set or key must be provided"
            )

        self.client = ApifyClient(token=self.key)

    def start_actor(
        self,
        actor_id: str,
        run_input: Any = None,
        memory_mbytes: int | None = None,
        timeout_secs: int | None = None,
        build: str | None = None,
        webhooks: list[WebhookTypeWithPayload | WebhookTypeWithoutPayload] | None = None,
    ):
        actor_client = self.client.actor(actor_id=actor_id)
        run = actor_client.start(
            run_input=run_input,
            memory_mbytes=memory_mbytes,
            timeout_secs=timeout_secs,
            build=build,
            webhooks=webhooks # type: ignore
        )
        return run

    def list_items(self, run_id: str):
        dataset_client = self.client.run(run_id=run_id).dataset()
        items = dataset_client.list_items()
        return items
