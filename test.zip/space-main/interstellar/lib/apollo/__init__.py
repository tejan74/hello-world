import pydash
import requests
import uuid
import time
import json
import config

from lib.cache import CacheInterface
from typing import List, Optional
from lib.apollo._classes import PersonEnrichWebhookRevealPhoneNumbers, PersonEnrichPhoneNumber, CompanySearchCriteria
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

class ApolloException(Exception):
    def __init__(self, status_code, *args: object) -> None:
        super().__init__(f"Error response, status code: {status_code}",*args)
        self.status_code = status_code

class ApiClient:
    BASE_URL = "https://api.apollo.io"

    ORBITAL_WEBHOOK_BASE_URL = "REPLACE_ME_WITH_CLOUD_RUN_URL"

    def __init__(self, key: Optional[str] = None, cache: CacheInterface | None = None) -> None:
        # Accept overwritten key for client or use default
        self._key = key or config.get_parameter("APOLLO_API_KEY")

        # Base headers required for every call
        self.headers = {
            "Content-Type": "application/json",
            "Cache-Control": "no-cache",
            "X-Api-Key": self._key
        }

        # TODO(ani): don't make this optional 
        self.cache = cache if cache else CacheInterface()   

    # API calls
    def bulk_organization_enrichment(self, domains: list[str]):
        """Enrich multiple organization at once"""

        # Validations
        if not domains or len(domains) == 0:
            raise ValueError("domains param is required for bulk organization enrichment")

        # Required body
        data = {"domains": domains}

        [body, res] = self._post(path = "/api/v1/organizations/bulk_enrich", json = data)

        return body

    def organization_enrichment(self, domain: str):
        if not domain:
            raise ValueError("domain param is required for organization enrichment")

        """Enrich single organization"""
        [body, res] = self._get(f"/v1/organizations/enrich?domain={domain}")

        return body

    def person_enrichment(self, linkedin: str, reveal_personal_email: bool | None = False, reveal_personal_phone: bool | None = None):
        """Enrich single person"""
       # validations
        if not linkedin:
            raise ValueError("linkedin param is required for person enrichment")

        # For any required webhooks, we generate a UUID up front
        orbital_webhook_id = "phone-reveal-" + str(uuid.uuid4())

        # Required query params
        json_body = {
            "linkedin_url": linkedin, 
            "reveal_personal_emails": reveal_personal_email, 
            "reveal_phone_number": reveal_personal_phone,
            "webhook_url": self.ORBITAL_WEBHOOK_BASE_URL + f"/webhooks/person_enrich_reveal_phone/{orbital_webhook_id}" if reveal_personal_phone else None
        }
        
        # Send out request
        [body,res] = self._post("/v1/people/match", json = json_body)
        
        # Apollo returns empty response if there is an issue in the request
        if pydash.get(body, "person.linkedin_url", None) is None:
            raise ApolloException(400, "Bad Request")

        if reveal_personal_phone: 
            # Setup initial state for waiting until webhook response is tracked
            loop = 0
            phone_numbers: List[PersonEnrichPhoneNumber] = self.cache.get(orbital_webhook_id)

            # Loop while refreshing phone numbers from cache for up to 60 seconds,
            # note that empty phone number array as a response means we'll continue
            while phone_numbers is None and loop <= 15:
                logger.info("Response not received yet, waiting for 10 seconds...")
                time.sleep(10)
                loop += 1
                cache_data = self.cache.get(orbital_webhook_id)
                if cache_data:
                    # convert string to object
                    cache_data = PersonEnrichWebhookRevealPhoneNumbers(**json.loads(cache_data))

                    # Check if webhook failed
                    if cache_data.status == "failed":
                        logger.error(f"Webhook failed for {orbital_webhook_id}")
                    # Check if webhook succeeded
                    if cache_data.people and len(cache_data.people) > 0:
                        logger.info(f"Got webhook response for id {orbital_webhook_id}")
                        phone_numbers = cache_data.people[0].phone_numbers
                    else:
                        logger.error(f"Webhook response is empty for {orbital_webhook_id}")
                    break
                
            # Add phone numbers to body
            if phone_numbers:
                body["phone_numbers"] = phone_numbers

        return body

    def get_companies_list(
        self,
        companies_search_criteria: CompanySearchCriteria | None
    ):
        """Get all companies list based on search criteria
        Please refer below documentation for more details
        https://apolloio.github.io/apollo-api-docs/?shell#organization-search
        """
        search_criteria_payload = {}
        if companies_search_criteria is not None:
            search_criteria_payload = {
                "page": companies_search_criteria.page_number,
                "per_page": companies_search_criteria.page_size,
                "organization_num_employees_ranges": companies_search_criteria.company_employees_number_ranges,
                "organization_locations": companies_search_criteria.company_locations,
                "q_organization_keyword_tags": companies_search_criteria.company_keyword_tags,
                "q_organization_name": companies_search_criteria.company_name
            }
       
        [body, res] = self._post(f"/v1/mixed_companies/search", json=search_criteria_payload)

        return body
    
    # internal get method
    # injects api key in the request
    def _get(self, path: str, **kwargs):
        return self._request("GET", path, **kwargs)
    
    # internal post method
    # injects api key in the request
    def _post(self, path: str, **kwargs):
        return self._request("POST", path, **kwargs)

    def _request(self, type:str, path:str, **kwargs):
        response = requests.request(type, self.BASE_URL + path, headers = self.headers, **kwargs)

        # accept only 2xx status codes
        if response.status_code >= 200 and response.status_code < 300:
            return [response.json(), response]
        else:
            raise ApolloException(response.status_code, response.content)
