import pydantic

from typing import List, Annotated, Optional


class PersonEnrichPhoneNumber(pydantic.BaseModel):
    raw_number: Optional[str]
    sanitized_number: Optional[str]
    type_cd: Optional[str]
    position: Optional[int]
    status_cd: Optional[str]
    dnc_status_cd: Optional[str]
    dnc_other_info: Optional[str]


class PersonEnrichPhoneNumbers(pydantic.BaseModel):
    id: str
    status: str
    phone_numbers: List[PersonEnrichPhoneNumber]


class PersonEnrichWebhookRevealPhoneNumbers(pydantic.BaseModel):
    status: str
    total_requested_enrichments: int
    unique_enriched_records: int
    missing_records: int
    credits_consumed: int
    people: List[PersonEnrichPhoneNumbers]


""" Companies search criteria
        :param company_locations: Locations of the company headquarters to fetch. Eg. ["New York, US", "California, US"]
        :param company_name: Name of the company to fetch.
        :param page_number: Page number of the search result.
        :param page_size: Number of companies per page.
        :param company_employees_number_ranges: A list of employees ranges Eg. ["1,100", "1,1000"].
        :param company_keyword_tags: Locations of the companies to fetch. Eg.["sales strategy", "lead"] """


class CompanySearchCriteria(pydantic.BaseModel):
    company_locations: list[str] | None = None
    company_name: str | None = None
    page_number: int | None = None
    page_size: int | None = None
    company_employees_number_ranges: list[str] | None = None
    company_keyword_tags: list[str] | None = None
