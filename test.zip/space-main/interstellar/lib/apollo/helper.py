from typing import Any
from lib.cache import db as CacheDb
from util import db
import config

# TODO (ani): make a better caching thingy x2
class ApolloDbCache(CacheDb.Client):
    _type = "APOLLO"
    _ttl = 12 * 30 * 24 * 60 * 60  # ~12 months

    def __init__(self):
        super().__init__(db.get_db_connection(config.get_parameter("TOOLS_DB_URL")))

    def get(self, key: str):
        return super().get(self._type, key)

    def add(self, key: str, data: Any):
        super().add(self._type, key, data, self._ttl)
