import unittest
import json

from lib.apollo.helper import ApolloDbCache
from lib.apollo import ApiClient
from lib import apollo 

class Test(unittest.TestCase):
    def test_person_enrich(self):
        client = ApiClient(cache=ApolloDbCache())
        data = client.person_enrichment("https://www.linkedin.com/in/ever-loyal/", reveal_personal_email = True, reveal_personal_phone = True)
        print(data)

    def test_get_companies_list(self):
        client = apollo.ApiClient()
        data = client.get_companies_list(None)
        print(json.dumps(data))

if __name__ == "__main__":
    unittest.main() 
