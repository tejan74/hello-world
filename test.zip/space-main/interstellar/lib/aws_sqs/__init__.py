import time
import boto3
from botocore.exceptions import ClientError


class SQSDeleteMessageException(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)


class SQSClient:
    def __init__(self, queue_url, region_name):
        self.sqs = boto3.client(
            "sqs",
            region_name=region_name,
        )
        self.queue_url = queue_url

    def send_message(
        self,
        message_body,
        group_id: str,
        deduplication_id: str | None = None,
        queue_url: str | None = None,
        delay_seconds: int = 0,
    ):

        queue_url = queue_url or self.queue_url

        try:
            if queue_url and queue_url.endswith(".fifo"):
                response = self.sqs.send_message(
                    QueueUrl=queue_url,
                    MessageBody=message_body,
                    MessageGroupId=group_id,
                    MessageDeduplicationId=deduplication_id,
                )
            else:
                response = self.sqs.send_message(
                    QueueUrl=queue_url or self.queue_url,
                    MessageBody=message_body,
                    DelaySeconds=delay_seconds,
                )
            return response["MessageId"]
        except ClientError as e:
            raise Exception(f"Error sending message: {e}")

    def receive_messages(
        self, max_messages=1, wait_time_seconds=20, visibility_timeout=30
    ):
        try:
            response = self.sqs.receive_message(
                QueueUrl=self.queue_url,
                MaxNumberOfMessages=max_messages,
                WaitTimeSeconds=wait_time_seconds,
                VisibilityTimeout=visibility_timeout,
            )
            messages = response.get("Messages", [])
            return messages
        except ClientError as e:
            raise Exception(f"Error receiving messages: {e}")

    def delete_message(self, receipt_handle):
        try:
            self.sqs.delete_message(
                QueueUrl=self.queue_url, ReceiptHandle=receipt_handle
            )
        except Exception as e:
            raise SQSDeleteMessageException(f"Error deleting message: {e}")

    def change_message_visibility(self, receipt_handle, visibility_timeout):
        self.sqs.change_message_visibility(
            QueueUrl=self.queue_url,
            ReceiptHandle=receipt_handle,
            VisibilityTimeout=visibility_timeout,
        )
