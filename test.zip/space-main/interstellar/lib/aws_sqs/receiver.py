import abc
import time

import config
from lib.aws_sqs import SQSClient, SQSDeleteMessageException
from util.exception import RetryableException
import util.logger

logger = util.logger.interstellar_logger(__name__)


class SQSReceiver(abc.ABC):
    def __init__(self, queue_url, **kwargs):
        self.queue_url = queue_url
        self.dead_letter_queue_url = kwargs.get("dead_letter_queue_url", None)

        if not queue_url:
            raise ValueError("queue_url is required")

        aws_region = config.get_parameter("AWS_REGION")

        self._client = SQSClient(
            queue_url=queue_url,
            region_name=aws_region,
        )

        # TODO: We should fetch this from the SQS attributes: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sqs/client/get_queue_attributes.html
        if self.dead_letter_queue_url:
            self._dead_letter_queue_client = SQSClient(
                queue_url=self.dead_letter_queue_url,
                region_name=aws_region,
            )

        self._receive_message_wait_time = kwargs.get("receive_message_wait_time", 20)
        self._batch_size_to_fetch = kwargs.get("batch_size_to_fetch", 1)
        self._visibility_timeout = kwargs.get("visibility_timeout", 30)
        self._retry_wait_time = kwargs.get("retry_wait_time", 5)

    @abc.abstractmethod
    def process_message(self, message):
        pass

    def _receive(self):
        while True:
            messages = self._client.receive_messages(
                self._batch_size_to_fetch,
                self._receive_message_wait_time,
                self._visibility_timeout,
            )

            logger.info(f"Received {len(messages)} messages")

            for message in messages:
                logger.info(f"Extracting message to process: {message}")
                message_body = message.get("Body")
                message_receipt_handle = message.get("ReceiptHandle")
                message_id = message.get("MessageId")
                status = "running"

                try:
                    logger.info(f"Processing message handler: {message_id}")

                    # Cases to handle after processing message:
                    # 1. Message processed successfully
                    # 2. Message processing failed
                    # 3. Message processing failed but retryable
                    # 4. Unknown state occurred
                    # 5. TODO: Message still processing, but visibility timeout expired in SQS
                    self.process_message(message_body)

                    logger.info(f"Message {message_id} processed successfully")
                    status = "success"
                except RetryableException as e:
                    logger.error(f"Retryable error processing message {message_id}")
                    status = "retryable_error"
                except Exception as e:
                    logger.error(f"Failed to process so deleting message {message_id}")
                    status = "error"

                # Post process
                try:
                    if status == "error":
                        # Write to dead letter queue
                        self._send_to_dead_letter_queue(message_body)
                        self._client.delete_message(message_receipt_handle)
                    elif status == "retryable_error":
                        self._client.change_message_visibility(
                            message_receipt_handle, self._retry_wait_time
                        )
                    elif status == "success":
                        self._client.delete_message(message_receipt_handle)
                    else:
                        logger.info(
                            f"Message {message_id} has unknown status {status}, this should not happen"
                        )
                except SQSDeleteMessageException as e:
                    logger.error(f"Failed to process so deleting message {message_id}")
                    self._send_to_dead_letter_queue(message_body)
                except Exception as e:
                    logger.error(f"Failed to post process message {message_id}")
                    self._send_to_dead_letter_queue(message_body)

    def _send_to_dead_letter_queue(self, message):
        if self.dead_letter_queue_url:
            logger.info(f"Writing message {message} to dead letter queue")
            self._dead_letter_queue_client.send_message(message, f"dlq-{time.time()}")
        else:
            logger.info("No dead letter queue specified, ignoring")

    def start(self):
        logger.info("Starting SQS Listener")
        self._receive()
