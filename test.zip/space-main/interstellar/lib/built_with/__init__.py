from typing import Any
from util.logger import interstellar_logger
import pydash
import requests
import config

logger = interstellar_logger(__name__)


class ApiClient:
    def __init__(self, key: str | None = None) -> None:
        self.api_key = key or config.get_parameter("BUILT_WITH_API_KEY")
        self.base_url = "https://api.builtwith.com"
        self.base_params = {"KEY": self.api_key}

    def _make_request(self, url: str, params: dict[str, Any] | None = None):
        response = requests.get(url=url, params=params)
        credits_used = pydash.get(response.headers, "X-API-CREDITS-USED")
        credits_remaining = pydash.get(response.headers, "X-API-CREDITS-REMAINING")
        total_credits = pydash.get(response.headers, "X-API-CREDITS-AVAILABLE")
        logger.info(
            f'BuiltWith Credits Usage: "credits_used": {credits_used}, "credits_remaining": {credits_remaining}, "total_credits": {total_credits}'
        )
        return response

    def get_technologies(self, domain: str, only_live: bool = True):
        # live_only: Get technologies that built with considers to be live in the current market and is not obsoleted Refer: https://api.builtwith.com/domain-api
        url = f"{self.base_url}/v21/api.json"
        params = {**self.base_params, "LOOKUP": domain}
        if only_live:
            params["LIVEONLY"] = "yes"

        return self._make_request(url=url, params=params)

    def get_companies(
        self,
        technology: str,
        country_code: str | None = None,
        since: str | None = None,
        get_historical: bool = True,
        offset: str | None = None,
    ):
        # Refer: https://api.builtwith.com/lists-api
        url = f"{self.base_url}/lists11/api.json"
        params = {
            **self.base_params,
            "TECH": technology,
            "META": "yes",
        }
        if country_code:
            params["COUNTRY"] = country_code
        if offset:
            params["OFFSET"] = offset
        if since:
            params["SINCE"] = since
        if get_historical and (not since):
            params["ALL"] = "yes"

        return self._make_request(url=url, params=params)
