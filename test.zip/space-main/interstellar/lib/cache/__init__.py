from lib.cache._classes import CacheInterface
