from typing import Any

class CacheInterface:
    def add(self, key: str, data: Any) -> None:
        pass
    def get(self, key: str) -> Any:
        pass
