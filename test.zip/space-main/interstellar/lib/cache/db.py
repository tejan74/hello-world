import datetime
import json
from typing import Any, Optional

from psycopg2._psycopg import connection

from lib.cache._classes import CacheInterface
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Client(CacheInterface):
    def __init__(self, conn: connection):
        self.conn = conn

    def add(self, type: str, key: str, data: Any, ttl: Optional[int] = None):
        try:
            jdata = json.dumps(data)
            with self.conn:
                with self.conn.cursor() as cur:
                    cur.execute(
                        'DELETE from "Cache" where type=%s and key=%s', (type, key)
                    )
                    if ttl:
                        cur.execute(
                            'INSERT INTO "Cache" (type,key,data,ttl,"updatedAt") values (%s,%s,%s,%s,%s)',
                            (
                                type,
                                key,
                                jdata,
                                ttl,
                                datetime.datetime.now().strftime(
                                    "%Y-%m-%d %H:%M:%S.%f"
                                ),
                            ),
                        )
                    else:
                        cur.execute(
                            'INSERT INTO "Cache" (type,key,data,"updatedAt") values (%s,%s,%s,now())',
                            (
                                type,
                                key,
                                jdata
                            ),
                        )
        except BaseException as e:
            logger.exception("CACHE ERROR", e)

    def get(self, type: str, key: str, force: bool = False):
        try:
            with self.conn:
                with self.conn.cursor() as cur:
                    cur.execute(
                        'SELECT data,"createdAt",ttl from "Cache" where type=%s and key=%s order by "createdAt" desc limit 1',
                        (type, key),
                    )
                    result = cur.fetchone()
                    if result:
                        if force or (
                            (result[1] + datetime.timedelta(0, result[2]))
                            >= datetime.datetime.now()
                        ):
                            logger.debug("Cache hit '%s'", key)
                            return result[0]
                    else:
                        logger.debug("Cache miss '%s'", key)
        except BaseException as e:
            logger.exception("CACHE ERROR", e)
        return None


"""
Cache table should be compatable with this table on INSERT, DELETE & SELECT operation
Language psql
CREATE TABLE "Cache" (
    type text NOT NULL
    key text NOT NULL,
    data jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ttl integer NOT NULL DEFAULT 86400,
);
"""
