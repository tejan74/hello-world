from typing import Any
import requests
import config
from util.request import BaseRequest


class ApiClient(BaseRequest):
    def __init__(self, api_key: str | None = None) -> None:
        self.api_key = api_key or config.get_parameter("CLEARBIT_API_KEY")
        self._auth_header = {"Authorization": f"Bearer {self.api_key}"}
        super().__init__(base_headers=self._auth_header)

    def enrich_person_using_email(self, email: str):
        url = "https://person.clearbit.com/v2/combined/find"
        params = {"email": email}

        return super().request(url=url, params=params)

    def enrich_company_using_domain(self, domain: str):
        url = "https://company.clearbit.com/v2/companies/find"
        params = {"domain": domain}

        return super().request(url=url, params=params)

    def enrich_person_and_company_using_email(self, email: str):
        url = "https://person.clearbit.com/v2/combined/find"
        params = {"email": email}

        return super().request(url=url, params=params)

    def get_company_domain_using_name(self, name: str):
        url = "https://company.clearbit.com/v1/domains/find"
        params = {"name": name}

        return super().request(url=url, params=params)

    def get_company_suggestions_using_name(self, name: str):
        url = "https://autocomplete.clearbit.com/v1/companies/suggest"
        params = {"query": name}

        return super().request(url=url, params=params)

    def discover_companies(
        self,
        query: str,
        page: int | None = None,
        page_size: int | None = None,
        limit: int | None = None,
        sort: str | None = None,
    ):
        url = "https://discovery.clearbit.com/v1/companies/search"
        params: dict[str, Any] = {"query": query}
        optional_params = {
            "page": page,
            "page_size": page_size,
            "limit": limit,
            "sort": sort,
        }
        params.update({k: v for k, v in optional_params.items() if v is not None})

        return super().request(url=url, params=params)

    def get_leads_for_company(
        self,
        domain: str,
        roles: list[str] | None = None,
        seniorities: list[str] | None = None,
        titles: list[str] | None = None,
        cities: list[str] | None = None,
        states: list[str] | None = None,
        countries: list[str] | None = None,
        page: int | None = None,
        page_size: int | None = None,
        suppression: str | None = None,
    ):
        url = "https://prospector.clearbit.com/v1/people/search"
        params: dict[str, Any] = {"domain": domain}

        # This is to match how clearbit takes multiple inputs. Example: if we want to give engineer, data analyst
        # We cannot do the above like roles[] = [engineer, data analyst] or engineer, data analyst
        # We have to do roles[] = 'engineer' and roles[] = 'data analyst'
        # Api example: https://prospector.clearbit.com/v1/people/search?domain=google.com&roles[]=communications&roles[]=customer_service
        def extend_params(key: str, values: list[str] | None = None):
            if values:
                params.update({f"{key}[]": value for value in values})

        # Adding optional parameters
        extend_params("roles", roles)
        extend_params("seniorities", seniorities)
        extend_params("titles", titles)
        extend_params("cities", cities)
        extend_params("states", states)
        extend_params("countries", countries)

        optional_params = {
            "page": page,
            "page_size": page_size,
            "suppression": suppression,
        }
        params.update({k: v for k, v in optional_params.items() if v is not None})

        return super().request(url=url, params=params)
