import requests
from pydash import is_none, omit_by
from typing import Any, List, Dict, Optional, Tuple, TypedDict

from lib.cache import CacheInterface
import config
from util import regex

from lib.coresignal._classes import (
    CoreSignalException,
    CoreSignalMaxQueryCountExceedException,
)
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class SubscriptionResponseType(TypedDict):
    subscription_id: str


class ApiClient:
    DEFAULT_BASE_URL = "https://api.coresignal.com/cdapi"
    MAX_PAGE_SIZE = 1000

    def __init__(
        self, token: Optional[str] = None, cache: CacheInterface | None = None
    ) -> None:
        self.token = token or config.get_parameter("CORESIGNAL_API_KEY")

        self._credits_remaining = 100_000

        self._auth_header = {"Authorization": f"Bearer {self.token}"}

        self.cache = cache if cache else CacheInterface()

    def search_members_es(self, query: dict) -> Tuple[List[int], int]:
        [body, res] = self._post("/v1/linkedin/member/search/es_dsl", json=query)
        return (body, int(res.headers.get("x-total-results")))

    def subscribe_members_es(
        self, query: dict, webhook_url: str
    ) -> SubscriptionResponseType:
        data = {"webhook_url": webhook_url, "es_dsl_query": query}
        [body, _] = self._post("/v1/subscriptions/linkedin/member/es_dsl", json=data)
        return body

    # TOOD (ani): add shortcode dereference from linkedin url
    def get_company_by_linkedin(self, linkedin_url: str) -> Dict[str, Any]:
        shortcode = regex.extract_linkedin_shortcode(linkedin_url)
        if shortcode is None:
            return {}

        return self.get_company_by_id(shortcode)

    def get_member_by_id(self, id: int | str) -> Dict[str, Any]:
        body = self._get(f"/v1/linkedin/member/collect/{id}")
        return body

    def get_company_by_id(self, id: int | str) -> Dict[str, Any]:
        body = self._get(f"/v1/linkedin/company/collect/{id}")
        return body

    def search_company_filter(
        self,
        website: str | None = None,
        name: str | None = None,
        country: str | None = None,
    ):
        filters = omit_by(
            {
                "website": website,
                "name": name,
                "country": country,
            },
            is_none,
        )
        [body, response] = self._post(
            "/v1/linkedin/company/search/filter", json=filters
        )
        return (body, int(response.headers.get("x-total-results")))

    def _post(self, url, **kwargs):
        return self._request("post", url, **kwargs)

    def _get(self, url, ignore_cache=False, **kwargs):
        cache_key = url.lstrip("/").replace("/", ":")

        body = None

        if not ignore_cache:
            body = self.cache.get(cache_key)

        if not body:
            [body, _] = self._request("get", url, **kwargs)
            self.cache.add(cache_key, body)

        return body

    def _request(self, type: str, url: str, **kwargs):
        response = requests.request(
            type, self.DEFAULT_BASE_URL + url, headers=self._auth_header, **kwargs
        )

        if response.headers.get("x-credits-remaining"):
            self._credits_remaining = response.headers.get("x-credits-remaining")
            logger.info(f"CoreSignal Credits Remaining: {self._credits_remaining}")

        if response.status_code == 200:
            return [response.json(), response]
        else:
            raise CoreSignalException(
                f"Error response, status code: {response.status_code} ",
                response.content,
            )
