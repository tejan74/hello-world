
class CoreSignalException(Exception):
    def __init__(self, status_code, *args: object) -> None:
        super().__init__(f"Error response, status code: {status_code}",*args)
        self.status_code = status_code

class CoreSignalMaxQueryCountExceedException(Exception):
    def __init__(self, *args: object) -> None:
        super().__init__(*args)
