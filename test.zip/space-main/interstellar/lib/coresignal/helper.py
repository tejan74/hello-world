import json
import math
import re
from typing import Any, Callable, Dict, Iterable, List, Optional, Set
from more_itertools import divide, partition
from lib.cache import db as CacheDb
import config
from lib.coresignal.constant import SupportedCountries
from util.db import get_db_connection
import pydash
from lib.coresignal._classes import CoreSignalMaxQueryCountExceedException
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

# TODO (ankith): let's figure out the cache changes in the new
class CoreSignalDBCache(CacheDb.Client):
    _type = "CORE_SIGNAL"
    _ttl = 6 * 30 * 24 * 60 * 60  # ~6 months

    def __init__(self):
        super().__init__(get_db_connection(config.get_parameter("TOOLS_DB_URL")))

    def get(self, key: str):
        return super().get(self._type, key)

    def add(self, key: str, data: Any):
        super().add(self._type, key, data, self._ttl)


def build_coresignal_search_query(
    company: Dict[str, str],
    locations: Optional[List[Dict[str, str]]] = None,
    countries: Optional[Set[SupportedCountries]] = None,
    required_titles: Optional[List[str]] = None,
    optional_titles: Optional[List[str]] = None,
    titles_weight: Optional[List[Dict[str, str | int]]] = None,
    filter_titles: Optional[List[str]] = None,
):
    location_queries = []

    if locations and len(locations) > 0:
        loc_any, loc_both = partition(lambda x: x["state"] and x["city"], locations)

        for loc in loc_any:
            if loc["state"] or loc["city"]:
                location_queries.append(
                    location_match_query_frag(loc["state"] or loc["city"]),
                )

        for state, sub_locations in pydash.group_by(loc_both, lambda x: x["state"]).items():
            if len(sub_locations) == 1:
                query = {
                    "bool": {
                        "must": [
                            location_match_query_frag(sub_locations[0]["city"]),
                            location_match_query_frag(sub_locations[0]["state"]),
                        ]
                    }
                }
            else:
                query = {
                    "bool": {
                        "must": [
                            location_match_query_frag(state),
                            {
                                "bool": {
                                    "should": [
                                        location_match_query_frag(y["city"])
                                        for y in sub_locations
                                    ]
                                }
                            },
                        ]
                    }
                }
            location_queries.append(query)

    country_query = []
    if countries and len(countries) > 0:
        country_query = [{"terms": {"country": list(countries)}}]

    required_title_query = []
    if required_titles and len(required_titles) > 0:
        required_title_query = list(map(title_match_query_frag, required_titles))

    optional_title_query = []
    if optional_titles and len(optional_titles) > 0:
        cleaned_optional_titles = [
        f'"{x}"~0' if " " in x else x
        for x in map(sanitize_query_string, optional_titles)
    ]
        optional_title_query = [
            {
                "query_string": {
                    "query": " OR ".join(cleaned_optional_titles),
                    "fields": ["member_experience_collection.title"],
                    "default_operator": "AND",
                }
            }
        ]

    title_weight_query = []
    if titles_weight and len(titles_weight) > 0:
        title_weight_query = [
            {
                "bool": {
                    "should": [
                        {"match_all": {}},
                        {
                            "query_string": {
                                "query": " OR ".join(
                                    map(
                                        lambda x: f'"{sanitize_query_string(str(x["text"]))}"^{x["weight"]}',
                                        titles_weight,
                                    )
                                ),
                                "fields": ["member_experience_collection.title"],
                                "default_operator": "AND",
                            }
                        },
                    ]
                }
            }
        ]

    filter_titles_query = []
    if filter_titles and len(filter_titles) > 0:
        filter_titles_query = [
            {
                "query_string": {
                    "query": "NOT("
                    + " OR ".join(
                        map(lambda x: f"({sanitize_query_string(x)})", filter_titles)
                    )
                    + ")",
                    "default_field": "member_experience_collection.title",
                    "default_operator": "AND",
                }
            }
        ]

    company_query = {
        "nested": {
            "path": "member_experience_collection",
            "query": {
                "bool": {
                    "must": [
                        {
                            "term": {
                                "member_experience_collection.company_id": company[
                                    "id"
                                ],
                            }
                        },
                        {
                            "term": {
                                "member_experience_collection.date_to": "1000",  # data_to empty i.e still working there
                            }
                        },
                        *required_title_query,
                        *optional_title_query,
                        *title_weight_query,
                    ],
                    "filter": [
                        {
                            "term": {
                                "member_experience_collection.deleted": 0,  # only experience that isn't deleted
                            },
                        },
                        *filter_titles_query,
                    ],
                }
            },
        }
    }

    fullQuery = {
        "query": {
            "bool": {
                "must": [
                    *(
                        [
                            {
                                "bool": {
                                    "should": location_queries,
                                }
                            }
                        ]
                        if len(location_queries) > 0
                        else []
                    ),
                    *country_query,
                    company_query,
                ]
            },
        },
        "sort": ["_score"],
    }

    logger.debug("Full Query %s", fullQuery)

    return fullQuery

def title_match_query_frag(text: str, weight: Optional[str] = None):
    q = {
        "match": {
            "member_experience_collection.title": {
                "query": text,
                "operator": "and",  # allow no match with partial input title
            }
        }
    }

    if weight:
        q["match"]["member_experience_collection.title"]["boost"] = weight

    return q

def location_match_query_frag(text: str):
    return {
        "match": {
            "location": {
                "query": text,
                "operator": "and",  # allow no match with partial input title
            }
        }
    }

def sanitize_query_string(text: str):
    # TODO escape these instead of replace
    return re.sub(
        re.compile(r'(\+|-|=|&&|\|\||>|<|!|\(|\)|\{|\}|\[|\]|\^|"|~|\*|\?|:|\\|/)'),
        "",
        text,
    ).strip()

def split_query_if_long(
    list_param: Iterable[Dict[str, str]], query_builder: Callable[[Iterable[Dict[str, str]]], Dict[str, Any]]
):
    max_query_size = 15000 - 100  # 1500 is the limit 100 is for safety
    max_query_count = 5
    _query = query_builder(list_param)
    query_length = len(json.dumps(_query))
    n = math.ceil(query_length / max_query_size)
    logger.debug("Query length %s", query_length)
    logger.debug("Initial Split count %s", n)

    queries = [_query]
    highest_length = query_length
    sub_query_lengths = []
    while highest_length > max_query_size:
        queries = []
        for list_param_batch in divide(n, list_param):
            lpb = list(list_param_batch)
            if len(lpb) < 0:
                break
            queries.append(query_builder(lpb))
        sub_query_lengths = list(map(lambda q: len(json.dumps(q)), queries))
        highest_length = max(sub_query_lengths)
        n += 1
        if n > 5:
            raise CoreSignalMaxQueryCountExceedException(
                f"Max query count ({max_query_count}) exceeded"
            )

    if len(queries) > 1:
        logger.debug("Final Split count %s", n)
        logger.debug("Splited querys length %s", sub_query_lengths)

    return queries

def surface_leads_current_exp(lead, company_id):
    sorted_exp = pydash.sort(
        pydash.filter_(
            pydash.get(lead, "member_experience_collection"),
            lambda x: not pydash.get(x, "date_to")
            and pydash.get(x, "deleted") == 0
            and pydash.get(x, "company_id") == company_id,
        ),
        lambda a, b: compare_date(pydash.get(b, "date_from"), pydash.get(a, "date_from")),
    )
    lead["current_experience"] = pydash.get(sorted_exp, 0)


def compare_date(a, b):
    return date_to_num(a) - date_to_num(b)


def date_to_num(a):
    if type(a) == type("s") and a:
        match = re.search(
            r"(January|February|March|April|May|June|July|August|September|October|November|December)? ?(\d+)",
            a,
        )

        if match is None:
            return 0
        month, year = match.groups()
        return int(year if year else 0) + CORESIGNAL_MONTHS.index(month) if month else 0
    else:
        return 0


CORESIGNAL_MONTHS = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
]
