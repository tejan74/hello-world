import unittest
import util.regex
from unittest.mock import Mock
from . import CacheInterface, ApiClient

class TestCoreSignal(unittest.TestCase):
    def test_get_linkedin_shortcode(self):
        shortcode = util.regex.extract_linkedin_shortcode("https://www.linkedin.com/company/merck")
        self.assertEqual(shortcode,"merck")
        
    def test_get_company_by_linkedin(self):
        cmock = self._get_cache_mock()
        cs = ApiClient(cache = cmock)

        company = cs.get_company_by_linkedin("https://www.linkedin.com/company/merck")
        self.assertEqual(company["name"],"Merck")

        self.assertEqual(len(cmock.method_calls),2)
        company2 = cs.get_company_by_linkedin("https://www.linkedin.com/company/merck")
        self.assertEqual(company2["name"],"Merck")
        self.assertEqual(len(cmock.method_calls),3)

    def test_search_members_es(self):
        cs = ApiClient()
        q = {
            "query":{
                "match": {
                    "id": 419151816
                }
            }
        }
        members = cs.search_members_es(q)
        self.assertTupleEqual(members,([419151816],1))

    # def test_get_member_by_id(self):
    #     cmock = self._get_cache_mock()
    #     cs = ApiClient(cache = cmock)
    #     member = cs.get_member_by_id(419151816)
    #     self.assertEqual({"first_name":"Adithya"}, {"first_name":"Adithya"} | member)

    #     self.assertEqual(len(cmock.method_calls),2)
    #     member2 = cs.get_member_by_id(419151816)
    #     self.assertEqual({"first_name":"Adithya"}, {"first_name":"Adithya"} | member2)
    #     self.assertEqual(len(cmock.method_calls),3)
    
    def _get_cache_mock(self):
        cache = {}
        def get(key): return cache.get(key)
        def add(key,data): cache[key] = data
        cmock = Mock(CacheInterface)
        cmock.get.side_effect = get
        cmock.add.side_effect = add
        return cmock
        


if __name__ == '__main__':
    unittest.main()
