# config
#     - tenant_id
#     - access_token
#     - refresh_token
#     - object_mapper({company_locations: 'company_loc'}) # per tenant, per custom object
#     - feild_mapper({company: {office_policy: 'hs_cs_office_policy'}}) # per tenant, per object
#     - retry_config

import abc
from enum import Enum
from typing import Dict

import pydantic


class Association(pydantic.BaseModel):
    object_type: str
    object_id: str
    category: str
    type_id: int


class CrmObject(Enum):
    company = "company"
    contact = "contact"
    opportunity = "opportunity"
    company_location = "company_location"


class OAuth(abc.ABC):
    """
    OAuth interface for CRM providers
    """

    @abc.abstractmethod
    def generate_authorization_url(
        self,
        client_id: str,
        redirect_uri: str,
        state: str,
        scopes: list[str] | None = None,
    ) -> str:
        pass

    @abc.abstractmethod
    def get_access_token(
        self, client_id: str, client_secret: str, code: str, redirect_uri: str
    ) -> dict:
        pass


class CRM(abc.ABC):
    """
    Orbital CRM interface for Orbital specific CRM Operations
    """

    @abc.abstractmethod
    def list_company(
        self,
        modified_after: str | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ):
        pass

    @abc.abstractmethod
    def list_contact(
        self,
        modified_after: str | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ):
        """
        List contacts from CRM, with company, opportunity and location associations
        """
        pass

    @abc.abstractmethod
    def list_deal(
        self,
        modified_after: str | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ):
        """
        List opportunities from CRM, with company, contact and location associations
        """
        pass

    @abc.abstractmethod
    def list_company_location(
        self,
        modified_after: str | None = None,
        page_size: int = 100,
        cursor: str | None = None,
    ):
        """
        List company locations from CRM, with company and contact associations
        """
        pass

    @abc.abstractmethod
    def create_company(
        self, object: dict, associations: list[Association] | None = None
    ):
        pass

    @abc.abstractmethod
    def create_opportunity(
        self, object: dict, associations: list[Association] | None = None
    ):
        pass

    # TODO (ani/adi): one of us should split this into two layers, one high-level CRM implementation that is more generic
    # without custom methods to support specific CRM objects that we're creating
    @abc.abstractmethod
    def create_company_location(
        self, object: dict, associations: list[Association] | None = None
    ):
        # This is a custom method that is only available in our CRM implementation because this is not a standard CRM object
        pass

    @abc.abstractmethod
    def create_contact(
        self, object: dict, associations: list[Association] | None = None
    ):
        pass

    @abc.abstractmethod
    def create_association(
        self, source: str, source_id: str, target: str, target_id: str
    ):
        pass

    @abc.abstractmethod
    def delete_association(
        self, source: str, source_id: str, target: str, target_id: str
    ):
        pass

    @abc.abstractmethod
    def update_company(self, object_id: str, object: dict):
        pass

    @abc.abstractmethod
    def update_opportunity(self, object_id: str, object: dict):
        pass

    @abc.abstractmethod
    def update_company_location(self, object_id: str, object: dict):
        # This is a custom method that is only available in our CRM implementation because this is not a standard CRM object
        pass

    @abc.abstractmethod
    def update_contact(self, object_id: str, object: dict):
        pass

    @abc.abstractmethod
    def delete_company(self, id: str):
        pass

    @abc.abstractmethod
    def delete_opportunity(self, id: str):
        pass

    @abc.abstractmethod
    def delete_company_location(self, id: str):
        # This is a custom method that is only available in our CRM implementation because this is not a standard CRM object
        pass

    @abc.abstractmethod
    def delete_contact(self, id: str):
        pass
