from typing import Literal, Optional
from urllib.parse import quote_plus, urlencode
import pydash
import requests

SortType = Literal["asc", "desc"]
SortByType = Literal["planyear"]

class ApiClient:
    BASE_EFAST_URL = "https://www.efast.dol.gov/services/afs"
    DEFAULT_QUERY_PARSER = "lucene"
    
    # Initialize
    def __init__(self, query_parser: Optional[str] = None) -> None:
        # Accept overwritten query parser
        self._query_parser = query_parser or self.DEFAULT_QUERY_PARSER

    def _get_encoded_params(self, plan_sponsor: str, plan_name: str | None, plan_year: int | None, size: int, sort_by: SortByType, sort: SortType):
        # Base param
        params = {
            "q.parser": self._query_parser,
            "size": size,
        }

        # Adding sort param
        if (sort_by and not sort) or (sort and not sort_by):
            raise Exception("Both sort_by and sort needs to be provided. Either add both, or remove both")
        if sort_by and sort:
            params["sort"] = pydash.join([sort_by,sort], " ")

        # Creating query
        plan_sponsor_words = pydash.split(plan_sponsor, " ")
        plan_sponsor_conditions = " AND ".join([f"(plansponsor:'{word}')" for word in plan_sponsor_words])

        plan_name_conditions = None

        if plan_name:
            plan_name_words = pydash.split(plan_name, " ")
            plan_name_conditions = " AND ".join([f"(planname:'{word}')" for word in plan_name_words])

        query = f"({plan_name_conditions}) AND ({plan_sponsor_conditions})" if plan_name_conditions else f"{plan_sponsor_conditions}"
        query = f'({query + (f" AND ((planyear:{plan_year}))" if plan_year else "")})'

        # Adding query param
        params["q"] = query

        # URL-encode the parameters
        # This is for plus (+) encoding which will replace space with + instead of %20. requests.get() by default does %20 encoding
        encoded_params = urlencode(params, quote_via = quote_plus)

        return encoded_params



    # Query for data
    def query(self, plan_sponsor: str, plan_name: str | None = None, plan_year: int | None = None, size: int = 200, sort_by: SortByType = "planyear", sort: SortType = "desc"):
        # Get encoded params
        encoded_params = self._get_encoded_params(plan_sponsor, plan_name, plan_year, size, sort_by, sort)

        # Construct the full URL
        full_url = f"{self.BASE_EFAST_URL}?{encoded_params}"

        # Make the GET request
        res = requests.get(url=full_url)

        return res.json()
