import pydantic
import requests
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class EnrichleyClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.enrichley.io/api/v1"
        self.headers = {
            "X-API-KEY": self.api_key,
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def _post(self, endpoint, payload, headers=None):
        try:
            response = requests.post(
                f"{self.base_url}{endpoint}",
                json=payload,
                headers=headers if headers is not None else self.headers,
            )
            if response.status_code == 200:
                data = response.json()
                return data
            else:
                response.raise_for_status()
                return None
        except (requests.RequestException, pydantic.ValidationError) as e:
            logger.exception(f"Error in Enrichley request: {e}")
            return None

    def validate_single_email(self, email: str):
        """
        It's validates a single email and returns its validation status.
        https://enrichley.readme.io/reference/validatesingleemail

        Args:
        email
        """
        data = self._post(endpoint="/validate-single-email", payload={"email": email})
        return data
