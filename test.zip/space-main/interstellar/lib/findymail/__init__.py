from lib.findymail.types import (
    SearchDomainResponse,
    SearchNameResponse,
    VerifyMailResponse,
)

from lib.http import HttpLib
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class FindymailClient(HttpLib):
    def __init__(self, api_key: str, base_url=None, query_params=None, headers=None):
        self.api_key = api_key
        if base_url is None:
            base_url = "https://app.findymail.com/api"
        if headers is None:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            }
        super().__init__(base_url=base_url, query_params=query_params, headers=headers)

    def verify_email(self, email: str) -> VerifyMailResponse | None:
        """
        Email Verifier: Verify the validity of an email address.
        https://app.findymail.com/docs/#email-verifier-POSTapi-verify

        This endpoint allows you to:
        - Verify if an email address is valid or not.

        email:
        The email address that you want to verify.

        Uses one verifier credit for each attempted verification.

        Returns:
        VerifyMailResponse | None: Returns a `VerifyMailResponse` object containing the verification results if the request is successful, or `None` if the request fails or no data is returned.
        """
        data = self.request(method="POST", path="/verify", json={"email": email})
        return VerifyMailResponse(**data) if data is not None else None

    def search_name(
        self, name: str, domain: str, webhook_url: str | None
    ) -> SearchNameResponse | None:
        """
        Email Finder by Name: Search for email addresses associated with a specific individual by their name and domain.
        https://app.findymail.com/docs/#email-finder-POSTapi-search-name

        This endpoint allows you to:
        - Find email addresses based on the individual's name and their company domain.
        - Optionally, you can provide a webhook URL to receive notifications when the search is completed.

        name:
        The full name of the individual you are searching for.

        domain:
        The domain of the company where the individual works. This helps narrow down the search.

        webhook_url (optional):
        A URL where the system can send asynchronous notifications about the search results. If not provided, notifications will not be sent.

        Returns:
        SearchNameResponse | None: Returns a `SearchNameResponse` object containing the search results if the request is successful, or `None` if the request fails or no data is returned.
        """
        payload = {"name": name, "domain": domain}
        if webhook_url:
            payload["webhook_url"] = webhook_url
        data = self.request(method="POST", path="/search/name", json=payload)
        return SearchNameResponse(**data) if data is not None else None

    def search_domain(
        self, domain: str, roles: list[str], webhook_url: str | None = None
    ) -> SearchDomainResponse | None:
        """
        Domain Search for Contacts: Attempt to find a contact with a valid email address at a specified domain based on provided roles.
        https://app.findymail.com/docs/#email-finder-POSTapi-search-domain

        This endpoint allows you to:
        - Search for a contact with a valid email address at a given domain.
        - Filter the search results based on specific roles or job titles.
        - Optionally, provide a webhook URL to receive notifications when the search is completed.

        domain:
        The domain of the company where you are searching for contacts. The system will try to find a valid email address associated with this domain.

        roles:
        A list of roles or job titles to refine the search. The search results will be filtered to include only those contacts who match one of the specified roles.

        webhook_url (optional):
        A URL where the system can send asynchronous notifications about the search results. If not provided, notifications will not be sent.

        Returns:
        SearchDomainResponse | None: Returns a `SearchDomainResponse` object containing the search results if a valid email is found, or `None` if no valid email is found or if the request fails.
        """
        data = self.request(
            method="POST",
            path="/search/domain",
            json=(
                {"domain": domain, "roles": roles}
                if webhook_url is None
                else {"domain": domain, "roles": roles, "webhook_url": webhook_url}
            ),
        )
        return SearchDomainResponse(**data) if data is not None else None

    def search_linkedIn(
        self, linkedIn_url: str, webhook_url: str | None = None
    ) -> SearchNameResponse | None:
        """
        LinkedIn Profile Search: Retrieve information associated with a LinkedIn profile, including potential email addresses.
        https://app.findymail.com/docs/#email-finder-POSTapi-search-linkedin

        This endpoint allows you to:
        - Search for a LinkedIn profile using its URL.
        - Optionally, provide a webhook URL to receive notifications about the search results.

        linkedIn_url:
        The URL of the LinkedIn profile that you want to search. The system will attempt to retrieve associated information and potential email addresses from this profile.

        webhook_url (optional):
        A URL where the system can send asynchronous notifications about the search results. If not provided, notifications will not be sent.

        Notes:
        - This endpoint is limited to 30 concurrent requests when used synchronously. Ensure you do not exceed this limit to avoid request throttling.

        Returns:
        SearchNameResponse | None: Returns a `SearchNameResponse` object containing the retrieved profile information and potential email addresses if found, or `None` if no relevant data is found or if the request fails.
        """
        data = self.request(
            method="POST",
            path="/search/linkedin",
            json=(
                {"linkedin_url": linkedIn_url}
                if webhook_url is None
                else {"linkedin_url": linkedIn_url, "webhook_url": webhook_url}
            ),
        )
        return SearchNameResponse(**data) if data is not None else None
