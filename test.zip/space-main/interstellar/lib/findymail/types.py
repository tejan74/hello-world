import pydantic


class VerifyMailResponse(pydantic.BaseModel):
    verified: bool | None = None
    email: str | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class Contact(pydantic.BaseModel):
    id: int | None = None
    name: str | None = None
    first_name: str | None = None
    email: str | None = None
    domain: str | None = None
    company: str | None = None
    linkedin_url: str | None = None
    job_title: str | None = None
    company_city: str | None = None
    company_region: str | None = None
    company_country: str | None = None
    city: str | None = None
    region: str | None = None
    country: str | None = None
    phone_number: str | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class SearchNameResponse(pydantic.BaseModel):
    contact: Contact | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class SearchDomainResponse(pydantic.BaseModel):
    contacts: list[Contact] | None = None
    model_config = pydantic.ConfigDict(extra="allow")
