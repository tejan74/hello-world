from typing import Dict, List, Union
from util.db import get_db_connection
import config


class GIS():
    def __init__(self):
        self.db = get_db_connection(config.get_parameter("TOOLS_DB_URL"))

    # given a zip code, return the city and state
    def locations_near_zip(
        self, zip: str, region_code: str, radius: int
    ) -> Union[None, List[Dict[str, str]]]:
        with self.db.cursor() as cur:
            cur.execute(
                """SELECT geo FROM "GEO_ZipCode" where zip ilike %s and "countryCode" ilike %s;""",
                (zip, region_code),
            )
            if cur.rowcount == 0:
                return None
            geo = cur.fetchone()

            if geo is not None:
                geo = geo[0]

            query = """SELECT distinct city,state FROM "GEO_ZipCode" where ST_DWithin(geo, %s::geography, %s) and "countryCode" ilike %s"""
            params = [geo, radius * 1000, region_code]
            cur.execute(query, params)
            result = cur.fetchall()
            return list(map(lambda x: {"city": x[0], "state": x[1]}, result))
        
