from google.cloud import storage

class ApiClient:
    def __init__(self, bucket: str) -> None:
        """
        bucket: Name of the storage bucket
        """
        self.bucket = storage.Client().bucket(bucket)
    
    def list_files(self, prefix: str , include_subdirectories: bool | None = True, glob: str | None = None):
        """
            ref: https://cloud.google.com/python/docs/reference/storage/latest/google.cloud.storage.bucket.Bucket#google_cloud_storage_bucket_Bucket_list_blobs
        """

        # Setting the delimiter will make the list_blobs function return only the files in the directory
        delimiter = None if include_subdirectories else "/"
        blobs = self.bucket.list_blobs(prefix = prefix, delimiter = delimiter, match_glob = glob)

        # Just returning the name of the blobs for now, add more fields if needed
        return [{ "name": blob.name , "metadata": blob.metadata } for blob in blobs]

    def upload_file(self, cloud_path: str, local_path: str, overwrite: bool | None = True):
        # Create blob
        blob = self.bucket.blob(cloud_path)

        # Setting 0 to the generation_match_precondition will make the upload fail if the file already exists
        generation_match_precondition = None if overwrite else 0
        blob.upload_from_filename(local_path, if_generation_match=generation_match_precondition)

        return cloud_path

    def download_file(self, cloud_path: str, local_path: str):
        blob = self.bucket.blob(cloud_path)
        blob.download_to_filename(local_path)
        return local_path

    def delete_file(self, path: str):
        blob = self.bucket.blob(path)
        blob.delete()
        return path
    
    def rename_file(self, cloud_path: str, new_cloud_path: str):
        blob = self.bucket.blob(cloud_path)
        self.bucket.rename_blob(blob,new_cloud_path)
        return new_cloud_path
