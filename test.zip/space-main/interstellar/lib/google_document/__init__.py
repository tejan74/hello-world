from lib.google_document._simple_editor import SimpleGoogleDocEditor, Styles
