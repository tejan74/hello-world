from enum import Enum

import google.auth
from googleapiclient.discovery import build
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Styles(Enum):
    """Style constants to be used for text formatting."""

    BOLD = "+bold"
    ITALIC = "+italic"
    UNDERLINE = "+underline"
    STRIKETHROUGH = "+strikethrough"
    SMALL_CAPS = "+smallCaps"
    NO_BOLD = "-bold"
    NO_ITALIC = "-italic"
    NO_UNDERLINE = "-underline"
    NO_STRIKETHROUGH = "-strikethrough"
    NO_SMALL_CAPS = "-smallCaps"


class SimpleGoogleDocEditor:
    """Class to make simple edits of  google documents using the google docs API.
    Uses googles  Application Default Credentials to authenticate. see: https://cloud.google.com/docs/authentication/application-default-credentials

    HOW TO USE
    -----------
    sde = SimpleGoogleDocEditor("xxx-xxxxxxxx")
    sde.clear_document()
    sde.append_text("Hello, Riley!\n", [Styles.BOLD, Styles.ITALIC])
    sde.append_text("How are", KeepPrevStyle=False)
    sde.append_text(" you?\n", [Styles.UNDERLINE])
    sde.apply()

    Note: requests reference - https://developers.google.com/docs/api/reference/rest/v1/documents/request
    Note: api reference - https://googleapis.github.io/google-api-python-client/docs/dyn/docs_v1.html
    """

    _SCOPES = ["https://www.googleapis.com/auth/documents"]

    def __init__(self, document_id: str) -> None:
        creds, _ = creds, _ = google.auth.default(scopes=self.__class__._SCOPES)
        self._api = build("docs", "v1", credentials=creds).documents()
        self._document_id = document_id

        doc = self._api.get(documentId=self._document_id).execute()
        last_index = doc["body"]["content"][-1]["endIndex"]
        self._cur_index = last_index - 1

        self._pending_requests = []

    def __del__(self):
        self._api.close()

    def clear_document(self):
        """delete all text in the document body.
        Cannot use if there are pending requests."""
        if len(self._pending_requests):
            raise Exception(
                "There are pending requests. Please execute them before clearing the document."
            )

        doc = self._api.get(documentId=self._document_id).execute()
        last_index = doc["body"]["content"][-1]["endIndex"]
        self._api.batchUpdate(
            documentId=self._document_id,
            body={
                "requests": [
                    {
                        # refer: https://developers.google.com/docs/api/reference/rest/v1/documents/request#DeleteContentRangeRequest
                        "deleteContentRange": {
                            "range": {
                                "startIndex": 1,
                                "endIndex": last_index
                                - 1,  # -1 to ignore the last newline (causes error otherwise)
                            }
                        }
                    }
                ]
            },
        ).execute()
        self._cur_index = 1

    def append_text(
        self,
        text: str,
        style: list[Styles] = [],
        keep_prev_style: bool = True,
        link: str | None = None,
    ):
        """Append text at the end of the document body with the specified style.
        param text: The text to append.
        param style: A list of Styles to apply to the text.
        param keep_prev_style: When adding text to google doc it will take the style of the text previous to it.
            it will also merge any style that is applied through the style parameter. So setting this to False will
            disable this behavior and use the default value for all the unset style.
        """
        self._pending_requests.append(
            # append text to the end of body section
            # refer: https://developers.google.com/docs/api/reference/rest/v1/documents/request#InsertTextRequest
            {"insertText": {"text": text, "endOfSegmentLocation": {"segmentId": ""}}}
        )
        if len(style) or not keep_prev_style or link:
            # Style enum has the keys for this dict without the + or - prefix
            # when + turn the style on and when - turn the style off
            text_style: dict = {s.value[1:]: s.value.startswith("+") for s in style}
            if link:
                text_style["link"] = {"url": link}
            # without mask google docs will reset all unset styles to default, so setting mask
            # when we explicitly set style for text. * will set all unset styles to default.
            style_mask = ",".join(text_style.keys()) if keep_prev_style or link else "*"
            self._pending_requests.append(
                {
                    # refer: https://developers.google.com/docs/api/reference/rest/v1/documents/request#UpdateTextStyleRequest
                    "updateTextStyle": {
                        "textStyle": text_style,
                        "fields": style_mask,
                        "range": {
                            "startIndex": self._cur_index,
                            "endIndex": self._cur_index + len(text),
                        },
                    }
                }
            )
        self._cur_index += len(text)

    def apply(self):
        """Execute the pending requests.
        need to call this method to apply the changes to the document.
        """
        if len(self._pending_requests):
            self._api.batchUpdate(
                documentId=self._document_id, body={"requests": self._pending_requests}
            ).execute()
            self._pending_requests = []
        else:
            logger.warning("No pending requests to execute.")

    # ---- Utility methods ----

    @staticmethod
    def create_document(title: str):
        """Create a new document with the specified title.
        return: The document ID of the created document.
        """
        creds, _ = google.auth.default(scopes=SimpleGoogleDocEditor._SCOPES)
        api = build("docs", "v1", credentials=creds).documents()
        doc = api.create(body={"title": title}).execute()
        return doc["documentId"]
