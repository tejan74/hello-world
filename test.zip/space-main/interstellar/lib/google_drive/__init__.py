import google.auth
from googleapiclient.discovery import build


class GoogleDrive:
    """Class to make using the google drive API easier.
    Uses googles  Application Default Credentials to authenticate. see: https://cloud.google.com/docs/authentication/application-default-credentials
    """

    _SCOPES = ["https://www.googleapis.com/auth/drive"]

    def __init__(self):
        creds, _ = google.auth.default(scopes=self.__class__._SCOPES)
        self._api = build("drive", "v3", credentials=creds)

    def __del__(self):
        self._api.close()

    def move_file(self, file_id: str, folder_id: str):
        """Move a file to a different folder in drive.
        Note: need access to both the file and the folder to move the file.
        Note: u can get the file_id and folder_id from the url of the file/folder.
        """
        self._api.files().update(fileId=file_id, addParents=folder_id).execute()

    def copy_file(self, file_id: str, folder_id: str):
        """Copy a file to a different folder in drive.
        Note: need access to both the file and the folder to move the file.
        Note: u can get the file_id and folder_id from the url of the file/folder.
        """
        file = self._api.files().get(fileId=file_id, fields="name").execute()
        copied_file = {"name": file["name"], "parents": [folder_id]}
        return self._api.files().copy(fileId=file_id, body=copied_file).execute()
