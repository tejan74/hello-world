from typing import Optional
import config
import googlemaps

from lib.google_maps._classes import ViewPort
from pydash import filter_
from pydash import merge

import requests
import pydash
import json
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class GoogleMapsException(Exception):
    def __init__(self, status_code, *args: object) -> None:
        super().__init__(f"Error response, status code: {status_code}", *args)
        self.status_code = status_code


class ApiClient:
    def __init__(self, key: str | None = None):
        # Accept overwritten key for client or use default
        self.key = key or config.get_parameter("GOOGLE_SERVICE_API_KEY")

        # Setup Google Maps client using key
        self.client = googlemaps.Client(key=self.key)

    def address_validation(self, address: str, region_code: Optional[str] = "US"):
        return self.client.addressvalidation(address.strip().split("\n"), regionCode=region_code)  # type: ignore

    def geocode(self, address: str):
        return self.client.geocode(address)

    def places_nearby(self, lat: float, lng: float, radius, keyword=None):
        return self.client.places_nearby(
            location=(lat, lng),
            radius=radius,
            keyword=keyword,
        )

    # Finds places based on text query
    # Please refer below documentation for additional details
    # https://developers.google.com/maps/documentation/places/web-service/search-text
    def search_places(
        self,
        text_query: str,
        view_port: ViewPort | None = None,
        latitude: float | None = None,
        longitude: float | None = None,
        radius: float | None = 500.0,
        region_code: str | None = "US",
        rank_preference: str = "RELEVANCE",
        strict_type_filtering: bool = False,
        max_result_count: int = 20,
        field_mask: str = "places.id,places.displayName,places.formattedAddress,places.websiteUri,places.businessStatus,places.types,places.location,places.internationalPhoneNumber,places.nationalPhoneNumber",
        include_permanently_closed: bool | None = False,
    ):
        """
        Google places search.

        :param text_query: A text string on which results will be fetched Eg: "Schools in Austin, Texas".

        :param view_port: A rectangular area of the search location. If this param is passed the search will be restricted to this rectangular area.

        :param latitude: Latitude of the search location. If view port is passed this param will be ignored.

        :param longitude: Longitude of the search location. If view port is passed this param will be ignored.

        :param radius: Distance in meters to provide search results bias. If view port is passed this param will be ignored.

        :param rank_preference: Enables ranking of the search results. Currently supports RELEVANCE, DISTANCE.

        :param max_result_count: The maximum number of results expected as response. Currently maximum of 20 results will be returned.

        :param field_mask: This is a string with all the fields needed in the response. Please refer below documentation for additional information.
        ref: https://developers.google.com/maps/documentation/places/web-service/text-search

        :param include_permanently_closed: Include permanently closed places.

        """

        url = "https://places.googleapis.com/v1/places:searchText"

        request_payload = self._build_search_places_payload(
            text_query,
            view_port,
            latitude,
            longitude,
            radius,
            region_code,
            rank_preference,
            strict_type_filtering,
            max_result_count,
        )

        headers = {
            "Content-Type": "application/json",
            "X-Goog-Api-Key": self.key,
            "X-Goog-FieldMask": field_mask,
        }

        response = self._post(url, request_payload, headers)

        # Get places list
        places_list = pydash.get(response, "places", [])

        if not places_list:
            return []

        if not include_permanently_closed:
            filtered_places = filter_(
                places_list,
                lambda place: pydash.get(place, "businessStatus")
                != "CLOSED_PERMANENTLY",
            )
            return filtered_places
        else:
            return places_list


    def _build_search_places_payload(
        self,
        text_query,
        view_port,
        latitude,
        longitude,
        radius,
        region_code,
        rank_preference,
        strict_type_filtering,
        max_result_count,
    ):
        request_payload = {
            "textQuery": text_query,
            "rankPreference": rank_preference,
            "regionCode": region_code,
            "strictTypeFiltering": strict_type_filtering,
            "maxResultCount": max_result_count,
        }

        if view_port is not None:
            location_restriction = {
                "locationRestriction": {
                    "rectangle": {
                        "high": {
                            "latitude": view_port.northeast_lat,
                            "longitude": view_port.northeast_lon,
                        },
                        "low": {
                            "latitude": view_port.southwest_lat,
                            "longitude": view_port.southwest_lon,
                        },
                    }
                },
            }
            merge(request_payload, request_payload, location_restriction)
        else:
            location_bias = {
                "locationBias": {
                    "circle": {
                        "center": {"latitude": latitude, "longitude": longitude},
                        "radius": radius,
                    }
                }
            }
            merge(request_payload, request_payload, location_bias)
        return request_payload

    def _post(self, url: str, data, headers):
        response = requests.post(url=url, headers=headers, json=data)

        if response.status_code == 200:
            return response.json()
        else:
            logger.error(f"Error {response.status_code}: {response.text}")
            raise Exception(f"Error {response.status_code}: {response.text}")
