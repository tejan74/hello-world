import pydantic


class ViewPort(pydantic.BaseModel):
    northeast_lat: float
    northeast_lon: float
    southwest_lat: float
    southwest_lon: float
