import unittest
import json
import pydash
from lib import google_maps
from lib.google_maps._classes import ViewPort
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Test(unittest.TestCase):

    def test_google_maps_view_port_bulk(self):
        client = google_maps.ApiClient()
        geocode_response = client.geocode("New York, USA")
        logger.info("place geocode", json.dumps(geocode_response))

        def split_viewport(northeast_lat, northeast_lon, southwest_lat, southwest_lon):
            lat_range = abs(northeast_lat - southwest_lat) / 3
            lon_range = abs(northeast_lon - southwest_lon) / 4

            rectangles = []

            for i in range(3):
                for j in range(4):
                    rect_northeast_lat = northeast_lat - i * lat_range
                    rect_northeast_lon = northeast_lon - j * lon_range
                    rect_southwest_lat = rect_northeast_lat - lat_range
                    rect_southwest_lon = rect_northeast_lon - lon_range

                    rectangles.append(
                        ViewPort(
                            northeast_lat=rect_northeast_lat,
                            northeast_lon=rect_northeast_lon,
                            southwest_lat=rect_southwest_lat,
                            southwest_lon=rect_southwest_lon,
                        )
                    )

            return rectangles

        # Example usage
        northeast_lat = pydash.get(geocode_response[0], "geometry.bounds.northeast.lat")
        northeast_lon = pydash.get(geocode_response[0], "geometry.bounds.northeast.lng")
        southwest_lat = pydash.get(geocode_response[0], "geometry.bounds.southwest.lat")
        southwest_lon = pydash.get(geocode_response[0], "geometry.bounds.southwest.lng")

        result = split_viewport(
            northeast_lat, northeast_lon, southwest_lat, southwest_lon
        )
        logger.info(result)

        results_list = []
        for viewport in result:
            response = client.search_places(
                view_port=viewport,
                text_query="Bank"
            )
            results_list.extend(response)

        logger.info("places response: ", results_list, len(results_list))

    def test_google_maps_in_view_port(self):
        client = google_maps.ApiClient()
        geocode_response = client.geocode("New York, USA")
        logger.info("place geocode", json.dumps(geocode_response))

        response = client.search_places(
            view_port=ViewPort(
                northeast_lat=pydash.get(
                    geocode_response[0], "geometry.bounds.northeast.lat"
                ),
                northeast_lon=pydash.get(
                    geocode_response[0], "geometry.bounds.northeast.lng"
                ),
                southwest_lat=pydash.get(
                    geocode_response[0], "geometry.bounds.southwest.lat"
                ),
                southwest_lon=pydash.get(
                    geocode_response[0], "geometry.bounds.southwest.lng"
                ),
            ),
            text_query="Bank",
            max_result_count=14,
        )

        logger.info(
            "places response: ",
            response,
            len(response),
        )

    def test_google_maps_by_location(self):
        client = google_maps.ApiClient()
        geocode_response = client.geocode("New York, USA")
        logger.info("place geocode", json.dumps(geocode_response))

        response = client.search_places(
            text_query="Bank",
            latitude=pydash.get(geocode_response[0], "geometry.location.lat"),
            longitude=pydash.get(geocode_response[0], "geometry.location.lng"),
            radius=1000,
            max_result_count=10,
        )

        logger.info(
            "places response: ",
            json.dumps(response),
            len(response)
        )


if __name__ == "__main__":
    unittest.main()
