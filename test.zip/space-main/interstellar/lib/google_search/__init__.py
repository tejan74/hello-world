from typing import Literal, Optional
import config

import google.auth
import googleapiclient.discovery
from googleapiclient.errors import HttpError

from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

FILE_TYPE_ALLOW_LIST = Literal["pdf", "doc", "docx", "xls", "xlsx"]

class ApiClient():
    # Default service configuration for Google SEarch
    DEFAULT_SERVICE = "customsearch"
    DEFAULT_SERVICE_VERSION = "v1"
    DEFAULT_REQUIRED_SCOPES = ["https://www.googleapis.com/auth/cse"]

    def __init__(self, service: str = DEFAULT_SERVICE, service_version: str = DEFAULT_SERVICE_VERSION, scopes: list = DEFAULT_REQUIRED_SCOPES):
        api_key = config.get_parameter("GOOGLE_SEARCH_API_KEY")
        # Setup scopes to be used for authentication
        if api_key:
            service = googleapiclient.discovery.build(service, service_version, developerKey = api_key)
        else:
            credentials, _ = google.auth.default(scopes = scopes)
            service = googleapiclient.discovery.build(service, service_version, credentials = credentials)
        
        # Set the API client for the services necessary
        self.client = service.cse() # type: ignore
    
    def search(self, query: str, limit: Optional[int] = 10, file_type: Optional[FILE_TYPE_ALLOW_LIST] = None):
        try:
            # Run the search query
            return self.client.list(
                q = query,
                cx = config.get_parameter("GOOGLE_SEARCH_ENGINE_ID"),
                num = limit,
                fileType = file_type
            ).execute()
        
        except HttpError as e:
            logger.exception(f"Google Search API error")
            raise(e)
        
