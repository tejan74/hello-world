from typing import Any
import google.auth
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from pydash import get


from lib.google_spreadsheet._utils import SheetRange
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class ApiClient:
    _SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]

    def __init__(self, spreadsheet_id: str):
        self._id = spreadsheet_id
        creds, _ = google.auth.default(scopes=self.__class__._SCOPES)

        self._api = build("sheets", "v4", credentials=creds).spreadsheets()

    def __del__(self):
        self._api.close()

    def get_by_range(self, range: str):
        """
        Get values from the sheet by range
        :param range: string in SheetName!A1:A10A1:A10 or A1:A10 or A1 notation
        """
        try:
            result = (
                self._api.values()
                .get(spreadsheetId=self._id, range=range, majorDimension="ROWS")
                .execute()
            )
            rows = result.get("values", [])
            logger.info(f"{len(rows)} rows retrieved")
            sr = SheetRange(range=result["range"])
            result["values"] = list(
                map(lambda x: [*x, *[""] * sr.width][: sr.width], result["values"])
            )
            return result
        except HttpError as error:
            logger.error(f"Error occured during sheets get: {error}")
            raise error

    def update(self, range: str, values: list[list[str | int | float | bool | None]]):
        """
        Update values in the sheet by range
        :param range: string in SheetName!A1:A10A1:A10 or A1:A10 or A1 notation
        :param values: list of lists of values
        """
        try:
            body = {"values": values}
            result = (
                self._api.values()
                .update(
                    spreadsheetId=self._id,
                    range=range,
                    valueInputOption="RAW",
                    body=body,
                )
                .execute()
            )
            logger.info(f"{result.get('updatedCells')} cells updated.")
            return result
        except HttpError as error:
            logger.error(f"Error occured during sheets update: {error}")
            raise error

    def append(self, range: str, values: list[list[str | int | float | bool | None]]):
        """
        refer: https://googleapis.github.io/google-api-python-client/docs/dyn/sheets_v4.spreadsheets.values.html
        """
        try:
            body = {"values": values}
            result = (
                self._api.values()
                .append(
                    spreadsheetId=self._id,
                    range=range,
                    valueInputOption="RAW",
                    body=body,
                )
                .execute()
            )
            logger.info(
                f"{get(result,'updates.updatedRows')}  rows & {get(result,'updates.updatedColumns')} columns appended."
            )
            return result
        except HttpError as error:
            logger.error(f"Error occured during sheets append: {error}")
            raise error
