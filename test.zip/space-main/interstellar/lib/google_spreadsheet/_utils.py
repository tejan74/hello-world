import copy
import re


class SheetCol(str):
    def __init__(self, value: str) -> None:
        super().__init__()
        self = value.upper()

    def __add__(self, other):
        if isinstance(other, int):
            nc = max(self.to_number(self) + other, 1)
            return self.from_number(nc)
        else:
            return self + other

    def __sub__(self, other):
        if isinstance(other, int):
            nc = max(self.to_number(self) - other, 1)
            return self.from_number(nc)
        else:
            return self - other

    @property
    def num(self):
        return self.to_number(self)

    @classmethod
    def to_number(cls, col: str) -> int:
        col = col.upper()
        num = 0
        for i, c in enumerate(col[::-1]):
            num += (ord(c) - ord("A") + 1) * (26**i)
        return num

    @classmethod
    def from_number(cls, num: int) -> str:
        col = ""
        i = 1
        while num > 0:
            d = num % 26
            if d == 0:
                d = 25
                num -= 1
            else:
                d -= 1
            col = chr(ord("A") + d) + col
            num //= 26
        return col


class SheetCell:
    def __init__(
        self,
        colrow: str | None = None,
        col: str | None = None,
        row: str | int | None = None,
    ) -> None:
        self._col, self._row = None, None
        if colrow:
            m = re.match(r"([a-zA-Z]*)(\d*)", colrow)
            if not m:
                raise ValueError(f"Invalid cell reference: {colrow}")
            [_col, _row] = list(map(lambda x: str(x) or None, list(m.groups())))

        if col:
            _col = col
        if row:
            _row = row

        if _col:
            self._col = SheetCol(_col)
        if _row:
            self._row = int(_row)

    @property
    def col(self):
        return self._col

    @property
    def row(self):
        return self._row

    @col.setter
    def col(self, value: str | SheetCol):
        if isinstance(value, SheetCol):
            self._col = copy.deepcopy(value)
        else:
            self._col = SheetCol(value)

    @row.setter
    def row(self, value: str | int):
        self._row = int(value)

    @property
    def colrow(self):
        return "".join(
            map(lambda x: str(x), filter(lambda x: x != None, [self.col, self.row]))
        )


class SheetRange:
    def __init__(
        self,
        range: str | None = None,
        name: str | None = None,
        start_col: str | None = None,
        start_row: str | int | None = None,
        end_col: str | None = None,
        end_row: str | int | None = None,
    ) -> None:

        [self.name, sc, sr, ec, er] = [None] * 5

        if range:
            m = re.match(r"(?:(.+?)!)?([A-Z]*)(\d*):?([A-Z]*)(\d*)", range)
            if not m:
                raise ValueError(f"Invalid range reference: {range}")
            [self.name, sc, sr, ec, er] = list(
                map(lambda x: str(x) or None, list(m.groups()))
            )

        if name:
            self.name = name
        if start_col:
            sc = start_col
        if start_row:
            sr = start_row
        if end_col:
            ec = end_col
        if end_row:
            er = end_row

        self._start = SheetCell(col=sc, row=sr)
        self._end = SheetCell(col=ec, row=er)

    @property
    def start(self):
        return self._start

    @property
    def end(self):
        return self._end

    @start.setter
    def start(self, value: SheetCell):
        self._start = copy.deepcopy(value)

    @end.setter
    def end(self, value: SheetCell):
        self._end = copy.deepcopy(value)

    @property
    def range(self):
        rf = ":".join(filter(lambda x: x != None, [self.start.colrow, self.end.colrow]))
        return "!".join(filter(lambda x: x != None, [self.name, rf])) # type: ignore

    @property
    def height(self):
        if self.end.row == None:
            return 0
        if self.start.row == None:
            return self.end.row
        return abs(self.end.row - self.start.row + 1)

    @property
    def width(self):
        if self.end.col == None:
            if self.start.col != None:
                return 1
            else:
                return 0
        if self.start.col == None:
            return self.end.col.num
        return abs(self.end.col.num - self.start.col.num + 1)
