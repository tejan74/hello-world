import unittest


from lib.google_spreadsheet import ApiClient


class TestSheets(unittest.TestCase):
    def test_gt(self):
        m = ApiClient("1GEiqDkFuckqBAfMLq062HWHqTkV9IMBYQLKzYrVPfMI").get_by_range(
            "A:A"
        )
        print(m)
        self.assertEqual(len(m["values"]), 9)

    def test_update(self):
        m = ApiClient("1GEiqDkFuckqBAfMLq062HWHqTkV9IMBYQLKzYrVPfMI").update(
            "Sheet1!B3", [["test", "periperi", "fries"]]
        )
        print(m)
        self.assertEqual(m["updatedColumns"], 3)


if __name__ == "__main__":
    unittest.main()
