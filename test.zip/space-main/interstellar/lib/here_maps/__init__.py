import requests
from typing import Optional
import config
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class HereMapsException(Exception):
    def __init__(self, status_code, *args: object) -> None:
        super().__init__(f"Error response, status code: {status_code}", *args)
        self.status_code = status_code


class ApiClient:
    def __init__(self, api_key: str | None = None):
        # Accept overwritten key for client or use default
        self.api_key = api_key or config.get_parameter("HERE_MAPS_API_KEY")

    # Finds the latitude and longitude of an address
    # ref: https://www.here.com/docs/bundle/geocoding-and-search-api-v7-api-reference/page/index.html
    def geocode(self, address: str, limit: Optional[int] = 1) -> dict:
        url = f"https://geocode.search.hereapi.com/v1/geocode"
        params = {"q": address, "apiKey": self.api_key, "limit": limit}
        return self._get(url, params)

    # Finds places around a given location within a given radius in meters
    # ref: https://www.here.com/docs/bundle/geocoding-and-search-api-v7-api-reference/page/index.html
    def discover(
        self,
        query: str,
        latitude: float | None = None,
        longitude: float | None = None,
        country_code: str | None = None,
        radius: int | None = 1000,
        limit: int | None = 1,
    ) -> dict:
        url = f"https://discover.search.hereapi.com/v1/discover"

        # Initializing the search in parameter, giving preference to radius if it is present then to countryCode
        search_in = None
        if radius is not None and latitude is not None and longitude is not None:
            search_in = f"circle:{latitude},{longitude};r={radius}" if radius is not None else None
        elif country_code is not None:
            search_in = (f"countryCode:{country_code}")

        params = {
            "q": query,
            "at": f"{latitude},{longitude}" if radius is None or radius == 0 else None,
            "in": search_in if search_in else None,
            "apiKey": self.api_key,
            "limit": limit,
        }
        logger.info("search params", params)
        return self._get(url, params)

    def _get(self, url: str, params: dict):
        params = {k: v for k, v in params.items() if v is not None}
        response = requests.get(url=url, params=params)

        if response.status_code == 200:
            return response.json()
        else:
            logger.error(f"Error {response.status_code}: {response.text}")
            raise Exception(f"Error {response.status_code}: {response.text}")
