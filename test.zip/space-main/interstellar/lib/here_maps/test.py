import unittest
import os
import json
import pydash

from lib import here_maps
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Test(unittest.TestCase):
    def test_geocode(self):
        companyToFind = "Mercy Home for Boys & Girls"
        address = "1140 West Jackson Boulevard, Chicago, Illinois, United States, 60607"

        api = here_maps.ApiClient(api_key=os.environ["HERE_MAPS_API_KEY"])
        output = api.geocode(address)
        logger.info(output)
        logger.info("-----")

        latitude = pydash.get(output["items"][0], "position.lat")
        longitude = pydash.get(output["items"][0], "position.lng")

        output = api.discover(companyToFind, latitude=latitude, longitude=longitude, radius=500)
        logger.info(output)

    def test_discover(self):
        search_query = "Food"
        location = "Texas"
        client = here_maps.ApiClient()
        output = client.geocode(location)
        logger.info(output)
        logger.info("-----")

        latitude = pydash.get(output["items"][0], "position.lat")
        longitude = pydash.get(output["items"][0], "position.lng")

        response = client.discover(query=search_query, latitude=latitude, longitude=longitude, limit=10)

        logger.info(json.dumps(response))


if __name__ == "__main__":
    unittest.main()
