import pydantic
import requests

from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class HttpLib:
    def __init__(self, base_url, query_params=None, headers=None):
        self.base_url = base_url
        self.query_params = query_params
        self.headers = headers

    def _construct_url(self, path, subdomain=None):
        url = self.base_url
        if subdomain:
            url = f"https://{subdomain}.{url}"
        url = f"{url}/{path.lstrip('/')}"
        return url

    def request(
        self,
        method,
        path,
        query_params=None,
        json=None,
        body=None,
        headers=None,
        subdomain=None,
    ) -> dict | None:
        try:
            url = self._construct_url(path, subdomain)
            full_headers = {**(self.headers or {}), **(headers or {})}
            full_query_params = {**(self.query_params or {}), **(query_params or {})}
            response = requests.request(
                method,
                url,
                headers=full_headers,
                params=full_query_params,
                json=json,
                data=body,
            )
            if response.status_code == 200:
                return response.json()
            else:
                return None
        except (requests.RequestException, pydantic.ValidationError) as e:
            logger.exception(f"Error in http request: {e}")
            return None
