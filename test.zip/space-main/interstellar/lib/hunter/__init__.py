from lib.http import HttpLib
from lib.hunter.types import (
    AccountInfoResponse,
    DomainSearchResponse,
    EmailCountResponse,
    EmailFinderResponse,
    EmailType,
    EmailVerifierResponse,
    SeniorityType,
)
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class HunterClient(HttpLib):
    def __init__(self, api_key: str, base_url=None, query_params=None, headers=None):
        self.api_key = api_key
        if base_url is None:
            base_url = "https://api.hunter.io/v2"
        if headers is None:
            headers = {
                "X-API-KEY": self.api_key,
                "Content-Type": "application/json",
            }
        super().__init__(base_url=base_url, query_params=query_params, headers=headers)

    def domain_search(
        self,
        domain: str,
        company: str,
        limit: int = 10,
        offset: int = 0,
        type: EmailType | None = None,
        seniority: SeniorityType | None = None,
        department: str | None = None,
        required_field: str | None = None,
    ) -> DomainSearchResponse | None:
        """
        It returns all the email addresses using this domain name found on the internet.
        https://hunter.io/api-documentation/v2#domain-search

        Args:
        domain:
        Domain name from which you want to find the email addresses.

        company:
        The company name from which you want to find the email addresses

        limit:
        Specifies the max number of email addresses to return. The default is 10.

        offset:
        Specifies the number of email addresses to skip. The default is 0.

        type:
        Get only personal or generic email addresses.

        seniority:
        Get only email addresses for people with the selected seniority level

        department:
        Get only email addresses for people working in the selected department(s).

        required_field:
        Get only email addresses that have the selected field(s)
        """
        data = self.request(
            method="GET",
            path="/domain-search?",
            json={
                "domain": domain,
                "company": company,
                "limit": limit,
                "offset": offset,
                "type": type,
                "seniority": seniority,
                "department": department,
                "required_field": required_field,
                "api_key": self.api_key,
            },
        )
        return DomainSearchResponse(**data) if data is not None else None

    def email_finder(
        self,
        domain: str,
        company: str,
        first_name: str,
        last_name: str,
        full_name: str,
        max_duration: int = 10,
    ) -> EmailFinderResponse | None:
        """
        This API endpoint finds the most likely email address from a domain name, a first name and a last name.
        https://hunter.io/api-documentation/v2#email-finder

         Args:
         domain:
         Domain name from which you want to find the email addresses.

         company:
         The company name from which you want to find the email addresses

         first_name:
         The person's first name. It doesn't need to be in lowercase.

         last_name:
         The person's last name. It doesn't need to be in lowercase.

         full_name:
         The person's full name

         max_duration:
         Get only email addresses for people with the selected seniority level
        """
        data = self.request(
            method="GET",
            path="/email-finder?",
            json={
                "domain": domain,
                "company": company,
                "first_name": first_name,
                "last_name": last_name,
                "full_name": full_name,
                "max_duration": max_duration,
                "api_key": self.api_key,
            },
        )
        return EmailFinderResponse(**data) if data is not None else None

    def email_verifier(
        self,
        email: str,
    ) -> EmailVerifierResponse | None:
        """
        This API endpoint allows you to verify the deliverability of an email address
        https://hunter.io/api-documentation/v2#email-verifier

        Args:
        email:
        The email address you want to verify
        """
        data = self.request(
            method="GET",
            path="/email-verifier?",
            json={"email": email, "api_key": self.api_key},
        )
        return EmailVerifierResponse(**data) if data is not None else None

    def email_count(
        self, domain: str, company: str, type: EmailType | None = None
    ) -> EmailCountResponse | None:
        """
        This API endpoint allows you to know how many email addresses we have for one domain or for one company. It's free and doesn't require authentication.
        https://hunter.io/api-documentation/v2#email-count

         Args:
         email:
         The email address you want to verify
        """
        data = self.request(
            method="GET",
            path="/email-count?",
            json={
                "domain": domain,
                "company": company,
                "type": type,
                "api_key": self.api_key,
            },
        )
        return EmailCountResponse(**data) if data is not None else None

    def account_information(
        self,
    ) -> AccountInfoResponse | None:
        """
        This API endpoint enables you to get information regarding your Hunter account at any time. This call is free.
        https://hunter.io/api-documentation/v2#account
        """
        data = self.request(
            method="GET",
            path="/account?",
            json={"api_key": self.api_key},
        )
        return AccountInfoResponse(**data) if data is not None else None
