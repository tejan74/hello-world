import enum
import pydantic


class EmailType(enum.Enum):
    PERSONAL = "personal"
    GENERIC = "generic"


class SeniorityType(enum.Enum):
    JUNIOR = "junior"
    SENIOR = "senior"
    EXECUTIVE = "executive"


class EmailSource(pydantic.BaseModel):
    domain: str | None = None
    uri: str | None = None
    extracted_on: str | None = None
    last_seen_on: str | None = None
    still_on_page: bool | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class Email(pydantic.BaseModel):
    value: str | None = None
    type: str | None = None
    confidence: int | None = None
    sources: list[EmailSource] | None = None
    first_name: str | None = None
    last_name: str | None = None
    position: str | None = None
    seniority: str | None = None
    department: str | None = None
    linkedin: str | None = None
    twitter: str | None = None
    phone_number: str | None = None
    verification: dict
    model_config = pydantic.ConfigDict(extra="allow")


class DomainData(pydantic.BaseModel):
    domain: str | None = None
    disposable: bool | None = None
    webmail: bool | None = None
    accept_all: bool | None = None
    pattern: str | None = None
    organization: str | None = None
    description: str | None = None
    industry: str | None = None
    twitter: str | None = None
    facebook: str | None = None
    linkedin: str | None = None
    instagram: str | None = None
    youtube: str | None = None
    technologies: list
    country: str | None = None
    state: str | None = None
    city: str | None = None
    postal_code: str | None = None
    street: str | None = None
    headcount: str | None = None
    company_type: str | None = None
    emails: list[Email] | None = None
    linked_domains: list | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class Params(pydantic.BaseModel):
    domain: str | None = None
    company: str | None = None
    type: str | None = None
    seniority: str | None = None
    department: str | None = None
    email: str | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class Meta(pydantic.BaseModel):
    results: int | None = None
    limit: int | None = None
    offset: int | None = None
    params: Params | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class DomainSearchResponse(pydantic.BaseModel):
    data: DomainData
    meta: Meta


class Source(pydantic.BaseModel):
    domain: str | None = None
    uri: pydantic.HttpUrl | None = None
    extracted_on: str | None = None
    last_seen_on: str | None = None
    still_on_page: bool | None = None


class Verification(pydantic.BaseModel):
    date: str | None = None
    status: str | None = None


class Data(pydantic.BaseModel):
    first_name: str | None = None
    last_name: str | None = None
    email: str | None = None
    score: int | None = None
    domain: str | None = None
    accept_all: bool | None = None
    position: str | None = None
    twitter: str | None = None
    linkedin_url: str | None = None
    phone_number: str | None = None
    company: str | None = None
    sources: list | None = None
    verification: Verification | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class EmailFinderMeta(pydantic.BaseModel):
    params: Params
    model_config = pydantic.ConfigDict(extra="allow")


class EmailFinderResponse(pydantic.BaseModel):
    data: Data
    meta: EmailFinderMeta


class EmailVerifierData(pydantic.BaseModel):
    status: str | None = None
    result: str | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class EmailVerifierResponse(pydantic.BaseModel):
    data: EmailVerifierData
    meta: EmailFinderMeta


class CountData(pydantic.BaseModel):
    total: int | None = None
    personal_emails: int | None = None
    generic_emails: int | None = None
    department: dict
    seniority: dict


class EmailCountResponse(pydantic.BaseModel):
    data: CountData
    meta: dict


class AccountData(pydantic.BaseModel):
    first_name: str | None = None
    last_name: str | None = None
    email: str | None = None
    plan_name: str | None = None
    calls: dict | None = None
    requests: dict | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class AccountInfoResponse(pydantic.BaseModel):
    data: AccountData
