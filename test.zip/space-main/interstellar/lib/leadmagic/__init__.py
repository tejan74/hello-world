from lib.http import HttpLib
from lib.leadmagic.types import (
    B2BTextResponse,
    CompanySearchResponse,
    CompetitorsSearchResponse,
    EmailFinderResponse,
    JobsFinderResponse,
    MobileFinderResponse,
    ProfileSearchResponse,
    ValidateEmailResponse,
)

from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class LeadMagicClient(HttpLib):
    def __init__(self, api_key: str, base_url=None, query_params=None, headers=None):
        self.api_key = api_key
        if base_url is None:
            base_url = "https://api.leadmagic.io"  # Update to the correct base URL
        if headers is None:
            headers = {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            }
        super().__init__(base_url=base_url, query_params=query_params, headers=headers)

    def email_validate(self, email: str) -> ValidateEmailResponse | None:
        """
        Email Validation: Validate the authenticity and status of an email address.
        https://docs.leadmagic.io/reference/email-validation

        LeadMagic's Email Validation system offers:
        - High quality and cost-effective email validation.
        - For just 1 LeadMagic credit, you get 20 email validations.
        - You are only charged for valid email validations. "Catch_all" or "unknown" emails will not incur charges unless engagement data indicates validity.

        Args:
        email:
        The email address to be validated. Must be a valid email format.

        Returns:
        ValidateEmailResponse | None: Returns a `ValidateEmailResponse` object with the validation results if the request is successful, or `None` if the request fails.
        """
        data = self.request(
            method="POST", path="/email-validate", json={"email": email}
        )
        return ValidateEmailResponse(**data) if data is not None else None

    def email_finder(
        self, first_name: str, last_name: str, domain: str, company_name: str
    ) -> EmailFinderResponse | None:
        """
        Email Finder: Retrieve a valid email address for a given person and company.
        https://docs.leadmagic.io/reference/email-finder

        This endpoint helps you:
        - Find an email address based on the provided first name, last name, domain, and company name.
        - The response guarantees that the email found is 100% valid.

        Args:
        first_name:
        The first name of the individual whose email address you are searching for.

        last_name:
        The last name of the individual whose email address you are searching for.

        domain:
        The domain of the company where the email address is expected. This should match the domain of the company associated with the email.

        company_name:
        The name of the company where the email address is expected. This should match the company associated with the email.

        Returns:
        EmailFinderResponse | None: Returns an `EmailFinderResponse` object with the valid email address if the request is successful, or `None` if the request fails.
        """
        data = self.request(
            method="POST",
            path="/email-finder",
            json={
                "first_name": first_name,
                "last_name": last_name,
                "domain": domain,
                "company_name": company_name,
            },
        )
        return EmailFinderResponse(**data) if data is not None else None

    def mobile_finder(self, profile_url: str) -> MobileFinderResponse | None:
        """
        Mobile Finder: Retrieve a mobile phone number from a social media profile.
        https://docs.leadmagic.io/reference/mobile-finder

        This endpoint allows you to:
        - Find a mobile phone number associated with the provided profile URL.
        - The cost for finding one mobile phone number is 5 Credits.
        - You are only charged if a valid mobile number is found.

        Args:
        profile_url:
        The URL of the social media profile (e.g., LinkedIn, Facebook) where the mobile phone number is expected to be found.
        This should be a valid URL pointing to a public profile from which the phone number can be extracted.

        Returns:
        MobileFinderResponse | None: Returns a `MobileFinderResponse` object with the mobile phone number if the request is successful, or `None` if the request fails or no number is found.
        """
        data = self.request(
            method="POST", path="/mobile-finder", json={"profile_url": profile_url}
        )
        return MobileFinderResponse(**data) if data is not None else None

    def profile_search(self, profile_url: str) -> ProfileSearchResponse | None:
        """
        Profile Search: Retrieve full profile details from a B2B profile URL.
        https://docs.leadmagic.io/reference/profile-finder

        This endpoint allows you to:
        - Provide a B2B profile URL and receive the complete profile details of the person associated with that URL.
        - Useful for obtaining comprehensive information from professional profiles.

        Args:
        profile_url:
        The URL of the B2B profile (e.g., LinkedIn profile) from which the full profile details will be retrieved.
        Ensure that this is a valid URL pointing to a public B2B profile for accurate results.

        Returns:
        ProfileSearchResponse | None: Returns a `ProfileSearchResponse` object with the profile details if the request is successful, or `None` if the request fails or no profile details are found.
        """
        data = self.request(
            method="POST", path="/profile-search", json={"profile_url": profile_url}
        )
        return ProfileSearchResponse(**data) if data is not None else None

    def company_search(
        self, profile_url: str, company_domain: str, company_name: str
    ) -> CompanySearchResponse | None:
        """
        Company Search: Retrieve full details for a company based on various identifiers.
        https://docs.leadmagic.io/reference/company-finder

        This endpoint allows you to:
        - Provide a Company Profile URL, Company Domain, or Company Name to get comprehensive details about the company.
        - Useful for obtaining detailed company information from multiple sources.

        Args:
        profile_url:
        The URL of the company's profile page (e.g., LinkedIn) where company details are accessible.
        This should be a valid URL pointing to a public profile or company page.

        company_domain:
        The domain name of the company (e.g., example.com). This can help in identifying the company and fetching related details.

        company_name:
        The name of the company (e.g., "Example Inc."). This will be used to search for the company's information if provided.

        Returns:
        CompanySearchResponse | None: Returns a `CompanySearchResponse` object with the company details if the request is successful, or `None` if the request fails or no company details are found.
        """
        data = self.request(
            method="POST",
            path="/company-search",
            json={
                "profile_url": profile_url,
                "company_domain": company_domain,
                "company_name": company_name,
            },
        )
        return CompanySearchResponse(**data) if data is not None else None

    def competitors_search(
        self, profile_url: str, company_domain: str, company_name: str
    ) -> CompetitorsSearchResponse | None:
        """
        Competitors Search: Identify competitors of a company based on provided identifiers.
        https://docs.leadmagic.io/reference/competitors-search

        This endpoint allows you to:
        - Search for competitors of a company using various identifiers such as profile URL, company domain, or company name.
        - Provides a list of competitors related to the given company.

        Args:
        profile_url:
        The URL of the company's profile page (e.g., LinkedIn) used to search for competitors.
        This should be a valid URL pointing to a public company profile or page.

        company_domain:
        The domain name of the company (e.g., example.com). This helps in finding competitors based on the company's web presence.

        company_name:
        The name of the company (e.g., "Example Inc."). This will be used to identify the company and search for its competitors.

        Returns:
        CompetitorsSearchResponse | None: Returns a `CompetitorsSearchResponse` object with the list of competitors if the request is successful, or `None` if the request fails or no competitors are found.
        """
        data = self.request(
            method="POST",
            path="/competitors",
            json={
                "profile_url": profile_url,
                "company_domain": company_domain,
                "company_name": company_name,
            },
        )
        return CompetitorsSearchResponse(**data) if data is not None else None

    def b2b_profile(
        self, work_email: str, personal_email: str
    ) -> B2BTextResponse | None:
        """
        B2B Profile: Retrieve B2B profile information based on email addresses.
        https://docs.leadmagic.io/reference/b2b-profile

        This endpoint allows you to:
        - Fetch detailed B2B profile information for an individual using both their work and personal email addresses.

        Args:
        work_email:
        The work email address of the individual. This is used to obtain professional details associated with the person.

        personal_email:
        The personal email address of the individual. This is used to cross-reference and obtain additional profile information.

        Returns:
        B2BTextResponse | None: Returns a `B2BTextResponse` object containing the B2B profile details if the request is successful, or `None` if the request fails or no profile is found.
        """
        data = self.request(
            method="POST",
            path="/b2b-profile",
            json={
                "work_email": work_email,
                "personal_email": personal_email,
            },
        )
        return B2BTextResponse(**data) if data is not None else None

    def jobs_finder(
        self,
        company_name: str,
        company_website: str,
        job_title: str,
        experience_level: str,
        has_remote: bool,
        posted_within: int,
        page: int,
        per_page: int,
    ) -> JobsFinderResponse | None:
        """
        Jobs Finder: Search for job listings based on various criteria.
        https://docs.leadmagic.io/reference/jobs-finder

        This endpoint allows you to:
        - Find job listings matching specific criteria, including company details, job title, experience level, and remote work options.

        Args:
        company_name:
        The name of the company to search for job listings.

        company_website:
        The website URL of the company, used to refine search results and ensure accuracy.

        job_title:
        The job title you are searching for, such as "Software Engineer" or "Marketing Manager."

        experience_level:
        The required experience level for the job position, such as "entry," "mid," or "senior."

        has_remote:
        Whether to include job listings that offer remote work. Set to `True` to include remote jobs, `False` to exclude them.

        posted_within:
        The number of days within which the job postings should have been made. For example, `7` to get jobs posted within the last week.

        page:
        The page number of the search results to retrieve. Useful for pagination.

        per_page:
        The number of job listings to return per page. Helps to control the volume of data returned in each response.

        Returns:
        JobsFinderResponse | None: Returns a `JobsFinderResponse` object containing the search results if the request is successful, or `None` if the request fails or no results are found.
        """
        data = self.request(
            method="POST",
            path="/jobs-finder",
            json={
                "company_name": company_name,
                "company_website": company_website,
                "job_title": job_title,
                "experience_level": experience_level,
                "has_remote": has_remote,
                "posted_within": posted_within,
                "page": page,
                "per_page": per_page,
            },
        )
        return JobsFinderResponse(**data) if data is not None else None
