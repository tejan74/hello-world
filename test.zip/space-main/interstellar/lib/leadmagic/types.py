import pydantic


class ValidateEmailResponse(pydantic.BaseModel):
    email: str
    email_status: str
    credits_consumed: int
    mx_record: str
    mx_provider: str

    model_config = pydantic.ConfigDict(extra="allow")


class CompanyLocation(pydantic.BaseModel):
    name: str | None = None
    locality: str | None = None
    region: str | None = None
    metro: str | None = None
    country: str | None = None
    continent: str | None = None
    street_address: str | None = None
    address_line_2: str | None = None
    postal_code: str | None = None
    geo: str | None = None

    model_config = pydantic.ConfigDict(extra="allow")


class EmailFinderResponse(pydantic.BaseModel):
    email: str | None = None
    status: str | None = None
    credits_consumed: int | None = None  # Updated type to int
    message: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    domain: str | None = None
    is_domain_catch_all: bool | None = None
    mx_record: str | None = None
    mx_provider: str | None = None
    mx_security_gateway: bool | None = None
    company_name: str | None = None
    company_industry: str | None = None
    company_size: str | None = None
    company_founded: int | str | None = None
    company_location: CompanyLocation | None = None
    company_linkedin_url: str | None = None
    company_linkedin_id: str | None = None
    company_facebook_url: str | None = None
    company_twitter_url: str | None = None
    company_type: str | None = None

    model_config = pydantic.ConfigDict(extra="allow")


class MobileFinderResponse(pydantic.BaseModel):
    profile_url: str | None = None
    mobile_number: str | None = None
    credits_consumed: str | None = None

    model_config = pydantic.ConfigDict(extra="allow")


# class Experience(pydantic.BaseModel):
#     companyLink1: pydantic.HttpUrl | None = None
#     logo: pydantic.HttpUrl | None = None
#     title: str
#     subtitle: str
#     caption: str
#     breakdown: bool
#     subComponents: list | None = None


class ProfileSearchResponse(pydantic.BaseModel):
    profileUrl: str | None = None
    creditsConsumed: int | None = None
    firstName: str | None = None
    lastName: str | None = None
    fullName: str | None = None
    publicIdentifier: str | None = None
    headline: str | None = None
    userSkills: str | None = None
    company_name: str | None = None
    company_size: str | None = None
    company_industry: str | None = None
    company_linkedin_url: str | None = None
    company_website: str | None = None
    totalTenureMonths: str | None = None
    totalTenureDays: str | None = None
    totalTenureYears: str | None = None
    connections: int | None = None
    followers: int | None = None
    urn: str | None = None
    country: str | None = None
    location: str | None = None
    profilePic: str | None = None
    about: str | None = None
    experiences: list | None = None
    highlights: list | None = None

    model_config = pydantic.ConfigDict(extra="allow")


class Location(pydantic.BaseModel):
    country: str | None = None
    city: str | None = None
    geographicArea: str | None = None
    postalCode: str | None = None
    line1: str | None = None
    line2: str | None = None
    description: str | None = None
    headquarter: bool | None = None
    localizedName: str | None = None
    latitude: float | None = None
    longitude: float | None = None

    model_config = pydantic.ConfigDict(extra="allow")


# class EmployeeCountRange(pydantic.BaseModel):
#     start: int | None = None
#     end: int | None = None


class Headquarter(pydantic.BaseModel):
    country: str | None = None
    city: str | None = None
    geographicArea: str | None = None
    postalCode: str | None = None
    line1: str | None = None
    line2: str | None = None
    description: str | None = None
    model_config = pydantic.ConfigDict(extra="allow")


# class SimilarOrganization(pydantic.BaseModel):
#     name: str | None = None
#     followerCount: int | None = None
#     url: pydantic.HttpUrl | None = None
#     logoResolutionResult: pydantic.HttpUrl | None = None
#     industry: str | None = None
#     companyId: int | None = None
#     employeeCountRange: EmployeeCountRange | None = None
#     headquarter: Headquarter | None = None
#     universalName: str | None = None


class CompanySearchResponse(pydantic.BaseModel):
    companyName: str | None = None
    companyId: int | None = None
    locations: list[Location] | None = None
    employeeCount: int | None = None
    specialities: list | None = None
    employeeCountRange: list | None = None
    similarOrganizations: list | None = None
    tagline: str | None = None
    followerCount: int | None = None
    originalCoverImage: pydantic.HttpUrl | None = None
    logoResolutionResult: pydantic.HttpUrl | None = None
    industry: str | None = None
    description: str | None = None
    websiteUrl: pydantic.HttpUrl | None = None
    headquarter: Headquarter | None = None
    universalName: str | None = None
    hashtag: str | None = None
    url: pydantic.HttpUrl | None = None
    affiliatedOrganizationsByEmployees: list | None = None
    affiliatedOrganizationsByShowcases: list | None = None

    model_config = pydantic.ConfigDict(extra="allow")


# class Tag(pydantic.BaseModel):
#     name: str | None = None
#     slug: str | None = None
#     primary: bool | None = None


# class FinancialMetrics(pydantic.BaseModel):
#     currency_code: str | None = None
#     period: str | None = None
#     revenue: float | None = None
#     cost_of_goods_sold: float | None = None
#     gross_profit: float | None = None
#     net_income: float | None = None


# class OperatingMetric(pydantic.BaseModel):
#     period: str | None = None
#     value: float | None = None
#     definition: str | None = None
#     operating_metric_group: str | None = None
#     currency_code: str | None = None


# class FundingMetrics(pydantic.BaseModel):
#     date: str | None = None
#     latest: float | None = None
#     currency_code: str | None = None
#     total: float | None = None


# class TwitterEngagementAnalytics(pydantic.BaseModel):
#     collectedAt: str | None = None
#     tweets: int | None = None
#     following: int | None = None
#     followers: int | None = None
#     tweetsForPeriod: int | None = None
#     avgTweetsPerDay: float | None = None
#     avgRetweetsPerTweet: float | None = None
#     avgLikesPerTweet: float | None = None
#     tweetsPercentageEngagementForPeriod: float | None = None


class TwitterEngagement(pydantic.BaseModel):
    handle: str | None = None
    analytics: list | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class CompetitorsSearchResponse(pydantic.BaseModel):
    name: str | None = None
    shortDescription: str | None = None
    founded_year: str | None = None
    companyType: str | None = None
    hq: str | None = None
    employeesCount: int | None = None
    valuation: float | None = None
    tags: list | None = None
    twitter_followers: int | None = None
    growth: int | None = None
    non_hq_locations: list | None = None
    more_locations: bool | None = None
    financial_metrics: list | None = None
    operating_metrics: list | None = None
    funding_metrics: list | None = None
    twitterEngagement: TwitterEngagement | None = None

    model_config = pydantic.ConfigDict(extra="allow")


class B2BTextResponse(pydantic.BaseModel):
    profile_url: str | None = None
    message: str | None = None
    credits_consumed: int | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class Region(pydantic.BaseModel):
    id: int | None = None
    name: str | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class Country(pydantic.BaseModel):
    code: str | None = None
    name: str | None = None
    region: Region | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class City(pydantic.BaseModel):
    geonameid: int | None = None
    asciiname: str | None = None
    name: str | None = None
    country: Country | None = None
    timezone: str | None = None
    latitude: str | None = None
    longitude: str | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class Company(pydantic.BaseModel):
    name: str | None = None
    website_url: pydantic.HttpUrl | None = None
    linkedin_url: pydantic.HttpUrl | None = None
    twitter_handle: str | None = None
    github_url: pydantic.HttpUrl | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class JobType(pydantic.BaseModel):
    id: int | None = None
    name: str | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class Job(pydantic.BaseModel):
    company: Company | None = None
    title: str | None = None
    location: str | None = None
    types: list[JobType] | None = None
    cities: list[City] | None = None
    countries: list[Country] | None = None
    regions: list[Region] | None = None
    has_remote: bool | None = None
    published: str | None = None
    description: str | None = None
    responsibilities: list | None = None
    qualifications: list | None = None
    application_url: pydantic.HttpUrl | None = None
    language: str | None = None
    clearance_required: bool | None = None
    salary_min: float | None = None
    salary_max: float | None = None
    salary_currency: str | None = None
    experience_level: str | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class JobsFinderResponse(pydantic.BaseModel):
    total_count: int | None = None
    page: int | None = None
    per_page: int | None = None
    total_pages: int | None = None
    credits_consumed: int | None = None
    results: list[Job] | None = None

    model_config = pydantic.ConfigDict(extra="allow")
