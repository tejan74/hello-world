from datetime import datetime, timedelta

from lib.http import HttpLib


class MarketstackClient(HttpLib):
    def __init__(self, api_key: str, base_url=None, query_params=None, headers=None):
        self.api_key = api_key
        if base_url is None:
            base_url = "https://api.marketstack.com/v1"
        self.base_url = base_url
        if headers is None:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            }
        self.headers = headers
        super().__init__(base_url=base_url, query_params=query_params, headers=headers)

    def get_stock_price(self, symbol: str, date_from: str, date_to: str):
        """
        Fetch historical stock prices from the Marketstack API.

        :param symbol: Stock symbol (e.g., 'AAPL')
        :param date_from: Start date in 'YYYY-MM-DD' format
        :param date_to: End date in 'YYYY-MM-DD' format
        :return: List of historical stock prices
        """
        endpoint = f"/eod"
        params = {
            "access_key": self.api_key,
            "symbols": symbol,
            "date_from": date_from,
            "date_to": date_to,
        }
        response = self.request(method="GET", path=endpoint, query_params=params)
        return response["data"] if response else None

    def calculate_percentage_change(self, symbol: str, from_date: str, to_date: str):
        """
        Calculate the percentage change in stock price from start_date to end_date.

        :param symbol: Stock symbol (e.g., 'AAPL')
        :param start_date: Start date in 'YYYY-MM-DD' format
        :param end_date: End date in 'YYYY-MM-DD' format
        :return: Percentage change
        """

        data = self.get_stock_price(symbol, from_date, to_date)
        if not data:
            raise ValueError("No data returned from API.")

        # Ensure data is sorted by date
        data_sorted = sorted(
            data, key=lambda x: datetime.fromisoformat(x["date"].replace("Z", "+00:00"))
        )

        # Use the first and last elements as start and end prices
        start_price = data_sorted[0]["close"]
        end_price = data_sorted[-1]["close"]

        if start_price is None or end_price is None:
            raise ValueError("Could not find start or end price in the data.")

        # Calculate percentage change
        percentage_change = ((end_price - start_price) / start_price) * 100
        # Check if the percentage change is less than 10%
        if percentage_change < 10:
            return f"Percentage change is less than 10%: {percentage_change:.2f}%"
        else:
            return f"Percentage change: {percentage_change:.2f}%"
