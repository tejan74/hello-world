import sqlalchemy

import config


def get_engine(connection_url: str | None = None):
    if not connection_url:
        connection_url = config.get_parameter("MIXRANK_DB_URL")

    if not connection_url:
        raise Exception("Empty connection_url")

    return sqlalchemy.create_engine(connection_url)
