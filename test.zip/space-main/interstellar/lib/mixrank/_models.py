from datetime import datetime, date, time
from uuid import UUID
from sqlalchemy import ARRAY, ForeignKey, Integer, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class LinkedinCompany(Base):
    __tablename__ = "linkedin_company"

    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[datetime | None]  # timestamp without time zone DEFAULT now(),
    updated_at: Mapped[datetime | None]  # timestamp without time zone DEFAULT now(),

    company_name: Mapped[str | None]  # character varying,
    website: Mapped[str | None]  # character varying,
    industry: Mapped[str | None]  # character varying,
    founded: Mapped[int | None]  # integer,
    domain: Mapped[str | None]  # character varying,
    description: Mapped[str | None]  # character varying,
    locality: Mapped[str | None]  # character varying,
    employee_count: Mapped[int | None]  # integer,
    follower_count: Mapped[int | None]  # integer,
    country_code: Mapped[str | None]  # character varying,
    industry_codes: Mapped[list[int] | None] = mapped_column(
        ARRAY(Integer)
    )  # integer[],
    ticker: Mapped[str | None]  # character varying,
    universal_name: Mapped[str | None]  # character varying,
    square_logo_url: Mapped[str | None]  # text,
    square_logo_url_internal: Mapped[UUID | None]  # uuid
    specialty_ids: Mapped[list[int] | None] = mapped_column(
        ARRAY(Integer)
    )  # integer[],
    parent_id: Mapped[int | None]  # integer,
    max_snapshot_id: Mapped[int | None]  # bigint,
    similar_company_ids: Mapped[list[int] | None] = mapped_column(
        ARRAY(Integer)
    )  # integer[],
    affiliated_company_ids: Mapped[list[int] | None] = mapped_column(
        ARRAY(Integer)
    )  # integer[],
    employee_profile_ids: Mapped[list[int] | None] = mapped_column(
        ARRAY(Integer)
    )  # integer[],
    company_headline: Mapped[str | None]  # text,

    # relations id fields
    country_iso: Mapped[str | None]  # text REFERENCES country(iso),
    industry_code: Mapped[int | None]  # integer REFERENCES linkedin_industry(id),
    company_type_code: Mapped[
        str | None
    ]  # character varying REFERENCES company_type(id),
    company_size_code: Mapped[
        str | None
    ]  # character varying REFERENCES company_size(id),

    # relations
    LinkedinProfilePositions: Mapped[list["LinkedinProfilePosition"]] = relationship(
        "LinkedinProfilePosition", back_populates="LinkedinCompany"
    )
    LinkedinJobs: Mapped[list["LinkedinJob"]] = relationship(
        "LinkedinJob", back_populates="LinkedinCompany"
    )


class LinkedinProfile(Base):
    __tablename__ = "linkedin_profile"

    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[datetime | None]  # timestamp without time zone DEFAULT now(),
    updated_at: Mapped[datetime | None]  # timestamp without time zone DEFAULT now(),

    first_name: Mapped[str | None]  # character varying,
    last_name: Mapped[str | None]  # character varying,
    formatted_name: Mapped[str | None]  # character varying,
    public_profile_url: Mapped[str | None]  # character varying,
    headline: Mapped[str | None]  # character varying,
    linkedin_industry_id: Mapped[int | None]  # integer,
    location_name: Mapped[str | None]  # character varying,
    location_country_code: Mapped[str | None]  # character varying,
    internal_picture_url: Mapped[str | None]  # character varying,
    connections: Mapped[int | None]  # integer,
    num_recommenders: Mapped[int | None]  # integer,
    skills: Mapped[list[str] | None] = mapped_column(
        ARRAY(String)
    )  # character varying[],
    summary: Mapped[str | None]  # character varying,
    interests: Mapped[str | None]  # character varying,
    specialties: Mapped[str | None]  # character varying,
    org: Mapped[str | None]  # text,
    title: Mapped[str | None]  # text,
    jobs_count: Mapped[int | None]  # integer,
    max_snapshot_id: Mapped[int | None]  # bigint,
    num_followers: Mapped[int | None]  # integer,
    people_also_viewed: Mapped[list[int] | None] = mapped_column(
        ARRAY(Integer)
    )  # integer[],
    others_named: Mapped[list[int] | None] = mapped_column(ARRAY(Integer))  # integer[],
    linkedin_user_id: Mapped[int | None]  # integer,
    linkedin_industry_past_ids: Mapped[list[int] | None] = mapped_column(
        ARRAY(Integer)
    )  # integer[],
    dob_date_year_infer: Mapped[int | None]  # integer,
    linkedin_profile_cover_image_id: Mapped[int | None]  # bigint,
    privacy_redact: Mapped[bool | None]  # boolean,
    slug_status: Mapped[str | None]  # "char"

    # relations
    LinkedinProfilePositions: Mapped["LinkedinProfilePosition"] = relationship(
        "LinkedinProfilePosition", back_populates="LinkedinProfile"
    )


class LinkedinProfilePosition(Base):
    __tablename__ = "linkedin_profile_position2"

    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[datetime | None]  # timestamp without time zone DEFAULT now(),
    updated_at: Mapped[datetime | None]  # timestamp without time zone DEFAULT now(),

    company_name: Mapped[str | None]  # text,
    title: Mapped[str | None]  # text,
    is_current: Mapped[bool | None]  # boolean,
    summary: Mapped[str | None]  # text,
    start_date_year: Mapped[int | None]  # smallint,
    start_date_month: Mapped[int | None]  # smallint,
    start_date: Mapped[
        date | None
    ]  # date GENERATED ALWAYS AS (make_date(start_date_year::integer, COALESCE(start_date_month::integer, 1), 1)) STORED,
    end_date_year: Mapped[int | None]  # smallint,
    end_date_month: Mapped[int | None]  # smallint,
    end_date: Mapped[
        date | None
    ]  # date GENERATED ALWAYS AS (make_date(end_date_year::integer, COALESCE(end_date_month::integer, 1), 1)) STORED,
    locality: Mapped[str | None]  # text,
    min_snapshot_id: Mapped[int | None]  # bigint,
    md5_bigint: Mapped[
        int
    ]  # bigint NOT NULL GENERATED ALWAYS AS (biginthash(VARIADIC ARRAY[md5(VARIADIC ARRAY[linkedin_profile_id::text, COALESCE(company_name, linkedin_company_id::text), title])])) STORED UNIQUE,
    sort_order: Mapped[int | None]  # smallint

    # relations id fields
    linkedin_company_id: Mapped[int | None] = mapped_column(
        ForeignKey("linkedin_company.id")
    )  # integer REFERENCES linkedin_company(id) ON DELETE CASCADE ON UPDATE CASCADE,
    linkedin_profile_id: Mapped[int] = mapped_column(
        ForeignKey("linkedin_profile.id")
    )  # integer NOT NULL REFERENCES linkedin_profile(id),

    # relations
    LinkedinCompany: Mapped[LinkedinCompany] = relationship(
        "LinkedinCompany", back_populates="LinkedinProfilePositions"
    )
    LinkedinProfile: Mapped[LinkedinProfile] = relationship(
        "LinkedinProfile", back_populates="LinkedinProfilePositions"
    )


class LinkedinJob(Base):
    __tablename__ = "linkedin_job"

    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[datetime | None]  # timestamp without time zone DEFAULT now(),
    updated_at: Mapped[datetime | None]  # timestamp without time zone DEFAULT now(),

    job_id: Mapped[int]  # bigint NOT NULL,
    job_slug: Mapped[str]  # text NOT NULL,
    posted_date: Mapped[date | None]  # date,
    posted_time: Mapped[time | None]  # time without time zone,
    posted_timestamp: Mapped[
        datetime | None
    ]  #  without time zone GENERATED ALWAYS AS (posted_date + posted_time) STORED,
    # posted_tsrange tsrange,
    title_id: Mapped[int | None]  # integer,
    title: Mapped[str | None]  # text
    company_name: Mapped[str | None]  # text
    company_universal_name: Mapped[str | None]  # text
    location: Mapped[str | None]  # text
    address_country: Mapped[str | None]  # text
    address_locality: Mapped[str | None]  # text
    address_region: Mapped[str | None]  # text
    postal_code: Mapped[str | None]  # text
    street_address: Mapped[str | None]  # text
    latitude: Mapped[int | None]  # numeric,
    longitude: Mapped[int | None]  # numeric,
    applicants: Mapped[int | None]  # integer,
    description: Mapped[str | None]  # text
    job_functions: Mapped[list[int] | None] = mapped_column(
        ARRAY(Integer)
    )  # integer[],
    industries: Mapped[list[int] | None] = mapped_column(ARRAY(Integer))  # integer[],
    salary_range: Mapped[str | None]  # text
    salary_min: Mapped[int | None]  # numeric,
    salary_max: Mapped[int | None]  # numeric,
    salary_unit: Mapped[str | None]  # text
    required_months_of_experience: Mapped[int | None]  # integer,
    academic_qualification: Mapped[str | None]  # text
    apply_external_url: Mapped[str | None]  # text
    external_job_id: Mapped[str | None]  # text
    valid_until: Mapped[datetime | None]  # timestamp without time zone,
    benefit_ids: Mapped[list[int] | None] = mapped_column(ARRAY(Integer))  # integer[],
    closed_since: Mapped[datetime | None]  # timestamp without time zone,

    # relations id fields
    linkedin_company_id: Mapped[int | None] = mapped_column(
        ForeignKey("linkedin_company.id")
    )  # integer REFERENCES linkedin_company(id),
    location_geo_id: Mapped[
        int | None
    ]  # integer REFERENCES linkedin_geo(linkedin_geoid),
    applicant_range_id: Mapped[
        str | None
    ]  # text REFERENCES linkedin_job_applicant_range(id),
    linkedin_seniority_level_id: Mapped[
        int | None
    ]  # integer REFERENCES linkedin_seniority(id),
    linkedin_employment_type_id: Mapped[
        int | None
    ]  # integer REFERENCES linkedin_employment_type(id),
    salary_currency_id: Mapped[int | None]  # integer REFERENCES linkedin_currency(id),
    recruiter_profile_id: Mapped[int | None]  # integer REFERENCES linkedin_profile(id),
    recruiter_slug_id: Mapped[
        int | None
    ]  # bigint REFERENCES linkedin_profile_slug(id),
    description_key64: Mapped[
        int | None
    ]  # bigint REFERENCES linkedin_job_description(description_key64)

    # relations
    LinkedinCompany: Mapped[LinkedinCompany] = relationship(
        "LinkedinCompany", back_populates="LinkedinJobs"
    )
