import config
import openai

from typing import Optional, Literal

# Default base URL for OpenAI API
DEFAULT_BASE_URL = "https://api.openai.com/v1"

# Libraries we're comfortable using
SupportedModel = Literal[
    "gpt-4o-2024-08-06",
    "gpt-4o-2024-05-13",  # Adding this because though "gpt-4o" currently points to this snapshot but in the very near future "gpt-4o" will point to the above snapshot
    "gpt-4o-mini",
    "gpt-4o",
    "gpt-4-turbo",
    "gpt-4-0125-preview",
    "gpt-4-1106-preview",
    "gpt-4-vision-preview",
    "gpt-4",
    "gpt-4-32k",
]

"""
OpenAI Library
"""


class BadRequestError(openai.BadRequestError):
    pass


class ApiClient:
    # Initialize
    def __init__(
        self,
        model: SupportedModel,
        key: Optional[str] = None,
        base_url: Optional[str] = DEFAULT_BASE_URL,
    ):
        # Assign model or use default model
        self.model = model

        # TODO (ani): check if model is a valid supported model

        # Accept overwritten key for client or use default
        self.key = key or config.get_parameter("OPENAI_API_KEY")
        if self.key is None:
            raise ValueError(
                "OPENAI_API_KEY environment variable must be set or key must be provided"
            )

        # Setup OpenAI client using key
        self.client = openai.OpenAI(api_key=self.key, base_url=base_url)

    def create_vector_store(self, vector_store_name: str):
        vector_store = self.client.beta.vector_stores.create(name=vector_store_name)
        return vector_store

    def delete_vector_store(self, vector_store_id: str):
        deleted_vector_store = self.client.beta.vector_stores.delete(
            vector_store_id=vector_store_id
        )
        return deleted_vector_store

    # Chat APIs
    from lib.open_ai._chat import completion as chat
    from lib.open_ai._chat import completion_vision as chat_vision

    # Assistants APIs
    from lib.open_ai._file import (
        create_file,
        upload_file_to_vector_store,
        delete_file,
        delete_file_from_vector_store,
    )
    from lib.open_ai._thread import (
        create_thread,
        run_thread,
        run_thread_and_poll,
        retrieve_thread_run,
        delete_thread,
        create_message,
        list_messages,
    )
    from lib.open_ai._assistant import create_assistant, delete_assistant


class AzureOpenAIClient(ApiClient):
    __api_version = "2024-02-01"

    def __init__(
        self,
        endpoint_url: str,
        deployment: str | None = None,
        key: str | None = None,
    ):
        # Assign model or use default model
        self.deployment = deployment if deployment else "gpt-4o-mini"

        # Accept overwritten key for client or use default
        self.key = key or config.get_parameter("AZURE_OPENAI_API_KEY")
        if self.key is None:
            raise ValueError(
                "OPENAI_API_KEY environment variable must be set or key must be provided"
            )

        # Setup Azure OpenAI client using key
        self.client = openai.AzureOpenAI(
            api_key=self.key,
            api_version=self.__api_version,
            azure_endpoint=endpoint_url,
        )

    def azure_completion(
        self,
        query: str,
        temperature: float = 0.75,
        max_tokens: int = 300,
    ):
        response = self.client.chat.completions.create(
            model=self.deployment,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": query},
            ],
            max_tokens=max_tokens,
            temperature=temperature,
        )
        return response
