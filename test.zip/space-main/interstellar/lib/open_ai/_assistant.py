from typing import List


def create_assistant(self, name: str, instructions: str, model: str | None = None, max_num_results: int | None = None):
    assistant = self.client.beta.assistants.create(
        name=name,
        instructions=instructions,
        model=model if model else self.model,
        tools=[
            {
                "type": "file_search",
                "file_search": {"max_num_results": max_num_results or 20},
            }
        ],
    )

    return assistant

def delete_assistant(self, assistant_id: str):
    deleted_assistant = self.client.beta.assistants.delete(assistant_id=assistant_id)

    return deleted_assistant
