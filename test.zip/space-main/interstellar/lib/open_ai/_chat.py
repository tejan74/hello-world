from typing import Optional, Literal


# TODO: make this more robust to support other query types other than just chat text AND
# make the output format a parameter not a boolean
def completion(
    self,
    user_query: str,
    system_prompt: str | None = None,
    output_format: Literal["text", "json_object"] = "text",
    temperature: Optional[float] = 0.75,
    model: str | None = None,
):
    system_message = {"role": "system", "content": system_prompt}

    user_messsage = {"role": "user", "content": user_query}

    messages = [system_message, user_messsage] if system_prompt else [user_messsage]

    try:
        response = self.client.chat.completions.create(
            model=model if model else self.model,
            messages=messages,
            response_format={"type": output_format},
            temperature=temperature,
        )

        return response

    # TODO: add more specific exception handling or standardize
    except Exception as e:
        raise (e)


# Currently gpt-4-1106-preview is not accepting response_format parameter, if passed leading to a runtime error
# TODO: @Chitti once gpt-4-vision-preview becomes stable - consolidate above completion function and this function
def completion_vision(
    self,
    user_message_content: list,
    system_message_content: str | None = None,
    temperature: Optional[float] = 0.75,
    max_tokens: Optional[int] = 300,
    output_format: Literal["text", "json_object"] = "text",
    model: str | None = None,
):
    system_message = {"role": "system", "content": system_message_content}

    user_messsage = {"role": "user", "content": user_message_content}

    messages = (
        [system_message, user_messsage] if system_message_content else [user_messsage]
    )

    try:
        response = self.client.chat.completions.create(
            model=model if model else self.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            response_format={"type": output_format},
        )

        return response

    except Exception as e:
        raise (e)
