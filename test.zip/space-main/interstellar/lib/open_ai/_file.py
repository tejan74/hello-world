def create_file(self, file_path: str):
    file = self.client.files.create(file=open(file_path, "rb"), purpose="assistants")

    return file


def upload_file_to_vector_store(self, file_paths: list[str], vector_store_id: str):
    file_streams = [open(path, "rb") for path in file_paths]
    file_batch = self.client.beta.vector_stores.file_batches.upload_and_poll(
        vector_store_id=vector_store_id, files=file_streams
    )

    return file_batch


def delete_file(self, file_id: str):
    deleted_file = self.client.files.delete(file_id)

    return deleted_file


def delete_file_from_vector_store(self, file_id: str, vector_store_id: str):
    deleted_vector_store_file = self.client.beta.vector_stores.files.delete(
        vector_store_id=vector_store_id, file_id=file_id
    )

    return deleted_vector_store_file
