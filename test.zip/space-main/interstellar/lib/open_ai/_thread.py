from typing import Literal, TypedDict

class ToolsType(TypedDict):
    type: Literal["file_search", "code_interpreter"]

class AttachmentType(TypedDict):
    file_id: str
    tools: list[ToolsType]

def create_thread(self):
    thread = self.client.beta.threads.create()

    return thread

def run_thread(self, thread_id: str, assistant_id: str):
    run = self.client.beta.threads.runs.create(
        thread_id = thread_id,
        assistant_id = assistant_id
    )

    return run

def run_thread_and_poll(self, thread_id: str, assistant_id: str):
    run = self.client.beta.threads.runs.create_and_poll(
        thread_id = thread_id,
        assistant_id = assistant_id
    )

    return run

def retrieve_thread_run(self, run_id: str, thread_id: str):
    run = self.client.beta.threads.runs.retrieve(
        thread_id = thread_id,
        run_id = run_id
    )

    return run

def delete_thread(self, thread_id: str):
    deleted_thread = self.client.beta.threads.delete(thread_id=thread_id)

    return deleted_thread


def create_message(self, thread_id: str, message: str, attachments: list[AttachmentType]):
    msg = self.client.beta.threads.messages.create(
        thread_id = thread_id,
        role = "user",
        content = message,
        attachments = attachments
    )

    return msg

def list_messages(self, thread_id: str):
    messages = self.client.beta.threads.messages.list(thread_id)

    return messages

