from peopledatalabs import PDLPY
import pydantic
from lib.people_data_labs.types import (
    CompanyEnrichmentResponse,
    IPEnrichmentResponse,
    PersonEnrichmentResponse,
    PersonIdentityResponse,
    SearchResponse,
)
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class PeopleDataLabsClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.pdl_client = PDLPY(self.api_key)

    def person_enrich(
        self,
        pdl_id: str | None = None,
        name: str | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
        middle_name: str | None = None,
        location: str | None = None,
        street_address: str | None = None,
        locality: str | None = None,
        region: str | None = None,
        country: str | None = None,
        postal_code: str | None = None,
        company: str | None = None,
        school: str | None = None,
        phone: str | None = None,
        email: str | None = None,
        email_hash: str | None = None,
        profile: str | None = None,
        lid: str | None = None,
        birth_date: str | None = None,
        data_include: str | None = None,
        pretty: bool = False,
        min_likelihood: int = 2,
        include_if_matched: bool = False,
        required: str | None = None,
        titlecase: bool = False,
    ) -> PersonEnrichmentResponse | None:
        """
        It will return the matching person record if the LinkedIn URL passed to it exists in our dataset.
        https://docs.peopledatalabs.com/docs/quickstart-person-enrichment-api

        Args:
        https://docs.peopledatalabs.com/docs/input-parameters-person-enrichment-api
        """
        try:
            params = {
                "pdl_id": pdl_id,
                "name": name,
                "first_name": first_name,
                "last_name": last_name,
                "middle_name": middle_name,
                "location": location,
                "street_address": street_address,
                "locality": locality,
                "region": region,
                "country": country,
                "postal_code": postal_code,
                "company": company,
                "school": school,
                "phone": phone,
                "email": email,
                "email_hash": email_hash,
                "profile": profile,
                "lid": lid,
                "birth_date": birth_date,
                "data_include": data_include,
                "pretty": pretty,
                "min_likelihood": min_likelihood,
                "include_if_matched": include_if_matched,
                "required": required,
                "titlecase": titlecase,
            }
            response = self.pdl_client.person.enrichment(**params).json()
            if response["status"] == 200:
                record = response["data"]
                return PersonEnrichmentResponse(**record)
        except (Exception, pydantic.ValidationError) as e:
            logger.exception(f"Error in PeopleDataLabsClient request: {e}")
            return None

    def person_identify(
        self,
        profile: str | None = None,
        email: str | None = None,
        phone: str | None = None,
        email_hash: str | None = None,
        lid: str | None = None,
        street_address: str | None = None,
        locality: str | None = None,
        region: str | None = None,
        country: str | None = None,
        postal_code: str | None = None,
        company: str | None = None,
        name: str | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
    ) -> PersonIdentityResponse | None:
        """
        It allows you to use broad search inputs to retrieve multiple records from our person dataset
        https://docs.peopledatalabs.com/docs/quickstart-person-identify-api

        Args:
        https://docs.peopledatalabs.com/docs/input-parameters-person-identify-api
        """
        try:
            params = {
                "profile": profile,
                "email": email,
                "phone": phone,
                "email_hash": email_hash,
                "lid": lid,
                "street_address": street_address,
                "locality": locality,
                "region": region,
                "country": country,
                "postal_code": postal_code,
                "company": company,
                "name": name,
                "first_name": first_name,
                "last_name": last_name,
            }
            response = self.pdl_client.person.identify(**params).json()
            if response["status"] == 200:
                record = response["matches"]
                return PersonIdentityResponse(**record)
        except (Exception, pydantic.ValidationError) as e:
            logger.exception(f"Error in PeopleDataLabsClient request: {e}")
            return None

    def person_search(
        self,
        query: str | None = None,
        sql: str | None = None,
        size: int = 1,
        count_only: bool = False,
        scroll_token: str | None = None,
        dataset: str = "resume",
        titlecase: bool = False,
        data_include: str | None = None,
        pretty: bool = False,
    ) -> SearchResponse | None:
        """
        It gives you access to every profile in our full Person Dataset, which you can filter and segment using a search query.
        https://docs.peopledatalabs.com/docs/quickstart-person-search-api

        Args:
        https://docs.peopledatalabs.com/docs/input-parameters-person-search-api
        """
        try:
            params = {
                "query": query,
                "sql": sql,
                "size": size,
                "count_only": count_only,
                "scroll_token": scroll_token,
                "dataset": dataset,
                "titlecase": titlecase,
                "data_include": data_include,
                "pretty": pretty,
            }
            response = self.pdl_client.person.search(**params).json()
            if response["status"] == 200:
                record = response
                return SearchResponse(**record)
        except (Exception, pydantic.ValidationError) as e:
            logger.exception(f"Error in PeopleDataLabsClient request: {e}")
            return None

    def company_search(
        self,
        query: str | None = None,
        sql: str | None = None,
        size: int = 1,
        count_only: bool = False,
        scroll_token: str | None = None,
        titlecase: bool = False,
        pretty: bool = False,
    ) -> SearchResponse | None:
        """
        It gives you access to every record in our full Company Dataset, which you can filter and segment using a search query
        https://docs.peopledatalabs.com/docs/quickstart-company-search-api

        Args:
        https://docs.peopledatalabs.com/docs/input-parameters-company-search-api
        """
        try:
            params = {
                "query": query,
                "sql": sql,
                "size": size,
                "count_only": count_only,
                "scroll_token": scroll_token,
                "titlecase": titlecase,
                "pretty": pretty,
            }
            response = self.pdl_client.person.search(**params).json()
            if response["status"] == 200:
                record = response
                return SearchResponse(**record)
        except (Exception, pydantic.ValidationError) as e:
            logger.exception(f"Error in PeopleDataLabsClient request: {e}")
            return None

    def company_enrich(
        self,
        pdl_id: str | None = None,
        name: str | None = None,
        profile: str | None = None,
        ticker: str | None = None,
        website: str | None = None,
        location: str | None = None,
        street_address: str | None = None,
        locality: str | None = None,
        region: str | None = None,
        country: str | None = None,
        postal_code: str | None = None,
        data_include: str | None = None,
        pretty: bool = False,
        min_likelihood: int = 2,
        include_if_matched: bool = False,
        required: str | None = None,
        titlecase: bool = False,
    ) -> CompanyEnrichmentResponse | None:
        """
        The API will return the matching person record if the LinkedIn URL passed to it exists in our dataset.
        https://docs.peopledatalabs.com/docs/output-response-company-enrichment-api

        Args:
        https://docs.peopledatalabs.com/docs/input-parameters-company-enrichment-api
        """
        try:
            params = {
                "pdl_id": pdl_id,
                "name": name,
                "location": location,
                "street_address": street_address,
                "locality": locality,
                "region": region,
                "country": country,
                "postal_code": postal_code,
                "profile": profile,
                "data_include": data_include,
                "pretty": pretty,
                "min_likelihood": min_likelihood,
                "include_if_matched": include_if_matched,
                "required": required,
                "titlecase": titlecase,
                "ticker": ticker,
                "website": website,
            }
            response = self.pdl_client.company.enrichment(**params).json()
            if response["status"] == 200:
                record = response
                return CompanyEnrichmentResponse(**record)
        except (Exception, pydantic.ValidationError) as e:
            logger.exception(f"Error in PeopleDataLabsClient request: {e}")
            return None

    def ip_enrich(
        self,
        ip: str,
        return_ip_location: bool = False,
        return_ip_metadata: bool = False,
        return_person: bool = False,
        return_if_unmatched: bool = False,
        titlecase: bool = False,
        pretty: bool = False,
    ) -> IPEnrichmentResponse | None:
        try:
            params = {
                "ip": ip,
                "return_ip_location": return_ip_location,
                "return_ip_metadata": return_ip_metadata,
                "return_person": return_person,
                "return_if_unmatched": return_if_unmatched,
                "titlecase": titlecase,
                "pretty": pretty,
            }
            response = self.pdl_client.ip(**params).json()
            if response["status"] == 200:
                record = response
                return IPEnrichmentResponse(**record)
        except (Exception, pydantic.ValidationError) as e:
            logger.exception(f"Error in PeopleDataLabsClient request: {e}")
            return None
