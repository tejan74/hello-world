import pydantic


class PersonEnrichmentResponse(pydantic.BaseModel):
    id: str | None = None
    full_name: str | None = None
    sex: str | None = None
    linkedin_url: str | None = None
    industry: str | None = None
    job_title: str | None = None
    job_title_role: str | None = None
    job_title_sub_role: str | None = None
    job_title_levels: list | None = None
    job_company_name: str | None = None
    job_company_website: str | None = None
    location_name: str | None = None
    birth_date: str | None = None
    birth_year: str | None = None
    countries: list | None = None
    education: list | None = None
    emails: list | None = None
    experience: list | None = None
    facebook_id: str | None = None
    facebook_url: str | None = None
    facebook_username: str | None = None
    first_name: str | None = None
    github_url: str | None = None
    github_username: str | None = None
    interests: list | None = None
    job_company_facebook_url: str | None = None
    job_company_founded: int | None = None
    job_company_id: str | None = None
    job_company_industry: str | None = None
    job_company_linkedin_id: str | None = None
    job_company_linkedin_url: str | None = None
    job_company_location_address_line_2: str | None = None
    job_company_location_continent: str | None = None
    job_company_location_country: str | None = None
    job_company_location_geo: str | None = None
    job_company_location_locality: str | None = None
    job_company_location_metro: str | None = None
    job_company_location_name: str | None = None
    job_company_location_postal_code: str | None = None
    job_company_location_region: str | None = None
    job_company_location_street_address: str | None = None
    job_company_size: str | None = None
    job_company_twitter_url: str | None = None
    job_last_updated: str | None = None
    job_last_changed: str | None = None
    job_last_verified: str | None = None
    job_start_date: str | None = None
    last_initial: str | None = None
    last_name: str | None = None
    linkedin_id: str | None = None
    linkedin_username: str | None = None
    location_address_line_2: str | None = None
    location_continent: str | None = None
    location_country: str | None = None
    location_geo: str | None = None
    location_last_updated: str | None = None
    location_locality: str | None = None
    location_metro: str | None = None
    location_names: list | None = None
    location_postal_code: str | None = None
    location_region: str | None = None
    location_street_address: str | None = None
    middle_initial: str | None = None
    middle_name: str | None = None
    mobile_phone: str | None = None
    personal_emails: list | None = None
    phone_numbers: list | None = None
    profiles: list | None = None
    regions: list | None = None
    skills: list | None = None
    street_addresses: list | None = None
    twitter_url: str | None = None
    twitter_username: str | None = None
    version_status: dict | None = None
    work_email: pydantic.EmailStr | None = None
    model_config = pydantic.ConfigDict(
        extra="allow",
        use_enum_values=True,
    )


class PersonIdentityResponse(pydantic.BaseModel):
    data: dict | None = None
    match_score: int | None = None
    matched_on: list | None = None


class SearchResponse(pydantic.BaseModel):
    status: int
    data: list | None = None
    scroll_token: str | None = None
    total: int | None = None


class CompanyEnrichmentResponse(pydantic.BaseModel):
    status: int
    id: int | None = None
    name: str | None = None
    likelihood: int | None = None
    matched: list | None = None
    model_config = pydantic.ConfigDict(
        extra="allow",
    )


class IPData(pydantic.BaseModel):
    ip: dict | None = None
    company: dict | None = None
    person: dict | None = None
    dataset_version: str | None = None
    model_config = pydantic.ConfigDict(
        extra="allow",
    )


class IPEnrichmentResponse(pydantic.BaseModel):
    status: int
    data: IPData | None = None
