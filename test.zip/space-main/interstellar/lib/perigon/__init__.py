from datetime import datetime
from lib.http import HttpLib  # Assuming HttpLib is a custom HTTP client wrapper


class PerigonClient(HttpLib):
    def __init__(self, api_key: str, base_url=None, query_params=None, headers=None):
        self.api_key = api_key
        if base_url is None:
            base_url = "https://api.goperigon.com/v1"
        self.base_url = base_url
        if headers is None:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            }
        self.headers = headers
        super().__init__(base_url=base_url, query_params=query_params, headers=headers)

    def get_articles(self, title: str, query: str, from_date: datetime, to_date: datetime):
        # Calculate the dates
        to_date = to_date.strftime("%Y-%m-%d")
        from_date = from_date.strftime("%Y-%m-%d")

        params = {
            "q": query,
            "title": title,
            "from": from_date,
            "to": to_date,
            "apiKey": self.api_key,
        }

        # Make the GET request
        response = self.request(method="GET", path="/all?", query_params=params)
        return response
