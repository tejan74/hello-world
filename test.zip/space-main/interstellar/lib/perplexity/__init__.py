import config

from typing import Literal, Optional
import openai

SupportedModel = Literal[
    "codellama-34b-instruct", 
    "llama-2-70b-chat", 
    "mistral-7b-instruct", 
    "mixtral-8x7b-instruct", 
    "pplx-7b-chat", 
    "pplx-70b-chat", 
    "pplx-7b-online",
    "pplx-70b-online"
]

class ApiClient():
    def __init__(self, model: SupportedModel, key: Optional[str] = None):
        # Assign model or use default model 
        self.model = model

        # TODO (ani): check if model is a valid supported model

        # Accept overwritten key for client or use default
        self.key = key or config.get_parameter("PERPLEXITY_API_KEY")
        if self.key is None:
            raise ValueError("PERPLEXITY_API_KEY environment variable must be set or key must be provided")
        
        # Setup OpenAI client using key
        self.client = openai.OpenAI(api_key=self.key, base_url="http://api.perplexity.ai")
    
    # Perplexity can use the OpenAI client, so we're jut going to import chat from there
    from lib.open_ai._chat import completion as chat
