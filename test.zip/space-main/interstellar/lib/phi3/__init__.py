from typing import Literal
import requests
from util.logger import interstellar_logger
import config

logger = interstellar_logger(__name__)


class ApiClient:
    def __init__(self, api_key: str | None = None) -> None:
        self.api_key = api_key or config.get_parameter("AZURE_PHI3_API_TOKEN")

        if self.api_key is None:
            raise Exception("No API key provided")

        self.api_url = "https://phi-3-medium-128k-instruct-4bgd.eastus2.models.ai.azure.com/v1/chat/completions"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def completion(
        self,
        user_query: str,
        system_prompt: str | None = None,
        output_format: Literal["text", "json_object"] = "text",
        temperature: float = 0.75,
        frequency_penalty: float = 0,
        presence_penalty: float = 0,
        max_tokens: int = 300,
        top_p: float = 1,
    ):
        system_message = (
            {"role": "system", "content": system_prompt} if system_prompt else None
        )
        user_message = {"role": "user", "content": user_query}

        messages = [message for message in [system_message, user_message] if message]

        data = {
            "messages": messages,
            "frequency_penalty": frequency_penalty,
            "presence_penalty": presence_penalty,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "response_format": {"type": output_format},
        }

        try:
            response = requests.post(self.api_url, headers=self.headers, json=data)
            response.raise_for_status()  # Raises HTTPError for bad responses

            result = response.json()

            # Extract content from the result
            content = (
                result.get("choices", [{}])[0].get("message", {}).get("content", "")
            )

            if output_format == "text":
                return content

            return result

        except requests.HTTPError as http_err:
            logger.error(f"HTTP error occurred: {http_err}")
            raise
        except requests.RequestException as req_err:
            logger.error(f"Request error occurred: {req_err}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            raise
