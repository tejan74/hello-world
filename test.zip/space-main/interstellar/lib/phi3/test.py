import unittest
from lib import phi3

class TestPhi3(unittest.TestCase):
    def test(self):
        phi3_model = phi3.ApiClient()
        response = phi3_model.completion("Who is the president of India?")
        print(response)

if __name__ == '__main__':
    unittest.main()
