from lib.http import HttpLib
from lib.predictleads.types import PredictLeadsAPIResponse
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class PredictLeadsClient(HttpLib):
    def __init__(
        self,
        api_key: str,
        api_token: str,
        base_url=None,
        query_params=None,
        headers=None,
    ):
        self.api_key = api_key
        self.api_token = api_token
        if base_url is None:
            base_url = "https://predictleads.com/api/v3/"
        if headers is None:
            headers = {
                "X-Api-Key": self.api_key,
                "X-Api-Token": self.api_token,
                "Content-Type": "application/json",
            }
        super().__init__(
            base_url=base_url,
            query_params=query_params,
            headers=headers,
        )

    def retrieve_company(
        self, domain: str, page: int = 1, limit: int = 100
    ) -> PredictLeadsAPIResponse | None:
        """
        Retrieve company data by domain name.
        https://docs.predictleads.com/v3/api_endpoints/companies_dataset/retrieve_company
        Args:
        domain (str): The domain name of the company.
        page (int): The page number of the results to retrieve.
        limit (int): The number of results to retrieve per page.
        """
        query_params: dict = {
            "page": page,
            "limit": limit,
        }
        response = self.request(
            method="GET",
            path=f"companies/{domain}",
            query_params=query_params,
        )
        if response is not None:
            company_data = response
            # Process the company data here
            return PredictLeadsAPIResponse(**company_data)
        else:
            logger.error(f"Failed to retrieve company data. Status code: {response}")
            return None

    def retrieve_company_news_events(
        self, domain: str
    ) -> PredictLeadsAPIResponse | None:
        """
        Retrieve news events data for a company by domain name.
        https://docs.predictleads.com/v3/api_endpoints/news_events_dataset
        Args:
        domain (str): The domain name of the company.
        """
        response = self.request(method="GET", path=f"companies/{domain}/news_events")
        if response is not None:
            news_events_data = response
            # Process the news events data here
            return PredictLeadsAPIResponse(**news_events_data)
        else:
            logger.error(
                f"Failed to retrieve news events data. Status code: {response}"
            )
            return None

    def retrieve_financing_events(
        self, domain: str, page: int = 1, limit: int = 100
    ) -> PredictLeadsAPIResponse | None:
        """
        Retrieve financing events data for a company by domain name.
        https://docs.predictleads.com/v3/api_endpoints/financing_events_dataset
        Args:
        domain (str): The domain name of the company.
        page (int): The page number of the results to retrieve.
        limit (int): The number of results to retrieve per page.
        """
        query_params: dict = {
            "page": page,
            "limit": limit,
        }

        response = self.request(
            method="GET",
            path=f"/companies/{domain}/financing_events",
            query_params=query_params,
        )
        if response is not None:
            financing_events_data = response
            # Process the financing events data here
            return PredictLeadsAPIResponse(**financing_events_data)
        else:
            logger.error(
                f"Failed to retrieve financing events data. Status code: {response}"
            )
            return None

    def retrieve_job_openings(
        self,
        domain: str,
        categories: list | None = None,
        Items: str | None = None,
        with_job_descriptions: bool = False,
        active_only: bool = False,
        not_closed: bool = False,
        first_seen_at_from: str | None = None,
        first_seen_at_until: str | None = None,
        last_seen_at_from: str | None = None,
        last_seen_at_until: str | None = None,
        with_description_only: bool = False,
        with_location_only: bool = False,
        page: int = 1,
        limit: int = 100,
    ) -> PredictLeadsAPIResponse | None:
        """
        Retrieve a list of company's Job Openings data by domain name.
        https://docs.predictleads.com/v3/api_endpoints/job_openings_dataset
        """
        query_params: dict = {
            "categories": categories,
            "Items": Items,
            "with_job_descriptions": with_job_descriptions,
            "active_only": active_only,
            "not_closed": not_closed,
            "first_seen_at_from": first_seen_at_from,
            "first_seen_at_until": first_seen_at_until,
            "last_seen_at_from": last_seen_at_from,
            "last_seen_at_until": last_seen_at_until,
            "with_description_only": with_description_only,
            "with_location_only": with_location_only,
            "page": page,
            "limit": limit,
        }

        response = self.request(
            method="GET",
            path=f"/companies/{domain}/job_openings",
            query_params=query_params,
        )
        if response is not None:
            job_openings_data = response
            # Process the job openings data here
            return PredictLeadsAPIResponse(**job_openings_data)
        else:
            logger.error(
                f"Failed to retrieve job openings data. Status code: {response}"
            )
            return None

    def retrieve_technologies(
        self, page: int = 1, limit: int = 100
    ) -> PredictLeadsAPIResponse | None:
        """
        Retrieve a list of Technologies ordered by creation date ascending.
        https://docs.predictleads.com/v3/api_endpoints/technologies_dataset/retrieve_technologies
        """
        query_params: dict = {
            "page": page,
            "limit": limit,
        }
        response = self.request(
            method="GET",
            path=f"technologies",
            query_params=query_params,
        )
        if response is not None:
            technologies_data = response
            # Process the technologies data here
            return PredictLeadsAPIResponse(**technologies_data)
        else:
            logger.error(
                f"Failed to retrieve technologies data. Status code: {response}"
            )
            return None

    def retrieve_website_evolution(
        self, domain: str, page: int = 1, limit: int = 100
    ) -> PredictLeadsAPIResponse | None:
        """
        Retrieve website evolution data for a company by domain name.
        https://docs.predictleads.com/v3/api_endpoints/website_evolution_dataset
        """
        query_params: dict = {
            "page": page,
            "limit": limit,
        }
        response = self.request(
            method="GET",
            path=f"/companies/{domain}/website_evolution",
            query_params=query_params,
        )
        if response is not None:
            website_evolution_data = response
            # Process the website evolution data here
            return PredictLeadsAPIResponse(**website_evolution_data)
        else:
            logger.error(
                f"Failed to retrieve website evolution data. Status code: {response}"
            )
            return None

    def retrieve_github_repositories(
        self, domain: str, page: int = 1, limit: int = 100
    ) -> PredictLeadsAPIResponse | None:
        """
        Retrieve GitHub repositories data for a company by domain name.
        https://docs.predictleads.com/v3/api_endpoints/github_repositories_dataset/retrieve_company_s_github_repositories
        """
        query_params: dict = {
            "page": page,
            "limit": limit,
        }
        response = self.request(
            method="GET",
            path=f"/companies/{domain}/github_repositories",
            query_params=query_params,
        )
        if response is not None:
            github_repositories_data = response
            # Process the GitHub repositories data here
            return PredictLeadsAPIResponse(**github_repositories_data)
        else:
            logger.error(
                f"Failed to retrieve GitHub repositories data. Status code: {response}"
            )
            return None
