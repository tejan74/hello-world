import pydantic


class DataModel(pydantic.BaseModel):
    id: str | None = None
    type: str | None = None
    attributes: dict | None = None
    relationships: dict | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class PredictLeadsAPIResponse(pydantic.BaseModel):
    data: list[DataModel] | None = None
    included: list | None = None
    model_config = pydantic.ConfigDict(extra="allow")
