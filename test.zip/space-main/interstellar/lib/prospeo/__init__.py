from typing import Literal
from lib.http import HttpLib
from lib.prospeo.types import (
    AccountInformationResponse,
    DomainSearchResponse,
    EmailCountResponse,
    EmailFinderResponse,
    EmailVerifierResponse,
    LinkedInEmailFinderResponse,
)
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class ProspeoClient(HttpLib):
    def __init__(self, api_key: str, base_url=None, query_params=None, headers=None):
        self.api_key = api_key
        if base_url is None:
            base_url = "https://api.prospeo.io"  # Update to the correct base URL
        if headers is None:
            headers = {
                "X-KEY": self.api_key,
                "Content-Type": "application/json",
            }
        super().__init__(base_url=base_url, query_params=query_params, headers=headers)

    def domain_search(
        self,
        company: str,
        limit: int = 1000,
        email_type: Literal["all", "professional", "generic"] = "all",
        company_enrichment: bool = False,
    ) -> DomainSearchResponse | None:
        """
        Domain Search: Discover email addresses associated with a domain name, website, or company name.
        https://api.prospeo.io/domain-search

        Args:
        company:
        The name of the company or domain to search. Must be a valid domain name or company name.

        limit:
        The maximum number of results to return. Defaults to 1000.

        email_type:
        The type of email addresses to search for (e.g., 'professional', 'personal', 'all'). Defaults to 'ALL'.

        company_enrichment:
        Whether to include additional company information in the response. Defaults to False.

        Returns:
        DomainSearchResponse | None: The API response with email details or None if the request fails.
        """
        data = self.request(
            method="POST",
            path="/domain-search",
            json={
                "company": company,
                "limit": limit,
                "email_type": email_type,
                "company_enrichment": company_enrichment,
            },
        )
        return DomainSearchResponse(**data) if data is not None else None

    def email_finder(
        self,
        company: str,
        first_name: str | None = None,
        last_name: str | None = None,
        full_name: str | None = None,
    ) -> EmailFinderResponse | None:
        """
        Email Finder: Find an email address associated with a company and a person's name.
        https://prospeo.io/api/email-finder

        Args:
        company:
        The company name to search for. Must be a valid company name.

        first_name:
        The first name of the person. Optional. If provided, it helps to narrow down the search.

        last_name:
        The last name of the person. Optional. If provided, it helps to narrow down the search.

        full_name:
        The full name of the person. Optional. If provided, it can be used instead of first_name and last_name for a more precise search.

        Returns:
        EmailFinderResponse | None: Returns an `EmailFinderResponse` object if the request is successful, or `None` if the request fails.
        """
        data = self.request(
            method="POST",
            path="/email-finder",
            json={
                "company": company,
                "first_name": first_name,
                "last_name": last_name,
                "full_name": full_name,
            },
        )
        return EmailFinderResponse(**data) if data is not None else None

    def email_verifier(
        self,
        email: str,
        email_anon_id: str,  # The ID of the email obtained from the /domain-search endpoint.
    ) -> EmailVerifierResponse | None:
        """
        Email Verifier: Verify the validity of an email address.
        https://prospeo.io/api/email-verifier

        This endpoint allows you to:
        - Check if an email address is VALID, CATCH_ALL, or INVALID.
        - The system performs a thorough check to determine the email's status.
        - Verification costs 0.5 credits per email, except for emails validated via the /domain-search endpoint, where charges apply only if the email is VALID.

        Args:
        email:
        The email address to be verified. Must be a valid email format.

        email_anon_id:
        The ID associated with the email obtained from the /domain-search endpoint. Used to reference the email in the context of the domain search.

        Returns:
        EmailVerifierResponse | None: Returns an `EmailVerifierResponse` object with the verification results if the request is successful, or `None` if the request fails.
        """
        data = self.request(
            method="POST",
            path="/email-verifier",
            json={
                "email": email,
                "email_anon_id": email_anon_id,
            },
        )
        return EmailVerifierResponse(**data) if data is not None else None

    def linkedin_email_finder(
        self, url: str, profile_only: bool | None = None
    ) -> LinkedInEmailFinderResponse | None:
        """
        LinkedIn Email Finder: Extract data from a LinkedIn profile and find a valid verified email.
        https://prospeo.io/api/linkedin-email-finder

        This endpoint allows you to:
        - Retrieve detailed information from a LinkedIn profile in real-time.
        - Obtain data from the company page associated with the LinkedIn profile.
        - Find a valid, verified email address from the lead.
        - Receive all extracted details and the verified email in a clean JSON output, all in one request.

        url:
        The URL of the LinkedIn profile or company page you want to extract data from. Must be a valid LinkedIn URL.

        profile_only:
        Optional parameter to specify whether you only need the data from the LinkedIn profile itself, without including detailed company information and the email. This can reduce the response time.

        Returns:
        LinkedInEmailFinderResponse | None: Returns a `LinkedInEmailFinderResponse` object with the extracted details and verified email if the request is successful, or `None` if the request fails.
        """
        data = self.request(
            method="POST",
            path="/linkedin-email-finder",
            json={
                "url": url,
                "profile_only": profile_only,
            },
        )
        return LinkedInEmailFinderResponse(**data) if data is not None else None

    def email_count(self, domain: str) -> EmailCountResponse | None:
        """
        Email Count: Count the number of emails stored in the database for a given domain.
        https://prospeo.io/api/email-count

        This endpoint allows you to:
        - Retrieve the total number of email addresses associated with the specified domain.

        Args:
        domain:
        The domain for which you want to count the stored email addresses. Must be a valid domain name.

        Returns:
        EmailCountResponse | None: Returns an `EmailCountResponse` object with the email count if the request is successful, or `None` if the request fails.
        """
        data = self.request(method="POST", path="/email-count", json={"domain": domain})
        return EmailCountResponse(**data) if data is not None else None

    def account_information(self) -> AccountInformationResponse | None:
        """
        Retrieve Account Information: Get details about the current user's account usage, remaining credits, plan, and next quota renewal date.
        https://prospeo.io/api/account-information

        This endpoint allows you to:
        - Retrieve information about the current user's account usage.
        - Check the remaining credits available.
        - Find out the current subscription plan.
        - Get the date for the next quota renewal.

        Returns:
        AccountInformationResponse | None: Returns an `AccountInformationResponse` object if the request is successful, or `None` if the request fails.
        """
        data = self.request(method="POST", path="/account-information", json=None)
        return AccountInformationResponse(**data) if data is not None else None
