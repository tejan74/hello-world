import pydantic
import datetime
import enum


class Verification(pydantic.BaseModel):
    status: str | None = None
    last_verified_at: datetime.datetime | None = None

    model_config = pydantic.ConfigDict(extra="allow")


class EmailList(pydantic.BaseModel):
    email: str | None = None
    email_anon_id: str | None = None
    email_type: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    verification: Verification | None = None

    model_config = pydantic.ConfigDict(extra="allow")


class Meta(pydantic.BaseModel):
    search_id: str | None = None
    total_emails: int | None = None
    remaining_emails: int | None = None
    more_results: bool | None = None
    domain: str | None = None
    limit: int | None = None

    model_config = pydantic.ConfigDict(extra="allow")


class DomainSearchResponse(pydantic.BaseModel):
    error: bool | None = None
    response: dict | None = None  # Allows for flexible extra fields
    email_list: list[EmailList] | None = None
    company_enrichment: str | None = None
    meta: Meta | None = None
    extra: dict | None = None  # Holds any additional fields

    model_config = pydantic.ConfigDict(extra="allow")


class EmailFinder(pydantic.BaseModel):
    free: bool | None = None
    email: str | None = None
    email_anon_id: str | None = None
    email_status: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    domain: str | None = None
    total_emails: int | None = None

    model_config = pydantic.ConfigDict(extra="allow")


class EmailFinderResponse(pydantic.BaseModel):
    error: bool
    response: EmailFinder | None = None  # Forward declaration for nested model


class EmailVerifier(pydantic.BaseModel):
    free: bool | None = None
    email: str | None = None
    email_anon_id: str | None = None
    domain: str | None = None
    email_status: str | None = None
    email_sub_status: str | None = None
    catch_all_recovery: bool | None = None
    valid_format: bool | None = None
    disposable: bool | None = None
    gibberish: bool | None = None
    type: str | None = None
    catch_all: bool | None = None
    mx_record_present: bool | None = None
    mx_record_main: str | None = None
    mx_record_list: list | None = None
    smtp_provider: str | None = None
    total_emails: int | None = None

    model_config = pydantic.ConfigDict(extra="allow")


class EmailVerifierResponse(pydantic.BaseModel):
    error: bool
    response: EmailVerifier | None = None


class Location(pydantic.BaseModel):
    country: str | None = None
    country_code: str | None = None
    state: str | None = None
    city: str | None = None
    timezone: str | None = None
    timezone_offset: str | None = None
    postal_code: str | None = None
    raw: str | None = None

    model_config = pydantic.ConfigDict(
        extra="allow"
    )  # Allows extra fields in this model


# class CompanyModel(pydantic.BaseModel):
#     name: str | None = None
#     is_catch_all: bool | None = None
#     size: str | None = None
#     logo: str | None = None
#     linkedin: str | None = None
#     website: str | None = None
#     common_email_pattern: str | None = None
#     industry: str | None = None
#     founded_in: int | None = None
#     description: str | None = None
#     location: Location | None = None

#     model_config = pydantic.ConfigDict(
#         extra="allow"
#     )  # Allows extra fields in this model


# class WorkExperienceModel(pydantic.BaseModel):
#     company: Optional[Dict[str, Union[int, str]]] = None  # Adapt to company structure
#     date: Optional[Dict[str, Dict[str, Optional[int]]]] = (
#         None  # Adapt to date structure
#     )
#     profile_positions: Optional[
#         List[Dict[str, Union[str, Dict[str, Optional[int]]]]]
#     ] = None  # Adapt to position structure

#     model_config = pydantic.ConfigDict(
#         extra="allow"
#     )  # Allows extra fields in this model


# class EducationModel(pydantic.BaseModel):
#     date: Optional[Dict[str, Dict[str, Optional[int]]]] = (
#         None  # Adapt to date structure
#     )
#     school: Optional[Dict[str, Union[str, str]]] = None  # Adapt to school structure
#     degree_name: str | None = None
#     field_of_study: str | None = None

#     model_config = pydantic.ConfigDict(
#         extra="allow"
#     )  # Allows extra fields in this model


# class LanguageModel(pydantic.BaseModel):
#     primary_locale: Optional[Dict[str, str]] = None  # Adapt to locale structure
#     supported_locales: Optional[List[Dict[str, str]]] = None
#     profile_languages: Optional[List[str]] = None

#     model_config = pydantic.ConfigDict(
#         extra="allow"
#     )  # Allows extra fields in this model


class LinkedInData(pydantic.BaseModel):
    email_list: list[EmailList] | None = None
    work_experience: list | None = None
    education: list | None = None
    languages: list | None = None


class LinkedInEmailFinderResponse(pydantic.BaseModel):
    error: bool
    response: LinkedInData

    model_config = pydantic.ConfigDict(extra="allow")


class Count(pydantic.BaseModel):
    count: int


class EmailCountResponse(pydantic.BaseModel):
    error: bool
    response: Count

    model_config = pydantic.ConfigDict(extra="allow")


class AccountInfo(pydantic.BaseModel):
    current_plan: str
    remaining_credits: int
    used_credits: int
    next_quota_renewal_days: int
    next_quota_renewal_date: datetime.datetime

    model_config = pydantic.ConfigDict(extra="allow")


class AccountInformationResponse(pydantic.BaseModel):
    error: bool
    response: AccountInfo

    model_config = pydantic.ConfigDict(extra="allow")
