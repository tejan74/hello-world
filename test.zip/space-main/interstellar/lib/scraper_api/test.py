import unittest
from lib.scraper_api import ApiClient


class Test(unittest.TestCase):
    def test_scraper(self):
        scraper = ApiClient()
        scraper.load_url("http://google.com/")
        print(scraper.get_raw())


if __name__ == "__main__":
    unittest.main()
