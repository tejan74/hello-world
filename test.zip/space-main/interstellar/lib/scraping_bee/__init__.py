import re
from typing import Any
from urllib.parse import urljoin
from bs4 import BeautifulSoup, Tag
import config
from scrapingbee import ScrapingBeeClient
from util.logger import interstellar_logger


logger = interstellar_logger(__name__)


class ApiClient:
    def __init__(self, api_key: str | None = None) -> None:
        self.api_key = api_key or config.get_parameter("SCRAPING_BEE_API_KEY")
        self.client = ScrapingBeeClient(api_key=self.api_key)

    def load_url(
        self, url: str, headers: dict[str, Any] = {}, params: dict[str, Any] = {}
    ):
        """
        Get the content of the url using scraping_bee
        :param url: The URL for which the content needs to be fetched
        :param headers: Headers to pass with the request
        """
        logger.info(f"Loading url {url}")
        self.url = url
        self.response = self.client.get(url=url, params=params, headers=headers)
        self.soup = BeautifulSoup(self.response.text, "html.parser")
        return self.response.status_code

    def get_meta(self):
        """
        Get the meta data of the page. title, description
        """
        if self.soup is None:
            raise ValueError("No response found. Load the url first.")

        title = self.soup.title.string if self.soup.title else ""

        description = self.soup.find("meta", attrs={"name": "description"})
        description = description.attrs["content"] if description else ""  # type: ignore

        return {"title": title, "description": description}

    def scrape_full_text(self):
        """
        Scrape the full text from the page
        """
        if self.soup is None:
            return ""

        body = self.soup.find("body")

        if body is None:
            return ""

        text = body.get_text()
        return text

    def scrape_links(self):
        """
        Scrape all the links from the page
        """
        if self.soup is None:
            raise ValueError("No response found. Load the url first.")

        links = []
        for link in self.soup.find_all("a"):
            links.append(
                {
                    "link": link.get("href"),
                    "text": link.get_text(),
                }
            )

        return links

    def scrape_images(self):
        """
        Scrape all the images from the page
        """
        if self.soup is None:
            raise ValueError("No response found. Load the URL first.")

        images = []
        base_url = self.get_base_uri()

        for img in self.soup.find_all("img"):
            src = img.get("src")
            alt = img.get("alt")

            # Validate and handle the src attribute
            if not src:
                continue  # Skip images with no src

            # Handle absolute URLs and relative URLs
            if not src.startswith("data:image/"):
                src = urljoin(base_url, src)

            images.append(
                {
                    "src": src,
                    "alt": alt,
                }
            )

        return images

    def get_raw(self):
        """
        Get the raw response from the API
        """
        if self.response is None:
            raise ValueError("No response found. Load the url first.")

        return self.response.text

    def get_base_uri(self):
        """
        Get the base uri of the page
        """
        if self.soup is None:
            raise ValueError("No response found. Load the url first.")

        base = self.soup.find("base")

        if isinstance(base, Tag):
            return str(base["href"])
        else:
            return self.url
