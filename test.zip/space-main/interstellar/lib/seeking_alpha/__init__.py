from datetime import datetime
import random
import time
from typing import Any, Literal
import pydash
import requests
import config

# Default Rapid API Host for Seeking Alpha
DEFAULT_RAPIDAPI_HOST = "seeking-alpha.p.rapidapi.com"

# Rapid API Base URL
RAPID_API_BASE_URL = "https://seeking-alpha.p.rapidapi.com"

# Seeking Alpha Base Url
SEEKING_ALPHA_BASE_URL = "https://seekingalpha.com"

# Seeking Alpha Base Pdf Api
SEEKING_ALPHA_BASE_PDF_API_URL = f"{SEEKING_ALPHA_BASE_URL}/api/v3/filings"

# Filing Catergories
FilingCategoryKeys = Literal["all", "financials", "news", "proxies", "tenders", "ownership", "others"]

# Type Keys
TypeKeys = Literal["people", "symbols", "pages"]

class ApiClient:
    # Initialize
    def __init__(self, key: str | None = None) -> None:
        # Accept overwritten key for client or use default
        self._key = key or config.get_parameter("RAPIDAPI_API_KEY")

        # Base headers required for every call
        self.headers = {
            "X-RapidAPI-Key": self._key,
            "X-RapidAPI-Host": DEFAULT_RAPIDAPI_HOST
        }

        # Set base url
        self.base_url = RAPID_API_BASE_URL

    # API call
    def _make_request(self, path: str, query_string: dict[str, Any]):
        response = requests.get(url = self.base_url + path, headers = self.headers, params = query_string)
        
        return response.json()
    
    # Get new headers for calling seeking alpha directly
    def _get_seeking_alpha_headers(self):
        response = requests.get(SEEKING_ALPHA_BASE_URL)

        # Extract the headers from the response
        seeking_alpha_headers = response.headers

        headers = {
            'Host': 'seekingalpha.com',
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:122.0) Gecko/20100101 Firefox/122.0',
            'Cache-Control': 'no-cache',
            'Accept': '*/*',
            "Accept-Language": "en-US,en;q=0.5",
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Cookie': pydash.get(seeking_alpha_headers, "set-cookie")
        }

        return headers

    # Symbols
    def get_symbols(self, query: str, type: list[TypeKeys] = ["symbols"], size: int | None = 1):
        path = "/v2/auto-complete"
        query_string = {"query": query, "type": pydash.join(type, ","), "size": size}

        return self._make_request(path,query_string)
    
    # SEC Filings
    def get_sec_filings(self, symbol: str, filing_category: FilingCategoryKeys):
        path = "/symbols/get-sec-filings"
        query_string = {"symbol": symbol, "filing_category": filing_category}

        return self._make_request(path,query_string)
    
    # SEC Filings Details
    def get_sec_details(self, filing_id: str):
        path = f"{SEEKING_ALPHA_BASE_PDF_API_URL}/{filing_id}?include=ticker"

        headers = self._get_seeking_alpha_headers()

        response = requests.get(path, headers=headers)

        return response.json()
    
    # Transcripts
    def get_transcripts(self, id: str, from_year: int, to_year: int | None = None, size: int | None = 40, number: int | None = 1):
        path = "/transcripts/v2/list"
        from_timestamp = int(datetime(from_year, 1, 1).timestamp())
        query_string = {"id": id, "since": from_timestamp, "size": size, "number": number}

        if to_year:
            to_timestamp = int(datetime(to_year, 12, 31).timestamp())
            query_string["until"] = to_timestamp

        return self._make_request(path,query_string)
    
    # Get 10K PDF
    def get_annual_report(self, name: str, symbol: str | None = None, retries: int = 3, wait: int = 5) -> str | None:
        for _ in range(retries):
            # Retrieve symbol for the given name
            if not symbol:
                response = self.get_symbols(query=name)
                symbol = pydash.get(response, "symbols[0].name")

            if symbol:
                # TODO: Do this more cleanly
                symbol = symbol.strip().strip("<b>").strip("</b>")
                response = self.get_sec_filings(symbol=symbol, filing_category="financials")
                filings = pydash.get(response, "data")

                if filings and isinstance(filings, list):
                    for filing in filings:
                        time.sleep(random.randint(int(wait * 0.5), int(wait * 1.5)))
                        # Retrieve pdf_id and construct the pdf_url
                        filing_id: str | None = pydash.get(filing, "id")
                        if filing_id:
                            details = self.get_sec_details(filing_id)
                            if pydash.get(details, "data.attributes.sec_code") == "10-K":
                                pdf_path = pydash.get(details, "data.attributes.pdf_path")
                                return pdf_path
                            
        # Return None if no matching condition is met
        return None
    
    # Download 10K's
    def download(self, pdf_link: str, file_path: str):
        headers = self._get_seeking_alpha_headers()
        response = requests.get(url=f"{SEEKING_ALPHA_BASE_URL}{pdf_link}", headers=headers)
        if response.status_code == 200:
            with open(file_path, "wb") as file:
                file.write(response.content)
            return file_path
        else:
            return None

