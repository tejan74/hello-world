import pydash
from typing import Optional
import signal
import atexit
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.webdriver import WebDriver as FirefoxDriver
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.firefox.service import Service as GeckoDriverService
from lib.selenium.constant import GECKO_LATEST_RELEASE_URL


class WebScraper:
    def __init__(self, browser: Optional[WebDriver] = None):
        # The lateest release is stored in orbital_public Data Lake to avoid github rate limiting us

        # TODO: Moved this inside to speed up warm start
        gdm_install = pydash.once(
            GeckoDriverManager(latest_release_url=GECKO_LATEST_RELEASE_URL).install
        )

        if browser is None:
            options = Options()
            options.add_argument("--headless")
            options.add_argument("--disable-gpu")

            self._browser = FirefoxDriver(
                service=GeckoDriverService(gdm_install()), options=options
            )

            self._browser.set_window_size(
                1366, 768
            )  # most common desktop screen resolution (https://www.browserstack.com/guide/ideal-screen-sizes-for-responsive-design)
            self._own_browser = True
            browser = (
                self._browser
            )  # to avoid holding a reference to self in the callback (without this the __del__ won't work as intended)
            close = lambda *args: browser.quit()
            # these are some fail safes to ensure the browser is closed when the program is terminated
            # cuz python doesn't guarantee the __del__ method to be called when the program is terminated
            atexit.register(close)
            signal.signal(signal.SIGTERM, close)
            signal.signal(signal.SIGINT, close)
        else:
            self._browser = browser
            self._own_browser = False

    def __del__(self):
        """Works when there are no reference to this object.
        But it doesn't seems to work when the program is terminated (only tested in mac).
        """
        if self._own_browser:
            self._browser.quit()

    def load_url(self, url):
        self._browser.get(url)

    def scrape_full_text(self):
        texts = self._browser.execute_script(_textRetrieveScript)
        allText = ""
        for text in texts:
            allText += text["text"] + " "

        return allText

    def scrape_links(self):
        links = self._browser.execute_script(_linkRetrieveScript)
        return links

    def maximize_window(self):
        self._browser.maximize_window()

    def get_initial_page_height(self):
        return self._browser.execute_script(_getInitialPageHeightScript)

    def get_window_inner_size(self):
        return self._browser.execute_script(
            "return {width: window.innerWidth, height: window.innerHeight};"
        )

    def save_screenshot(self, screenshot_download_location):
        self._browser.save_screenshot(screenshot_download_location)
        print(f"Screenshot saved to: {screenshot_download_location}")

    def scroll_page(self, scroll_to):
        self._browser.execute_script(f"window.scrollTo(0, {scroll_to});")


_getInitialPageHeightScript = "return Math.max( document.body.scrollHeight, document.body.offsetHeight, document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight);"

_textRetrieveScript = """
function getTextNodePosition(n) {
    const r = document.createRange()
    r.selectNodeContents(n)
    return r.getBoundingClientRect()
} 
function extractText(n) {
    if(["STYLE","SCRIPT","NOSCRIPT"].includes(n.nodeName)) return []
    if(n.nodeType === 3) {
		return [{
            text: n.textContent,
            rect: getTextNodePosition(n)
        }]
	}
	if(n.childNodes && n.childNodes.length > 0) {
		const textNodes = []
		for(const cn of Array.from(n.childNodes)) {
			textNodes.push(...extractText(cn))
		}
		return textNodes
	}
	return []
}
// json parse & stringify is to avoid this error 'selenium.common.exceptions.JavascriptException: Message: Cyclic object value'
return JSON.parse(JSON.stringify(extractText(document.body)))
"""

_linkRetrieveScript = """
function getTextNodePosition(n) {
    const r = document.createRange()
    r.selectNodeContents(n)
    return r.getBoundingClientRect()
} 
function extractLink(n) {
    if(n.nodeName === "A") {
		return [n.href]
	}
	if(n.childNodes && n.childNodes.length > 0) {
		const links = []
		for(const cn of Array.from(n.childNodes)) {
			links.push(...extractLink(cn))
		}
		return links
	}
	return []
}
return JSON.parse(JSON.stringify(extractLink(document.body)))
"""
