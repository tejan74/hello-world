import os

from util.logger import interstellar_logger
import config

logger = interstellar_logger(__name__)


# refer https://github.com/ultrafunkamsterdam/undetected-chromedriver/issues/1306
class ChromeProxy:
    def __init__(
        self, scheme: str, host: str, port: int, username: str = "", password: str = ""
    ):
        self.scheme = scheme
        self.host = host
        self.port = port
        self.username = username
        self.password = password

    def get_path(self) -> str:
        return os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "proxy_extension"
        )

    def create_extension(self, name: str = "Chrome Proxy", version="1.0.0") -> str:
        proxy_folder = self.get_path()

        # check if the directory and files exist
        if os.path.exists(proxy_folder):
            if os.path.exists(f"{proxy_folder}/manifest.json") and os.path.exists(
                f"{proxy_folder}/background.js"
            ):
                return proxy_folder

        os.makedirs(proxy_folder, exist_ok=True)

        # generate manifest (establish extension name and version)
        manifest = ChromeProxy.manifest_json
        manifest = manifest.replace("<ext_name>", name)
        manifest = manifest.replace("<ext_ver>", version)

        # write manifest to extension directory
        with open(f"{proxy_folder}/manifest.json", "w") as f:
            f.write(manifest)

        # generate javascript code (replace some placeholders)
        js = ChromeProxy.background_js
        js = js.replace("<proxy_scheme>", self.scheme)
        js = js.replace("<proxy_host>", self.host)
        js = js.replace("<proxy_port>", str(self.port))
        js = js.replace("<proxy_username>", self.username)
        js = js.replace("<proxy_password>", self.password)

        # write javascript code to extension directory
        with open(f"{proxy_folder}/background.js", "w") as f:
            f.write(js)

        return proxy_folder

    manifest_json = """
    {
        "version": "<ext_ver>",
        "manifest_version": 3,
        "name": "<ext_name>",
        "permissions": [
            "proxy",
            "tabs",
            "storage",
            "webRequest",
            "webRequestAuthProvider"
        ],
        "host_permissions": [
            "<all_urls>"
        ],
        "background": {
            "service_worker": "background.js"
        },
        "minimum_chrome_version": "22.0.0"
    }
    """

    background_js = """
    var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "<proxy_scheme>",
                host: "<proxy_host>",
                port: parseInt("<proxy_port>")
            },
            bypassList: ["localhost"]
        }
    };

    chrome.proxy.settings.set({
        value: config,
        scope: "regular"
    }, function() {});

    function callbackFn(details) {
        return {
            authCredentials: {
                username: "<proxy_username>",
                password: "<proxy_password>"
            }
        };
    }

    chrome.webRequest.onAuthRequired.addListener(
        callbackFn, {
            urls: ["<all_urls>"]
        },
        ['blocking']
    );
    """


class CaptchaSolver:
    def __init__(self, api_key: str, auto_solve: bool | None = False) -> None:
        self.api_key = api_key
        self.auto_solve = auto_solve

    def get_path(self) -> str:
        return f"{config.get_tmp_dir()}/chrome/extension/captcha_solver"

    def create_extension(self, name: str = "Captcha Solver", version="1.0.0") -> str:
        captcha_folder = self.get_path()

        # check if the directory and files exist
        if not os.path.exists(captcha_folder):
            # create the directory and unzip the extension from assets/capsolver.zip
            logger.info("Unzipping captcha solver extension")
            os.makedirs(captcha_folder, exist_ok=True)
            os.system(f"unzip -q assets/capsolver.zip -d {captcha_folder}")

        # replace api_key in assets/config.js
        with open(f"{captcha_folder}/assets/config.js", "r") as f:
            config_js = f.read()
            config_js = config_js.replace("apiKey: '',", f"apiKey: '{self.api_key}',")

            if not self.auto_solve:
                config_js = config_js.replace(
                    "manualSolving: false,", "manualSolving: true,"
                )

        with open(f"{captcha_folder}/assets/config.js", "w") as f:
            f.write(config_js)

        return captcha_folder
