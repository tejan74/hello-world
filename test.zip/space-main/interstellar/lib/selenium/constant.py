GECKO_LATEST_RELEASE_URL = (
    "https://storage.googleapis.com/orbital_public_cache/ff-latest.json"
)
