import base64
import os
import random
import time
from typing import Optional
import config
from lib.selenium.chrome_extensions import CaptchaSolver
from playwright.sync_api import sync_playwright, ProxySettings
import config
from util.logger import interstellar_logger
from bs4 import BeautifulSoup

logger = interstellar_logger(__name__)


class PlaywrightOrbBrowser:
    def __init__(
        self,
        use_proxy: Optional[bool] = False,
        use_captcha_solver: Optional[bool] = False,
        resolution: Optional[str] = "1366,768",
        auto_captcha: Optional[bool] = False,
        record_video: Optional[bool] = False,
        click_type: Optional[str] = "element",
    ):
        # TODO: once we identify which one is the most stable, we can make it the default
        self.click_type = click_type
        # we're using the synchronous running version of playwright, sync_playwright
        self.playwright = sync_playwright().start()

        # Enable proxy for Chromium Browser if requested
        proxy = None
        if use_proxy:
            proxy_url = config.get_parameter("BROWSER_PROXY_URL")
            if not proxy_url:
                logger.error("No proxy url found")
                raise ValueError("No proxy url found")

            # TODO: Have these separated into different config parameters
            scheme, username_password = proxy_url.split("@")[0].split("://")
            username, password = username_password.split(":")
            proxy, port = proxy_url.split("@")[1].split(":")

            proxy = ProxySettings(
                server=f"{scheme}://{proxy}:{port}",
                username=username,
                password=password,
            )

        # Add necessary extensions to Chromium Browser based on config requested
        extensions = []
        if use_captcha_solver:
            api_key = config.get_parameter("CAPTCHA_SOLVER_API_KEY")

            if not api_key:
                logger.error("No captcha solver api key found")
                raise ValueError("No captcha solver api key found")

            captcha_solver = CaptchaSolver(api_key, auto_captcha)
            path = captcha_solver.create_extension()
            extensions.append(path)

        # Launch Chromium Browser with necessary configurations
        resolution = resolution if resolution else "1366,768"
        self.browser = self.playwright.chromium.launch_persistent_context(
            f"{config.get_tmp_dir()}/chrome-data/context",
            viewport={
                "width": int(resolution.split(",")[0]),
                "height": int(resolution.split(",")[1]),
            },
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.5481.105 Safari/537.36",
            locale="en-US",
            args=[
                f"--disable-extensions-except={','.join(extensions)}",
                f"--load-extension={','.join(extensions)}",
                "--headless=new",
            ],
            proxy=proxy,
            record_video_dir=(
                os.path.join(os.getcwd(), f"{config.get_tmp_dir()}/chrome-data/video")
                if record_video
                else None
            ),
        )

        self.page = self.browser.pages[0]
        self.page.set_default_timeout(90000)
        self.page.set_default_navigation_timeout(60000)

        logger.info(
            f"Browser launched with resolution: {resolution}, proxy: {use_proxy}, extensions: {extensions}"
        )

    def close_dialog_modals(self):
        try:
            # Common selectors for dialog modals
            selectors = [
                'div[role="dialog"]',
                "div.modal",
                "div.dialog",
                "div.popup",
                ".modal-dialog",
                ".modal",
                ".popup",
                ".dialog",
                ".alert",
                ".notification",
            ]

            for selector in selectors:
                modals = self.page.query_selector_all(selector)
                for modal in modals:
                    close_buttons = modal.query_selector_all(
                        ".close, .close-button, .btn-close, .btn-dismiss"
                    )
                    if close_buttons:
                        for button in close_buttons:
                            logger.info(
                                f"Closing modal with selector: {selector} and button: {button}"
                            )
                            button.click()
                    else:
                        logger.info(
                            f"Modal found but no close button found for selector: {selector}"
                        )
        except Exception as e:
            logger.error(f"Error while closing dialog modals: {e}")

    def execute_script(self, script):
        return self.page.evaluate(script)

    def load_url(self, url):
        self.page.goto(url)

    def has_captcha(self) -> bool:
        return self.page.query_selector("#capsolver-solver-tip-button") is not None

    def solve_captcha(self):
        if self.has_captcha():
            if self.is_captcha_solved():
                logger.info("Captcha already solved")
                return
            self.page.click("#capsolver-solver-tip-button")
        else:
            logger.error("No captcha found")
            raise ValueError("No captcha found")

    def is_captcha_solved(self):
        element = self.page.query_selector("#capsolver-solver-tip-button")
        return element.get_attribute("data-state") == "solved" if element else False

    def wait_for_captcha(self, max_wait: Optional[int] = 60) -> bool:
        if not self.has_captcha():
            logger.error("No captcha found")
            return False

        remaining_wait_time = max_wait if max_wait else 60
        while remaining_wait_time > 0:
            element = self.page.query_selector("#capsolver-solver-tip-button")
            if element:
                if element.get_attribute("data-state") == "solved":
                    logger.info("Captcha solved")
                    return True
                else:
                    logger.info(
                        f"Waiting for captcha to be solved, state: {element.get_attribute('data-state')}. Polling again in 3 seconds."
                    )
                    time.sleep(3)
                    remaining_wait_time -= 3
            else:
                logger.error("Captcha not found")
                return False

        logger.error("Captcha not solved in time")
        return False

    def get_raw(self):
        content = self.page.content()
        soup = BeautifulSoup(content, "html.parser")

        for data in soup(["style", "script", "svg"]):
            # Remove tags
            data.decompose()

        return str(soup)

    def get_window_inner_size(self):
        return self.page.evaluate(
            "({width: window.innerWidth, height: window.innerHeight})"
        )

    def screenshot_as_base64(self):
        return base64.b64encode(self.page.screenshot(full_page=True)).decode("ascii")

    def save_screenshot(self, screenshot_download_location):
        self.page.screenshot(path=screenshot_download_location)
        print(f"Screenshot saved to: {screenshot_download_location}")

    def get_element_screenshot(self, id=None, css_selector=None):
        if not id and not css_selector:
            raise ValueError("id or css_selector must be provided")
        selector = f"#{id}" if id else css_selector
        if selector:
            element = self.page.locator(selector)
            if element:
                return base64.b64encode(element.screenshot()).decode("ascii")
        return None

    def scroll_to_position(self, scroll_to):
        self.page.evaluate(f"window.scrollTo(0, {scroll_to});")

    def scroll_to_tag(self, tag):
        logger.info(f"Scrolling to tag: {tag}")
        self.page.evaluate(
            f"""
            const elements = document.getElementsByTagName('{tag}');
            if (elements.length > 0) {{
                elements[0].scrollIntoView({{ behavior: "instant", block: "center" }});
            }}
        """
        )

    def scroll_to_element_by_css_selector(self, css_selector):
        logger.info(f"Scrolling to element with css selector: {css_selector}")
        self.page.evaluate(
            f"""
            const element = document.querySelector('{css_selector}');
            if (element) {{
                element.scrollIntoView({{ behavior: "instant"}});
            }}
        """
        )

    def scrape_full_text(self):
        _textRetrieveScript = """
        function getTextNodePosition(n) {
            const r = document.createRange()
            r.selectNodeContents(n)
            return r.getBoundingClientRect()
        } 
        function extractText(n) {
            if(["STYLE","SCRIPT","NOSCRIPT"].includes(n.nodeName)) return []
            if(n.nodeType === 3) {
                return [{
                    text: n.textContent,
                    rect: getTextNodePosition(n)
                }]
            }
            if(n.childNodes && n.childNodes.length > 0) {
                const textNodes = []
                for(const cn of Array.from(n.childNodes)) {
                    textNodes.push(...extractText(cn))
                }
                return textNodes
            }
            return []
        }
        // json parse & stringify is to avoid cyclic object value errors
        return JSON.parse(JSON.stringify(extractText(document.body)))
        """
        texts = self.page.evaluate(_textRetrieveScript)
        allText = " ".join([text["text"] for text in texts])
        return allText

    def scrape_links(self):
        _linkRetrieveScript = """
        function extractLink(n) {
            if(n.nodeName === "A") {
                return [{
                    href: n.href,
                    text: n.innerText,
                }]
            }
            if(n.childNodes && n.childNodes.length > 0) {
                const links = []
                for(const cn of Array.from(n.childNodes)) {
                    links.push(...extractLink(cn))
                }
                return links
            }
            return []
        }
        return JSON.parse(JSON.stringify(extractLink(document.body)))
        """
        links = self.page.evaluate(_linkRetrieveScript)
        return links

    def execute_instruction(self, instruction):
        def human_delay():
            time.sleep(random.uniform(0.1, 0.5))

        if "click" in instruction:
            self.execute_instruction({"solve_captcha": [True, 90]})
            selector = instruction["click"]
            element = self.page.locator(selector).first

            logger.info(f"Pressing button with text {element.text_content()}")

            logger.info("Moving mouse random positions")
            mouse_movements = random.randint(1, 10)

            # Random mouse movements
            x = random.uniform(0, 20)
            y = random.uniform(0, 20)
            for _ in range(mouse_movements):
                logger.info(f"Random: Moving mouse to {x}, {y}")
                self.page.mouse.move(x, y)
                x = random.uniform(x, x + random.randint(20, 50))
                y = random.uniform(y, y + random.randint(20, 50))
                time.sleep(random.uniform(0.3, 0.8))

            time.sleep(random.uniform(1, 3))

            # Scroll to element
            logger.info("Scrolling to element")
            element.scroll_into_view_if_needed()
            time.sleep(random.uniform(1, 3))

            # Mouse click on element
            rect = self.page.evaluate(
                "element => document.querySelector(element).getBoundingClientRect();",
                selector,
            )

            click_position = {
                "x": rect["x"] + rect["width"] / 2,
                "y": rect["y"] + rect["height"] / 2,
            }

            logger.info(f"Moving mouse to {click_position}")
            self.page.mouse.move(click_position["x"], click_position["y"])
            time.sleep(random.uniform(1, 3))

            if self.click_type == "mouse":
                logger.info(f"Mouse click on {selector}")
                self.page.mouse.click(click_position["x"], click_position["y"])
                time.sleep(random.uniform(1, 3))
            elif self.click_type == "element":
                logger.info(f"Clicking the element {selector}")
                element.click(button="left")
                time.sleep(random.uniform(1, 3))
            # # Press Enter on element
            # # check if the element is still present
            # if not self.page.locator(selector).first:
            #     logger.info(
            #         f"Element {selector} not found after element click, so not pressing enter"
            #     )
            #     return
            elif self.click_type == "enter":
                logger.info(f"Pressing Enter on {selector}")
                element.press("Enter")
                time.sleep(random.uniform(1, 3))
            else:
                logger.error(f"Invalid click type: {self.click_type} for {selector}")
                raise ValueError(f"Invalid click type: {self.click_type}")

            logger.info(f"Clicked on {selector}")
            human_delay()
            logger.info("Waiting for network idle")

            try:
                self.page.wait_for_load_state("networkidle")
            except Exception as e:
                logger.error(f"Error while waiting for network idle: {e}")
            self.execute_instruction({"solve_captcha": [True, 90]})
        elif "wait_for" in instruction:
            selector = instruction["wait_for"]
            self.page.wait_for_selector(selector)
            human_delay()
        elif "wait" in instruction:
            time_ms = instruction["wait"]
            time.sleep(time_ms / 1000)
            human_delay()
        elif "fill" in instruction:
            selector, value = instruction["fill"]
            element = self.page.locator(selector).first
            element.press_sequentially(value)
            human_delay()
        elif "check" in instruction:
            selector = instruction["check"]
            self.page.check(selector)
            human_delay()
        elif "uncheck" in instruction:
            selector = instruction["uncheck"]
            self.page.uncheck(selector)
            human_delay()
        elif "select_option" in instruction:
            selector, option_value = instruction["select_option"]
            self.page.select_option(selector, option_value)
            human_delay()
        elif "scroll_to_element" in instruction:
            selector = instruction["scroll_to_element"]
            element = self.page.locator(selector).first
            element.scroll_into_view_if_needed()
            human_delay()
        elif "evaluate" in instruction:
            script = instruction["evaluate"]
            output = self.page.evaluate(script)
            human_delay()
            return output
        elif "wait_event" in instruction:
            event = instruction["wait_event"]
            self.page.wait_for_event(event)
            human_delay()
        elif "extract" in instruction:
            selector = instruction["extract"]
            elements = self.page.locator(selector).all()
            elements_html = []
            for element in elements:
                if element:
                    elements_html.append(element.evaluate("e => e.outerHTML"))

            return elements_html
        elif "paginate" in instruction:
            max_iterations = 50
            paginate = instruction["paginate"]
            next_button_selector = paginate.get("next_button_selector")
            all_page_buttons = paginate.get("all_page_button_selectors")
            instructions = paginate["instructions"]

            iterations = 0
            output = []
            if next_button_selector:
                locator = self.page.locator(next_button_selector)
                output.append(self.execute_instructions(instructions))

                while locator.first and iterations < max_iterations:
                    try:
                        is_enabled = locator.first.is_enabled(timeout=5000)
                        if not is_enabled:
                            logger.info("Next button is disabled, Breaking loop")
                            break
                    except Exception as e:
                        logger.error(
                            f"Error while checking if next button is enabled, Breaking loop: {e}"
                        )
                        break

                    time.sleep(random.uniform(1, 3))
                    try:
                        logger.info(f"Clicking next button {next_button_selector}")
                        locator.first.click()
                    except Exception as e:
                        logger.error(
                            f"Error while clicking next button, Breaking loop: {e}"
                        )
                        break
                    locator = self.page.locator(next_button_selector)
                    time.sleep(5)
                    data = self.execute_instructions(instructions)

                    # check if the content is same as previous page
                    # TODO: this is specific to the quizziz solution, need to make this better
                    if output and data == output[-1]:
                        logger.info("Content same as previous page, Breaking loop")
                        break

                    output.append(data)
                    iterations += 1

            elif all_page_buttons:
                # removing first page button as it is the current page
                for button in all_page_buttons:
                    human_delay()
                    logger.info(f"Clicking button {button}")
                    self.page.locator(button).first.click()
                    time.sleep(5)
                    output.append(self.execute_instructions(instructions))

            message = f"Iterated {iterations} pages"
            logger.info(message)

            output.append({"message": message})
            return output

        elif "solve_captcha" in instruction:
            solve_captcha, max_wait = instruction["solve_captcha"]
            captcha_solved = False
            logger.info("Checking for captcha")
            if self.has_captcha():
                logger.info("Captcha found")
                self.solve_captcha()
                captcha_solved = self.wait_for_captcha(max_wait)
            else:
                logger.error("No captcha found")
            human_delay()
            return captcha_solved

    def execute_instructions(self, instructions):
        data = []
        for instruction in instructions:
            logger.info(f"Executing instruction {instruction}")
            output = self.execute_instruction(instruction)
            logger.info(f"Output of instruction {instruction}: {output}")
            instruction_with_output = {**instruction, "output": output}
            data.append(instruction_with_output)
        return data

    def close(self):
        self.page.close()
        self.browser.close()
        self.playwright.stop()
        logger.info("Browser closed")
