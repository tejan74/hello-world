from lib2to3.pgen2 import driver
import os
import time
from typing import Optional
from selenium_stealth import stealth
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import config
from lib.selenium.chrome_extensions import CaptchaSolver, ChromeProxy
from util.logger import interstellar_logger
from selenium.webdriver.common.by import By

logger = interstellar_logger(__name__)


class ProxyChromeBrowser:
    def __init__(
        self,
        use_proxy: Optional[bool] = False,
        use_captcha_solver: Optional[bool] = False,
        resolution: Optional[str] = "1366,768",
        auto_captcha: Optional[bool] = False,
    ):
        options = Options()
        options.add_argument("--headless=new")

        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option("useAutomationExtension", False)
        # Disable GPU
        options.add_argument("--disable-gpu")

        # Disable software rasterizer (for improved performance in headless mode)
        options.add_argument("--disable-software-rasterizer")

        # set window size to 1920x1080
        options.add_argument(f"--window-size=f{resolution}")

        # Disable sandbox
        options.add_argument("--no-sandbox")

        # Disable dev shm usage
        options.add_argument("--disable-dev-shm-usage")

        extensions = []
        if use_proxy:
            # appending the US location params to the user secret directly
            # refer https://developers.oxylabs.io/proxies/residential-proxies/location-settings/select-country
            proxy_url = config.get_parameter("BROWSER_PROXY_URL")

            if not proxy_url:
                logger.error("No proxy url found")
                raise ValueError("No proxy url found")

            scheme, username_password = proxy_url.split("@")[0].split("://")
            username, password = username_password.split(":")
            proxy, port = proxy_url.split("@")[1].split(":")

            if not scheme or not username or not password or not proxy or not port:
                logger.error("Invalid proxy url")
                raise ValueError("Invalid proxy url")

            proxy = ChromeProxy(scheme, proxy, int(port), username, password)
            path = proxy.create_extension()
            extensions.append(path)

        if use_captcha_solver:
            api_key = config.get_parameter("CAPTCHA_SOLVER_API_KEY")

            if not api_key:
                logger.error("No captcha solver api key found")
                raise ValueError("No captcha solver api key found")

            captcha_solver = CaptchaSolver(api_key, auto_captcha)
            path = captcha_solver.create_extension()
            extensions.append(path)
        
        if len(extensions) > 0:
            options.add_argument(f"--load-extension={",".join(extensions)}")

        self._driver = webdriver.Chrome(options=options)
        stealth(
            self._driver,
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.5481.105 Safari/537.36",
            languages=["en-US", "en"],
            vendor="Google Inc.",
            platform="Win32",
            webgl_vendor="Intel Inc.",
            renderer="Intel Iris OpenGL Engine",
            fix_hairline=True,
        )

    def execute_script(self, script):
        return self._driver.execute_script(script)

    def load_url(self, url):
        self._driver.get(url)

    def has_captcha(self) -> bool:
        # check if there is a button with id capsolver-solver-tip-button
        try:
            elem = self._driver.find_element(by="id", value="capsolver-solver-tip-button")
            if elem:
                return True
        except:
            logger.info("No captcha found")
        return False
    
    def solve_captcha(self):
        # click the button with id capsolver-solver-tip-button
        if self.has_captcha():
            self.execute_script("document.getElementById('capsolver-solver-tip-button').click()")
        else:
            logger.error("No captcha found")
            raise ValueError("No captcha found")
    
    def wait_for_captcha(self, max_wait: int | None = 60) -> bool:
       # wait for this element to appear <div id="capsolver-solver-tip-button" class="capsolver-solver" data-state="solved">
        if not self.has_captcha():
            logger.error("No captcha found")
            return False
        
        remaining_wait_time = max_wait if max_wait else 60
        while remaining_wait_time > 0:
            element = self._driver.find_element(by="id", value="capsolver-solver-tip-button")
            if element and element.get_attribute("data-state") == "solved":
                logger.info("Captcha solved")
                return True
            else:
                logger.info(f"Waiting for captcha to be solved, state: {element.get_attribute('data-state')}. Polling again in 3 seconds.")
                time.sleep(3)
                remaining_wait_time -= 3

        logger.error("Captcha not solved in time")
        return False


    def get_raw(self):
        return self._driver.page_source

    def get_window_inner_size(self):
        return self._driver.execute_script(
            "return {width: window.innerWidth, height: window.innerHeight};"
        )

    def screenshot_as_base64(self):
        return self._driver.get_screenshot_as_base64()
    
    def save_screenshot(self, screenshot_download_location):
        self._driver.save_screenshot(screenshot_download_location)
        print(f"Screenshot saved to: {screenshot_download_location}")

    def get_element_screenshot(self, id=None, css_selector=None):
        if not id and not css_selector:
            raise ValueError("id or css_selector must be provided")
        by = id and By.ID or By.CSS_SELECTOR
        return self._driver.find_element(by=by, value=id or css_selector).screenshot_as_base64

    def scroll_page(self, scroll_to):
        self._driver.execute_script(f"window.scrollTo(0, {scroll_to});")

    def scroll_to_tag(self, tag):
        logger.info(f"Scrolling to tag: {tag}")
        self._driver.execute_script(
            f"""
                elements = document.getElementsByTagName('{tag}');
                if (elements.length > 0) {{
                    elements[0].scrollIntoView({{ behavior: "instant", block: "center" }});
                }} 
            """
        )

    def scroll_to_element_by_css_selector(self, css_selector):
        logger.info(f"Scrolling to element with css selector: {css_selector}")
        self._driver.execute_script(
            f"""
                element = document.querySelector('{css_selector}');
                if (element) {{
                    element.scrollIntoView({{ behavior: "instant"}});
                }} 
            """
        )
    
    def scrape_full_text(self):
        _textRetrieveScript = """
        function getTextNodePosition(n) {
            const r = document.createRange()
            r.selectNodeContents(n)
            return r.getBoundingClientRect()
        } 
        function extractText(n) {
            if(["STYLE","SCRIPT","NOSCRIPT"].includes(n.nodeName)) return []
            if(n.nodeType === 3) {
                return [{
                    text: n.textContent,
                    rect: getTextNodePosition(n)
                }]
            }
            if(n.childNodes && n.childNodes.length > 0) {
                const textNodes = []
                for(const cn of Array.from(n.childNodes)) {
                    textNodes.push(...extractText(cn))
                }
                return textNodes
            }
            return []
        }
        // json parse & stringify is to avoid this error 'selenium.common.exceptions.JavascriptException: Message: Cyclic object value'
        return JSON.parse(JSON.stringify(extractText(document.body)))
        """
        texts = self._driver.execute_script(_textRetrieveScript)
        allText = ""
        for text in texts:
            allText += text["text"] + " "

        return allText

    def scrape_links(self):
        _linkRetrieveScript = """
        function getTextNodePosition(n) {
            const r = document.createRange()
            r.selectNodeContents(n)
            return r.getBoundingClientRect()
        } 
        function extractLink(n) {
            if(n.nodeName === "A") {
                return [{
                    href: n.href,
                    text: n.innerText,
                }]
            }
            if(n.childNodes && n.childNodes.length > 0) {
                const links = []
                for(const cn of Array.from(n.childNodes)) {
                    links.push(...extractLink(cn))
                }
                return links
            }
            return []
        }
        return JSON.parse(JSON.stringify(extractLink(document.body)))
        """
        links = self._driver.execute_script(_linkRetrieveScript)
        return links

