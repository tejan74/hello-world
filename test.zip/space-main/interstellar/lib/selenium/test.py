import time
import unittest
from lib.selenium import WebScraper
from lib.selenium.playwright_chromium import PlaywrightOrbBrowser
from lib.selenium.proxy_chrome import ProxyChromeBrowser


class Test(unittest.TestCase):
    def test_scraper(self):
        scraper = WebScraper()
        scraper.load_url("https://www.google.com")
        text = scraper.scrape_full_text()
        links = scraper.scrape_links()
        print(text)
        print(links)

    def test_browser_script(self):
        scraper = ProxyChromeBrowser(True, True)
        scraper.load_url("https://punchbowlsocial.com/contact-us/")
        scraper.save_screenshot("screenshot1.png")
        if scraper.has_captcha():
            print("Captcha found")
            scraper.solve_captcha()
            scraper.wait_for_captcha()
        scraper.scroll_to_tag("form")
        scraper.save_screenshot("screenshot.png")

    def test_playwright_browser_script(self):
        scraper = PlaywrightOrbBrowser(True, True)
        scraper.load_url("https://punchbowlsocial.com/contact-us/")
        time.sleep(5)

        scraper.execute_instructions(
            [
                {"scroll_to_element": "form"},
                {"solve_captcha": [True, 60]},
                {"click": "#gform_submit_button_1"},
                {"solve_captcha": [True, 60]},
            ]
        )

    def test_element_screenshot(self):
        scraper = ProxyChromeBrowser(False, False)
        scraper.load_url("https://duckduckgo.com/?t=h_&q=hello&ia=web")
        sc = scraper.get_element_screenshot(id="links_wrapper")
        with open("screenshot.png", "wb") as f:
            f.write(sc.encode())

    def test_common_parent_element_screenshot(self):
        scraper = ProxyChromeBrowser(False, False)
        scraper.load_url("https://duckduckgo.com/?t=h_&q=hello&ia=web")
        scraper.execute_script(
            """
            (function() {
                function getAllParents(el) {
                    return el.parentElement ? [el.parentElement,...getAllParents(el.parentElement)] : []
                }

                function getCommonParent(el1,el2) {
                    if(typeof el1 == 'string') el1 = document.querySelector(el1)
                    if(typeof el2 == 'string') el2 = document.querySelector(el2)
                    if(!el1 || !el2) return null

                    const a1 = [...getAllParents(el1).reverse(),el1]
                    const a2 = [...getAllParents(el2).reverse(),el2]
                    let commonParent = null
                    for(let i=0; i < Math.min(a1.length,a2.length);i++){
                        if(a1[i] === a2[i]){commonParent=a1[i]} else break;
                    }
                    return commonParent
                }

                function assignAttrToCommonParent(el1, el2, attr, value) {
                    const cp = getCommonParent(el1,el2) ?? document.body
                    cp.setAttribute(attr, value)
                }

                return assignAttrToCommonParent('#search_form_input', '#search_form', 'data-ss-id', 'common-parent-543')
            })()
        """
        )
        sc = scraper.get_element_screenshot(
            css_selector="[data-ss-id='common-parent-543']"
        )
        if sc:
            with open("screenshot.png", "wb") as f:
                f.write(sc.encode())

    def test_paginate_instructions(self):
        scraper = PlaywrightOrbBrowser()
        scraper.load_url("https://www.zps.org/about-us/district-information/district-staff/")
        instructions = {"instructions": [{"paginate": {"instructions": [{"extract": ".fbcms_table_body"}], "next_button_selector": ".ajcp_next"}}]}
        out=scraper.execute_instructions(
            instructions=instructions.get("instructions")    
        )
        #write to file
        with open("output.json", "w") as f:
            f.write(str(out))


if __name__ == "__main__":
    unittest.main()
