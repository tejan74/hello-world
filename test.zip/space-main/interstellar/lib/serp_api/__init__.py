from serpapi import GoogleSearch
from lib.serp_api.types import GetSearchResponse
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class SerpApiClient:
    def __init__(self, api_key, provider):
        self.api_key = api_key
        self.provider = provider

    def _build_params(self, **kwargs):
        """
        Build parameters dictionary for API requests.
        """
        params = kwargs
        params["api_key"] = self.api_key
        return params

    def _search(self, params):
        """
        This API fetches Google search and Google map results from SerpApi.
        """
        try:
            search = GoogleSearch(params)
            result = search.get_dict()
            if result and result.get("search_metadata", {}).get("status") == "Success":
                return GetSearchResponse(**result)
            else:
                return None
        except Exception as e:
            logger.error(f"An error occurred in SerpApiClient{e}")
            return None

    def search_google(self, q: str, **kwargs) -> GetSearchResponse | None:
        """
        Fetch Google search results from SerpApi.
        https://serpapi.com/search-api
        Args:
            q (str): Search Query (required)
            **kwargs: Additional search parameters
        """
        params = self._build_params(q=q, type="search", **kwargs)
        result = self._search(params=params)
        return result

    def search_google_maps(self, q: str, **kwargs) -> GetSearchResponse | None:
        """
        Fetch Google Maps results from SerpApi.
        https://serpapi.com/google-maps-api
        Args:
            q (str): Search Query (required)
            ll (str): Latitude/Longitude (required)
            **kwargs: Additional map parameters
        """
        params = self._build_params(
            q=q, type="search", google_domain="google.com", **kwargs
        )
        result = self._search(params=params)
        return result
