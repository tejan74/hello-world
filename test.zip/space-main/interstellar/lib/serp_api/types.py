import pydantic


class BaseKnowledgeGraph(pydantic.BaseModel):
    title: str | None = None


class CompanyKnowledgeGraph(BaseKnowledgeGraph):
    title: str | None = None
    type: str | None = None
    entity_type: str | None = None
    kgmid: str | None = None
    knowledge_graph_search_link: str | None = None
    serpapi_knowledge_graph_search_link: str | None = None
    image: str | None = None
    description: str | None = None
    website: str | None = None
    source: dict | None = None
    stock_price: str | None = None
    stock_price_links: list | None = None
    founder: str | None = None
    founder_links: list | None = None
    founded: str | None = None
    founded_links: list | None = None
    revenue: str | None = None
    headquarters: str | None = None
    headquarters_links: list | None = None
    president: str | None = None
    president_links: list | None = None
    number_of_locations: str | None = None
    menu_nutrition: list | None = None
    profiles: list | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class BusinessKnowledgeGraph(BaseKnowledgeGraph):
    title: str | None = None
    type: str | None = None
    entity_type: str | None = None
    kgmid: str | None = None
    knowledge_graph_search_link: str | None = None
    serpapi_knowledge_graph_search_link: str | None = None
    place_id: str | None = None
    directions: str | None = None
    review_count: int | None = None
    located_in: str | None = None
    address: str | None = None
    address_links: list | None = None
    raw_hours: str | None = None
    hours: dict | None = None
    phone: str | None = None
    phone_links: list | None = None
    user_reviews: list | None = None
    people_also_search_for: list | None = None
    people_also_search_for_link: str | None = None
    people_also_search_for_stick: str | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class Place(pydantic.BaseModel):
    position: int | None = None
    label: str | None = None
    description: str | None = None
    place_id: str | None = None
    place_id_search: str | None = None
    lsig: str | None = None
    service_options: dict | None = None
    links: dict | None = None
    title: str | None = None
    phone: str | None = None
    address: str | None = None
    hours: str | None = None
    rating: str | float | None = None
    reviews: int | None = None
    type: str | None = None
    gps_coordinates: dict | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class LocalPack(pydantic.BaseModel):
    places: list[Place] | None = None
    more_locations_link: str | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class GoogleSearchData(pydantic.BaseModel):
    status: str | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class GetSearchResponse(pydantic.BaseModel):
    search_metadata: GoogleSearchData
    knowledge_graph: BusinessKnowledgeGraph | CompanyKnowledgeGraph | None = None
    local_results: LocalPack | list[LocalPack] | None = None
    model_config = pydantic.ConfigDict(extra="allow")
