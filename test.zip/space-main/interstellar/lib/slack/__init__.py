import config
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class ApiClient:

    def __init__(
        self,
        token: str | None = None,
    ):
        self.token = token or config.get_parameter("SLACK_BOT_TOKEN")
        self.client = WebClient(token=self.token)

    def post_message(self, channel: str, text: str):
        """
        Post messages to a slack channel
        :param channel: The channel code to which the messages to be posted eg. C03FBUVF65Q
        :param text: The message text that need to be posted in the slack channel
        """
        try:
            return self.client.chat_postMessage(channel=channel, text=text)
        except SlackApiError:
            logger.exception("Error occurred while posting message to slack channel")
            raise
