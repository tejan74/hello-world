import unittest
from lib import slack
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Test(unittest.TestCase):

    def setUp(self):
        self.client = slack.ApiClient()

    def test_post_message(self):
        self.client.post_message(
            channel="C03FBUVF65Q",
            text="There are currently 10 pending REVERSE ENRICH requests awaiting processing.",
        )


if __name__ == "__main__":
    unittest.main()
