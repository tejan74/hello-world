from typing import Any, Literal
from util.logger import interstellar_logger
import pydash
import requests
import config

logger = interstellar_logger(__name__)


Fields = Literal[
    "meta",
    "company",
    "contact",
    "social",
    "signals",
    "locale",
    "security",
    "trackers",
    "keywords",
    "events",
]

AllFields = Literal["all"]


class ApiClient:
    def __init__(self, api_key: str | None = None) -> None:
        self.api_key = api_key or config.get_parameter("WAPPALYZER_API_KEY")
        self.headers = {"x-api-key": self.api_key}
        self.base_url = "https://api.wappalyzer.com/v2"

    def _make_request(self, url: str, params: dict[str, Any] | None = None):
        response = requests.get(url=url, headers=self.headers, params=params)
        if response.status_code == 200:
            credits_spent = pydash.get(response.headers, "wappalyzer-credits-spent")
            credits_remaining = pydash.get(
                response.headers, "wappalyzer-credits-remaining"
            )
            logger.info(
                f'Wappalyzer Credits Usage: "credits_spent": {credits_spent}, "credits_remaining": {credits_remaining}'
            )
            return response.json()
        else:
            raise Exception(
                f"Failed to complete the request: {response.status_code}, {response.text}"
            )

    # TODO: Add support for recursive and asynchronous results (Webhooks)
    def technology_lookup(
        self,
        url: str,
        remove_noise: bool = True,
        min_age: int = 0,
        max_age: int = 2,
        squash: bool = True,
        sets: list[Fields] | AllFields = [],
    ):
        """
        Find out the technology stack of any website, such as the CMS or e-commerce platform.

        Args:
            url: Url to perform technology lookup on
            remove_noise: Exclude low confidence result
            min_age: Return results that have been verified at least once before min_age months ago. Defaults to 0 for most recent results
            max_age: Return results that have been verified at least once in the last max_age months. Defaults to 2 for best results
            squash: Merge monthly results into a single set. Defaults to true. Set to false to group results by month
            sets: List of additional field sets to include in the results (e.g. meta,social). Some fields require an eligible plan
        """
        url = f"{self.base_url}/lookup/"
        params = {
            "urls": url,
            "recursive": False,
            "denoise": remove_noise,
            "min_age": min_age,
            "max_age": max_age,
            "squash": squash,
        }
        if sets == "all":
            params["sets"] = sets
        elif len(sets):
            params["sets"] = ",".join(sets)

        return self._make_request(url=url, params=params)

    def subdomain_finder(
        self, domains: list[str], limit: int = 100, after: str | None = None
    ):
        """
        Enumerate subdomains for a domain.

        Args:
            domains: List of domains between 1 - 10
            limit: Maximum number of result to return
            after: Get the next page of results by passing the value of "moreAfter" from a previous response
        """
        url = f"{self.base_url}/subdomains/"
        if (not len(domains)) or (len(domains) > 10):
            raise Exception("Domains should be between length of 1-10")

        params = {"domains": ",".join(domains), "limit": limit}
        if after:
            params["after"] = after

        return self._make_request(url=url, params=params)

    def email_verification(self, email: str):
        """
        Verify email addresses before sending to improve delivery. A high bounce rate lowers your sender reputation and you risk getting blocked by email providers.

        Args:
            email: Email address (e.g. info@example.com)
        """
        url = f"{self.base_url}/verify/"
        params = {"email": email}

        return self._make_request(url=url, params=params)
