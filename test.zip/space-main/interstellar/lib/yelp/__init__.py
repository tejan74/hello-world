from lib.http import HttpLib
from lib.yelp.types import (
    Business,
    BusinessMatchResponse,
    BusinessReviewsHighlightsResponse,
    BusinessReviewsResponse,
    BusinessSearchResponse,
    FoodDeliverySearchResponse,
    SearchPhoneResponse,
)


class YelpClient(HttpLib):
    def __init__(self, api_key, base_url=None, query_params=None, headers=None):
        if base_url is None:
            base_url = "https://api.yelp.com/v3"
        if headers is None:
            headers = {"accept": "application/json"}
        headers["Authorization"] = f"Bearer {api_key}"
        # Initialize the parent HttpLib with base_url, query_params, and headers
        super().__init__(base_url=base_url, query_params=query_params, headers=headers)

    def business_search(
        self,
        location: str | None = None,
        latitude: int | None = None,
        longitude: int | None = None,
        term: str | None = None,
        radius: int | None = None,
        categories: list | None = None,
        locale: str | None = None,
        price: list[int] | None = None,
        open_now: bool = False,
        open_at: int | None = None,
        attributes: list[str] | None = None,
        sort_by: str = "best_match",
        device_platform: str | None = None,
        reservation_date: str | None = None,
        reservation_time: str | None = None,
        reservation_covers: int | None = None,
        matches_party_size_param: bool = False,
        limit: int = 20,
        offset: int | None = None,
    ) -> BusinessSearchResponse | None:
        """
        This endpoint returns up to 240 businesses with some basic information based on the provided search criteria.
        https://docs.developer.yelp.com/reference/v3_business_search
        """
        response = self.request(
            method="GET",
            path="businesses/search",
            query_params={
                "location": location,
                "latitude": latitude,
                "longitude": longitude,
                "term": term,
                "radius": radius,
                "categories": categories,
                "locale": locale,
                "price": price,
                "open_now": open_now,
                "open_at": open_at,
                "attributes": attributes,
                "sort_by": sort_by,
                "device_platform": device_platform,
                "reservation_date": reservation_date,
                "reservation_time": reservation_time,
                "reservation_covers": reservation_covers,
                "matches_party_size_param": matches_party_size_param,
                "limit": limit,
                "offset": offset,
            },
        )
        return BusinessSearchResponse(**response) if response is not None else None

    def business_match(
        self,
        name: str,
        city: str,
        state: str,
        country: str,
        address1: str,
        address2: str | None = None,
        address3: str | None = None,
        postal_code: str | None = None,
        latitude: int | None = None,
        longitude: int | None = None,
        phone: str | None = None,
        yelp_business_id: int | None = None,
        limit: int = 3,
        match_threshold: str = "default",
    ) -> BusinessMatchResponse | None:
        """
        This endpoint lets you match business data from other sources against businesses on Yelp,
        based on provided business information.
        https://docs.developer.yelp.com/reference/v3_business_match
        """
        response = self.request(
            method="GET",
            path="businesses/matches",
            query_params={
                "name": name,
                "city": city,
                "state": state,
                "country": country,
                "address1": address1,
                "address2": address2,
                "address3": address3,
                "postal_code": postal_code,
                "latitude": latitude,
                "longitude": longitude,
                "phone": phone,
                "yelp_business_id": yelp_business_id,
                "limit": limit,
                "match_threshold": match_threshold,
            },
        )
        return BusinessMatchResponse(**response) if response is not None else None

    def business_details(
        self,
        business_id_or_alias: str,
        locale: str | None = None,
        device_platform: str | None = None,
    ) -> Business | None:
        """
        Returns detailed business content
        https://docs.developer.yelp.com/reference/v3_business_info
        """
        response = self.request(
            method="GET",
            path=f"businesses/{business_id_or_alias}",
            query_params={
                "locale": locale,
                "device_platform": device_platform,
            },
        )
        return Business(**response) if response is not None else None

    def search_phone(
        self,
        phone: str,
        locale: str | None = None,
    ) -> SearchPhoneResponse | None:
        """
        Returns a list of businesses based on the provided phone number
        https://docs.developer.yelp.com/reference/v3_business_phone_search
        """
        response = self.request(
            method="GET",
            path="businesses/search/phone",
            query_params={
                "phone": phone,
                "locale": locale,
            },
        )
        return SearchPhoneResponse(**response) if response is not None else None

    def food_delivery_search(
        self,
        transaction_type: str,
        latitude: int | None = None,
        longitude: int | None = None,
        location: str | None = None,
        term: str | None = None,
        categories: list[str] | None = None,
        price: list[int] | None = None,
    ) -> FoodDeliverySearchResponse | None:
        """
        Returns a list of businesses which support requested transaction type.
        https://docs.developer.yelp.com/reference/v3_transaction_search
        """
        response = self.request(
            method="GET",
            path=f"transactions/{transaction_type}/search",
            query_params={
                "latitude": latitude,
                "longitude": longitude,
                "location": location,
                "term": term,
                "categories": categories,
                "price": price,
            },
        )
        return FoodDeliverySearchResponse(**response) if response is not None else None

    def business_reviews(
        self,
        business_id_or_alias: str,
        locale: str | None = None,
        offset: int | None = None,
        limit: int = 20,
        sort_by: str = "yelp_sort",
    ) -> BusinessReviewsResponse | None:
        """
        Returns up to three review excerpts for a given business ordered by Yelp's default sort order.
        https://docs.developer.yelp.com/reference/v3_business_reviews
        """
        response = self.request(
            method="GET",
            path=f"businesses/{business_id_or_alias}/reviews",
            query_params={
                "locale": locale,
                "offset": offset,
                "limit": limit,
                "sort_by": sort_by,
            },
        )
        return BusinessReviewsResponse(**response) if response is not None else None

    def business_reviews_highlights(
        self,
        business_id_or_alias: str,
        count: int = 3,
        locale: str | None = None,
        device_platform: str | None = None,
    ) -> BusinessReviewsHighlightsResponse | None:
        """
        Return a business's review highlights
        https://docs.developer.yelp.com/reference/v3_business_review_highlights
        """
        response = self.request(
            method="GET",
            path=f"businesses/{business_id_or_alias}/reviews",
            query_params={
                "count": count,
                "locale": locale,
                "device_platform": device_platform,
            },
        )
        return (
            BusinessReviewsHighlightsResponse(**response)
            if response is not None
            else None
        )
