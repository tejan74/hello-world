import pydantic


class Business(pydantic.BaseModel):
    id: str | None = None
    alias: str | None = None
    name: str | None = None
    image_url: str | None = None
    is_closed: bool | None = None
    url: str | None = None
    review_count: int | None = None
    categories: list | None = None
    rating: float | None = None
    coordinates: dict | None = None
    transactions: list | None = None
    price: str | None = None
    location: dict | None = None
    phone: str | None = None
    display_phone: str | None = None
    business_hours: list | None = None
    attributes: dict | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class BusinessSearchResponse(pydantic.BaseModel):
    businesses: list[Business] | None = None
    total: int | None = None
    region: dict | None = None
    model_config = pydantic.ConfigDict(extra="allow")


class BusinessMatchResponse(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra="allow")


class SearchPhoneResponse(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra="allow")


class FoodDeliverySearchResponse(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra="allow")


class BusinessReviewsResponse(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra="allow")


class BusinessReviewsHighlightsResponse(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra="allow")
