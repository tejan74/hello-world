import zenrows
from bs4 import BeautifulSoup, Tag
from util.logger import interstellar_logger
from urllib.parse import urljoin

logger = interstellar_logger(__name__)


class ZenRowsClient:
    def __init__(self, api_key):
        self.client = zenrows.ZenRowsClient(api_key)

    def web_scraper(
        self,
        url: str,
        js_render: bool = False,
        custom_headers: bool = False,
        premium_proxy: bool = False,
        proxy_country: str | None = None,
        session_id: str | None = None,
        device: str | None = None,
        original_status: bool = False,
        allowed_status_codes: str | None = None,
        wait_for: str | None = None,
        wait: str = "0",
        block_resources: str | None = None,
        json_response: bool = False,
        css_extractor: str | None = None,
        autoparse: bool = False,
        markdown_response: bool = False,
        screenshot: bool = False,
        screenshot_fullpage: bool = False,
        screenshot_selector: str | None = None,
    ):
        """
        The ZenRows API simplifies web scraping with just two essentials:
        1) An API key
        2) The encoded URL you want to scrape
        https://docs.zenrows.com/api-reference
        """
        self.url = url
        try:
            params = {
                "js_render": str(js_render).lower(),
                "autoparse": str(autoparse).lower(),
                "original_status": str(original_status).lower(),
                "proxy_country": proxy_country,
                "premium_proxy": str(premium_proxy).lower(),
                "custom_headers": str(custom_headers).lower(),
                "markdown_response": str(markdown_response).lower(),
                "screenshot": str(screenshot).lower(),
                "screenshot_fullpage": str(screenshot_fullpage).lower(),
                "wait": wait,
                "wait_for": wait_for,
                "session_id": session_id,
                "device": device,
                "allowed_status_codes": allowed_status_codes,
                "block_resources": block_resources,
                "json_response": str(json_response).lower(),
                "css_extractor": css_extractor,
                "screenshot_selector": screenshot_selector,
            }
            self.response = self.client.get(url, params=params)
            if self.response.status_code and self.response.text:
                self.soup = BeautifulSoup(self.response.text, "html.parser")
                return self.response.status_code
        except Exception as e:
            logger.error(f"An error occurred in ZenrowsClient: {e}")
            raise

    def scrape_full_text(self):
        """
        Scrape the full text from the page
        """
        if self.soup is None:
            return ""

        body = self.soup.find("body")

        if body is None:
            return ""

        text = body.get_text()
        return text

    def scrape_links(self):
        """
        Scrape all the links from the page
        """
        if self.soup is None:
            raise ValueError("No response found. Load the url first.")

        links = []
        for link in self.soup.find_all("a"):
            links.append(
                {
                    "link": link.get("href"),
                    "text": link.get_text(),
                }
            )

        return links

    def get_base_uri(self):
        """
        Get the base uri of the page
        """
        if self.soup is None:
            raise ValueError("No response found. Load the url first.")

        base = self.soup.find("base")

        if isinstance(base, Tag):
            return str(base["href"])
        else:
            return self.url

    def scrape_images(self):
        """
        Scrape all the images from the page
        """
        if self.soup is None:
            raise ValueError("No response found. Load the URL first.")

        images = []
        base_url = self.get_base_uri()

        for img in self.soup.find_all("img"):
            src = img.get("src")
            alt = img.get("alt")

            # Validate and handle the src attribute
            if not src:
                continue  # Skip images with no src

            # Handle absolute URLs and relative URLs
            if not src.startswith("data:image/"):
                src = urljoin(base_url, src)

            images.append(
                {
                    "src": src,
                    "alt": alt,
                }
            )

        return images

    def get_raw(self, remove_styles_script_svg: bool = True):
        """
        Get the raw response from the API
        """
        if self.response is None:
            raise ValueError("No response found. Load the url first.")

        if remove_styles_script_svg:
            soup = BeautifulSoup(self.response.text, "html.parser")
            for data in soup(["style", "script", "svg"]):
                # Remove tags
                data.decompose()
            return str(soup)

        return self.response.text

    def get_meta(self):
        """
        Get the meta data of the page. title, description
        """
        if self.soup is None:
            raise ValueError("No response found. Load the url first.")

        title = self.soup.title.string if self.soup.title else ""

        description = self.soup.find("meta", attrs={"name": "description"})
        description = description.attrs["content"] if description else ""  # type: ignore

        return {"title": title, "description": description}
