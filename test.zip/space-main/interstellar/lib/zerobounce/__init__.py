import datetime
from zerobouncesdk import (
    ZeroBounce,
    ZBException,
    ZBValidateBatchElement,
    ZBGetApiUsageResponse,
    ZBGetCreditsResponse,
    ZBValidateBatchResponse,
    ZBValidateResponse,
)


class ZeroBounceClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.zero_bounce = ZeroBounce(self.api_key)

    def validate_email(self, email: str) -> ZBValidateResponse | None:
        """
        Validate an email address
        https://www.zerobounce.net/docs/zerobounce-api-wrappers/#api_wrappers__v2__python
        Args:
        email:
        The email address to validate.
        """
        try:
            response = self.zero_bounce.validate(email)
            print("ZeroBounce get_activity response: " + str(response))
            return response
        except ZBException as e:
            print("ZeroBounce get_activity error: " + str(e))

    def validate_batch_email(self, emails: list) -> ZBValidateBatchResponse | None:
        """
        Validate a batch of email addresses using the ZeroBounce API.
        https://www.zerobounce.net/docs/zerobounce-api-wrappers/#api_wrappers__v2__python
        Args:
        emails (List[str]): A list of email addresses to validate.
        """
        try:
            # Create ZBValidateBatchElement instances
            email_batch = [
                ZBValidateBatchElement(email_address=email) for email in emails
            ]

            # Pass the list of ZBValidateBatchElement directly
            response = self.zero_bounce.validate_batch(email_batch)
            return response
        except ZBException as e:
            print("ZeroBounce validate_batch error: " + str(e))

    def get_api_usage(
        self, start_date: datetime.date, end_date: datetime.date
    ) -> ZBGetApiUsageResponse | None:
        """
        Retrieve API usage statistics from ZeroBounce for a specified date range.
        https://www.zerobounce.net/docs/zerobounce-api-wrappers/#api_wrappers__v2__python
        Args:
        start_date (date): The start date of the date range for which to retrieve API usage.
        end_date (date): The end date of the date range for which to retrieve API usage.

        """
        try:
            response = self.zero_bounce.get_api_usage(
                start_date=start_date, end_date=end_date
            )
            return response
        except ZBException as e:
            print("ZeroBounce validate_batch error: " + str(e))

    def get_credits(self) -> ZBGetCreditsResponse | None:
        """
        Retrieve the current credit balance from ZeroBounce.
        """
        try:
            response = self.zero_bounce.get_credits()
            return response
        except ZBException as e:
            print("ZeroBounce validate_batch error: " + str(e))
