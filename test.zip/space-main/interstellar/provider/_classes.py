from typing import Any, Generic, Literal, TypeVar
import pydantic
from util.logger import interstellar_logger

T = TypeVar("T")

logger = interstellar_logger(__name__)


class ProviderResponseStatus:
    FAILED = "FAILED"
    COMPLETED = "COMPLETED"
    WAITING = "WAITING"


_ProviderResponseStatusLiteral = Literal["FAILED", "COMPLETED", "WAITING"]


class ProviderException(Exception):
    def __init__(self, code: str, message: str, e: Exception | None = None):
        self.code = code
        self.message = message
        self.e = e
        super().__init__(message)


class ProviderResponseError(pydantic.BaseModel):
    """
    GENERIC INTERFACES FOR PROVIDERS

    Providers provide Responses.
    Each response contains two attributes:
    - a *result*
    - an *error*
    """

    model_config = pydantic.ConfigDict(arbitrary_types_allowed=True)

    code: str
    message: str
    retryable: bool = False
    e: Exception | None = None


class ProviderResponse(pydantic.BaseModel, Generic[T]):
    result: T | None = None
    status: _ProviderResponseStatusLiteral | None = None
    error: ProviderResponseError | None = None

    # number of provider specific units used by the provider
    action_usage_units: int | None = None
    # types like token, credit, etc.
    action_usage_unit_type: str | None = None
    # extra data for usage
    action_usage_extra_data: dict[str, Any] | None = None

    def get_result(self) -> T:
        """
        Throws an exception if the response contains an error
        returns the result as a non optional value
        """
        if self.error:
            raise ProviderException(self.error.code, self.error.message, self.error.e)

        # if there is no error, the result is guaranteed to be non-None
        # type ignore is used to suppress the type hint error
        return self.result  # type: ignore

    def get_safe_result(self) -> T | None:
        """
        Logs error and Returns the result as a nullable value
        """
        if self.error:
            logger.error(self.error.message, extra={"error": self.error})

        return self.result


class ProviderUsageType:
    TOKEN = "token"
    CREDIT = "credit"
