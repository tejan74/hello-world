from lib import apollo
from lib.apollo._classes import CompanySearchCriteria
from provider.companies_search._classes import (
    Interface,
    Request,
    Response,
    Result,
    Company,
)
from provider import ProviderResponseError
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Provider(Interface):

    MAX_RESULT_LIMIT = 1000

    DEFAULT_PAGE_SIZE = 100

    def __init__(self, api_key: str | None = None):
        self.client = apollo.ApiClient(api_key)

    def search_companies(
        self,
        req: Request,
    ) -> Response:
        
        try:
            # Initializing total_pages to 1 to allow first API call to get actual total pages
            total_pages = 1
            page_number = 1
            if req.result_count is None:
                req.result_count = self.MAX_RESULT_LIMIT
                
            # build result object
            companies_list_result = []

            while (
                page_number <= total_pages and len(companies_list_result) < req.result_count
            ):
                company_search_criteria = CompanySearchCriteria(
                    page_number=page_number,
                    page_size=self.DEFAULT_PAGE_SIZE,
                    company_locations=req.company_locations,
                    company_name=req.company_name,
                    company_employees_number_ranges=req.company_employees_number_ranges,
                )

                logger.info("search criteria", company_search_criteria)

                # Get companies list based on search criteria
                response = self.client.get_companies_list(company_search_criteria)

                # Get company list
                companies_list = response.get("accounts", {})

                # check if company list is found, this is None if no company is found
                if not companies_list:
                    return Response(
                        error=ProviderResponseError(
                            code="NO_DATA",
                            message="No data found",
                        )
                    )

                total_pages = response.get("pagination").get("total_pages")
                page_number = page_number + 1

                for company in companies_list:
                    company_result = Company(
                        name=company.get("name"),
                        domain=company.get("domain"),
                        primary_domain=company.get("primary_domain"),
                        website_url=company.get("website_url"),
                        linkedin_url=company.get("linkedin_url"),
                        linkedin_uid=company.get("linkedin_uid"),
                        publicly_traded_symbol=company.get("publicly_traded_symbol"),
                        logo_url=company.get("logo_url")
                    )
                    companies_list_result.append(company_result)
                    if req.result_count == len(companies_list_result):
                        break

            result = Result(companies_list=companies_list_result)
            # return response
            return Response(result=result)

        except apollo.ApolloException as e:
            logger.exception("Error while fetching companies list.")
            return Response(
                error=ProviderResponseError(
                    code=f"APOLLO_ERROR_{e.status_code}",
                    message="Error while fetching companies list.",
                    e=e,
                )
            )
        except Exception as e:
            logger.exception("Error while fetching companies list.")
            return Response(
                error=ProviderResponseError(
                    code="APOLLO_ERROR_UNKNOWN",
                    message="Error while fetching companies list.",
                    e=e,
                )
            )
