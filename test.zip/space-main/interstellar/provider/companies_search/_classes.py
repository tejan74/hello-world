import abc
import pydantic

from provider import ProviderResponse

class Company(pydantic.BaseModel):
    name: str | None
    domain: str | None
    primary_domain: str | None
    website_url: str | None
    linkedin_url: str | None
    linkedin_uid: str | None
    publicly_traded_symbol: str | None
    logo_url: str | None

# Interfaces and classes for Companies List
class Request(pydantic.BaseModel):
    company_locations: list[str] | None = None
    company_name: str | None = None
    company_employees_number_ranges: list[str] | None = None
    result_count: int | None = None

class Result(pydantic.BaseModel):
    companies_list: list[Company]

# Output leverages Company List's result and the generic Provider Error system
Response = ProviderResponse[Result]

# Provider for CompanyEnrich
class Interface(abc.ABC):
    """
    Interface for companies list.
    """

    @abc.abstractmethod
    def search_companies(
        self,
        req: Request
    ) -> Response:
        """
        Search companies using request parameters.
        :param company_locations: Locations of the company headquarters to fetch. Eg. ["New York, US", "California, US"]
        :param company_name: Name of the company to fetch.
        :param company_employees_number_ranges: A list of employees ranges Eg. ["1,100", "1,1000"].
        :param result_count: An expected number of results in the list 
        :return: List of companies.
        """
        pass
