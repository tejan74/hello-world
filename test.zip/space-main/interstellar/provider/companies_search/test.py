import unittest
import pytest
import json

from provider.companies_search import apollo, Request


class Test(unittest.TestCase):
    @pytest.mark.asyncio
    async def test_get_companies_list_by_name(self):
        provider = apollo.Provider()
        response = await provider.search_companies(Request(company_locations=['US'], result_count=10))
        print(response)


if __name__ == "__main__":
    unittest.main()
