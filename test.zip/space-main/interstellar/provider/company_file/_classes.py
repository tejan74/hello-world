import abc
import pydantic

from provider._classes import ProviderResponse

# Interfaces and classes for Company File
class Request(pydantic.BaseModel):
    domain: str
    file_name: str
    download_path: str

class Result(pydantic.BaseModel):
    cloud_path: str
    local_path: str

Response = ProviderResponse[Result]

class Interface(abc.ABC):
    def __init__(self):
        pass

    @abc.abstractmethod
    def download(self, req: Request) -> Response:
        """
        Get a specific file for a company (If multiple file exists of the same type it will get the latest file)

        Args:
            domain: Company domain. Eg: google.com -> (Correct) google.com/ -> (Incorrect) www.google.com -> (Incorrect) https://www.google.com -> (Incorrect)
            file_name: Name of the file without the extension. Eg: 10K -> (Correct) 10K.pdf -> (Incorrect)
            download_path: Directory where to download the file

        Returns:
            Response object
        """
        pass
