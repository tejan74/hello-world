import config
from lib import google_cloud_storage

from provider.company_file._classes import Interface, Request, Response, Result
from provider._classes import ProviderResponseError
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

class Provider(Interface):
    def __init__(self):
        super().__init__()

        # Accept overwritten bucket for client or use default
        self.bucket = config.get_parameter("DATA_LAKE_GCS_BUCKET")
        if self.bucket is None:
            raise ValueError("DATA_LAKE_GCS_BUCKET environment variable must be set")

        # Setup GCS client
        self.gcs_client = google_cloud_storage.ApiClient(self.bucket)

    def download(self, req: Request):
        # Create the prefix by replacing '.' with '_' in domain. 
        # In GCS the folder structure is Second level domain_Top level domain with no protocol and/or sub domain Eg: google_com
        prefix = req.domain.strip().strip("/").strip("https://").strip("http://").strip("www.").replace(".", "_")

        # List the files with matching name (Don't put extension in the file name). 
        # This will search is the sub folders inside the domain folders which and get all the files with the same name from all the sub folders
        # **/ will look any any sub folder and .* will look for any extension
        files = self.gcs_client.list_files(prefix, glob = f"**/{req.file_name}.*")

        if len(files) == 0:
            logger.error(f"No file found for {req.file_name} in path {prefix}/")
            return Response(error = ProviderResponseError(code = "FILE_NOT_FOUND", message = f"No file found for {req.file_name} in path {prefix}/"))
        logger.info(f"Found {len(files)} files for {req.file_name} in path {prefix}/")

        # Sort the files according to date and get the latest file. The sub folders inside a domain directory are dates like 2024_02_09 
        # and as we are getting all the files with the same name from multiple sub folders sorting them in Desc order will give the latest file on top
        latest_file = sorted([file["name"] for file in files], reverse = True)[0]
        logger.info(f"Latest file found is {latest_file}")

        path = self.gcs_client.download_file(latest_file, req.download_path)

        return Response(result = Result(cloud_path = latest_file, local_path = path))
