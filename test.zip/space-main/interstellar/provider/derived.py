"""
This is the provider derived column action
"""

from typing import Any
import pydantic

from provider._classes import ProviderResponse


class Request(pydantic.BaseModel):
    input: Any


class Result(pydantic.BaseModel):
    data: Any


Response = ProviderResponse[Result]


class Provider:
    def derive(self, input: Request):
        return Response(result=Result(data=input.input))
