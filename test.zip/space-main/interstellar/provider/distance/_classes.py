import abc
from typing import Any

from pydantic import BaseModel

from provider import ProviderResponse

class Location(BaseModel):
    latitude: str | float
    longitude: str | float
    obj: Any

class RequestNearestLocation(BaseModel):
    latitude: float
    longitude: float
    all_locations: list[Location]

class RequestDistance(BaseModel):
    latitude1: float
    longitude1: float
    latitude2: float
    longitude2: float

class Result(BaseModel):
    nearest_location: Location
    distance: float

Response = ProviderResponse[Result]

class Interface(abc.ABC):
    """
    Interface for the distance provider
    """

    @abc.abstractmethod
    def find_nearest_location(self, req: RequestNearestLocation) -> Response:
        """
        Find the nearest location from the given list of locations
        """
        pass

    @abc.abstractmethod    
    def find_distance(self, req: RequestDistance) -> float:
        """
        Find the distance between two locations
        """
        pass
