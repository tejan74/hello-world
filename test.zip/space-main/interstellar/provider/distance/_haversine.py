import math
import pydash

from provider.distance._classes import Location, RequestNearestLocation, RequestDistance, Result, Response, Interface
from provider import ProviderResponseError
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

class Provider(Interface):
    
    def find_nearest_location(self, req: RequestNearestLocation) -> Response:
        # validations
        if not req.all_locations or len(req.all_locations) == 0:
            raise ValueError("locations param is empty")

        if not req.latitude or not req.longitude:
            raise ValueError("latitude or longitude is empty")

        # set the initial nearest location to the first location in the list, so we don't have to do a None check
        nearest_location = req.all_locations[0]
        # set the initial distance to infinity
        min_distance = float('inf')

        try:
            # find the nearest location
            for location in req.all_locations:
                distance = self.find_distance(RequestDistance(latitude1=req.latitude, longitude1=req.longitude, latitude2=float(pydash.get(location, "latitude")), longitude2=float(pydash.get(location, "longitude"))))
                # if the distance is less than the current distance, update the nearest location and distance
                if distance < min_distance:
                    min_distance = distance
                    nearest_location = location
        except Exception as e:
            logger.exception(f"Error finding nearest location: {e}")
            return Response(error=ProviderResponseError(code="UNKNOWN_ERROR", message="Error finding nearest location", e=e))

        return Response(result=Result(nearest_location=nearest_location, distance=min_distance))

    def find_distance(self, req: RequestDistance) -> float:
        # Radius of the Earth in kilometers
        radius = 6371.0

        # Convert latitude and longitude from degrees to radians
        lat1 = math.radians(req.latitude1)
        lon1 = math.radians(req.longitude1)
        lat2 = math.radians(req.latitude2)
        lon2 = math.radians(req.longitude2)

        # Haversine formula
        dlon = lon2 - lon1
        dlat = lat2 - lat1
        a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

        # Calculate the distance
        distance = radius * c

        return distance
