import unittest
import os

from provider import distance

data = [
            {
                "state": "Canada",
                "metro": "Toronto",
                "city": "Scarborough",
                "latitude": "43.7764",
                "longitude": "-79.2318",
                "stateCode": "ON"
            },
            {
                "state": "Canada",
                "metro": "Toronto",
                "city": "Markham",
                "latitude": "43.8561",
                "longitude": "-79.337",
                "stateCode": "ON"
            },
            {
                "state": "Canada",
                "metro": "Toronto",
                "city": "Thornhill",
                "latitude": "43.8207",
                "longitude": "-79.4245",
                "stateCode": "ON"
            },
            {
                "state": "Canada",
                "metro": "Toronto",
                "city": "Richmond Hill",
                "latitude": "43.8828",
                "longitude": "-79.4406",
                "stateCode": "ON"
            },
            {
                "state": "Canada",
                "metro": "Toronto",
                "city": "Vaughan",
                "latitude": "43.8364",
                "longitude": "-79.4985",
                "stateCode": "ON"
            },
            {
                "state": "Canada",
                "metro": "Toronto",
                "city": "Toronto",
                "latitude": "43.6532",
                "longitude": "-79.3832",
                "stateCode": "ON"
            },
            {
                "state": "Indiana",
                "metro": "Indianapolis",
                "city": "Indianapolis",
                "latitude": "39.7684",
                "longitude": "-86.1581",
                "stateCode": "IN"
            },
            {
                "state": "Tennessee",
                "metro": "Nashville",
                "city": "Nashville",
                "latitude": "36.1627",
                "longitude": "-86.7816",
                "stateCode": "MT"
            }
        ]

class Test(unittest.TestCase):
    def test_nearest(self):
        lat = 39.7725706
        lng = -86.1640342

        provider = distance.Provider()
        all_locations = [distance.Location(**d, obj=d) for d in data]
        output = provider.find_nearest_location(lat, lng, all_locations)
        print(output)

if __name__ == "__main__":
    unittest.main() 
