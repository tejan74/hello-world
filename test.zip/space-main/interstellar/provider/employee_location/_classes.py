import abc
import pydantic
from typing import List

from provider._classes import ProviderResponse


class Location(pydantic.BaseModel):
    country_code: str
    """full address"""
    address: str
    """number of employees"""
    count: int

class Request(pydantic.BaseModel):
    company_websites: list[str]
    country_code: list[str] | None = None
    min_count: int | None = None

class Result(pydantic.BaseModel):
    locations: List[Location]

Response = ProviderResponse[Result]

class Interface(abc.ABC):
    @abc.abstractmethod
    def get(
        self, req: Request
    ) -> Response:
        pass
