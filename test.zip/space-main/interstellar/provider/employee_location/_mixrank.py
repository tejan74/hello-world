import sqlalchemy as sq
from sqlalchemy import orm

from lib import mixrank
from provider.employee_location._classes import Interface, Response, Result, Location
from provider._classes import ProviderResponseError
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Provider(Interface):
    def __init__(self) -> None:
        self._engine = mixrank.get_engine()

    def get(
        self, company_websites: list[str], country_codes: list[str] | None = None, min_count: int | None = None
    ) -> Response:
        try:
            with orm.Session(self._engine) as session:
                stmt = (
                    sq.select(
                        mixrank.LinkedinProfile.location_country_code,
                        mixrank.LinkedinProfile.location_name,
                        sq.func.count().label("count"),
                    )
                    .join(mixrank.LinkedinProfilePosition)
                    .join(mixrank.LinkedinCompany)
                    .where(
                        mixrank.LinkedinProfilePosition.is_current == True,
                        mixrank.LinkedinCompany.website.in_(company_websites),
                        mixrank.LinkedinProfile.location_name != None,
                    )
                    .group_by(
                        mixrank.LinkedinProfile.location_name,
                        mixrank.LinkedinProfile.location_country_code,
                    )
                )
                if country_codes:
                    stmt = stmt.where(
                        mixrank.LinkedinProfile.location_country_code.in_(country_codes)
                    )
                if min_count:
                    stmt = stmt.having(sq.func.count() >= min_count)
                    
                rows = session.execute(stmt).all()
                result = Result(locations=[])
                for row in rows:
                    result.locations.append(
                        Location(
                            country_code=row[0],
                            address=row[1],
                            count=row[2],
                        )
                    )
                return Response(result=result)
        except Exception as e:
            logger.exception(
                "Error while fetching employee location website: %s, min_count: %s, country_codes: %s",
                company_websites,
                min_count,
            )
            return Response(
                error=ProviderResponseError(
                    message="Error while fetching employee location",
                    code="EMPLOYEE_LOCATION_ERROR",
                    e=e,
                )
            )
