import abc
from dataclasses import dataclass
import pydantic
from typing import List, Set
from provider._classes import ProviderResponse
from lib.coresignal.constant import SupportedCountries


# Interfaces for request
class RequestHeadcountByZip(pydantic.BaseModel):
    linkedin: str
    zip: str | None = None
    region_code: str | None = None
    radius: int | None = 50
    required_titles: List[str] | None = None
    optional_titles: List[str] | None = None
    filter_titles: List[str] | None = None


class RequestHeadcountByCountry(pydantic.BaseModel):
    linkedin: str
    country: Set[SupportedCountries] | SupportedCountries
    required_titles: List[str] | None = None
    optional_titles: List[str] | None = None
    filter_titles: List[str] | None = None


class RequestHeadcountGlobal(pydantic.BaseModel):
    linkedin: str
    required_titles: List[str] | None = None
    optional_titles: List[str] | None = None
    filter_titles: List[str] | None = None


@dataclass
class RequestHeadcountByLocation:
    linkedin: str
    locations: List[dict]
    country: Set[SupportedCountries] | SupportedCountries | None = None
    required_titles: List[str] | None = None
    optional_titles: List[str] | None = None
    filter_titles: List[str] | None = None


# Build the result from running this provider
class Result(pydantic.BaseModel):
    count: int


# Setup the response for the provider based on the result and generic error
Response = ProviderResponse[Result]


class Interface(abc.ABC):
    @abc.abstractmethod
    def headcount_by_zip(self, req: RequestHeadcountByZip) -> Response:
        pass

    @abc.abstractmethod
    def headcount_by_locations(self, req: RequestHeadcountByLocation) -> Response:
        pass
