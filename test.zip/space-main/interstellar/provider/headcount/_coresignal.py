from calendar import c
from typing import Any, Optional, Set, cast
from more_itertools import unique_everseen

from engine._classes import ActionUsage
from lib import coresignal
from lib import gis
from lib.coresignal.constant import SupportedCountries
from lib.coresignal.helper import CoreSignalDBCache
from lib.coresignal.helper import (
    CoreSignalMaxQueryCountExceedException,
    build_coresignal_search_query,
    split_query_if_long,
)

from provider._classes import ProviderResponseError, ProviderUsageType
from provider.headcount._classes import (
    Result,
    RequestHeadcountByZip,
    RequestHeadcountByLocation,
    RequestHeadcountByCountry,
    RequestHeadcountGlobal,
    Response,
    Interface,
)

from util.gis import parse_zipcode
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Provider(Interface):
    def __init__(self, api_key: Optional[str] = None) -> None:
        # TODO: migrate this library to via Prisma
        self.gis = gis.GIS()
        self.cs = coresignal.ApiClient(api_key, None)

    # Get headcount by zip code
    def headcount_by_zip(self, req: RequestHeadcountByZip) -> Response:
        # strip domain in place
        req.linkedin = req.linkedin.strip()

        # validations
        if not req.linkedin or req.linkedin in ["NA", "#N/A"]:
            return Response(
                error=ProviderResponseError(
                    code="NO_LINKEDIN", message="No linkedin provided"
                )
            )

        if (req.zip and not req.region_code) or (req.region_code and not req.zip):
            return Response(
                error=ProviderResponseError(
                    code="ZIP_REGION_CODE_MISMATCH",
                    message="Both Zip and region code must be provided",
                )
            )

        # get locations from zip and region if provided
        locations = []
        if req.zip and req.region_code:
            parsed_zip = parse_zipcode(req.zip)
            locations = self.gis.locations_near_zip(
                parsed_zip["zip"], req.region_code, req.radius or 50
            )

            if not locations:
                return Response(
                    error=ProviderResponseError(
                        code="ZIP_NOT_FOUND", message="No locations found for zip code"
                    )
                )

        # get headcount from locations
        return self.headcount_by_locations(
            RequestHeadcountByLocation(
                linkedin=req.linkedin,
                locations=locations,
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                filter_titles=req.filter_titles,
            )
        )

    # Get headcount by country
    def headcount_by_country(self, req: RequestHeadcountByCountry) -> Response:
        # strip domain in place
        req.linkedin = req.linkedin.strip()

        # validations
        if not req.linkedin or req.linkedin in ["NA", "#N/A"]:
            return Response(
                error=ProviderResponseError(
                    code="NO_LINKEDIN", message="No linkedin provided"
                )
            )

        # get headcount from locations
        return self.headcount_by_locations(
            RequestHeadcountByLocation(
                linkedin=req.linkedin,
                locations=[],
                country=req.country,
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                filter_titles=req.filter_titles,
            )
        )

    # Get global headcount
    def headcount_global(self, req: RequestHeadcountGlobal) -> Response:
        # strip domain in place
        req.linkedin = req.linkedin.strip()

        # validations
        if not req.linkedin or req.linkedin in ["NA", "#N/A"]:
            return Response(
                error=ProviderResponseError(
                    code="NO_LINKEDIN", message="No linkedin provided"
                )
            )

        # get headcount from locations
        return self.headcount_by_locations(
            RequestHeadcountByLocation(
                linkedin=req.linkedin,
                locations=[],
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                filter_titles=req.filter_titles,
            )
        )

    # Get headcount by locations
    def headcount_by_locations(self, req: RequestHeadcountByLocation) -> Response:
        search_credits = 0
        collect_credits = 0

        def get_usage() -> dict[str, Any]:
            if search_credits + collect_credits == 0:
                return {}
            return {
                "action_usage_unit_type": ProviderUsageType.CREDIT,
                "action_usage_units": collect_credits * 4 + search_credits,
                "action_usage_extra_data": {
                    "collect_credits": collect_credits,
                    "search_credits": search_credits,
                    "collect_multiplier": 4,
                },
            }

        # get company from linkedin
        try:
            company = self.cs.get_company_by_linkedin(req.linkedin)
            collect_credits += 1
        except coresignal.CoreSignalException as e:
            logger.exception("Core signal, company error", e)
            # Rate limit exceeded
            if e.status_code == 429 or e.status_code == 503:
                logger.info(f"Rate limit exceeded while getting members: {e}")
                return Response(
                    error=ProviderResponseError(
                        code=str(e.status_code),
                        message="Core signal member search rate limit exceeded error",
                        retryable=True,
                        e=e,
                    )
                )

            return Response(
                error=ProviderResponseError(
                    code=f"CORESIGNAL_COMPANY_ERROR_{e.status_code}",
                    message=str(e),
                    e=e,
                ),
                **get_usage(),
            )
        except Exception as e:
            logger.exception("Unknown Error when calling coresignal company", e)
            return Response(
                error=ProviderResponseError(
                    code="CORESIGNAL_COMPANY_UNKNOWN_ERROR", message=str(e), e=e
                ),
                **get_usage(),
            )

        # validate if coresignal company exists
        if not company:
            return Response(
                error=ProviderResponseError(
                    code="CORESIGNAL_COMPANY_ERROR",
                    message=f"Company not found for linkedin: {req.linkedin}",
                ),
                **get_usage(),
            )

        try:
            if isinstance(req.country, str):
                if req.country in SupportedCountries.__args__:
                    countries: Set[SupportedCountries] | None = {
                        cast(SupportedCountries, req.country)
                    }
                else:
                    raise ValueError(
                        f"Country '{req.country}' is not in supported format"
                    )
            else:
                countries = req.country
        except ValueError as ve:
            logger.error("Country conversion error: %s", ve)
            return Response(
                error=ProviderResponseError(
                    code="INVALID_COUNTRY",
                    message=str(ve),
                    e=ve,
                )
            )
        except Exception as e:
            logger.exception("Unknown error during country conversion", exc_info=True)
            return Response(
                error=ProviderResponseError(
                    code="COUNTRY_CONVERSION_ERROR",
                    message="Unknown error during country conversion",
                    e=e,
                )
            )

        # build search query and split into multiple queries if too long
        try:
            query_builder = lambda l: build_coresignal_search_query(
                company,
                l,
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                filter_titles=req.filter_titles,
                countries=countries,
            )
            queries = split_query_if_long(req.locations, query_builder)
        except CoreSignalMaxQueryCountExceedException:
            logger.exception("Query Split error")
            return Response(
                error=ProviderResponseError(
                    code="CORESIGNAL_SPLIT_ERROR_422", message="Query split error"
                ),
                **get_usage(),
            )

        # run queries and get headcount
        try:
            count = 0
            if len(queries) == 1:
                [_, _count] = self.cs.search_members_es(queries[0])
                count = _count
                search_credits += 1
            else:
                allIds: list[int] = []
                # this runs through split queries and counts unique ids
                for query in queries:
                    [ids, count] = self.cs.search_members_es(query)
                    if count >= self.cs.MAX_PAGE_SIZE:
                        # TODO: ankith - can't we paginate here?
                        return Response(
                            error=ProviderResponseError(
                                code="CORESIGNAL_SPLIT_ERROR_422",
                                message=f"Implied 422 - sub query has count {count} ",
                            )
                        )
                    allIds.extend(ids)
                count = len(list(unique_everseen(allIds)))

            return Response(
                result=Result(count=count),
                **get_usage(),
            )
        except coresignal.CoreSignalException as e:
            logger.exception("Core signal, search error", e)
            # Rate limit exceeded
            if e.status_code == 429 or e.status_code == 503:
                logger.info(f"Rate limit exceeded while getting members: {e}")
                return Response(
                    error=ProviderResponseError(
                        code=str(e.status_code),
                        message="Core signal member search rate limit exceeded error",
                        retryable=True,
                        e=e,
                    )
                )

            # TODO: Do we always get status code?
            return Response(
                error=ProviderResponseError(
                    code=f"CORESIGNAL_MEMBER_SEARCH_ERROR_{e.status_code}",
                    message=str(e),
                    e=e,
                ),
                **get_usage(),
            )
        except Exception as e:
            logger.exception("Unknown Error when calling coresignal search", e)
            return Response(
                error=ProviderResponseError(
                    code="CORESIGNAL_MEMBER_SEARCH_UNKNOWN_ERROR", message=str(e), e=e
                ),
                **get_usage(),
            )

    @staticmethod
    def chargeable_units_calculator(usage: ActionUsage) -> int:
        return (usage.action_units or 0) * 4
