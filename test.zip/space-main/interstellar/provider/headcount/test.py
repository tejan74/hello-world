import unittest

from provider.headcount import coresignal, RequestHeadcountByZip

class TestHeadcount(unittest.TestCase):
    def test_coresignal(self):
        provider = coresignal.Provider()
        result = provider.headcount_by_zip(
            RequestHeadcountByZip(
                zip="33056",
                region_code="US",
                linkedin="https://www.linkedin.com/company/google"
            )
        )
        print(result)

if __name__ == "__main__":
    unittest.main()
