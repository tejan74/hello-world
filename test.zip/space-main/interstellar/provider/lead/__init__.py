# Providers for Leads
from provider.lead import _coresignal as coresignal

# Types and interfaces
from provider.lead._classes import Interface, Response, Result, Lead, RequestGetByCityState, RequestGetByCountry, RequestGetByZip, RequestGetGlobal
