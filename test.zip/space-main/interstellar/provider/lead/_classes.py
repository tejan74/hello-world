import abc
import pydantic
from typing import Dict, List, Set

from lib.coresignal.constant import SupportedCountries
from provider._classes import ProviderResponse


class RequestGetByZip(pydantic.BaseModel):
    company_linkedin: str
    lead_count: int
    zip: str
    region_code: str
    radius: int | None = 50
    required_titles: List[str] | None = None
    optional_titles: List[str] | None = None
    titles_weight: List[Dict[str, str | int]] | None = None
    filter_titles: List[str] | None = None


class RequestGetGlobal(pydantic.BaseModel):
    company_linkedin: str
    lead_count: int
    required_titles: List[str] | None = None
    optional_titles: List[str] | None = None
    titles_weight: List[Dict[str, str | int]] | None = None
    filter_titles: List[str] | None = None


class RequestGetByCountry(pydantic.BaseModel):
    company_linkedin: str
    country: Set[SupportedCountries] | str
    lead_count: int
    required_titles: List[str] | None = None
    optional_titles: List[str] | None = None
    titles_weight: List[Dict[str, str | int]] | None = None
    filter_titles: List[str] | None = None


class RequestGetByCityState(pydantic.BaseModel):
    company_linkedin: str
    locations: List[Dict[str, str]] = []
    lead_count: int
    country: Set[SupportedCountries] | str | None = None
    required_titles: List[str] | None = None
    optional_titles: List[str] | None = None
    titles_weight: List[Dict[str, str | int]] | None = None
    filter_titles: List[str] | None = None


# Unified model for lead
class Job(pydantic.BaseModel):
    title: str | None = None
    date_to: str | None = None
    date_from: str | None = None
    duration: str | int | None = None
    location: str | None = None
    company_url: str | None = None
    company_name: str | None = None


class Lead(pydantic.BaseModel):
    name: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    title: str | None = None
    url: str | None = None
    location: str | None = None
    industry: str | None = None
    summary: str | None = None
    country: str | None = None
    connections_count: int | None = None
    experience_count: int | None = None
    job: Job | None = None


# Result as part of response
class Result(pydantic.BaseModel):
    leads: List[Lead]
    count: int


# Response contains Result and Response
Response = ProviderResponse[Result]


# Interface for provider
class Interface(abc.ABC):
    """Abstract class for company leads providers."""

    def __init__(self) -> None:
        pass

    @abc.abstractmethod
    def get_by_zip(self, req: RequestGetByZip) -> Response:
        """Get leads for a company in a zip code.

        Args:
            company_name (str): Company name.

        Returns:
            list: List of leads.
        """
        pass

    @abc.abstractmethod
    def get_global(self, req: RequestGetGlobal) -> Response:
        """Get leads for a company.

        Args:
            company_name (str): Company name.

        Returns:
            list: List of leads.
        """
        pass

    @abc.abstractmethod
    def get_by_country(self, req: RequestGetByCountry) -> Response:
        """Get leads for a company in a country.

        Args:
            company_name (str): Company name.
            country (str): Country name.

        Returns:
            list: List of leads.
        """
        pass

    @abc.abstractmethod
    def get_by_city_state(self, req: RequestGetByCityState) -> Response:
        """Get leads for a company in a city and state.

        Args:
            company_name (str): Company name.

        Returns:
            list: List of leads.
        """
        pass
