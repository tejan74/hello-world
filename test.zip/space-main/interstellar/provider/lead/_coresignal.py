import json
from typing import Any, Dict, Iterable, List, Optional, Set, cast
from unittest import result
from more_itertools import interleave_longest, unique_everseen

from lib import coresignal, gis
from lib.coresignal.constant import SupportedCountries
from lib.coresignal.helper import (
    CoreSignalDBCache,
    CoreSignalMaxQueryCountExceedException,
    build_coresignal_search_query,
    split_query_if_long,
    surface_leads_current_exp,
)

from provider._classes import ProviderResponseError
from provider.lead._classes import (
    Interface,
    Response,
    Result,
    Lead,
    RequestGetGlobal,
    RequestGetByCityState,
    RequestGetByCountry,
    RequestGetByZip,
)

from util.gis import parse_zipcode
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Provider(Interface):
    def __init__(self, api_key: Optional[str] = None) -> None:
        super().__init__()
        self.cs = coresignal.ApiClient(api_key, CoreSignalDBCache())
        self.gis = gis.GIS()

    def get_by_zip(self, req: RequestGetByZip) -> Response:
        pzip = parse_zipcode(req.zip)
        radius = req.radius or 50

        if not req.zip or req.zip == "NA" or req.zip == "#N/A":
            logger.debug("NO_ZIP_CODE")
            return Response(
                error=ProviderResponseError(
                    code="NO_ZIP_CODE", message="No zip code provided"
                )
            )

        locations = self.gis.locations_near_zip(pzip["zip"], req.region_code, radius)

        if not locations:
            logger.debug("ZIP_NOT_FOUND")
            return Response(
                error=ProviderResponseError(
                    code="ZIP_NOT_FOUND", message="Zip not found"
                )
            )

        logger.debug("location count %s", len(locations))

        leads = self.get_by_city_state(
            req=RequestGetByCityState(
                company_linkedin=req.company_linkedin,
                locations=locations,
                lead_count=req.lead_count,
                country=None,
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                titles_weight=req.titles_weight,
                filter_titles=req.filter_titles,
            )
        )
        return leads

    def get_global(self, req: RequestGetGlobal) -> Response:
        leads = self.get_by_city_state(
            req=RequestGetByCityState(
                company_linkedin=req.company_linkedin,
                locations=[],
                lead_count=req.lead_count,
                country=None,
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                titles_weight=req.titles_weight,
                filter_titles=req.filter_titles,
            )
        )
        return leads

    def get_by_country(self, req: RequestGetByCountry):
        if not req.country:
            logger.error("Invalid param: country")
            return Response(
                error=ProviderResponseError(
                    code="VALUE_E", message="Invalid param: country"
                )
            )

        leads = self.get_by_city_state(
            req=RequestGetByCityState(
                company_linkedin=req.company_linkedin,
                locations=[],
                lead_count=req.lead_count,
                country=req.country,
                required_titles=req.required_titles,
                optional_titles=req.optional_titles,
                titles_weight=req.titles_weight,
                filter_titles=req.filter_titles,
            )
        )
        return leads

    def get_by_city_state(self, req: RequestGetByCityState) -> Response:
        """Get leads for a company."""

        try:
            company = self.cs.get_company_by_linkedin(req.company_linkedin)
        except coresignal.CoreSignalException as e:
            logger.exception("Core signal, company error", e)
            # Rate limit exceeded
            if e.status_code == 429 or e.status_code == 503:
                logger.info(f"Rate limit exceeded while getting members: {e}")
                return Response(
                    error=ProviderResponseError(
                        code=f"CORESIGNAL_COMPANY_ERROR_{e.status_code}",
                        message="Core signal member search rate limit exceeded error",
                        retryable=True,
                        e=e,
                    )
                )

            return Response(
                error=ProviderResponseError(
                    code=f"CORESIGNAL_COMPANY_ERROR_{e.status_code}",
                    message="Core signal, company error",
                    e=e,
                )
            )
        except Exception as e:
            logger.exception("Unknown Error when calling coresignal company", e)
            return Response(
                error=ProviderResponseError(
                    code="UNKNOWN_ERROR",
                    message="Unknown Error when calling coresignal company",
                    e=e,
                )
            )
        if not company:
            return Response(
                error=ProviderResponseError(
                    code="COMPANY_NOT_FOUND", message="Company not found"
                )
            )

        # Convert the string to SupportedCountries Literal and create a set
        try:
            if isinstance(req.country, str):
                if req.country in SupportedCountries.__args__:
                    countries: Set[SupportedCountries] | None = {
                        cast(SupportedCountries, req.country)
                    }
                else:
                    raise ValueError(
                        f"Country '{req.country}' is not in supported format"
                    )
            else:
                countries = req.country
        except ValueError as ve:
            logger.error("Country conversion error: %s", ve)
            return Response(
                error=ProviderResponseError(
                    code="INVALID_COUNTRY",
                    message=str(ve),
                    e=ve,
                )
            )
        except Exception as e:
            logger.exception("Unknown error during country conversion", exc_info=True)
            return Response(
                error=ProviderResponseError(
                    code="COUNTRY_CONVERSION_ERROR",
                    message="Unknown error during country conversion",
                    e=e,
                )
            )

        try:
            query_builder = lambda l: build_coresignal_search_query(
                company,
                l,
                countries,
                req.required_titles,
                req.optional_titles,
                req.titles_weight,
                req.filter_titles,
            )
            queries = split_query_if_long(req.locations, query_builder)
            logger.debug("Query count %s", len(queries))
        except CoreSignalMaxQueryCountExceedException:
            logger.exception("Query Split error")
            return Response(
                error=ProviderResponseError(
                    code="QUERY_SPLIT_ERROR", message="Query Split error"
                )
            )

        try:
            lead_ids = list(
                unique_everseen(
                    interleave_longest(
                        *map(lambda q: self.cs.search_members_es(q)[0], queries)
                    )
                )
            )
            logger.debug("lead_ids count %s", len(lead_ids))
            logger.debug("lead_ids %s", lead_ids)
        except coresignal.CoreSignalException as e:
            logger.exception("Core signal, search error", e)
            # Rate limit exceeded
            if e.status_code == 429 or e.status_code == 503:
                logger.info(f"Rate limit exceeded while getting members: {e}")
                return Response(
                    error=ProviderResponseError(
                        code=f"CORESIGNAL_MEMBER_ERROR_{e.status_code}",
                        message="Core signal member search rate limit exceeded error",
                        retryable=True,
                        e=e,
                    )
                )

            return Response(
                error=ProviderResponseError(
                    code=f"CORESIGNAL_MEMBER_ERROR_{e.status_code}",
                    message="Core signal member search error",
                    e=e,
                )
            )
        except Exception as e:
            logger.exception("Unknown Error when calling coresignal search", e)
            return Response(
                error=ProviderResponseError(
                    code="CORESIGNAL_MEMBER_SEARCH_UNKNOWN_ERROR",
                    message="Unknown Error when calling coresignal search",
                    e=e,
                )
            )

        leads: List[Dict[str, Any]] = []
        for i in range(0, min(req.lead_count, len(lead_ids))):
            error_count = 0
            try:
                lead = self.cs.get_member_by_id(lead_ids[i])
                surface_leads_current_exp(lead, company["id"])
                leads.append(lead)
            except coresignal.CoreSignalException as e:
                logger.exception("Core signal, member collect error", e)
                error_count += 1
                if error_count >= 3:
                    # TODO: anktih: Need you help in understanding this
                    # leads.extend(
                    #     lead_error_result(
                    #         f"CONTINUES_CORESIGNAL_ERROR_{e.status_code} | CORESIGNAL-MEMBER-COLLECT"
                    #     )
                    # )
                    break
            except Exception as e:
                logger.exception(
                    "Unknown Error when calling coresignal memeber collect", e
                )
                return Response(
                    error=ProviderResponseError(
                        code="CORESIGNAL_MEMBER_COLLECT_UNKNOWN_ERROR",
                        message="Unknown Error when calling coresignal member collect",
                        e=e,
                    )
                )

        return Response(
            result=Result(
                leads=[
                    Lead(
                        name=l.get("name"),
                        first_name=l.get("first_name"),
                        last_name=l.get("last_name"),
                        title=l.get("title"),
                        url=l.get("url"),
                        location=l.get("location"),
                        industry=l.get("industry"),
                        summary=l.get("summary"),
                        country=l.get("country"),
                        connections_count=l.get("connections_count"),
                        experience_count=l.get("experience_count"),
                        job=l.get("current_experience"),
                    )
                    for l in leads
                ],
                count=len(leads),
            )
        )
