import unittest
from provider.lead._classes import RequestGetGlobal
from provider.lead import coresignal

class TestHeadcount(unittest.TestCase):
    def test_coresignal(self):
        provider = coresignal.Provider()
        result = provider.get_global(
            req = RequestGetGlobal(company_linkedin="https://www.linkedin.com/company/google",lead_count=1,required_titles=["Engineer"])
        ).get_result()
        print(result.leads)

if __name__ == "__main__":
    unittest.main()
