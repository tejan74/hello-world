""" 
Helper classes
"""

# Requirements for defining helper classes and interfaces, can eventually be split into helper file
import abc
import pydantic
from typing import Optional, Literal

from lib import anthropic
from lib.open_ai import SupportedModel
from provider._classes import ProviderResponse


# Types and classes
class Request(pydantic.BaseModel):
    model: str | None = None
    query: str
    output_format: Literal["text", "json_object"] = "text"
    temperature: float | None = None


# Using a different model for OpenAI schema json
class OpenAIRequest(Request):
    model: SupportedModel | None = None


class AnthropicRequest(Request):
    model: anthropic.ClaudeModel | None = None


class LLMUsage(pydantic.BaseModel):
    prompt_tokens: Optional[int]
    completion_tokens: Optional[int]
    total_tokens: Optional[int]


class Result(pydantic.BaseModel):
    message: str | dict | None
    usage: LLMUsage | None


Response = ProviderResponse[Result]

"""
Provider interface
"""


class Interface(abc.ABC):
    def __init__(self, api_key: str, model: str):
        pass

    @abc.abstractmethod
    def complete(self, req: Request) -> Response:
        pass
