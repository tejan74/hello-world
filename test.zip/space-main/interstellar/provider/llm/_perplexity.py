from math import e
from typing import Literal

from lib import perplexity
from provider import llm
from provider.llm._classes import Request, Response
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

class Provider(llm.openai.Provider):
    def __init__(self, model: perplexity.SupportedModel, api_key: str):
        self.client = perplexity.ApiClient(model, api_key)

    def complete(self, req: Request) -> Response:        
        if req.output_format == "json_object":
            # TODO: Find a place to do json checks and retries
            logger.error("Perplexity API does not support json_object output format")

        response = super().complete(req)
        
        return response
