import unittest

from pydantic import BaseModel

from provider.llm import openai, perplexity, anthropic, Request

class Sample(BaseModel):
    president: str

class Test(unittest.TestCase):
    def test_perplexity_basic(self):
        pplx = perplexity.Provider(api_key="", model="mistral-7b-instruct")
        output = pplx.complete(Request(query=f"You only talk in json format. Who is the president of the United States?", output_format="json_object"))
        print(output)
    
    def test_openai_basic(self):
        pplx = openai.Provider(api_key="", model="gpt-4-1106-preview")
        output = pplx.complete(Request(query="Who is the president of the United States? give output in json", output_format="json_object"))
        print(output)

    def test_anthropic_basic(self):
        pplx = anthropic.Provider(model="claude-2.1")
        output = pplx.complete(Request(query="Who is the president of the United States? give output in json", output_format="json_object"))
        print(output)

if __name__ == "__main__":
    unittest.main()
