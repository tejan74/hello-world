import abc
import pydantic
from provider import ProviderResponse

class Request(pydantic.BaseModel):
    search_query: str
    search_location: str
    place_type: str | None = None
    result_count: int | None = None

class Place(pydantic.BaseModel):
    name: str | None
    address: str | None
    logo_url: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    types: list[str] | None = None
    website: str | None = None
    phone: str | None = None


# Interfaces and classes for Companies List
class Result(pydantic.BaseModel):
    places_list: list[Place]


# Output leverages Company List's result and the generic Provider Error system
Response = ProviderResponse[Result]


# Provider for CompanyEnrich
class Interface(abc.ABC):
    """
    Interface for places list.
    """

    @abc.abstractmethod
    def search_places(
        self,
        req: Request
    ) -> Response:
        """
        Search places by location.
        :param search_query: Text query to  fetch results.
        :param search_location: Locations of the places to fetch. Eg. "New York, US"
        :param place_type: Type of the place.
        :param result_count: Maximum number of results expected as response
        :return: List of places.
        """
        pass
