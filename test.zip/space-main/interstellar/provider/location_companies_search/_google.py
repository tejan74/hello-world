import pydash
import json

from lib import google_maps
from lib.google_maps._classes import ViewPort
from provider.location_companies_search._classes import (
    Interface,
    Request,
    Response,
    Result,
    Place,
)
from provider import ProviderResponseError
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Provider(Interface):

    # Initializing the max result limit to below value.
    MAX_RESULT_LIMIT = 200

    def __init__(self, api_key: str | None = None):
        self.client = google_maps.ApiClient(api_key)

    def search_places(
        self,
        req: Request
    ) -> Response:
        """
        param: search_location: Search location for places. The more accurate the search location the more number of places will be returned.
        """

        try:

            if req.result_count is None or req.result_count > self.MAX_RESULT_LIMIT:
                req.result_count = self.MAX_RESULT_LIMIT

            formatted_search_query = req.search_query + " at " + req.search_location

            geocode_response = self.client.geocode(req.search_location)
            logger.info("place geocode", json.dumps(geocode_response))

            if not geocode_response:
                return Response(
                    error=ProviderResponseError(
                        code="INVALID_SEARCH_LOCATION",
                        message="Not a valid search location",
                    )
                )

            northeast_lat = pydash.get(
                geocode_response[0], "geometry.bounds.northeast.lat"
            )
            northeast_lon = pydash.get(
                geocode_response[0], "geometry.bounds.northeast.lng"
            )
            southwest_lat = pydash.get(
                geocode_response[0], "geometry.bounds.southwest.lat"
            )
            southwest_lon = pydash.get(
                geocode_response[0], "geometry.bounds.southwest.lng"
            )

            result = self.split_viewport(
                northeast_lat, northeast_lon, southwest_lat, southwest_lon
            )
            logger.info(result)

            places_result_list = []

            for viewport in result:
                response = self.client.search_places(
                    view_port=viewport, text_query=formatted_search_query
                )

                # Get places list
                places_list = response

                for place in places_list:
                    place_result = Place(
                        name=pydash.get(place, "displayName.text"),
                        address=pydash.get(place, "formattedAddress"),
                        types=pydash.get(place, "types"),
                        latitude=pydash.get(place, "location.latitude"),
                        longitude=pydash.get(place, "location.longitude"),
                        website=pydash.get(place, "websiteUri"),
                    )
                    places_result_list.append(place_result)

                    if req.result_count == len(places_result_list):
                        break

                if req.result_count == len(places_result_list):
                    break

            # check if places list is found, this is None if no place is found
            if not places_result_list:
                return Response(
                    error=ProviderResponseError(
                        code="NO_DATA",
                        message="No data found",
                    )
                )

            logger.info("places result count", len(places_result_list))
            result = Result(places_list=places_result_list)
            return Response(result=result)

        except google_maps.GoogleMapsException as e:
            logger.exception("Error while fetching places list.")
            return Response(
                error=ProviderResponseError(
                    code=f"GOOGLE_MAPS_{e.status_code}",
                    message="Error while fetching places list.",
                    e=e,
                )
            )
        except Exception as e:
            logger.exception("Error while fetching places list.")
            return Response(
                error=ProviderResponseError(
                    code="GOOGLE_MAPS_ERROR_UNKNOWN",
                    message="Error while fetching places list.",
                    e=e,
                )
            )

    def split_viewport(
        self, northeast_lat, northeast_lon, southwest_lat, southwest_lon
    ):
        """
        Splits the given view port into 12 parts and returns a list of view_ports
        :param northeast_lat North east latitude of the view port
        :param northeast_lon North east longitude of the view port
        :param southwest_lat South west latitude of the view port
        :param southwest_lon South west longitude of he view port
        """
        lat_range = abs(northeast_lat - southwest_lat) / 3
        lon_range = abs(northeast_lon - southwest_lon) / 4

        rectangles = []

        for i in range(3):
            for j in range(4):
                rect_northeast_lat = northeast_lat - i * lat_range
                rect_northeast_lon = northeast_lon - j * lon_range
                rect_southwest_lat = rect_northeast_lat - lat_range
                rect_southwest_lon = rect_northeast_lon - lon_range

                rectangles.append(
                    ViewPort(
                        northeast_lat=rect_northeast_lat,
                        northeast_lon=rect_northeast_lon,
                        southwest_lat=rect_southwest_lat,
                        southwest_lon=rect_southwest_lon,
                    )
                )

        return rectangles
