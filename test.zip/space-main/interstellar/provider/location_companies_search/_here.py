import pydash

from lib import here_maps
from provider.location_companies_search._classes import (
    Interface,
    Request,
    Response,
    Result,
    Place,
)
from provider import ProviderResponseError
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


class Provider(Interface):

    # Initializing the max result limit to below value. At the time of this implementation can provide max 100 results.
    MAX_RESULT_LIMIT = 100

    def __init__(self, api_key: str | None = None):
        self.client = here_maps.ApiClient(api_key)

    def search_places(
        self,
        req: Request
    ) -> Response:
        try:
            search_query, search_location, result_count = req.search_query, req.search_location, req.result_count
            
            if result_count is None:
                result_count = self.MAX_RESULT_LIMIT

            # build result object
            places_result_list = []

            formatted_search_query = search_query + " at " + search_location

            output = self.client.geocode(search_location)

            logger.info("search location geocode",output)

            if not pydash.get(output,"items",[]):
                return Response(
                    error=ProviderResponseError(
                        code="INVALID_SEARCH_LOCATION",
                        message="Not a valid search location",
                    )
                )

            latitude = pydash.get(output["items"][0],"position.lat")
            longitude = pydash.get(output["items"][0],"position.lng")
            country_code = pydash.get(output["items"][0],"address.countryCode")

            # Get places list based on text query
            response = self.client.discover(
                query=formatted_search_query,
                latitude=latitude,
                longitude=longitude,
                limit=result_count,
                country_code=country_code,
                radius=1000
            )

            # Get places list
            places_list = response.get("items", [])

            # check if places list is found, this is None if no company is found
            if not places_list:
                return Response(
                    error=ProviderResponseError(
                        code="NO_DATA",
                        message="No data found",
                    )
                )

            for place in places_list:
                place_result = Place(
                    name=pydash.get(place, "title", None),
                    address=pydash.get(place, "address.label", None),
                    latitude=pydash.get(place, "position.lat", None),
                    longitude=pydash.get(place, "position.lng", None),
                    phone=pydash.get(place, "contacts[0].phone[0].value", None),
                    website=pydash.get(place, "contacts[0].www[0].value", None),
                )
                places_result_list.append(place_result)
                if result_count == len(places_result_list):
                    break

            result = Result(places_list=places_result_list)
            # return response
            return Response(result=result)

        except here_maps.HereMapsException as e:
            logger.exception("Error while fetching places list.")
            return Response(
                error=ProviderResponseError(
                    code=f"HERE_MAPS_{e.status_code}",
                    message="Error while fetching places list.",
                    e=e,
                )
            )
        except Exception as e:
            logger.exception("Error while fetching places list.")
            return Response(
                error=ProviderResponseError(
                    code="HERE_MAPS_ERROR_UNKNOWN",
                    message="Error while fetching places list.",
                    e=e,
                )
            )
