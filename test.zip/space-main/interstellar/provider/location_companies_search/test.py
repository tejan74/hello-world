import unittest

from provider.location_companies_search import google, here, Request
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

class Test(unittest.TestCase):
    def test_search_places_google_maps(self):
        provider = google.Provider()
        response = provider.search_places(
            Request(search_query="Restaurants", search_location="New York", result_count=4)
        )
        logger.info(response)

    def test_search_places_here_maps(self):
        provider = here.Provider()
        response = provider.search_places(
            Request(search_query="Restaurants", search_location="New York")
        )
        logger.info(response)


if __name__ == "__main__":
    unittest.main()
