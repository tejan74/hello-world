# Providers for Scraper
from provider.scraper import _apify as apify

# Types and interfaces
from provider.scraper._classes import Interface, Response, Result, Request, RequestData
