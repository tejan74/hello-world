import pydash
import config
from provider.scraper._classes import (
    Interface,
    Request,
    RequestData,
    Response,
    Result,
)
from lib import apify
from apify_shared.consts import WebhookEventType
from provider._classes import ProviderResponseError, ProviderResponseStatus


class Provider(Interface):
    def __init__(
        self, api_key: str | None = None, webhook_url: str | None = None
    ) -> None:
        super().__init__()
        self.api_client = apify.ApiClient(key=api_key)
        self.webhook_url = webhook_url or config.get_parameter("APIFY_WEBHOOK_URL")
        self.webhooks: list[apify.WebhookTypeWithoutPayload] = [
            {
                "event_types": [
                    WebhookEventType.ACTOR_RUN_CREATED,
                    WebhookEventType.ACTOR_RUN_SUCCEEDED,
                    WebhookEventType.ACTOR_RUN_FAILED,
                    WebhookEventType.ACTOR_RUN_TIMED_OUT,
                    WebhookEventType.ACTOR_RUN_ABORTED,
                    WebhookEventType.ACTOR_RUN_RESURRECTED,
                ],
                "request_url": self.webhook_url,
            }
        ]

    def run(self, req: Request) -> Response:
        run = self.api_client.start_actor(
            actor_id=req.actor_id,
            run_input=req.run_input,
            memory_mbytes=req.memory_mbytes,
            timeout_secs=req.timeout,
            build=req.build,
            webhooks=self.webhooks,
        )

        run_id: str = pydash.get(run, "id")
        actor_id: str = pydash.get(run, "actId")

        if (not run_id) or (not actor_id):
            return Response(
                error=ProviderResponseError(
                    code="NO_RUN_ID",
                    message=f"No run_id / actor_id found for actor: {req.actor_id}",
                ),
                status=ProviderResponseStatus.FAILED,
            )

        return Response(
            result=Result(run_id=run_id, actor_id=actor_id),
            status=ProviderResponseStatus.WAITING,
        )

    def get_data(self, req: RequestData) -> Response:
        data = self.api_client.list_items(run_id=req.run_id)

        if (not data):
            return Response(
                error=ProviderResponseError(
                    code="NO_DATA_FOUND",
                    message=f"No data found for run_id: {req.run_id}",
                ),
                status=ProviderResponseStatus.FAILED,
            )

        return Response(
            result=Result(
                run_id=req.run_id,
                actor_id=req.actor_id,
                data={"count": data.count, "items": data.items},
            ),
            status=ProviderResponseStatus.COMPLETED,
        )
