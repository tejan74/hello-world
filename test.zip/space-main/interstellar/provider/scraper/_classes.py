import abc
from typing import Annotated, Any, Literal
import pydantic
from provider._classes import ProviderResponse


class Request(pydantic.BaseModel):
    actor_id: str
    run_input: Annotated[
        dict[str, Any],
        pydantic.WithJsonSchema({"additionalProperties": True, "type": "object"}),
    ]
    timeout: int | None = None
    build: str | None = None
    memory_mbytes: int | None = None


class RequestData(pydantic.BaseModel):
    actor_id: str
    run_id: str


class Result(pydantic.BaseModel):
    actor_id: str
    run_id: str
    data: Any = None


Response = ProviderResponse[Result]


class Interface(abc.ABC):

    def __init__(self, api_key: str | None = None, webhook_url: str | None = None):
        pass

    @abc.abstractmethod
    def run(self, req: Request) -> Response:
        pass

    @abc.abstractmethod
    def get_data(self, req: RequestData) -> Response:
        pass
