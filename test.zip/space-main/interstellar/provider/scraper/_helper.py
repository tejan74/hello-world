from prisma import Prisma, Json
from engine.v1.engine_sqs_client import EngineSQSClient
from provider.scraper._apify import Provider
from provider.scraper._classes import RequestData, Response
from provider._classes import ProviderResponseError, ProviderResponseStatus
from engine._classes import StepStatus


class ApifyStepStateManager:
    def __init__(self, prisma: Prisma) -> None:
        self._prisma = prisma
        self._provider = Provider()

    def update_wf_step_state(self, run_id: str, actor_id: str, status: str):
        if not self._prisma.is_connected():
            self._prisma.connect()

        wf_step_state = self._prisma.wf_stepstate.find_first(
            where={
                "output": {
                    "equals": Json(
                        {
                            "error": None,
                            "result": {
                                "data": None,
                                "run_id": run_id,
                                "actor_id": actor_id,
                            },
                            "status": ProviderResponseStatus.WAITING,
                        }
                    )
                }
            },
            order={"updatedAt": "desc"},
        )

        if not wf_step_state:
            raise Exception(f"No Workflow Step State Found for run_id: {run_id}")

        if status == "SUCCEEDED":
            data = self._provider.get_data(
                req=RequestData(actor_id=actor_id, run_id=run_id)
            )
        else:
            data = Response(
                error=ProviderResponseError(
                    code=status,
                    message=f"{status}! run_id: {run_id} actor_id: {actor_id}",
                ),
                status=ProviderResponseStatus.FAILED,
            )

        updated_wf_step_state = self._prisma.wf_stepstate.update(
            where={"uuid": wf_step_state.uuid},
            data={
                "output": Json(data.model_dump()),
                "status": StepStatus.FAILED if data.error else StepStatus.SUCCESSFUL,
            },
        )

        if (not data.error) and updated_wf_step_state:
            EngineSQSClient().notify_step_completion(
                instance_id=updated_wf_step_state.instanceId,
                step_id=updated_wf_step_state.stepId,
            )

        return updated_wf_step_state
