"""
This is a simple provider used for testing the system.
"""

import pydantic

from provider._classes import ProviderResponse


class Request(pydantic.BaseModel):
    a: int
    b: int


class Result(pydantic.BaseModel):
    result: int


Response = ProviderResponse[Result]


class Provider:
    def add(self, input: Request):
        return Response(result=Result(result=input.a + input.b))

    def subtract(self, input: Request):
        return Response(result=Result(result=input.a - input.b))

    def multiply(self, input: Request):
        return Response(result=Result(result=input.a * input.b))
