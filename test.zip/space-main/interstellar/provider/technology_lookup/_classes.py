import abc
import pydantic
from provider._classes import ProviderResponse


class Request(pydantic.BaseModel):
    url: str
    remove_noise: bool = True
    min_verification_age: int = 0
    max_verification_age: int = 2


class Category(pydantic.BaseModel):
    slug: str | None = None
    name: str | None = None


class Technology(pydantic.BaseModel):
    slug: str | None = None
    name: str | None = None
    categories: list[Category] = []


class Result(pydantic.BaseModel):
    technologies: list[Technology] = []


Response = ProviderResponse[Result]


class Interface(abc.ABC):
    def __init__(self, api_key: str | None = None) -> None:
        pass

    @abc.abstractmethod
    def lookup(self, req: Request) -> Response:
        pass
