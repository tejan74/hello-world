import pydash
from provider.technology_lookup._classes import Interface, Request, Response, Technology, Category, Result
from lib import wappalyzer
from provider._classes import ProviderResponseError

class Provider(Interface):
    def __init__(self, api_key: str | None = None) -> None:
        self.api_key = api_key
        self.api_client = wappalyzer.ApiClient(api_key=self.api_key)

    def lookup(self, req: Request) -> Response:
        try:
            res = self.api_client.technology_lookup(url=req.url, remove_noise=req.remove_noise, min_age=req.min_verification_age, max_age=req.max_verification_age)
            technologies_array = pydash.get(res, "0.technologies", [])
            technologies: list[Technology] = []
            for technology in technologies_array:
                slug = pydash.get(technology, "slug")
                name = pydash.get(technology, "name")
                categories_array = pydash.get(technology, "categories", [])
                categories: list[Category] = []
                for category in categories_array:
                    cat_slug = pydash.get(category, "slug")
                    cat_name = pydash.get(category, "name")
                    categories.append(Category(slug=cat_slug, name=cat_name))
                technologies.append(Technology(slug=slug, name=name, categories=categories))
            
            return Response(result=Result(technologies=technologies))
                
        except Exception as e:
            return Response(error=ProviderResponseError(code="CALL_FAILED", message=f"{e}"))
