# Providers for Capturing Web Page screenshots
from provider.web_capture._selenium import Provider


# Types and interfaces
from provider.web_capture._classes import Interface, Request, Response, Result
