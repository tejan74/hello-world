import abc
import pydantic

from provider._classes import ProviderResponse


class Request(pydantic.BaseModel):
    url: str
    screenshot_save_path: str = "./screenshots"
    return_image_url: bool = False


class Result(pydantic.BaseModel):
    image_count: int
    image_locations: list[str]
    image_urls: list[str] | None = None


Response = ProviderResponse[Result]


class Interface(abc.ABC):
    @abc.abstractmethod
    def capture_web_page(self, req: Request) -> Response:
        pass
