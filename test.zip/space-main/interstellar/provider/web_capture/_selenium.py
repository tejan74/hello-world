from lib.selenium import WebScraper
from provider._classes import ProviderResponseError
from provider.web_capture._classes import Interface, Request, Response, Result
import time 
import uuid

from util.files import create_file_directory
from util.images import get_base64_image_url
from util.logger import interstellar_logger


logger = interstellar_logger(__name__)
class Provider(Interface):
    def __init__(self):
        self.capturer = WebScraper()

    def capture_web_page(self, req: Request) -> Response:
        try:
            self.capturer.load_url(req.url)

            page_height = self.capturer.get_initial_page_height()

            # Scroll and take screenshots until the end of the page
            current_scroll = 0
            scroll_increment = self.capturer.get_window_inner_size()["height"] - 16/2 # subtracting 16 to create small overlap between screenshots to avoid text getting cut off 16=1em
            scroll_delay = 1
            image_locations = []
            image_urls = []
            folder_path = req.screenshot_save_path.strip().rstrip(" /")
            while current_scroll < page_height:
                unique_string = str(uuid.uuid4())
                screenshot_download_location = f"{folder_path}/{unique_string}.png"

                create_file_directory(folder_path)
                self.capturer.save_screenshot(screenshot_download_location)
                image_locations.append(screenshot_download_location)
                image_urls.append(
                    get_base64_image_url(screenshot_download_location, "image/png")
                )
                # Scroll down the page by the specified increment
                current_scroll += scroll_increment
                self.capturer.scroll_page(current_scroll)

                # Wait for a short time to let the content load and avoid capturing blank areas
                time.sleep(scroll_delay)

            return Response(
                result = Result(
                    image_count=len(image_locations),
                    image_locations=image_locations,
                    image_urls=image_urls if req.return_image_url else None,
                )
            )

        except Exception as e:
            logger.exception("Error while capturing web page screenshots")
            return Response(
                error = ProviderResponseError(
                    code="WEB_CAPTURE_ERROR",
                    message="Error while capturing web page screenshots",
                    e=e
                )
            )
