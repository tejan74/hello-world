import csv
from urllib import response
import pydash
from datetime import datetime
from typing import Any, Literal, TypedDict

# Importing functions from the script module
from script.collection.earnings_call_transcript import get_earnings_call_transcript
from script.collection.form_5500 import get_form_5500
from script.collection.download import download_file
from script.collection.page import save_page_as_pdf
from provider.web_search import google

from lib import apollo, seeking_alpha
from lib import google_cloud_storage

# Define custom types using Literal and TypedDict
SourceType = Literal["file", "page"]
DocumentType = Literal["annual_report", "earnings_call_transcript", "form_5500", "get_from_google"]
RequiredFiles = Literal["10K", "esg", "employee_benefits", "welfare_benefits", "earnings_call_transcript"]

class FileType(TypedDict):
    name: RequiredFiles
    query: str
    type: DocumentType

class GetFileResponseType(TypedDict):
    link: str | None
    got_from_source: bool

class OutputType(TypedDict):
    name: str
    link: str | None

def store_file(url: str, path: str, type: SourceType | None = "file", headers: dict[str, Any] | None = None, wait: int | None = None) -> str | None:
    downloaded_path = None

    if type and type == "file":
        downloaded_path = download_file(url, path, headers = headers)
    elif type and type == "page":
        downloaded_path = save_page_as_pdf(url, path, wait)

    if downloaded_path:
        print(f"File downloaded successfully: {downloaded_path}")
    else:
        print(f"Failed to download file: {path}")

    return downloaded_path

def get_file_from_source(name: str, file: FileType, symbol: str | None = None) -> GetFileResponseType:
    link = None
    got_from_source = True

    try:
        if file["type"] == "annual_report":
            if not symbol:
                return {"link": link, "got_from_source": got_from_source}
            link = seeking_alpha.ApiClient().get_annual_report(name, symbol)
        elif file["type"] == "earnings_call_transcript":
            link = get_earnings_call_transcript(name, datetime.now().year - 1)
        elif file["type"] == "form_5500":
            link = get_form_5500(sponsor=name, name="Welfare Benefits")
        elif file["type"] == "get_from_google":
            response = google.Provider().search(query=file["query"], limit=1, file_type="pdf")
            if response.result:
                link = response.result.items[0].link
        else:
            raise Exception(f"File: {file['name']} is not of correct type: {file['type']}")
    except BaseException as e:
        got_from_source = False
        print(e)

    # If no link is found and the document type is not 'get_from_google', try searching on Google
    if not link and file["type"] != "get_from_google":
        print(f"No file found for {file['name']} at source. Searching Google now.")
        response = google.Provider().search(query=file["query"], limit=1, file_type="pdf")
        if response.result:
            link = response.result.items[0].link
        got_from_source = False

    return {"link": link, "got_from_source": got_from_source}

def collect_data(name: str, domain: str, files: list[FileType], storage_path: str, bucket: str = "orbital-datalake", symbol: str | None = None, output_csv_path: str = "store/output.csv"):
    # Initialize clients and libraries
    gcs_lib = google_cloud_storage.ApiClient(bucket)
    seeking_alpha_client = seeking_alpha.ApiClient()
    apollo_client = apollo.ApiClient()
    

    file_output: list[OutputType] = []

    # Get industry
    res = apollo_client.organization_enrichment(domain)
    industry = pydash.get(res, "organization.industry")

    # Iterate through each file type and collect data
    for file in files:
        try:
            # Get link
            response = get_file_from_source(name, file, symbol)
            link: str | None = pydash.get(response, "link")
            got_from_source: bool = pydash.get(response, "got_from_source")

            if link:
                file_output.append({"name": file["name"], "link": link})
                print(f"File: {file['name']} found at {link}")
                source_type: SourceType = "page" if file["type"] == "earnings_call_transcript" else "file"   
                if file["type"] == "annual_report" and got_from_source:
                    path = seeking_alpha_client.download(pdf_link = link, file_path = f"{storage_path}/{file['name']}")
                else:
                    path = store_file(url = link, path = f"{storage_path}/{file['name']}", type = source_type)
                if path:
                    # Get current date in YYYY_MM_DD format to store in GCS
                    current_date = datetime.today()
                    formatted_date = current_date.strftime("%Y_%m_%d")
                    # Upload to GCS
                    gcs_lib.upload_file(f"{formatted_date}/{file['name']}", path, True)
                else:
                    print(f"File: {file['name']} failed to download")
            else:
                file_output.append({"name": file["name"], "link": None})
                print(f"File {file['name']} not found")

        except BaseException as e:
            file_output.append({"name": file["name"], "link": None})
            print(e)

    return {"file_output": file_output, "industry": industry}
