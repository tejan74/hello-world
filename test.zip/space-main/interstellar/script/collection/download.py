from typing import Any, Dict, Optional
import requests
from script.collection.page import DEFAULT_USER_AGENT

DEFAULT_HEADERS = {
     "User-Agent": DEFAULT_USER_AGENT
}

def download_file(url: str, file_path: str, headers: Optional[Dict[str, Any]] = DEFAULT_HEADERS, timeout: int | None = None) -> Optional[str]:
    try:
        # Make a GET request to the specified URL
        response = requests.get(url = url, headers = headers, timeout = timeout)

        # Check if the request was successful (status code 200)
        if response.status_code == 200:
            # Open the file in binary write mode and write the content
            with open(file_path, "wb") as file:
                file.write(response.content)
            
            # Return the file path after successful download
            return file_path
        else:
            # Return None on any other indicator of failure
            return None
    except BaseException as e:
        # Print the exception and return None if an error occurs
        print(f"Error: {e}")
        return None
