from typing import List, Optional
import pydash
from lib import seeking_alpha

SEEKING_ALPHA_BASE_URL = "https://seekingalpha.com"

def get_earnings_call_transcript(name: str, year: int, type: Optional[str] = "Earnings Call Transcript") -> Optional[str]:
    # Initialize Seeking Alpha API client
    client = seeking_alpha.ApiClient()

    # Retrieve symbol for the given name
    response = client.get_symbols(query=name)
    symbol: Optional[str] = pydash.get(response, "symbols[0].name")

    if symbol:
        # Retrieve transcripts for the symbol from the specified year
        response_transcripts = client.get_transcripts(id=symbol, from_year=year)

        # Extract transcripts data
        transcripts = pydash.get(response_transcripts, "data", [])

        # Check if transcripts is a list
        if transcripts and isinstance(transcripts, List):
            # Iterate through transcripts to find a matching type
            for transcript in transcripts:
                # Extract title from the transcript
                title: Optional[str] = pydash.get(transcript, "attributes.title")

                # Check if title matches the specified type (case-insensitive)
                if title and type and pydash.includes(title.lower(), type.lower()):
                    # Extract document path from the transcript
                    doc_path: Optional[str] = pydash.get(transcript, "links.self")

                    # Return the complete document URL if document path is found
                    if doc_path:
                        return SEEKING_ALPHA_BASE_URL + doc_path
    
    # Return None if no matching transcript is found
    return None



