import pydash
from lib import efast

EFAST_PDF_BASE_URL = "https://efast2-filings-public.s3.amazonaws.com/prd"

def get_form_5500(sponsor: str, year: int) -> str | None:
    # Initialize EFAST API client
    client = efast.ApiClient()

    # Loop to check for last 4 years
    for i in range(0, 4):
        # Query EFAST API for form 5500 filings matching the plan sponsor and name
        response = client.query(plan_sponsor=sponsor, plan_year = year - i)

        # Extract hits from the response
        hits = pydash.get(response, "hits.hit")

        # Sort hits by number of participants
        hits = pydash.sort_by(hits, lambda x: int(pydash.get(x, "fields.participantsboy") or 0), reverse = True)

        # Iterate through hits to find a matching plan name
        for hit in hits:
            # Extract plan name from the hit
            # {
            #     "id": "20230706083550NAL0018385936001",
            #     "fields": {
            #         "city": "New York",
            #         "plansponsor": "American Express Company and Its Participating Subsidiaries",
            #         "ein": "134922250",
            #         "datereceived": "2023-07-06T08:35:50Z",
            #         "planyear": "2022",
            #         "planname": "American Express Retiree Welfare Benefits Plan",
            #         "state": "NY",
            #         "participantsboy": "2353",
            #         "pdfpath": "/2023/07/06/20230706083550NAL0018385936001.pdf",
            #         "pn": "525"
            #     }
            # }
            plan_name: str | None = pydash.get(hit, "fields.planname")
            if not plan_name:
                continue
            if any(keyword in plan_name.lower() for keyword in ["retiree", "retire", "puerto rico", "death"]):
                continue
            pdf_path: str | None = pydash.get(hit, "fields.pdfpath")
            if any(keyword in plan_name.lower() for keyword in ["health", "welfare", "employee benefits", "group benefits", "flexible benefits"]) and pdf_path:
                return EFAST_PDF_BASE_URL + pdf_path
                            
    
    # Return None if no matching form 5500 is found
    return None
