import base64
import time
from typing import Dict, Optional
import pydash
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

DEFAULT_USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

DEFAULT_PDF_PARAMS = {
    'landscape': False,               # Set to True for landscape, False for portrait
    'printBackground': True,          # Print the background graphics or not
    'displayHeaderFooter': False,     # Include the header and footer defined by the page
    'scale': 1,                       # Scale of the webpage rendering. 1 is no scaling
    'paperWidth': 8.27,               # Width of the paper in inches (A4 size width)
    'paperHeight': 11.69,             # Height of the paper in inches (A4 size height)
    'marginTop': 0,                   # Top margin in inches
    'marginBottom': 0,                # Bottom margin in inches
    'marginLeft': 0,                  # Left margin in inches
    'marginRight': 0                  # Right margin in inches
}

def save_page_as_pdf(url: str, path: str, wait: Optional[int] = None, user_agent: Optional[str] = DEFAULT_USER_AGENT, pdf_params: Optional[Dict] = DEFAULT_PDF_PARAMS, pages: Optional[str] = None) -> Optional[str]:
    # Set up Chrome options
    chrome_options = webdriver.ChromeOptions()

    # Run in headless mode
    chrome_options.add_argument("--headless")   

    # Disable GPU
    chrome_options.add_argument("--disable-gpu")

    # Disable software rasterizer (for improved performance in headless mode)
    chrome_options.add_argument("--disable-software-rasterizer")

    # Set the user agent string
    chrome_options.add_argument(f"user-agent={user_agent}")

    # Disable sandbox
    chrome_options.add_argument("--no-sandbox")

    # Disable dev shm usage
    chrome_options.add_argument("--disable-dev-shm-usage")


    # Set path to the chromedriver executable
    service = Service(ChromeDriverManager().install())

    # Initialize the driver with the specified service and options
    driver = webdriver.Chrome(service=service, options=chrome_options)

    try:
        if pages and pdf_params:
            # Range of pages to print, Eg: '1' for 1st page, '2' for 2nd page, '1-2' for first two pages
            pdf_params["pageRanges"] = pages

        # Open the page
        driver.get(url)

        # Wait for the specified wait time
        if wait:
            time.sleep(wait)

        if pdf_params:
            # Use Chrome DevTools Protocol to print the page to PDF
            result = driver.execute_cdp_cmd("Page.printToPDF", pdf_params)
            # Decode base64 content
            pdf_content = base64.b64decode(pydash.get(result, "data"))

            # Save the PDF to a file
            with open(path, 'wb') as file:
                file.write(pdf_content)
    except BaseException as e:
        # Print the exception and return None if an error occurs
        print(f"Error: {e}")
        return None
    finally:
        # Close the browser in a 'finally' block to ensure it's closed even if an exception occurs
        driver.quit()

    return path
