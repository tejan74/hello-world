import time
from prisma import Prisma

from lib.crm.hubspot._classes import Hubspot, HubspotParams
from hubspot.crm.schemas.exceptions import UnauthorizedException
from hubspot.crm.properties.exceptions import (
    UnauthorizedException as UnauthorizedException2,
)
from hubspot.crm.objects.exceptions import (
    UnauthorizedException as UnauthorizedException3,
)

DB_URL = ""
ACCESS_TOKEN = ""
REFRESH_TOKEN = ""
CLIENT_ID = ""
CLIENT_SECRET = ""


prisma = Prisma(datasource={"url": DB_URL})


def table_setup(prisma: Prisma):
    prisma.execute_raw(
        """
       create table if not exists "hubspot_sync" (
            "crmId" varchar primary key,
            "objectType" varchar not null,
            "data" jsonb not null,
            "createdAt" timestamp not null default now(),
            "updatedAt" timestamp not null default now()
         );                
    """
    )


def main():
    prisma.connect()
    table_setup(prisma)

    sync_objects = [
        {"name": "account", "cursor": None, "assocs": ["contacts", "company"]},
        {"name": "company", "cursor": None, "assocs": ["contacts", "account"]},
        {"name": "contact", "cursor": None, "assocs": ["company", "account"]},
    ]
    for sync_object in sync_objects:
        obj_name = sync_object["name"]
        obj_assocs = sync_object["assocs"]
        print("starting to sync", obj_name)
        first_run = True
        cursor = sync_object["cursor"]
        page = 0
        while first_run or cursor:
            first_run = False
            out = list_hs_objects(obj_name, obj_assocs, cursor)
            objects = out["results"]
            cursor = out["pagination"]["cursor"]

            print(f"{obj_name} page {page} - {len(objects)} cursor {cursor}")

            while objects:
                obj = objects.pop()
                prisma.execute_raw(
                    """
                    insert into "hubspot_sync" ("crmId", "objectType", "data") values ($1,$2,$3)
                    on conflict ("crmId") do update set "data" = $3, "updatedAt" = now()
                """,
                    obj["id"],
                    obj_name,
                    obj,
                )
            page += 1


hs_last_call = time.time() - 1
hs_current_rate = 0
hs_allowed_rate = 10 / 70  # 70 (150) calls per 10 seconds


def list_hs_objects(obj_name: str, obj_assocs: list[str], cursor: str | None = None):
    global ACCESS_TOKEN
    global hs_last_call
    global hs_current_rate
    hs_client = Hubspot(
        HubspotParams(
            access_token=ACCESS_TOKEN,
            refresh_token=REFRESH_TOKEN,
            client_id=CLIENT_ID,
            client_secret=CLIENT_SECRET,
        )
    )
    i = 0
    while i < 3:
        if hs_current_rate > hs_allowed_rate:
            time.sleep(1)
        try:
            out = hs_client._get_objects_with_pagination(
                object_name=obj_name,
                associations=obj_assocs,
                page_size=100,
                cursor=cursor,
            )
            now = time.time()
            hs_current_rate = now - hs_last_call
            hs_last_call = now
            return out
        except (
            UnauthorizedException,
            UnauthorizedException2,
            UnauthorizedException3,
        ) as e:
            if "EXPIRED_AUTHENTICATION" in e.body:  # type: ignore
                res = hs_client.client.auth.oauth.tokens_api.create(
                    grant_type="refresh_token",
                    client_id=CLIENT_ID,
                    client_secret=CLIENT_SECRET,
                    refresh_token=REFRESH_TOKEN,
                )
                print("toke refreshed", res)
                hs_client = Hubspot(
                    HubspotParams(
                        access_token=res.access_token,
                        refresh_token=REFRESH_TOKEN,
                        client_id=CLIENT_ID,
                        client_secret=CLIENT_SECRET,
                    )
                )
                ACCESS_TOKEN = res.access_token
            else:
                raise e
        i += 1


if __name__ == "__main__":
    # hs_client = Hubspot(HubspotParams(access_token=ACCESS_TOKEN))
    # hs_client._get_objects_with_pagination(
    #     object_name="company", page_size=2, cursor=None
    # )
    main()
