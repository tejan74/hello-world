import datetime
import jwt
from typing import Any
import config

def create(payload: dict[str,Any], exp_days: int = 90):
    # Adding token expiry days
    payload["exp"] = datetime.datetime.utcnow() + datetime.timedelta(days = exp_days)

    encoded = None
    secret =  config.get_parameter("JWT_TOKEN_SECRET")
    if secret:
        encoded = jwt.encode(payload, secret, algorithm = "HS256")

    return encoded
