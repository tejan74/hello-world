import os
import shutil
from concurrent.futures.process import _ResultItem
from typing import Literal
from provider.document_search import openai
from provider import company_file as research_account
from script.collection.data_collection import RequiredFiles

def account_research(domain: str, questions: list[str], required_files: list[RequiredFiles]):
    print(f"Researching for Account: {domain}")
    store_path = f"store/{domain}"
    # Check if file_store directory exists or not
    if not os.path.exists(store_path):
        print("Making File Store Directory")
        os.makedirs(store_path)
    else:
        print("File Store found")


    company_file_provider = research_account.Provider()
    print(f"Downloading files")
    for rf in required_files:
        company_file_provider.download(domain, rf, f"{store_path}/{rf}.pdf")
    

    # Scan for files
    print("Scanning for files")
    file_paths: list[str] = []
    files = os.listdir(store_path)
    for file in files:
        file_paths.append(f"{store_path}/{file}")

    # Query using the provider
    provider = openai.Provider(documents=file_paths,system_instruction=None)
    print("Setting up Document Search Provider")
    provider.setup()
    print("Querying Document Search Provider")
    res = provider.query(queries=questions)
    print("Destroying Document Search Provider")
    provider.destroy()

    print("Removing File Store Directory")
    shutil.rmtree(store_path)

    return res

# Research a batch of accounts
def batch_account_research(domains: list[str], questions: list[str], required_files: list[RequiredFiles]):
   
    batch_results = []
    for domain in domains:
        result = account_research(domain, questions, required_files)
        batch_results.append({
            "domain": domain,
            "result": result
        })

    return batch_results
