from typing import TypedDict
import fitz

class ResponseType(TypedDict):
    carrier: str
    broker: str
    page: int

def form_5500_reasearch(path: str) -> list[ResponseType]:
    doc = fitz.open(path)
    pages = doc.page_count

    output: list[ResponseType] = []

    for i in range(pages):
        page = doc.load_page(i)
        # Context: We are trying to get the carrier and the broker name from the form 5500 pdf
        # Those names will only be present in the pages of Schedule A written in a specific area
        # We extract the text from the area and see if it's Schedule A
        # If yes we then extract the carriers name and brokers name 
        # Which are also present in particualar area of the page
        # This form 5500 shared a similar structure so we go with this approach
        schedule_a_text = page.get_textbox(fitz.Rect(0, 0, 120, 60)).split("\n")
        schedule_a_text = schedule_a_text[len(schedule_a_text) - 1]

        if schedule_a_text == "SCHEDULE A":
            carrier = page.get_textbox(fitz.Rect(0, 294, 350, 303))
            carrier = carrier.split("\n")
            carrier = carrier[len(carrier) - 1] if len(carrier) > 1 else "NA"
            broker = page.get_textbox(fitz.Rect(0, 460, 250, 470))
            broker = broker.split("\n")
            broker = broker[len(broker) - 1] if len(broker) > 2 else "NA"
            output.append({"carrier": carrier, "broker": broker, "page": i+1})

    doc.close()
    return output
