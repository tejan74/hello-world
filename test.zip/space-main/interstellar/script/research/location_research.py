from provider.vision import openai
from lib import google_cloud_storage
from util import files
from util import images
import os
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


def location_research(domain_name: str | None = None):
    logger.info(f"Researching company locations for: {domain_name if domain_name is not None else ''}")

    # Setup
    bucket_name = "orbital-9"
    staging_folder_name = "staging"
    errors_folder_name = "errors"

    formatted_domain_name = (
        domain_name.replace(".", "_") if domain_name is not None else None
    )

    base_file_download_location = (
        "./script/research/location_research/"
    )
    files.create_file_directory(base_file_download_location)

    logger.info(f"Creating vision provider")
    vision_model_name = "gpt-4-vision-preview"
    vision_provider = openai.Provider(vision_model_name)

    logger.info(f"Creating GCS Client")
    google_cloud_storage_client = google_cloud_storage.ApiClient(bucket_name)

    vision_prompt = "Return proper JSON document. Only return JSON not any other text. Return full JSON object as an array and don't add any additional keys. Only capture these fields address, city, state, zip code and phone"
    max_tokens = 4000
    image_format = "image/png"

    logger.info(f"Reading images from the bucket {bucket_name}")
    # List all location images with in the prefix folder
    prefix = (
        f"{formatted_domain_name}/"
        if domain_name is not None
        else f"{staging_folder_name}/"
    )
    location_images = google_cloud_storage_client.list_files(
        prefix=prefix, include_subdirectories=False
    )

    # Downloading and processing the location images
    for location_image in location_images:
        location_image_path = location_image.get('name')
        file_name = os.path.basename(location_image_path).strip()
        if file_name:
            file_download_location = base_file_download_location + file_name
            logger.info(f"Capturing addresses from image: {location_image_path}")

            google_cloud_storage_client.download_file(location_image_path, file_download_location)

            base64_image_url = images.get_base64_image_url(
                file_download_location, image_format
            )
            domain_name = location_image.get("metadata").get("domain_name")
            formatted_domain_name = (
                domain_name.replace(".", "_") if domain_name is not None else ""
            )
            try:
                logger.info("Invoking Vision Provider")
                res = vision_provider.complete(
                    vision_prompt=vision_prompt,
                    image_url=base64_image_url,
                    max_tokens=max_tokens,
                )

                logger.info(f"Processing image completed for: {location_image_path}")
                new_image_cloud_path = f"{formatted_domain_name}/{file_name}"

            except Exception as e:
                logger.info(f"Error while processing image: {location_image_path}", e)
                new_image_cloud_path = f"{errors_folder_name}/{file_name}"

            move_file_in_bucket(google_cloud_storage_client, location_image_path, new_image_cloud_path)

            files.delete_file(file_download_location)

    logger.info(f"Location research completed")

    # Clean up
    logger.info(f"Cleaning up the downloads folder")
    files.delete_folder(base_file_download_location)
    logger.info(f"Clean up completed")

def move_file_in_bucket(google_cloud_storage_client, cloud_path, new_cloud_path):
    logger.info(f"Moving {cloud_path} to {new_cloud_path}")
    google_cloud_storage_client.rename_file(
            cloud_path=cloud_path,
            new_cloud_path=new_cloud_path
        )
    logger.info(f"Image moved to: {new_cloud_path}")
