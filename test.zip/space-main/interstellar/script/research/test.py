import unittest
from pydantic import BaseModel
from script.research import location_research


class Test(unittest.TestCase):
    def test_location_research(self):
        location_research.location_research()


if __name__ == "__main__":
    unittest.main()
