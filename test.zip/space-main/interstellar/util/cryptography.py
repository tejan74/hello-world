import base64
from cryptography.fernet import Fernet

import config


def encrypt_tenant_secret(text: str):
    key = config.get_parameter("TENANT_ENCRYPTION_KEY")
    if not key:
        raise Exception("'TENANT_ENCRYPTION_KEY' is empty.")
    return encrypt(key, text)


def decrypt_tenant_secret(text: str):
    key = config.get_parameter("TENANT_ENCRYPTION_KEY")
    if not key:
        raise Exception("'TENANT_ENCRYPTION_KEY' is empty.")
    return decrypt(key, text)


def encrypt(key: str, text: str):
    """encrypt the text (in utf-8) using the key and return the encrypted text in base64 encoded format."""
    # Fernet is built on top of standard cryptographic primitives.
    # It uses AES in CBC mode with 128 bit key for encryption, PKCS7 for padding and HMAC using SHA256 for authentication
    # Create instance of symmetric encryption implementation.
    f = Fernet(key)
    return base64.b64encode(f.encrypt(text.encode("utf-8"))).decode("ascii")


def decrypt(key: str, text: str):
    """decrypt text encoded in base64 format using the key and return the decrypted text (in utf-8)."""
    # Create instance of symmetric encryption implementation
    f = Fernet(key)
    return f.decrypt(base64.b64decode(text)).decode("utf-8")


def generate_key():
    return Fernet.generate_key()
