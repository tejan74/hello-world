from urllib.parse import unquote, urlsplit

import psycopg2

def get_db_connection(url: str):
    parts = urlsplit(unquote(url))
    return psycopg2.connect(
        host=parts.hostname,
        port=parts.port,
        user=parts.username,
        password=parts.password,
        dbname=parts.path[1:],
    )
