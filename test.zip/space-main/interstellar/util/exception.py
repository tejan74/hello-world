def to_dict(e: BaseException):
    """Convert an exception to a JSON-serializable dictionary."""
    return {
        "type": e.__class__.__name__,
        "message": str(e),
        "__cause__": to_dict(e.__cause__) if e.__cause__ else None,
        "__context__": to_dict(e.__context__) if e.__context__ else None,
    }


class RetryableException(Exception):
    """An error that can be retried."""

    def __init__(self, message: str):
        super().__init__(message)
