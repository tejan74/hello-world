import os
import shutil
from typing import Any

import requests
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

DEFAULT_USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"


def create_file_directory(file_directory):
    if not os.path.exists(file_directory):
        logger.info("creating file directory")
        os.makedirs(file_directory)
    else:
        logger.info("File directory already exists")


def delete_folder(folder_path):
    try:
        shutil.rmtree(folder_path)
        logger.info(
            f"Folder '{folder_path}' and its contents have been successfully deleted"
        )
    except OSError as e:
        logger.info(f"Error: {folder_path} - {e.strerror}")


def delete_file(file_path):
    try:
        os.remove(file_path)
        logger.info(f"File '{file_path}' deleted successfully")
    except OSError as e:
        logger.info(f"Error while deleting file: {file_path} - {e.strerror}")


def download_file(
    url: str,
    file_path: str,
    headers: dict[str,Any] = {"User-Agent": DEFAULT_USER_AGENT},
    timeout: int | None = None,
) -> str | None:
    try:
        # Make a GET request to the specified URL
        response = requests.get(url=url, headers=headers, timeout=timeout)

        # Check if the request was successful (status code 200)
        if response.status_code == 200:
            # Open the file in binary write mode and write the content
            with open(file_path, "wb") as file:
                file.write(response.content)

            # Return the file path after successful download
            return file_path
        else:
            # Return None on any other indicator of failure
            return None
    except BaseException as e:
        # Print the exception and return None if an error occurs
        logger.exception(f"Error downloading file: {e}")
        return None
