import time
from typing import Callable

from pyparsing import Any

from util.time import calculate_exponential_delay
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)

def retry_callback(func: Callable[..., Any], retries: int = 3, base_delay = 1, scale = 2, jitter=0, max_delay=10*60):
    attempt_count = 1
    while True:
        try:
            return func()
        except BaseException as e:
            if attempt_count <= retries:
                logger.debug("Retry callback: callback error ",exc_info=e)
                time.sleep(calculate_exponential_delay(attempt_count, base_delay, scale, jitter, max_delay))
            else:
                raise e
        attempt_count += 1
