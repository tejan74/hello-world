import re

def parse_zipcode(zip: str):
    country = "United States"
    if re.match("[A-Z]",zip):
        zip = re.sub("( |-)","",zip,0,re.I)
        country = "Canada"
    else:
        zip = re.sub(" ","",zip).split("-")[0]
    return { "zip": zip, "country": country }
