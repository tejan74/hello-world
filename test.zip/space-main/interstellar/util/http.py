from typing import Literal
from urllib.parse import urlparse
import requests
from bs4 import BeautifulSoup, Tag
from util.logger import interstellar_logger

logger = interstellar_logger(__name__)


# note sure if we need this type keyword, but keeping it cuz its giving different color
type HttpMethods = Literal["GET", "OPTIONS", "HEAD", "POST", "PUT", "PATCH", "DELETE"]


def get_redirect_url_from_html(html_content: bytes):
    logger.info("Getting redirect url from html")
    # Parse the HTML content using BeautifulSoup
    soup = BeautifulSoup(html_content, "html.parser")
    # Check for meta refresh tag for redirection
    meta_tag = soup.find("meta", attrs={"http-equiv": "refresh"})
    if meta_tag and isinstance(meta_tag, Tag):
        # Extract the URL from the content attribute
        content = meta_tag["content"]
        if isinstance(content, str):
            redirect_url = content.split("url=")[-1].strip()
            if redirect_url:
                logger.info(f"Redirect url found = {redirect_url}")
                return redirect_url
            else:
                # Check for JavaScript-based redirection
                script_tags = soup.find_all("script")
                redirect_url = None
                for script in script_tags:
                    if "window.location" in script.text:
                        # A crude way to extract the URL from JavaScript
                        start = script.text.find("window.location")
                        start = (
                            script.text.find("=", start) + 1
                        )  # Find '=' after 'window.location'
                        end = script.text.find(";", start)
                        redirect_url = script.text[start:end].strip().strip("'\"")
                        if redirect_url:
                            break
                if redirect_url:
                    logger.info(f"Redirect url found = {redirect_url}")
                    return redirect_url
                else:
                    return None


def get_host_from_url(url: str):
    parsed_url = urlparse(url)
    return parsed_url.hostname
