import base64


def get_base64_image_url(image_path, image_format):
    with open(image_path, "rb") as image_file:
        base64_encoded_image = base64.b64encode(image_file.read()).decode("utf-8")
        return f"data:{image_format};base64,{base64_encoded_image}"
