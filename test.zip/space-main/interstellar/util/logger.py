import copy
import logging
import os
import sys
from asgi_correlation_id import CorrelationIdFilter

from util import request_context

_modify_root_logger_called = False


def interstellar_logger(name: str) -> logging.Logger:
    if not _modify_root_logger_called:
        modify_root_logger()

    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    return logger


def modify_root_logger():
    root_logger = logging.getLogger()

    # Check if the handler is already added
    for handler in root_logger.handlers:
        if (
            handler.__class__.__name__ == "InterstellarLogHandler"
        ):  # isinstance doesn't seems to work here
            return

    print("Existing root logger handlers:", root_logger.handlers)

    stdout_handler = InterstellarLogHandler(sys.stdout, highest_level=logging.WARNING)
    stderr_handler = InterstellarLogHandler(sys.stderr, lowest_level=logging.ERROR)

    root_logger.addHandler(stdout_handler)
    root_logger.addHandler(stderr_handler)
    root_logger.setLevel(logging.INFO)

    global _modify_root_logger_called
    _modify_root_logger_called = True


class InterstellarLogHandler(logging.StreamHandler):
    def __init__(
        self,
        stream=sys.stdout,
        lowest_level: int | None = None,
        highest_level: int | None = None,
    ):
        super().__init__(stream)
        self.addFilter(CorrelationIdFilter())
        self.addFilter(LevelFilter(lowest_level, highest_level))
        self.setFormatter(InterstellarFormatter())


class InterstellarFormatter(logging.Formatter):
    def __init__(self):
        super().__init__(
            # sample log format:
            # 07/30 00:15:56.677 [INFO ][qCFpFsbzaVWP6uSHVTwD4] path:/v1/engine/run/aa/aa :: Running step aa for instance aa :: location:/api/v1.py:20
            # 07/30 00:15:56.677 [ERROR][qCFpFsbzaVWP6uSHVTwD4] path:/v1/engine/run/aa/aa :: Error occurred in request path /v1/engine/run/aa/aa :: location:/api/v1.py:24
            # 07/30 00:15:56.677 [INFO ][None] path:/v1/engine/run/aa/aa :: 127.0.0.1:50315 - "POST /v1/engine/run/aa/aa HTTP/1.1" 500 :: location:/api/v1.py:22
            "%(asctime)s.%(msecs)03d [%(levelname)-5s][%(correlation_id)s] %(req_path_or_event)s :: %(message)s %(error_location)s",
            datefmt="%m/%d %H:%M:%S",
        )
        self._root_dir = os.path.realpath(
            __file__ + "/../../"
        )  # go back 2 levels (cuz this is util.logger) to get to the root directory

    def format(self, record: logging.LogRecord):
        r_ctx = request_context.request_context.get()
        extra_vars = {
            **dict([("request_context_" + k, v) for k, v in r_ctx.items()]),
            "error_location": "",
            "req_path_or_event": "",
        }

        if record.pathname.startswith(self._root_dir):
            extra_vars["error_location"] = (
                ":: location:"
                + record.pathname[len(self._root_dir) :]
                + ":"
                + str(record.lineno)
            )
        if extra_vars.get("request_context_path"):
            extra_vars["req_path_or_event"] = (
                "path:" + extra_vars["request_context_path"]
            )
        elif extra_vars.get("request_context_event"):
            extra_vars["req_path_or_event"] = (
                "event:"
                + extra_vars["request_context_event"]
                + "-"
                + extra_vars["request_context_step_id"]
            )

        record.__dict__.update(extra_vars)
        return super().format(record)


class LevelFilter(logging.Filter):
    def __init__(
        self, lowest_level: int | None = None, highest_level: int | None = None
    ):
        self._highest_level = (
            highest_level if highest_level is not None else logging.CRITICAL
        )
        self._lowest_level = (
            lowest_level if lowest_level is not None else logging.NOTSET
        )

    def filter(self, record):
        return (
            record.levelno >= self._lowest_level
            and record.levelno <= self._highest_level
        )
