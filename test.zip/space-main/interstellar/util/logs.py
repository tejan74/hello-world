import uuid

import nanoid


def generate_request_id_with_parent(
    parent_id: str, child_id: str, is_uuid: bool | None = True
) -> str:
    # check if child_id is a valid uuid
    final_child_id = child_id
    if is_uuid:
        try:
            uuid.UUID(child_id)

            # get last piece of the child_id uuid
            final_child_id = child_id.split("-")[-1]
        except ValueError:
            raise ValueError(f"child_id {child_id} is not a valid UUID")

    return f"{parent_id}::{final_child_id}"


def generate_request_id() -> str:
    return str(nanoid.generate())
