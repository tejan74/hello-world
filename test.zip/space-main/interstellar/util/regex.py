from urllib.parse import urlparse

def extract_linkedin_shortcode(linkedin_url: str):
    if not linkedin_url:
        return None
    
    # Parse out URL parts "https://linkedin.com/company/rocketship"
    # [ "https:", "/", "linkedin.com", "/", "company", "rocketship"]
    parsed_url = urlparse(linkedin_url)
    
    # Pick out the path and then the final argument which is just shortcode "rocketship"
    # [ "/", "company", "rocketship"]
    shortcode = parsed_url.path.strip('/').split('/')[-1]
    if len(shortcode) >= 2:
        return shortcode
    else:
        return None
