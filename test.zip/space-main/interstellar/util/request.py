from typing import Any
import requests

from util.http import HttpMethods


class BaseRequest:
    def __init__(
        self, base_url: str | None = None, base_headers: dict[str, Any] = {}
    ) -> None:
        self.base_url = base_url or ""
        self.base_headers = base_headers

    def request(
        self,
        url: str,
        method: HttpMethods = "GET",
        headers: dict[str, Any] = {},
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        timeout: int | None = None
    ) -> tuple[Any, int, requests.Response]:
        res = requests.request(
            method,
            self.base_url + url,
            headers={**self.base_headers, **headers},
            params=params,
            json=body,
            timeout=timeout
        )
        return (res.json(), res.status_code, res)
