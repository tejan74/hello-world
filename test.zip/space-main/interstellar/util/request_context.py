from contextvars import ContextVar
from email.policy import default
from typing import TypedDict


class RequestContext(TypedDict):
    path: str
    event: str
    step_id: str


default_request_context = RequestContext(path="", event="", step_id="")


request_context: ContextVar[RequestContext] = ContextVar(
    "request_context", default=default_request_context
)
