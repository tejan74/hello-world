import random


def calculate_exponential_delay(attempt, base_delay = 1, scale = 2, jitter = 0, max_delay = 10*60):
    '''Calculates exponential delay with jitter'''
    # jitter can be a single value or a list of two values for the range
    if type(jitter) == list:
        js, je = jitter[0], jitter[1]
    else:
        js, je = 0, jitter
    return min((scale ** attempt)/scale * base_delay + random.uniform(js, je), max_delay)
