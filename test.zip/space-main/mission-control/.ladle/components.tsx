import type { GlobalProvider } from "@ladle/react";
import { Theme } from "@radix-ui/themes";
import * as React from "react";

// Import style -- don't change this order unless you know what you are doing
import "@/ui/styles/tailwind/input.css";
// -- don't change this order unless you know what you are doing
import "@/ui/styles/radix/theme-config.css";
// -- don't change this order unless you know what you are doing
import "@radix-ui/themes/styles.css";
// -- don't put any component import above or below this line

export const Provider: GlobalProvider = ({
  children,
  globalState,
  storyMeta,
}) => (
  <>
    <h1>Theme: {globalState.theme}</h1>
    <h2>{storyMeta?.customValue}</h2>
    <Theme radius="large">{children}</Theme>
  </>
);
