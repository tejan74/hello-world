/** @type {import('@ladle/react').UserConfig} */
export default {
    stories: "ui/**/*.stories.tsx",
    addons: {
        msw: {
            enabled: true,
        },
    },
};
