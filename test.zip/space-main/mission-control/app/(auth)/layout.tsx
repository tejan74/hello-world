import AuthLayout from "@/ui/layout/AuthLayout";

export default function SignInLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <AuthLayout>{children}</AuthLayout>;
}
