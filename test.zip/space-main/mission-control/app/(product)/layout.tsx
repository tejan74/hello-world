import { getUserAuth } from "@/services/auth/userAuth";
import AppContextProvider from "@/ui/context/AppContext";
import NavLayout from "@/ui/layout/NavLayout";
export default async function ProductLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getUserAuth();
  return (
    <AppContextProvider user={user}>
      <NavLayout>{children}</NavLayout>
    </AppContextProvider>
  );
}
