import AuthLayout from "@/ui/layout/AuthLayout";

export default function WelcomeLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <AuthLayout>{children}</AuthLayout>;
}
