import { getUserAuth } from "@/services/auth/userAuth";
import GetStartedPage from "@/ui/pages/GetStarted";

export default async function Page() {
  const user = await getUserAuth();

  return <GetStartedPage user={user} />;
}
