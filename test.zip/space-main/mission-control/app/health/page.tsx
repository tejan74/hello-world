const HeathCheck = () => {
  return <div>Health Check</div>;
};

export default HeathCheck;
