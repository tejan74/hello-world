import NextAuthSessionProvider from "@/context/NextAuthSessionProvider";
import { Theme } from "@radix-ui/themes";
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import Script from "next/script";
import { Toaster } from "react-hot-toast";

// Import style -- don't change this order unless you know what you are doing
import "@/ui/styles/tailwind/input.css";
// -- don't change this order unless you know what you are doing
import "@/ui/styles/radix/theme-config.css";
// -- don't change this order unless you know what you are doing
import "@radix-ui/themes/styles.css";
// -- don't put any component import above or below this line

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
});

export const metadata: Metadata = {
  title: "Orbital",
  description: "Uncover what matters most",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={inter.className}>
      <Script
        id="heap-analytics"
        type="text/javascript"
        strategy="afterInteractive"
      >
        {`
            window.heapReadyCb=window.heapReadyCb||[],window.heap=window.heap||[],heap.load=function(e,t){window.heap.envId=e,window.heap.clientConfig=t=t||{},window.heap.clientConfig.shouldFetchServerConfig=!1;var a=document.createElement("script");a.type="text/javascript",a.async=!0,a.src="https://cdn.us.heap-api.com/config/"+e+"/heap_config.js";var r=document.getElementsByTagName("script")[0];r.parentNode.insertBefore(a,r);var n=["init","startTracking","stopTracking","track","resetIdentity","identify","getSessionId","getUserId","getIdentity","addUserProperties","addEventProperties","removeEventProperty","clearEventProperties","addAccountProperties","addAdapter","addTransformer","addTransformerFn","onReady","addPageviewProperties","removePageviewProperty","clearPageviewProperties","trackPageview"],i=function(e){return function(){var t=Array.prototype.slice.call(arguments,0);window.heapReadyCb.push({name:e,fn:function(){heap[e]&&heap[e].apply(heap,t)}})}};for(var p=0;p<n.length;p++)heap[n[p]]=i(n[p])};
            heap.load("${process.env.NEXT_PUBLIC_HEAP_ENV_ID}");
        `}
      </Script>
      <body>
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: "#363636",
              color: "#fff",
            },
          }}
        />
        <NextAuthSessionProvider>
          <Theme radius="large">{children}</Theme>
        </NextAuthSessionProvider>
      </body>
    </html>
  );
}
