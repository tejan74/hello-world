import { getUserAuth } from "@/services/auth/userAuth";
import { redirect } from "next/navigation";

export default async function Home() {
  await getUserAuth();
  redirect("/table");
}
