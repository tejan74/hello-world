export type IntegrationType = "oauth" | "token";

export type IntegrationObject =
  | {
      id: number;
      name: string;
      provider: string;
      integrationType: IntegrationType;
      logo: string;
      description: string;
      enabled: boolean;
      category: string;
    }
  | {
      id: number;
      name: string;
      provider: string;
      integrationType: "generic";
      logo: string;
      description: string;
      enabled: boolean;
      category: string;
      schema: Record<string, any>;
    };

export const INTEGRATIONS: IntegrationObject[] = [
  {
    id: 1,
    name: "Salesforce",
    provider: "salesforce",
    integrationType: "oauth",
    logo: "https://logo.clearbit.com/salesforce.com",
    description:
      "CRM platform for sales, marketing, and customer support. Salesforce provides a wide range of tools and features to help businesses manage their customer relationships effectively.",
    enabled: true,
    category: "CRM",
  },
  {
    id: 2,
    name: "HubSpot",
    provider: "hubspot",
    integrationType: "oauth",
    logo: "https://logo.clearbit.com/hubspot.com",
    description:
      "CRM platform for marketing, sales, and customer service. HubSpot offers a suite of tools to help businesses attract, engage, and delight customers.",
    enabled: true,
    category: "CRM",
  },
  {
    id: 3,
    name: "Pipedrive",
    provider: "pipedrive",
    integrationType: "token",
    logo: "https://logo.clearbit.com/pipedrive.com",
    description:
      "Sales CRM and pipeline management tool for small and medium-sized sales teams. Pipedrive helps sales teams organize and track their deals, manage their pipelines, and collaborate effectively.",
    enabled: false,
    category: "CRM",
  },
  {
    id: 4,
    name: "OpenAI",
    provider: "openai",
    integrationType: "token",
    logo: "https://logo.clearbit.com/openai.com",
    description:
      "AI research laboratory and company. OpenAI is dedicated to ensuring that artificial general intelligence (AGI) benefits all of humanity. They conduct research in various AI domains and develop cutting-edge technologies to advance the field of AI.",
    enabled: true,
    category: "AI",
  },
  {
    id: 5,
    name: "Apollo",
    provider: "apollo",
    integrationType: "token",
    logo: "https://logo.clearbit.com/apollo.io",
    description:
      "GraphQL platform for building, managing, and scaling applications. Apollo provides a comprehensive set of tools and services for developing GraphQL APIs.",
    enabled: true,
    category: "API",
  },
  {
    id: 6,
    name: "Slack",
    provider: "slack",
    integrationType: "oauth",
    logo: "https://logo.clearbit.com/slack.com",
    description:
      "Collaboration hub for team communication and file sharing. Slack is a popular messaging and collaboration platform that allows teams to communicate and collaborate in real-time.",
    enabled: false,
    category: "Communication",
  },
  {
    id: 7,
    name: "Salesforce Sandbox",
    provider: "salesforceSandbox",
    integrationType: "oauth",
    logo: "https://logo.clearbit.com/salesforce.com",
    description:
      "CRM platform for sales, marketing, and customer support. Salesforce Sandbox provides a testing environment for Salesforce users to develop and test their applications without affecting their production data.",
    enabled: true,
    category: "CRM",
  },
];
