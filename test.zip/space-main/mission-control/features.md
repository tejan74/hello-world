## Mission Control 
*Last updated 3 April 2024*

### Table features
**High-Prio**
1. Editable table names 
2. Lock table from editing
3. Delete table
4. Add/Delete column
5. Add/Delete row
6. Re-arrange column
7. Filter by column(s)
8. Sort by column 
9. Pagination
10. lock column
11. hide column

**Low-Prio**
- table cells are navigatable using keyboard like a spreadsheet
- live table showing all new data in near realtime
- data aggregation
- FUTURE: support commands through a global command pallet (cmd+k)
- FUTURE: generate table using AI. text to table
- FUTURE: Support Views in table that has s subset of underlying table columns and rename view

### Table Column & Cell features
**High-Prio**
1. Static data column type store user entered data
2. Action columns that runs an action on the its input
3. Formula columns that evaluate a given formula
4. Derived column that displays specific output element from an action field
6. **Input editor** for action column
7. **Formual editor** for formula column
8. **Editable cell** for static/derived column
9. **Output viewer** for cells of action column to see all output
10. conditional running of action column
11. Re-run action/formual column
12. Re-run single cell of action/formula column
13. Re-run whole table
14. kill switch to stop all runs in a table

**Low-Prio**
- Support overriding a single derived column cell with a static data


### Input editor features
1. ui element for each input field, like text, texture, options etc.
2. Description and example for input fields
3. support default value for input fields
4. validation of input field values
5. **Selector UI** for mapping value from other columns in to this.

### Formula editor features
**High-Prio**
1. **Selector UI** for mapping value from other columns
2. formula autocompletion
3. formula error detection & warning

**Low-Prio**
4. Sample formula execution preview
5. generate formula using AI

### Selector UI Features
**High-Prio**
1. Has List of all columns
2. Sub-list of all output elements from action fields
3. allow filtering of the above lists by text

**Low-Prio**
4. mouse and keyboard navigatable
5. can show preview value for leaf items if available 

### Output viewer features
**Low-Prio**
1. Show all elements of output produced by an action for a action column cell
2. Arrange the data in a tree like view with support for folding non-parent elements
3. Option to add an output element as a derived column
4. Show more info about error if cell has an error
5. Option to copy output elements as static values/columns (paste as value feature in Sheets) - LOW 







