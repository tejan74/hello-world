import { DragSourceMonitor, useDrag } from "react-dnd";
/**
 * Custom hook for making an element draggable.
 *
 * @param {string} uuid - The unique identifier for the draggable item.
 * @param {string} type - The type of the draggable item, used to differentiate between different draggable item types.
 *
 * @returns {Object} An object containing:
 * - `isDragging`: A boolean indicating if the item is currently being dragged.
 * - `drag`: A function to be assigned to the draggable element's `ref` to enable dragging.
 */
export function useDraggable(uuid: string, type: string) {
  const [{ isDragging }, drag] = useDrag({
    type: type, // The type of the item being dragged. This allows drop targets to accept only specific types.
    item: { uuid, type: type }, // The item being dragged, including its unique identifier and type.
    collect: (monitor: DragSourceMonitor) => ({
      isDragging: !!monitor.isDragging(), // Collects whether the item is currently being dragged.
    }),
  });
  // Return the drag state and the drag ref function to be used in the component.
  return {
    isDragging,
    drag,
  };
}
