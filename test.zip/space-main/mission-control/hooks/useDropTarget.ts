import TableListPageModel from "@/mobx/table/tableListModel";
import { ItemTypes } from "@/services/table/constants";
// import { logger } from "@/utils/logger/logger";
import { useCallback } from "react";
import { useDrop } from "react-dnd";

/**
 * Custom hook to handle drag-and-drop functionality for a specific drop target (folder).
 *
 * @param folderUuid - Unique identifier for the target folder where items are dropped.
 * @param model - Instance of the TableListPageModel which can be used to manage the state related to the table list.
 * @param onDrop - Callback function that will be triggered when an item is dropped into the folder.
 *
 * @returns An object containing:
 *  - isOver: Boolean indicating if the drag item is currently over the drop target.
 *  - drop: Reference function to be attached to the drop target.
 */
export const useDropTarget = (
  folderUuid: string,
  model: TableListPageModel,
  onDrop: (itemUuid: string, folderUuid: string, itemType: string) => void
) => {
  // Use the `useDrop` hook from react-dnd to create a drop target
  const [{ isOver }, drop] = useDrop({
    accept: [ItemTypes.TABLE, ItemTypes.FOLDER],
    drop: useCallback(
      (item: { uuid: string; type: string }) => {
        const itemUuid = item.uuid; // Extract item UUID from the item being dragged
        const itemType = item.type; // Extract item type (TABLE or FOLDER)
        const targetFolderUuid = folderUuid; // This is the folder UUID

        // logger.info(
        //   `Dropped ${itemType} ${itemUuid} into folder ${targetFolderUuid}`
        // );
        // Call the provided onDrop callback with the item details
        onDrop(itemUuid, targetFolderUuid, itemType);
      },
      [folderUuid, onDrop] // Dependencies for the useCallback hook
    ),
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  });
  // Return an object with `isOver` and `drop` properties to be used by the drop target component
  return { isOver, drop };
};
