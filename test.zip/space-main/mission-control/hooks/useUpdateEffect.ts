import { DependencyList, EffectCallback, useEffect, useRef } from "react";

/**
 * This hook is similar to useEffect, but it will not run the effect on the first render
 * i.e when component mounts, but will run on updates.
 *
 * Note: This is useful when a state is initialized lazily and it also need to be set to a new value
 * when some state changes using useEffect, but this useEffect will also run when the component mounts,
 * resetting the initial state value. This hook can prevent that.
 * @param func
 * @param deps
 */
export default function useUpdateEffect(
  func: EffectCallback,
  deps?: DependencyList
) {
  const firstRender = useRef(true);
  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      console.debug("ignoring useEffect on first render");
      return;
    }
    return func();
  }, deps);
}
