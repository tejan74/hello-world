import { makeAutoObservable } from "mobx";
import { UserType } from "../user/types";
import { UserModel } from "../user/UserModel";
import ConfirmDialogModel from "./dialogModel";

class AppModel {
  confirmDialog: ConfirmDialogModel | null = null;
  userModel: UserModel;

  constructor(user: UserType) {
    makeAutoObservable(this, undefined, { autoBind: true });
    this.userModel = new UserModel(user);
  }

  resetConfirmDialog() {
    this.confirmDialog = null;
  }

  askForConfirmation(options: {
    title: string;
    message: string;
    confirmButtonText?: string;
    cancelButtonText?: string;
  }): Promise<boolean | null> {
    this.confirmDialog = new ConfirmDialogModel(
      options.title,
      options.message,
      this.resetConfirmDialog,
      options.confirmButtonText,
      options.cancelButtonText
    );

    return this.confirmDialog.confirmationPromise;
  }
}

export default AppModel;
