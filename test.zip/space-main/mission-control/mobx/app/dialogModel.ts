import { makeAutoObservable } from "mobx";

class ConfirmDialogModel {
  title: string;
  message: string;
  confirmButtonText?: string;
  cancelButtonText?: string;
  private resolvePromise!: (
    value: boolean | PromiseLike<boolean | null> | null
  ) => void;
  #confirmationPromise: Promise<boolean | null>;

  constructor(
    title: string,
    message: string,
    private removeModel: () => void,
    confirmButtonText?: string,
    cancelButtonText?: string
  ) {
    this.title = title;
    this.message = message;
    this.confirmButtonText = confirmButtonText;
    this.cancelButtonText = cancelButtonText;
    this.#confirmationPromise = new Promise((resolve) => {
      this.resolvePromise = resolve;
    });

    makeAutoObservable(this, undefined, { autoBind: true });
  }

  get confirmationPromise() {
    return this.#confirmationPromise;
  }

  private reset() {
    this.title = "";
    this.message = "";
    this.confirmButtonText = "";
    this.cancelButtonText = "";
    this.#confirmationPromise = new Promise((resolve) => {
      this.resolvePromise = resolve;
    });
    this.removeModel();
  }

  async onConfirm() {
    this.resolvePromise(true);
    this.reset();
  }

  async onCancel() {
    this.resolvePromise(false);
    this.reset();
  }

  async onClose() {
    this.resolvePromise(null);
    this.reset();
  }
}

export default ConfirmDialogModel;
