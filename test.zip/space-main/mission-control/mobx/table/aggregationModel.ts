import { makeAutoObservable } from "mobx";
import { MutableRefObject } from "react";
import { TableInfo } from "./tableApi";
import {
  AggregationOptions,
  TableAggregation,
} from "@/services/table/data/types";

export default class AggregationModel {
  constructor(
    private tableData: {
      data: TableInfo | null;
      aggregation: TableAggregation;
    },
    private columnUuid: string,
    public readonly anchorRef: MutableRefObject<HTMLDivElement | null>,
    private modelSetAggregation: (x: string, y: AggregationOptions) => void,
    private modelDeleteAggregation: (x: string) => void,
    private removeModel: () => void
  ) {
    makeAutoObservable(this, undefined, { autoBind: true });
  }

  hide() {
    this.removeModel();
  }

  get column() {
    const c = this.tableData.data?.columns.find(
      (x) => x.uuid === this.columnUuid
    );
    if (c) return c;
    else throw new Error("no column");
  }

  get aggregationMetric() {
    return this.column.aggregationMetric;
  }

  get aggregationType() {
    return this.tableData.aggregation[this.columnUuid];
  }

  setAggregation(type: AggregationOptions) {
    this.modelSetAggregation(this.columnUuid, type);
  }

  deleteAggregation() {
    this.modelDeleteAggregation(this.columnUuid);
  }
}
