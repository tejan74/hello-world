import { Action } from "@/services/action/types";
import {
  AggregationOptions,
  TableAggregation,
  TableColumnInfo,
  TableUser,
} from "@/services/table/data/types";
import { ShortPoller } from "@/utils/poller";
import { mSec } from "@/utils/time";
import { isTrpcAbortError } from "@/utils/trpcUtil";
import { isNotNull } from "@/utils/type";
import { FavoriteType, TableViewType } from "@prisma/client";
import { keyBy, throttle } from "lodash";
import { autorun, makeAutoObservable, runInAction } from "mobx";
import { MutableRefObject } from "react";
import toast from "react-hot-toast";
import { v4 as uuidv4 } from "uuid";
import { z } from "zod";
import AppModel from "../app/appModel";
import { TableImportExportModel } from "../import/TableImportExportModel";
import { UserModel } from "../user/UserModel";
import { AddActionModel } from "./addActionModel";
import AddColumnModel from "./addColumnModel";
import AggregationModel from "./aggregationModel";
import AgTableModel from "./agTableModel";
import CellViewModel from "./cellViewModel";
import { ChangeManager, TableInfoChange } from "./changeManager";
import ColumnOptionsModel from "./columnOptionModel";
import CsvExporterModel from "./csvExporterModel";
import CsvImporterModel from "./csvImporterModel";
import EditColumnModel from "./editColumnModel";
import EditTableModel from "./editTableModel";
import MultiColumnOptionsModel from "./multiColumnOptionModel";
import { SelectActionModel } from "./selectActionModel";
import SortAndFilterModel from "./sortAndFilterModel";
import TableApi, { TableInfo } from "./tableApi";
import ViewFormModel from "./viewFormModel";

export const AggregateRowUuid = "AGGREGATE_FLOATING_ROW";

export type TableMeta = Omit<
  TableInfo,
  "data" | "columns" | "columnOrder" | "totalCount" | "filteredCount"
>;

export type FolderMeta = {
  uuid: string;
  name: string;
  parentFolderUuid: string | null;
  tables: TableMeta[];
  user: TableUser | null;
  createdAt: Date;
};

export enum RunOptions {
  ALL,
  RUN_10,
  SAVE,
}

const filterOpsSchema = z.union([
  z.literal("eq"),
  z.literal("ne"),
  z.literal("lt"),
  z.literal("le"),
  z.literal("gt"),
  z.literal("ge"),
  z.literal("match"),
  z.literal("notMatch"),
  z.literal("blank"),
  z.literal("notBlank"),
  z.literal("statusEqual"),
]);

const filterTypeSchema = z.record(
  z.string(),
  z
    .object({
      type: filterOpsSchema,
      value: z.string(),
    })
    .array()
);

export type FilterOps = z.infer<typeof filterOpsSchema>;
export type FilterType = z.infer<typeof filterTypeSchema>;

export type Pagination = {
  limit: number;
  offset: number;
  pageSize: number;
};

export type TableViewMeta = {
  type: TableViewType;
  name: string;
  uuid: string;
  default: boolean;
};

export default class TablePageModel {
  loadingTable = true;
  refreshingTable = false;
  tableData: {
    data: TableInfo | null;
    sort: Record<string, "asc" | "desc">;
    filter: FilterType;
    pagination: Pagination;
    searchString: string;
    aggregation: TableAggregation;
    viewUuid: string | null;
  } = {
    data: null,
    sort: {},
    filter: {},
    pagination: {
      limit: 200,
      offset: 0,
      pageSize: 200,
    },
    searchString: "",
    aggregation: {},
    viewUuid: null,
  };
  user: UserModel;
  views: TableViewMeta[] = [];

  tableUuid: string;
  agTable: AgTableModel;
  api: TableApi;
  changeManager: ChangeManager;
  shortPoller: ShortPoller;
  throttledTableRefresh: () => void;
  tableRefresh: () => void;
  private pollingErrorCount = 0;

  ColumnOptionsModel: ColumnOptionsModel | null = null;
  AddColumnModel: AddColumnModel | null = null;
  editColumnModel: EditColumnModel | null = null;
  addActionModel: AddActionModel | null = null;
  selectActionModel: SelectActionModel | null = null;
  cellViewModel: CellViewModel | null = null;
  editTableModel: EditTableModel | null = null;
  csvImportModel: CsvImporterModel | null = null;
  csvExportModel: CsvExporterModel | null = null;
  multiColumnOptionsModel: MultiColumnOptionsModel | null = null;
  SortAndFilterModel: SortAndFilterModel;
  AggregationModel: AggregationModel | null = null;
  tableImportExportModel: TableImportExportModel | null = null;
  viewFormModel: ViewFormModel | null = null;

  selectedColumnsUuid: string[] = [];

  moreRowsLoading = false;
  isOnline = false;
  selectedRows: { [key: string]: boolean } = {};

  get tableMeta(): TableMeta | null {
    if (this.tableData.data) {
      return {
        name: this.tableData.data.name,
        uuid: this.tableData.data.uuid,
        description: this.tableData.data.description,
        icon: this.tableData.data.icon,
        owner: this.tableData.data.owner,
        locked: this.tableData.data.locked,
        createdAt: this.tableData.data.createdAt,
        updatedAt: this.tableData.data.updatedAt,
        tags: this.tableData.data.tags,
        favoriteUuid: this.tableData.data.favoriteUuid,
      };
    } else {
      return null;
    }
  }

  constructor(
    uuid: string,
    user: UserModel,
    private app: AppModel,
    private searchParams: URLSearchParams
  ) {
    makeAutoObservable(this, undefined, { autoBind: true });

    this.tableUuid = uuid;
    this.changeManager = new ChangeManager(
      this.onStageChange,
      this.onCommitChange
    );
    this.api = new TableApi(uuid, this.tableData, this.changeManager);
    this.user = user;
    this.agTable = new AgTableModel(
      this.tableData,
      this.user,
      this.api,
      this.onAgTableHeaderClicked,
      this.onAgTableAddNewClicked,
      this.onAgTableCellClicked,
      this.onAgTableCellDoubleClicked,
      this.loadMoreRows,
      this.selectedRows,
      this.runColumn
    );
    this.shortPoller = new ShortPoller(this.poll, 4 * mSec.second);
    this.throttledTableRefresh = throttle(
      () => {
        this.shortPoller.pollImmediately(true);
      },
      1 * mSec.second,
      { trailing: true }
    );
    this.tableRefresh = () => this.shortPoller.pollImmediately(true);
    this.SortAndFilterModel = new SortAndFilterModel(
      this.tableData,
      this.tableRefresh
    );

    this.loadViewUuidFromUrl(searchParams);

    // update url with view uuid (automatically)
    autorun(() => {
      const url = new URL(window.location.href);
      const curUrl = url.toString();
      if (this.tableData.viewUuid) {
        url.searchParams.set("view", this.tableData.viewUuid);
        window.history.pushState(null, "", url.toString());
      } else {
        url.searchParams.delete("view");
      }
      if (curUrl !== url.toString()) {
        window.history.replaceState(null, "", url.toString());
      }
    });
    this.loadViews();
    this.shortPoller.start();
  }

  async runColumn(columnUuid: string, type: "all" | "filter" | "select") {
    if (!this.tableData.data?.data) {
      return;
    }

    const numberOfRows: number =
      type == "select"
        ? Object.entries(this.selectedRows).length
        : type == "filter"
        ? this.tableData.data?.filteredCount || 0
        : type == "all"
        ? this.tableData.data?.totalCount || 0
        : 0;

    const triggerRun = async () => {
      await this.api.runColumn(
        columnUuid,
        type == "filter" ? this.tableData.filter : undefined,
        type == "select"
          ? Object.entries(this.selectedRows)
              .filter(([k, v]) => v)
              .map(([k, v]) => k)
          : undefined
      );
    };

    if (numberOfRows < 1000) {
      triggerRun();
      return;
    }

    const confirm = await this.app.askForConfirmation({
      title: "Confirm Run",
      message: `You are going to run ${numberOfRows} rows. Press "Run" to confirm.`,
      cancelButtonText: "Cancel",
      confirmButtonText: "Run",
    });

    if (confirm) triggerRun();
  }

  dispose() {
    this.shortPoller.stop();
  }

  private onStageChange(change: TableInfoChange) {
    if (!this.tableData.data) return;
    this.changeManager.applyChange(this.tableData.data, change);
  }

  private onCommitChange() {
    if (!this.tableData.data) return;
    this.throttledTableRefresh();
  }

  private async poll(abortController: AbortController) {
    try {
      const data = await this.api.getTableData(
        this.tableUuid,
        {
          sort: this.tableData.sort,
          filter: this.tableData.filter,
          pagination: this.tableData.pagination,
          noTrim: false,
          selectedColumns: undefined,
          searchString: this.tableData.searchString,
          aggregation: this.tableData.aggregation,
          abortController: abortController,
        },
        this.tableData.viewUuid ?? undefined
      );
      this.pollingErrorCount = 0;

      if (!data) throw new Error("no data");

      runInAction(() => {
        this.changeManager.purgeOldChanges();
        this.changeManager.applyAllChanges(data);
        this.tableData.data = data;
        this.loadingTable = false;
        this.isOnline = true;
        this.moreRowsLoading = false;
      });
    } catch (e) {
      if (isTrpcAbortError(e)) return;
      console.error("Polling Error", e);
      runInAction(() => {
        this.isOnline = false;
      });
      if (this.pollingErrorCount++ >= 3) {
        throw e; // rethrow to stop polling
      }
    }
  }

  async loadViews() {
    const views = await this.api.getAllViews();
    runInAction(() => {
      this.views = views;
    });
  }

  get currentView() {
    return (
      this.views.find((view) => view.uuid === this.tableData.viewUuid) ?? null
    );
  }

  async setViewDataToTable(uuid: string, defaultView = false) {
    if (defaultView) {
      this.tableData.viewUuid = null;
      this.tableData.sort = {};
      this.tableData.filter = {};
      this.tableData.aggregation = {};
    } else {
      this.refreshingTable = true;
      const viewDetails = await this.api.getViewDetails(uuid);
      if (!viewDetails) return console.error("no view details");
      runInAction(() => {
        this.tableData.viewUuid = uuid;

        this.tableData.sort = {};
        for (const x of viewDetails.sort ?? []) {
          this.tableData.sort[x.columnUuid] = x.order;
        }

        this.tableData.filter = {};
        for (const x of viewDetails.filter ?? []) {
          if (!(x.columnUuid in this.tableData.filter))
            this.tableData.filter[x.columnUuid] = [];
          if (Array.isArray(x.value)) {
            for (const value of x.value) {
              this.tableData.filter[x.columnUuid].push({
                type: x.operator,
                value: value,
              });
            }
          } else {
            this.tableData.filter[x.columnUuid].push({
              type: x.operator,
              value: x.value,
            });
          }
        }

        this.tableData.aggregation = viewDetails.aggregation ?? ({} as const);
        this.refreshingTable = false;
      });
    }
    this.tableRefresh();
  }

  async updateView() {
    if (!this.tableData.viewUuid) throw new Error("no viewUuid");
    await this.api.updateViewData(
      this.tableData.viewUuid,
      this.tableData.filter,
      this.tableData.sort,
      this.tableData.aggregation
    );
  }

  get isTableLocked() {
    return this.tableData.data?.locked ?? false;
  }

  toggleTableLock() {
    if (!this.tableData.data) return;
    this.api.editTable(undefined, undefined, !this.tableData.data.locked);
  }

  onImportCsvClicked() {
    if (!this.api) throw new Error("no api");
    this.csvImportModel = new CsvImporterModel(this.tableData, this.api, () => {
      this.csvImportModel = null;
    });
  }

  onDuplicateTableClicked() {
    if (!this.api) throw new Error("no api");
    if (!this.tableData.data) throw new Error("no table data");
    this.api
      .duplicateTable(
        this.tableData.data.name + " (copy)",
        this.tableData.data.description
      )
      .then((uuid) => {
        window.open(`/table/${uuid}`, "_blank");
      });
  }

  toggleUserFavorite() {
    if (!this.api)
      throw new Error("Something went wrong, failed to connect to the server.");
    if (this.tableData.data?.favoriteUuid) {
      runInAction(() => {
        this.user
          .removeFavorite(this.tableData.data!.favoriteUuid!)
          .then((res: string) => {
            toast.success("Removed From Favorites", { icon: "☆" });
          });
        this.tableData.data!.favoriteUuid = undefined;
      });
    } else {
      this.user
        .addFavorite(
          FavoriteType.VIEW,
          this.tableData.viewUuid ?? undefined,
          this.tableData.viewUuid
            ? {
                tableUuid: this.tableUuid,
                viewUuid: this.tableData.viewUuid,
              }
            : { tableUuid: this.tableUuid }
        )
        .then((res: string) => {
          toast.success("Added To Favorites", { icon: "★" });
          runInAction(() => {
            this.tableData.data!.favoriteUuid = res;
          });
        });
    }
  }

  private loadViewUuidFromUrl(searchParams: URLSearchParams) {
    if (searchParams.has("view")) {
      const viewUuid = searchParams.get("view");
      this.tableData.viewUuid = viewUuid;
      if (viewUuid) {
        this.setViewDataToTable(viewUuid);
      }
    }
  }

  hideAllSidebarModel() {
    [
      this.editColumnModel,
      this.addActionModel,
      this.cellViewModel,
      this.editTableModel,
      this.selectActionModel,
    ]
      .filter(isNotNull)
      .forEach((x) => x.hide());
  }

  private async handleColumnDefPaste(
    columns: TableColumnInfo[]
  ): Promise<boolean> {
    try {
      const remappedUuids = Object.fromEntries(
        columns.map((x) => [x.uuid, uuidv4()])
      );

      let jsonColumns = Object.entries(remappedUuids).reduce(
        (a, [k, v]) => a.replaceAll(k, v),
        JSON.stringify(columns)
      );

      const remappedColumns: TableColumnInfo[] = JSON.parse(jsonColumns);

      for (const c of sortColumns(remappedColumns)) {
        if (c.type === "DYNAMIC") {
          await this.api.addActionColumn(
            c.name,
            c.action.uuid,
            c.config.inputConfig,
            c.config.preCheckFormula,
            c.config.outputPath,
            c.uuid
          );
        } else {
          await this.api.addStaticColumn(c.name, c.type, undefined, c.uuid);
        }
      }

      // If all operations succeed, return true
      return true;
    } catch (error) {
      console.error("Error handling column paste:", error);
      // Return false if any error occurs
      return false;
    }
  }

  async handleColumnPaste(): Promise<boolean> {
    try {
      const clipboardData = await navigator.clipboard.read();

      for (const item of clipboardData) {
        const htmlText = await (await item.getType("text/html")).text();
        const jsonString = htmlText.substring(
          htmlText.indexOf("{"),
          htmlText.lastIndexOf("}") + 1
        );

        const jsonDefinitions = JSON.parse(jsonString);

        if (jsonDefinitions.type === "column-definition") {
          return await this.handleColumnDefPaste(jsonDefinitions.columns);
        }
      }
    } catch (error) {
      console.error("Failed to process clipboard data:", error);
    }
    return true;
  }

  // ****************** Event Callbacks *************************
  // These are callbacks passed down to sub models to transmit
  // information (events mostly) back to the page model.
  // The page model then decides what to do with the information.
  // ************************************************************

  onAgTableHeaderClicked(
    columnUuids: string[],
    elRef: MutableRefObject<HTMLDivElement | HTMLButtonElement | null>
  ) {
    if (!this.api) throw new Error("no api");

    if (columnUuids.length == 1) {
      this.ColumnOptionsModel = new ColumnOptionsModel(
        this.tableData,
        this.user,
        this.api,
        columnUuids[0],
        elRef,
        this.onEditColumnClicked,
        this.onActionColumnAdd,
        () => {
          this.ColumnOptionsModel = null;
          this.selectedColumnsUuid = [];
        },
        this.onSelectActionColumn,
        this.tableData.viewUuid ?? undefined
      );
    } else {
      this.multiColumnOptionsModel = new MultiColumnOptionsModel(
        this.tableData,
        this.api,
        columnUuids,
        elRef,
        () => {
          this.multiColumnOptionsModel = null;
          this.selectedColumnsUuid = [];
        }
      );
    }
  }

  onAgTableAddNewClicked(elRef: MutableRefObject<HTMLDivElement | null>) {
    if (!this.api) throw new Error("no api");
    this.AddColumnModel = new AddColumnModel(
      this.tableData,
      this.api,
      elRef,
      this.onActionColumnAdd,
      () => {
        this.AddColumnModel = null;
      },
      this.onSelectActionColumn,
      undefined,
      this.tableData.viewUuid ?? undefined
    );
  }

  onAgTableCellClicked(
    columnUuid: string,
    rowUuid: string,
    elRef: MutableRefObject<HTMLDivElement | null>
  ) {
    if (rowUuid == AggregateRowUuid) {
      this.AggregationModel = new AggregationModel(
        this.tableData,
        columnUuid,
        elRef,
        this.setAggregation,
        this.deleteAggregation,
        () => (this.AggregationModel = null)
      );
    } else {
      this.agTable.selectedCell = { colUuid: columnUuid, rowUuid: rowUuid };
    }
  }

  onAgTableCellDoubleClicked(columnUuid: string, rowUuid: string) {
    const column = this.tableData.data?.columns.find(
      (x) => x.uuid === columnUuid
    );
    if (!column) return;
    if (column.type === "DYNAMIC") {
      this.hideAllSidebarModel();
      this.cellViewModel = new CellViewModel(
        this.tableData,
        this.api,
        columnUuid,
        column.name,
        rowUuid,
        () => {
          this.cellViewModel = null;
        }
      );
    }
  }

  onEditColumnClicked(columnUuid: string) {
    if (!this.api) throw new Error("no api");
    this.hideAllSidebarModel();
    this.editColumnModel = new EditColumnModel(
      this.tableData,
      this.api,
      columnUuid,
      this.tableData.data?.tags,
      () => {
        this.editColumnModel = null;
      },
      this.runColumn,
      this.user
    );
  }

  onActionColumnAdd(action: Action, prevColumnUuid?: string) {
    if (!this.api) throw new Error("no api");
    this.hideAllSidebarModel();
    this.addActionModel = new AddActionModel(
      action,
      this.tableData,
      this.api,
      () => {
        this.addActionModel = null;
      },
      this.runColumn,
      this.user,
      prevColumnUuid,
      this.tableData.viewUuid ?? undefined
    );
  }

  onSelectActionColumn(prevColumnUuid?: string) {
    if (!this.api)
      throw new Error(
        "Something went wrong, no connection to the server was found!"
      );
    this.hideAllSidebarModel();
    this.selectActionModel = new SelectActionModel(
      this.tableData,
      this.api,
      this.onActionColumnAdd,
      () => {
        this.selectActionModel = null;
      },
      prevColumnUuid,
      this.tableData.viewUuid ?? undefined
    );
  }

  editTableClicked() {
    if (!this.api) throw new Error("no api");
    this.hideAllSidebarModel();
    this.editTableModel = new EditTableModel(
      this.tableData,
      this.api,
      this.views,
      this.editView,
      () => {
        this.editTableModel = null;
      }
    );
  }

  onExportCsvClicked(type: "all" | "filtered") {
    this.csvExportModel = new CsvExporterModel(
      this.tableUuid,
      this.api,
      this.tableData.viewUuid,
      type == "filtered" ? this.tableData.filter : undefined,
      this.tableData.data?.columns,
      () => {
        this.csvExportModel = null;
      }
    );
  }

  onImportFromAnotherTableClicked() {
    this.tableImportExportModel = new TableImportExportModel(
      () => {
        this.tableImportExportModel = null;
      },
      undefined,
      {
        tableUuid: this.tableUuid,
      },
      this.tableData.filter,
      Object.keys(this.selectedRows).filter((x) => this.selectedRows[x])
    );
  }

  onExportToAnotherTableClicked() {
    this.tableImportExportModel = new TableImportExportModel(
      () => {
        this.tableImportExportModel = null;
      },
      {
        tableUuid: this.tableUuid,
      },
      undefined,
      this.tableData.filter,
      Object.keys(this.selectedRows).filter((x) => this.selectedRows[x])
    );
  }

  editView() {
    this.hideAllSidebarModel();
    this.viewFormModel = new ViewFormModel(
      "UPDATE",
      this.tableData,
      this.api,
      this.currentView,
      this.loadViews,
      this.setViewDataToTable,
      () => (this.viewFormModel = null)
    );
  }

  onViewCreateClicked() {
    this.viewFormModel = new ViewFormModel(
      "CREATE",
      this.tableData,
      this.api,
      this.currentView,
      this.loadViews,
      this.setViewDataToTable,
      () => (this.viewFormModel = null)
    );
  }

  loadMoreRows() {
    if (this.moreRowsLoading) return;
    this.tableData.pagination.limit += this.tableData.pagination.pageSize;
    this.moreRowsLoading = true;
    this.tableRefresh();
  }

  updateSearchString(searchString: string) {
    this.tableData.searchString = searchString;
    this.throttledTableRefresh();
  }

  setAggregation(columnUuid: string, type: AggregationOptions) {
    this.tableData.aggregation[columnUuid] = type;
    const columnIndex = this.tableData.data?.columns.findIndex(
      (x) => x.uuid == columnUuid
    );
    if (this.tableData.data && columnIndex) {
      this.tableData.data.columns[columnIndex].aggregationMetric = undefined;
    }
  }

  deleteAggregation(columnUuid: string) {
    delete this.tableData.aggregation[columnUuid];
  }
}

/**
 * This function sorts the columns based on their dependencies
 * This is a topological sort problem
 * TODO (ankith): move this along with the same kind of func from add columns form to a util file
 */
function sortColumns(columns: TableColumnInfo[]) {
  const visited = new Set<string>();
  const stack: TableColumnInfo[] = [];
  const colLut = keyBy(columns, "uuid");
  function dfs(field: TableColumnInfo) {
    if (visited.has(field.uuid)) return;
    visited.add(field.uuid);
    if (field.dependencies) {
      for (const ipFieldId of field.dependencies) {
        if (ipFieldId in colLut) {
          dfs(colLut[ipFieldId]);
        }
      }
    }
    stack.push(field);
  }
  for (const column of columns) {
    if (visited.has(column.uuid)) continue;
    dfs(column);
  }
  // no need to reverse, as the inputFieldIds is reverse connection
  // i.e when a field 'a' has a inputFieldId 'b' then 'b' is the parent of 'a'
  return stack;
}
