import { TenantDataView } from "@/services/tenantData/types";
import { trpc } from "@/trpc/client";
import { makeAutoObservable, runInAction } from "mobx";

export class TenantDataViewListModel {
  loading = false;
  list: TenantDataView[] = [];

  constructor() {
    makeAutoObservable(this, undefined, { autoBind: true });
    this.load();
  }

  async load() {
    const list = await trpc.tenantData.listViews.query();
    runInAction(() => {
      this.list = list;
    });
  }
}
