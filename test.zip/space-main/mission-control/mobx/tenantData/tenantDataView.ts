import { trpc } from "@/trpc/client";
import { makeAutoObservable, runInAction } from "mobx";

export class TenantDataViewModel {
  tenantDataView: { uuid: string } | null = null;

  constructor() {
    makeAutoObservable(this, undefined, { autoBind: true });
    this.load();
  }

  async load() {
    const tenantDataView = await trpc.tenantData.getTenantDataView.query();
    runInAction(() => {
      this.tenantDataView = tenantDataView;
    });
  }
}
