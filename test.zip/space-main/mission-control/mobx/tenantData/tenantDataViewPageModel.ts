import { FilterOperator, TableFilter } from "@/services/tenantData/types";
import { trpc } from "@/trpc/client";
import { ValueGetterParams } from "ag-grid-community";
import { isNumber } from "lodash";
import { makeAutoObservable, runInAction } from "mobx";
import { TableImportExportModel } from "../import/TableImportExportModel";
import { FilterType } from "../table/tablePageModel";
import { TenantSortAndFilterModel } from "./tenantSortandFilterModel";

export type Pagination = {
  limit: number;
  offset: number;
};

export type tenantFilter = {
  operator: FilterOperator;
  value: string;
};

// TODO: Use FilterType for filters instead of Record<string, tenantFilter[]>
const convertTenantFilterToFilterType = (
  filter: Record<string, tenantFilter[]>
): FilterType => {
  const tableFilter: FilterType = {};
  Object.entries(filter).forEach(([columnName, filters]) => {
    filters.forEach((filterData) => {
      if (!tableFilter[columnName]) {
        tableFilter[columnName] = [];
      }
      tableFilter[columnName].push({
        type: filterData.operator,
        value: filterData.value,
      });
    });
  });
  return tableFilter;
};

export class TenantDataViewPageModel {
  static readonly checkboxColFieldId = "checkbox";
  public loadingTable: boolean = false;
  public tableData: {
    data: {
      name: string;
      columns: string[];
      rows: Record<string, string | null>[];
      filteredRowCount: number;
      totalRowCount: number;
    } | null;
    filter: Record<string, tenantFilter[]>;
    sort: Record<string, "asc" | "desc">;
    pagination: Pagination;
  } = {
    data: null,
    filter: {},
    sort: {},
    pagination: {
      limit: 200,
      offset: 0,
    },
  };

  public comparator: "and" | "or" = "and";
  public TenantSortAndFilterModel: TenantSortAndFilterModel =
    new TenantSortAndFilterModel(this.tableData, this.loadData);
  moreRowsLoading = false;
  pageSize = 200;

  tableImportExportModel: TableImportExportModel | null = null;
  selectedRows: { [key: string]: boolean } = {};

  //// Example of filter
  // filter: {
  //   and: [
  //     { column: "naics", operator: "gt", value: "500000" },
  //     { column: "naics", operator: "lt", value: "600000" },
  //     {
  //       or: [
  //         { column: "name", operator: "match", value: "*s" },
  //         { column: "name", operator: "match", value: "*y" },
  //       ],
  //     },
  //   ],
  // },
  //// Example of sort
  // sort: [
  //   { column: "name", order: "asc" },
  //   { column: "naics", order: "desc" },
  // ],

  constructor(private uuid: string) {
    makeAutoObservable(this, undefined, { autoBind: true });
    this.loadData();
  }

  setRowSelected(rowUuid: string, isSelected: boolean) {
    this.selectedRows[rowUuid] = isSelected;
  }

  private getTableData() {
    const filter1: TableFilter = {
      ["and"]: [],
    };

    const filter2: TableFilter = {
      ["or"]: [],
    };

    Object.entries(this.tableData.filter).forEach(([columnName, filters]) => {
      filters.forEach((filterData) => {
        const filterObject = {
          value: filterData.value,
          column: columnName,
          operator: filterData.operator,
        };
        if (this.comparator === "and") {
          filter1.and.push(filterObject);
        } else {
          filter2.or.push(filterObject);
        }
      });
    });

    const apiData = {
      uuid: this.uuid,
      pagination: this.tableData.pagination,
      filter: this.tableData.filter
        ? this.comparator === "and"
          ? filter1
          : filter2
        : undefined,
      sort: this.tableData.sort
        ? Object.entries(this.tableData.sort).map(([column, order]) => ({
            column,
            order,
          }))
        : undefined,
    };

    return apiData;
  }

  private loadData() {
    this.loadingTable = true;

    const apiData = this.getTableData();
    trpc.tenantData.getViewData
      .query(apiData)
      .then((data) => {
        if (!data) throw new Error("No data");
        runInAction(() => {
          this.tableData.data = data;
        });
      })
      .catch((err) => {
        console.error(err);
      })
      .finally(() => {
        runInAction(() => {
          this.loadingTable = false;
          this.TenantSortAndFilterModel = new TenantSortAndFilterModel(
            this.tableData,
            this.loadData
          );
        });
      });
  }

  dispose() {
    // cleanup
  }

  getRowId = (params: { data: any }) => {
    return params.data.uuid;
  };

  get columnDefs() {
    if (this.tableData.data) {
      return [
        this.checkboxColDef,
        ...this.tableData.data.columns.map((c) => {
          return {
            headerName: c,
            field: c,
          };
        }),
      ];
    }
    return [this.checkboxColDef];
  }

  private get checkboxColDef() {
    return {
      headerName: "",
      field: TenantDataViewPageModel.checkboxColFieldId,
      headerCheckboxSelection: true,
      checkboxSelection: true,
      showDisabledCheckboxes: true,
      valueGetter: (params: ValueGetterParams) =>
        isNumber(params.node?.rowIndex) ? params.node.rowIndex + 1 : "",
      // ((container border * 2 + container padding * 2) + (checkbox width + margin)) + ((max number of digit in row number + max number of digits in total or filtered row) * 8) + ("count" word size = 30)
      // 8 is empirically chosen for the font size
      width:
        1 * 2 +
        9 * 2 +
        (16 + 12) +
        String(this.tableData.data?.rows.length ?? 1).length * 8 +
        String(
          this.tableData.data?.filteredRowCount ??
            this.tableData.data?.totalRowCount ??
            1
        ).length *
          5 +
        30,
      suppressMovable: true,
      lockPosition: "left",
      pinned: "left",
      lockPinned: true,
      resizable: false,
    };
  }

  reloadData() {
    this.loadData();
  }

  get rowData() {
    if (this.tableData.data) {
      return this.tableData.data.rows;
    }
    return [];
  }

  loadMoreRows() {
    if (this.moreRowsLoading) return;

    runInAction(() => {
      this.moreRowsLoading = true;
    });

    const apiData = this.getTableData();
    apiData.pagination.limit += this.pageSize;

    trpc.tenantData.getViewData
      .query(apiData)
      .then((data) => {
        if (!data) throw new Error("No data returned");

        runInAction(() => {
          this.tableData.data = data;
        });
      })
      .catch((error) => {
        console.error("Failed to load more rows:", error);
      })
      .finally(() => {
        runInAction(() => {
          this.moreRowsLoading = false;
        });
      });
  }

  setComparator(comparator: "and" | "or") {
    this.comparator = comparator;
  }

  onExportToTableClicked() {
    this.tableImportExportModel = new TableImportExportModel(
      () => {
        this.tableImportExportModel = null;
      },
      { tenantDataViewUuid: this.uuid },
      undefined,
      convertTenantFilterToFilterType(this.tableData.filter),
      Object.keys(this.selectedRows).filter((x) => this.selectedRows[x])
    );
  }
}
