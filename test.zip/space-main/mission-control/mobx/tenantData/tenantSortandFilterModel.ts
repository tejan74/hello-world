import { FilterOperator } from "@/services/tenantData/types";
import { isNotUndefined } from "@/utils/type";
import { makeAutoObservable, runInAction } from "mobx";
import { Pagination, tenantFilter } from "./tenantDataViewPageModel";

export class TenantSortAndFilterModel {
  constructor(
    public tableData: {
      data: {
        name: string;
        columns: string[];
        rows: Record<string, string | null>[];
        totalRowCount: number;
      } | null;
      sort: Record<string, "asc" | "desc">;
      filter: Record<string, tenantFilter[]>;
      pagination: Pagination;
    },
    private loadTable: () => void
  ) {
    makeAutoObservable(this, undefined, { autoBind: true });
  }

  getFilters(columnName: string | null) {
    if (!columnName) return;
    const aFilters = this.tableData.filter[columnName] ?? [];
    const filters: Record<FilterOperator, string | undefined> = {
      eq: undefined,
      ne: undefined,
      gt: undefined,
      ge: undefined,
      lt: undefined,
      le: undefined,
      match: undefined,
      notMatch: undefined,
      blank: undefined,
      notBlank: undefined,
      statusEqual: undefined,
    };
    for (const f of aFilters) {
      filters[f.operator] = f.value;
    }
    return filters;
  }

  applyFilter(
    columnName: string,
    filter: Record<FilterOperator, string | undefined>
  ) {
    const f = Object.entries(filter)
      .filter(([operator, value]) => isNotUndefined(value))
      .map(([type, value]) => ({
        operator: type as FilterOperator,
        value: value as string,
      }));

    if (f.length === 0) delete this.tableData.filter[columnName];
    else this.tableData.filter[columnName] = f;
    this.loadTable();
  }

  deleteFilter(columnName: string, typeToDelete: string) {
    const filterArray = this.tableData.filter[columnName] ?? [];
    const filteredFilter = filterArray.filter(
      (filter) => filter.operator !== typeToDelete
    );

    runInAction(() => {
      filteredFilter.length
        ? (this.tableData.filter[columnName] = filteredFilter)
        : delete this.tableData.filter[columnName];
      this.loadTable();
    });
  }

  deleteAllFilters() {
    this.tableData.filter = {};
    this.loadTable();
  }

  applySort(columnName: string, order: "asc" | "desc") {
    const currentSort = this.tableData.sort;

    if (currentSort[columnName] === order) {
      delete this.tableData.sort[columnName];
    } else this.tableData.sort[columnName] = order;
    this.loadTable();
  }

  getSortState(columnName: string) {
    return this.tableData.sort[columnName];
  }

  deleteSort(columnName: string) {
    delete this.tableData.sort[columnName];
    this.loadTable();
  }

  deleteAllSort() {
    this.tableData.sort = {};
    this.loadTable();
  }

  deleteAllFiltersAndSort() {
    this.deleteAllFilters();
    this.deleteAllSort();
    this.loadTable();
  }
}
