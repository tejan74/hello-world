import {
  UserFavoriteDataType,
  UserFavoriteType,
} from "@/services/table/data/types";
import { trpc } from "@/trpc/client";
import { FavoriteType, TenantStatus } from "@prisma/client";
import { makeAutoObservable, runInAction } from "mobx";
import { ReadPermissionRoles, WritePermissionRoles } from "./constants";
import { UserType } from "./types";

export type UserFavoriteMeta = {
  uuid: string;
  objectId: string;
  type: UserFavoriteType;
  data: any; // Data can be "any" because it is json with some basic info that we can expand on (09.2024: {tableUuid : string, viewUuid : string})
};

export type UserFavoriteDataMeta = {
  uuid: string;
  viewUuid: string;
  tableUuid: string;
  type: FavoriteType;
  link: string;
  text: string;
  extraText: string;
};
export class UserModel {
  id: string;
  name: string | null;
  email: string;
  domain: string;
  teamName: string;
  activeTeam: boolean;
  numberOfTeammates: number | null;
  image: string | null;
  role: string;
  data: UserType;
  allUserFavorites: UserFavoriteMeta[] = [];
  userFavorites: UserFavoriteDataMeta[] = [];

  constructor(data: UserType) {
    makeAutoObservable(this, undefined, { autoBind: true });
    this.id = data.id;
    this.name = data.name;
    this.email = data.email;
    this.domain = data.Tenant.domain;
    this.teamName = data.Tenant.name;
    this.activeTeam = data.Tenant.status == TenantStatus.ACTIVE;
    this.numberOfTeammates = data.Tenant.teamCount;
    this.role = data.Role.name;
    this.image = data.image;

    this.data = data;
    this.processFavorites();
  }

  hasPermission(action: string) {
    const canRead = ReadPermissionRoles.includes(this.role);
    const canWrite = WritePermissionRoles.includes(this.role);

    if (
      (action.includes("read") && !canRead) ||
      (action.includes("write") && !canWrite)
    ) {
      return false;
    }
    return true;
  }

  async updateTeamDetails(teamName: string, teamCount: number | null) {
    const res = await trpc.tenant.update.mutate({
      name: teamName,
      teamCount: teamCount,
    });

    runInAction(() => {
      if (res) {
        this.teamName = res.name;
        this.numberOfTeammates = res.teamCount;
      }
    });
  }

  async updateUserDetails(name: string) {
    const res = await trpc.user.update.mutate({
      id: this.id,
      name: name,
    });
    runInAction(() => {
      if (res) {
        this.name = res.name;
      }
    });
  }

  /**
   * Adds a favorite to the user's favorites list.
   *
   * @param type - The type of the favorite.
   * @param objectId - The ID of the object being favorited (optional).
   * @param data - Additional data associated with the favorite (optional).
   */
  async addFavorite(
    type: UserFavoriteType,
    objectId?: string,
    data?: UserFavoriteDataType
  ) {
    const res = await trpc.user.favorites.add.mutate({ objectId, type, data });
    runInAction(() => {
      this.processFavorites();
    });
    return res;
  }

  /**
   * Removes a favorite from the user's favorites list.
   *
   * @param favoriteUuid - The UUID of the favorite to be removed.
   */
  async removeFavorite(favoriteUuid: string) {
    const res = await trpc.user.favorites.remove.mutate({ uuid: favoriteUuid });
    runInAction(() => {
      this.processFavorites();
    });
    return res;
  }

  async fetchAllFavorites() {
    const res = await trpc.user.favorites.list.mutate();
    this.allUserFavorites = res;
  }
  async fetchTableName(tableUuid: string) {
    return await trpc.table.getname.query({ tableUuid });
  }

  // Helper function to fetch view name
  async fetchViewName(viewUuid: string, tableUuid: string) {
    const view = await trpc.table.view.get.query({ viewUuid, tableUuid });
    return view ? view.name : "";
  }

  // Helper function to generate table link
  generateTableLink(tableUuid: string, viewUuid: string) {
    return viewUuid
      ? `/table/${tableUuid}?view=${viewUuid}`
      : `/table/${tableUuid}`;
  }

  // Helper function to format table text
  formatTableText(tableName: string, viewName: string) {
    return viewName ? `${tableName} (${viewName})` : tableName;
  }

  async processFavorites() {
    await this.fetchAllFavorites();
    let tableData: UserFavoriteDataMeta[] = [];

    if (!Array.isArray(this.allUserFavorites)) {
      console.error("Error fetching table meta data");
      return;
    }
    // Process each favorite item
    for (const favorite of this.allUserFavorites) {
      if (favorite.type !== FavoriteType.VIEW) {
        continue;
      }
      const viewUuid = favorite?.data?.viewUuid;
      const tableUuid = favorite?.data?.tableUuid;
      try {
        // Fetch table data
        const tableName = await this.fetchTableName(tableUuid);

        // Determine viewName if viewUuid is present
        const viewName = viewUuid
          ? await this.fetchViewName(viewUuid, tableUuid)
          : "Default View";

        // Add tableData entry
        tableData.push({
          uuid: favorite.uuid,
          viewUuid: viewUuid,
          text: tableName,
          extraText: viewName,
          type: favorite.type,
          tableUuid: tableUuid,
          link: this.generateTableLink(tableUuid, viewUuid),
        });
      } catch (e) {
        console.error("Error fetching data for table:", tableUuid);
      }
    }

    runInAction(() => {
      if (tableData.length > 0) {
        this.userFavorites = tableData;
      }
    });
  }
}
