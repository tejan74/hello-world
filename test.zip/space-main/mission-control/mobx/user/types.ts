import { TenantStatus } from "@prisma/client";

export type UserType = {
  id: string;
  name: string | null;
  email: string;
  image :string|null
  Tenant: {
    name: string;
    teamCount: number | null;
    domain: string;
    status: TenantStatus;
  };
  Role: {
    name: string;
  }
};
