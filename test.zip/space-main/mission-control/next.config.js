/** @type {import('next').NextConfig} */

const moduleExports = {
    output: "standalone",
    poweredByHeader: false,
    reactStrictMode: true,
    experimental: {
        outputFileTracingIncludes: {
          '/': ['./node_modules/@google-cloud/tasks/build/esm/src/**/*.json'],
        },
      }
};

module.exports = moduleExports;
