import type { SpecialInputValue } from "@/ui/components/table/SpecialInput";
import { attempt, isArray, isPlainObject, isString } from "lodash";

// export type TemplatedInput = { $: SpecialInputValue };
export type TemplatedInput = `{ $: [${string}] }`;

export function isTemplatedInput(v: any): v is TemplatedInput {
  if (isTemplatedInput_old(v)) return true; // backward compatibility code
  if (isString(v) && v.includes("$")) {
    const jo = attempt(() => JSON.parse(v));
    if (jo instanceof Error) return false;
    return "$" in jo && isArray(jo["$"]);
  }
  return false;
}

export function isTemplatedInput_old(v: any): v is TemplatedInput {
  if (isPlainObject(v) && "$" in v) {
    return true;
  }
  return false;
}

export function getSpecialInputFromTemplatedInput(
  v: TemplatedInput | string | Record<string, any>
): Exclude<SpecialInputValue, string> {
  if (isTemplatedInput_old(v)) return getSpecialInputFromTemplatedInput_old(v); // backward compatibility code
  if (!isString(v)) throw new Error("Invalid input");
  const jo = JSON.parse(v);
  return jo.$;
}

function getSpecialInputFromTemplatedInput_old(
  v: TemplatedInput
): Exclude<SpecialInputValue, string> {
  // @ts-ignore
  return v.$;
}

export function specialInputToTemplatedInput(
  v: SpecialInputValue
): TemplatedInput {
  return JSON.stringify({ $: v }) as TemplatedInput;
}

export function isSpecialInput(
  v: any
): v is Exclude<SpecialInputValue, string> {
  return v instanceof Array;
}
