
-- create default view for all tables --
INSERT INTO "TableView" ("uuid", "name", "tableUuid", "tenantUuid", "createdById", "type", "default")
SELECT gen_random_uuid(), 'Default View', "uuid", "tenantUuid", "userId", 'TENANT', true
FROM "UI_Table"
WHERE "uuid" NOT IN (SELECT "tableUuid" FROM "TableView" WHERE "default" = true);

-- populate default view with existing column settings --
INSERT INTO "TableViewColumnOption" ("viewUuid", "columnUuid", "pinned", "hidden", "color")
SELECT v."uuid", c."uuid", c."pinned", c."hidden", c."color"
FROM "TableView" v 
JOIN "UI_Column" c using("tableUuid")
WHERE v."default" = true 
-- only include columns that are hidden, pinned, or have a color --
AND (c."hidden" = true OR c."pinned" = true OR c."color" IS NOT NULL)
ON CONFLICT DO NOTHING;





