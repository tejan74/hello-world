import { X_REQUEST_ID_HEADER } from "@/utils/constant";
import { createTRPCClient, httpBatchLink } from "@trpc/client";
import { nanoid } from "nanoid";
import superjson from "superjson";
import { AppRouter } from "./routers/app";

export const trpc = createTRPCClient<AppRouter>({
  links: [
    httpBatchLink({
      transformer: superjson,
      url: `${getBaseURL()}/api/rpc`,
      maxURLLength: 2083,
      headers: (opts) => {
        const reqId = nanoid();
        opts.opList
          .filter((x) => x.type === "mutation")
          .forEach((x) =>
            console.info(
              `Mutation Request: requestId='${reqId}', path='${
                x.path
              }', input=${JSON.stringify(x.input)}`
            )
          );
        return {
          [X_REQUEST_ID_HEADER]: reqId,
        };
      },
    }),
  ],
});

//TODO: Move these out
export function getBaseURLServerSide() {
  return process.env.APP_URL
    ? `https://${process.env.APP_URL}`
    : "http://localhost:3000";
}

export function getBaseURL() {
  return typeof window === "undefined"
    ? getBaseURLServerSide()
    : `${window.location.protocol}//${window.location.host}`;
}
