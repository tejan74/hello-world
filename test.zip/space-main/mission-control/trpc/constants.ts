export const ReadPermissionRoles = ["Astronaut", "Admin", "Table Editor", "Table Viewer","Guest"];
export const WritePermissionRoles = ["Astronaut", "Admin", "Table Editor"];
