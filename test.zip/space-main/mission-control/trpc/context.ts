import { authOptions } from "@/services/auth/authOptions";
import { X_REQUEST_ID_HEADER } from "@/utils/constant";
import { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import { getServerSession } from "next-auth/next";

export const createContext = async (opts: FetchCreateContextFnOptions) => {
  const session = await getServerSession(authOptions);
  const requestId = opts.req.headers.get(X_REQUEST_ID_HEADER) as
    | string
    | undefined;
  return { session, requestId };
};

export type Context = Awaited<ReturnType<typeof createContext>>;
