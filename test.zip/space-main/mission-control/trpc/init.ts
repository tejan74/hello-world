import { TRPCError, initTRPC } from "@trpc/server";
import superjson from "superjson";
import { ReadPermissionRoles, WritePermissionRoles } from "./constants";

// todo: fix the context to be shared across both graph and rpc
import { executeWithAsyncContext } from "@/utils/logger/asyncContext";
import { Context } from "./context";

const t = initTRPC.context<Context>().create({
  transformer: superjson,
});

export const router = t.router;
export const procedure = t.procedure;
export const middleware = t.middleware;

// refer docs: https://trpc.io/docs/server/middlewares
export const isUserAuthenticated = middleware(async ({ meta, next, ctx }) => {
  if (!(ctx.session && ctx.session.user)) {
    // refer docs: https://trpc.io/docs/server/error-handling
    throw new TRPCError({ code: "UNAUTHORIZED" });
  }
  return next({
    ctx: {
      session: ctx.session, // make session non-nullable
    },
  });
});

export const logContextMiddleware = middleware(
  async ({ ctx, next, path, type }) => {
    return await executeWithAsyncContext(next, {
      requestId: ctx.requestId as string,
      tenant: ctx.session?.user?.tenantUuid,
      method: type,
      path: path,
    });
  }
);

export const permissionMiddleware = middleware(
  async ({ meta, ctx, next, path, type }) => {
    const userId = ctx.session?.user.id;

    if (!userId) {
      throw Error("User does not exists");
    }
    const userRole = ctx.session?.user.Role;

    if (!ctx.session || !userRole) {
      throw new TRPCError({ code: "UNAUTHORIZED" });
    }

    const canRead = ReadPermissionRoles.includes(userRole.name);
    const canWrite = WritePermissionRoles.includes(userRole.name);

    if ((type === "query" && !canRead) || (type === "mutation" && !canWrite)) {
      throw new TRPCError({ code: "FORBIDDEN" });
    }
    return next({
      ctx: {
        session: ctx.session, // make session non-nullable
      },
    });
  }
);

export const privateProcedure = procedure
  .use(logContextMiddleware)
  .use(isUserAuthenticated)
  .use(permissionMiddleware);
