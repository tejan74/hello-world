import { fetchActions } from "@/services/action";
import { createPrismaClient } from "@/utils/db";
import { privateProcedure, router } from "../init";

const prisma = await createPrismaClient();

export const actionRouter = router({
  get: privateProcedure.query(async ({ ctx }) => {
    return await fetchActions(prisma);
  }),
});
