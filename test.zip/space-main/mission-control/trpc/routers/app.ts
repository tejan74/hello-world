import { router } from "../init";
import { actionRouter } from "./action";
import { folderRouter } from "./folder";
import { healthRouter } from "./health";
import { tableRouter } from "./table";
import { tenantRouter } from "./tenant";
import { tenantDataRouter } from "./tenantData";
import { userRouter } from "./user";

export const appRouter = router({
  health: healthRouter,
  table: tableRouter,
  action: actionRouter,
  tenant: tenantRouter,
  user: userRouter,
  folder: folderRouter,
  tenantData: tenantDataRouter,
});

export type AppRouter = typeof appRouter;
