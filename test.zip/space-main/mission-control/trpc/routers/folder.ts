import {
  CreateFolder,
  deleteFolder,
  listFolders,
  updateFolder,
} from "@/services/folder";
import { createPrismaClient } from "@/utils/db";
import { z } from "zod";
import { privateProcedure, router } from "../init";

const prisma = await createPrismaClient();
export const folderRouter = router({
  list: privateProcedure.query(async ({ ctx }) => {
    return await listFolders(prisma, ctx.session.user.tenantUuid);
  }),

  create: privateProcedure
    .input(
      z.object({
        folderName: z.string(),
        parentUuid: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await CreateFolder(
        prisma,
        ctx.session.user.tenantUuid,
        ctx.session.user.id,
        input.folderName,
        input.parentUuid
      );
    }),
  delete: privateProcedure
    .input(
      z.object({
        folderUuid: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await deleteFolder(
        prisma,
        ctx.session.user.tenantUuid,
        input.folderUuid
      );
    }),
  update: privateProcedure
    .input(
      z.object({
        folderUuid: z.string(),
        childFolderUuid: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await updateFolder(
        prisma,
        ctx.session.user.tenantUuid,
        input.folderUuid,
        input.childFolderUuid
      );
    }),
});
