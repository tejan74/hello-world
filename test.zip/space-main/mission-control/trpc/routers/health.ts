import { procedure, router } from "../init";

export const healthRouter = router({
  health: procedure.query(() => {
    return "Healthy!";
  }),
});
