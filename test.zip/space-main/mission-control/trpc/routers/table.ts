import { createTableImport, getTableImportStatus, triggerImport } from "@/services/import";
import { createImportSchema } from "@/services/import/types";
import {
  createTable,
  deleteTable,
  duplicateTable,
  fetchTable,
  fetchTableName,
  listTables,
  reorderColumn,
  updateTable,
} from "@/services/table";
import { createPrismaClient } from "@/utils/db";
import { logger } from "@/utils/logger/logger";
import { omit } from "lodash";
import { z } from "zod";
import { privateProcedure, router } from "../init";
import { columnRouter } from "./tableColumn";
import { dataRouter } from "./tableData";
import { rowRouter } from "./tableRow";
import { viewRouter } from "./view";
import { workflowRouter } from "./workflow";

const prisma = await createPrismaClient();

const tableProcedure = privateProcedure.input(
  z.object({
    tableUuid: z.string(),
  })
);

export const tableRouter = router({
  list: privateProcedure.query(async ({ ctx }) => {
    logger.info(`Listing tables for tenant ${ctx.session.user.tenantUuid}`);
    return await listTables(prisma, ctx.session.user.tenantUuid);
  }),
  create: privateProcedure
    .input(
      z.object({
        name: z.string(),
        description: z.string().optional(),
        icon: z.string().optional(),
        folderUuid: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await createTable(
        prisma,
        ctx.session.user.tenantUuid,
        ctx.session.user.id,
        input
      );
    }),
  get: tableProcedure.query(async ({ ctx, input }) => {
    return await fetchTable(
      prisma,
      ctx.session.user.tenantUuid,
      input.tableUuid
    );
  }),
  update: tableProcedure
    .input(
      z.object({
        name: z.string().optional(),
        description: z.string().optional(),
        icon: z.string().optional(),
        locked: z.boolean().optional(),
        tags: z.string().array().optional(),
        folderUuid: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const modifiedInput = omit(input, "tableUuid");
      return await updateTable(
        prisma,
        ctx.session.user.tenantUuid,
        input.tableUuid,
        modifiedInput
      );
    }),
  delete: tableProcedure.mutation(async ({ ctx, input }) => {
    return await deleteTable(
      prisma,
      ctx.session.user.tenantUuid,
      input.tableUuid
    );
  }),
  reorderColumn: tableProcedure
    .input(
      z.object({
        columnUuid: z.string(),
        prevColumnUuid: z.string().nullable(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await reorderColumn(
        prisma,
        ctx.session.user.tenantUuid,
        input.tableUuid,
        input.columnUuid,
        input.prevColumnUuid
      );
    }),
  duplicate: tableProcedure
    .input(
      z.object({
        tableUuid: z.string(),
        name: z.string(),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await duplicateTable(
        prisma,
        ctx.session.user.tenantUuid,
        ctx.session.user.id,
        input.tableUuid,
        input.name,
        input.description
      );
    }),
  getname: tableProcedure.query(async ({ ctx, input }) => {
    return await fetchTableName(
      prisma,
      ctx.session.user.tenantUuid,
      input.tableUuid
    );
  }),
  row: rowRouter,
  column: columnRouter,
  data: dataRouter,
  workflow: workflowRouter,
  import: router({
    create: privateProcedure
      .input(createImportSchema)
      .mutation(async ({ ctx, input }) => {
        const tableImport = await createTableImport(
          prisma,
          ctx.session.user.tenantUuid,
          input
        );
        await triggerImport(tableImport.uuid);
        return tableImport;
      }),
      status: privateProcedure.input(
        z.object({
          uuid: z.string(),
        })
      ).query(async ({ input }) => {
        return await getTableImportStatus(prisma, input.uuid);
      }),
  }),
  view: viewRouter,
});
