import {
  createColumn,
  deleteColumn,
  disableOrEnableColumnAutoRun,
  duplicateColumn,
  lockColumn,
  updateColumn,
  updateColumnOptions,
} from "@/services/table";
import {
  dynamicColumnSchema,
  dynamicColumnUpdateSchema,
  staticColumnSchema,
  staticColumnUpdateSchema,
} from "@/services/table/types";
import { createPrismaClient } from "@/utils/db";
import { z } from "zod";
import { privateProcedure, router } from "../init";

const prisma = await createPrismaClient();

const tableProcedure = privateProcedure.input(
  z.object({
    tableUuid: z.string(),
  })
);

export const columnRouter = router({
  toggleHidden: tableProcedure
    .input(
      z.object({
        columnUuid: z.string(),
        hide: z.boolean(),
        viewUuid: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await updateColumnOptions(
        prisma,
        ctx.session.user.tenantUuid,
        input.tableUuid,
        input.columnUuid,
        {
          hidden: input.hide,
        },
        input.viewUuid
      );
    }),
  togglePinned: tableProcedure
    .input(
      z.object({
        columnUuid: z.string(),
        pinned: z.boolean(),
        viewUuid: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await updateColumnOptions(
        prisma,
        ctx.session.user.tenantUuid,
        input.tableUuid,
        input.columnUuid,
        {
          pinned: input.pinned,
        },
        input.viewUuid
      );
    }),
  toggleLocked: tableProcedure
    .input(z.object({ columnUuid: z.string(), locked: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      return await lockColumn(
        prisma,
        ctx.session.user.tenantUuid,
        input.tableUuid,
        input.columnUuid,
        input.locked
      );
    }),
  //TODO: This looks bad, we should have a common router for all columns
  delete: tableProcedure
    .input(z.object({ columnUuid: z.string() }))
    .mutation(async ({ ctx, input }) => {
      await deleteColumn(
        prisma,
        ctx.session.user.tenantUuid,
        input.tableUuid,
        input.columnUuid
      );
    }),
  duplicate: tableProcedure
    .input(z.object({ columnUuid: z.string() }))
    .mutation(async ({ ctx, input }) => {
      return duplicateColumn(
        prisma,
        ctx.session.user.tenantUuid,
        input.tableUuid,
        input.columnUuid
      );
    }),

  addColor: tableProcedure
    .input(
      z.object({
        color: z.string().nullable(),
        columnUuid: z.string(),
        viewUuid: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await updateColumnOptions(
        prisma,
        ctx.session.user.tenantUuid,
        input.tableUuid,
        input.columnUuid,
        {
          color: input.color,
        },
        input.viewUuid
      );
    }),

  disableOrEnableAutoRun: tableProcedure
    .input(z.object({ columnUuid: z.string(), disabled: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const column = await disableOrEnableColumnAutoRun(
        prisma,
        input.columnUuid,
        input.disabled
      );
      return column;
    }),
  dynamic: router({
    create: tableProcedure
      .input(
        z.object({
          column: dynamicColumnSchema,
        })
      )
      .mutation(async ({ ctx, input }) => {
        const column = await createColumn(
          prisma,
          ctx.session.user.tenantUuid,
          input.tableUuid,
          input.column
        );

        //TODO: trigger cell rerun for all rows or first 5 rows
        return column;
      }),
    update: tableProcedure
      .input(
        z.object({
          columnUuid: z.string(),
          column: dynamicColumnUpdateSchema,
        })
      )
      .mutation(async ({ ctx, input }) => {
        const column = await updateColumn(
          prisma,
          ctx.session.user.tenantUuid,
          input.tableUuid,
          input.columnUuid,
          {
            type: "DYNAMIC",
            data: input.column,
          }
        );
        //TODO: trigger cell rerun for all rows or first 5 row
        return column;
      }),
  }),
  static: router({
    create: tableProcedure
      .input(
        z.object({
          column: staticColumnSchema,
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await createColumn(
          prisma,
          ctx.session.user.tenantUuid,
          input.tableUuid,
          input.column
        );
        //TODO: trigger row rerun for all rows or first 5 rows
      }),
    update: tableProcedure
      .input(
        z.object({
          columnUuid: z.string(),
          column: staticColumnUpdateSchema,
        })
      )
      .mutation(async ({ ctx, input }) => {
        const column = await updateColumn(
          prisma,
          ctx.session.user.tenantUuid,
          input.tableUuid,
          input.columnUuid,
          {
            type: "STATIC",
            data: input.column,
          }
        );
        //TODO: trigger cell rerun for all rows or first 5 rows
        return column;
      }),
  }),
});
