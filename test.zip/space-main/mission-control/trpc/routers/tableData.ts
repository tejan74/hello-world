import { notifyValueChange } from "@/services/table";
import {
  fetchData,
  getCellData,
  updateValuesFromClipboard,
  upsertStaticData,
} from "@/services/table/data";
import {
  AggregationOptions,
  TableFilterSchema,
} from "@/services/table/data/types";
import EngineSQSClient from "@/services/workflow/engineSqs";
import { createPrismaClient } from "@/utils/db";
import { z } from "zod";
import { privateProcedure, router } from "../init";

const prisma = await createPrismaClient();

const tableProcedure = privateProcedure.input(
  z.object({
    tableUuid: z.string(),
  })
);

export const dataRouter = router({
  get: tableProcedure
    .input(
      z.object({
        options: z.object({
          sort: z
            .object({
              columnUuid: z.string(),
              order: z.union([z.literal("asc"), z.literal("desc")]),
            })
            .array()
            .optional(),
          filter: TableFilterSchema.array().optional(),
          pagination: z
            .object({
              limit: z.number(),
              offset: z.number(),
            })
            .optional(),
          noTrim: z.boolean().optional(),
          columns: z.string().array().optional(),
          searchString: z.string().optional(),
          aggregation: z.record(z.nativeEnum(AggregationOptions)),
        }),
        viewUuid: z.string().optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      return await fetchData(
        prisma,
        input.tableUuid,
        ctx.session.user.tenantUuid,
        ctx.session.user.id,
        {
          sort: input.options.sort,
          filter: input.options.filter,
          pagination: input.options.pagination,
          noTrim: input.options.noTrim,
          columns: input.options.columns,
          searchString: input.options.searchString,
          aggregation: input.options.aggregation,
        },
        input.viewUuid
      );
    }),
  updateStaticValue: tableProcedure
    .input(
      z.object({
        columnUuid: z.string(),
        rowUuid: z.string(),
        data: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const updateStaticValue = await upsertStaticData(
        prisma,
        input.columnUuid,
        input.rowUuid,
        input.data
      );
      await notifyValueChange(prisma, input.rowUuid, input.columnUuid);
      const etc = new EngineSQSClient();
      etc.publishEvent("UPDATE_CELL", {
        table_uuid: input.tableUuid,
        row_uuid: input.rowUuid,
        column_uuid: input.columnUuid,
      });
      return updateStaticValue;
    }),
  getCell: tableProcedure
    .input(z.object({ columnUuid: z.string(), rowUuid: z.string() }))
    .query(async ({ input }) => {
      return await getCellData(
        prisma,
        input.tableUuid,
        input.columnUuid,
        input.rowUuid
      );
    }),
  export: tableProcedure
    .input(
      z.object({
        options: z.object({
          sort: z
            .object({
              columnUuid: z.string(),
              order: z.union([z.literal("asc"), z.literal("desc")]),
            })
            .array()
            .optional(),
          filter: TableFilterSchema.array().optional(),
          pagination: z
            .object({
              limit: z.number(),
              offset: z.number(),
            })
            .optional(),
          noTrim: z.boolean().optional(),
          columns: z.string().array().optional(),
          searchString: z.string().optional(),
          aggregation: z.record(z.nativeEnum(AggregationOptions)),
        }),
        viewUuid: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await fetchData(
        prisma,
        input.tableUuid,
        ctx.session.user.tenantUuid,
        ctx.session.user.id,
        {
          sort: input.options.sort,
          filter: input.options.filter,
          pagination: input.options.pagination,
          noTrim: input.options.noTrim,
          columns: input.options.columns,
          searchString: input.options.searchString,
          aggregation: input.options.aggregation,
        },
        input.viewUuid
      );
    }),
  updateValuesFromClipboard: tableProcedure
    .input(
      z.object({
        tableUuid: z.string(),
        rowUuid: z.string(),
        columnUuids: z.string().array(),
        rows: z.string().array().array(),
        options: z.object({
          sort: z
            .object({
              columnUuid: z.string(),
              order: z.union([z.literal("asc"), z.literal("desc")]),
            })
            .array()
            .optional(),
          filter: TableFilterSchema.array().optional(),
          searchString: z.string().optional(),
        }),
        viewUuid: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await updateValuesFromClipboard(
        prisma,
        input.tableUuid,
        input.rowUuid,
        input.columnUuids,
        input.rows,
        {
          sort: input.options.sort,
          filter: input.options.filter,
          searchString: input.options.searchString,
        },
        ctx.session.user.tenantUuid,
        input.viewUuid
      );
    }),
});
