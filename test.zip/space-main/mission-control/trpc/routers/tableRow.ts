import { createNewRow, deleteRow, importRows } from "@/services/table/data";
import { createPrismaClient } from "@/utils/db";
import { z } from "zod";
import { privateProcedure, router } from "../init";

const prisma = await createPrismaClient();

const tableProcedure = privateProcedure.input(
  z.object({
    tableUuid: z.string(),
  })
);

export const rowRouter = router({
  import: tableProcedure
    .input(
      z.object({
        rows: z.array(
          z.object({
            index: z.number(),
            values: z.record(z.string()),
          })
        ),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await importRows(
        prisma,
        input.tableUuid,
        ctx.session.user.tenantUuid,
        input.rows
      );
    }),
  create: tableProcedure
    .input(
      z.object({
        values: z.record(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await createNewRow(
        prisma,
        input.tableUuid,
        ctx.session.user.tenantUuid,
        input.values
      );
    }),
  delete: tableProcedure
    .input(
      z.object({
        rowUuid: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await deleteRow(
        prisma,
        input.tableUuid,
        input.rowUuid,
        ctx.session.user.tenantUuid
      );
    }),
});
