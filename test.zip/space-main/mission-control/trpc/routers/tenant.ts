import { getAllTenants } from "@/services/tenant/fetch";
import {
  createIntegrationAndOauthUrl,
  getCrmObjectFields,
  getCrmObjects,
  listIntegrations,
} from "@/services/tenant/integration";
import { updateTenant } from "@/services/tenant/update";
import { createPrismaClient } from "@/utils/db";
import { z } from "zod";
import { privateProcedure, router } from "../init";

const prisma = await createPrismaClient();

export const tenantRouter = router({
  update: privateProcedure
    .input(
      z.object({
        name: z.string(),
        teamCount: z.number().nullable(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await updateTenant(
        prisma,
        ctx.session.user.tenantUuid,
        input.name,
        input.teamCount
      );
    }),
  // TODO: This should be only allowed for "Astronaut" roles
  getAll: privateProcedure.query(async ({ ctx, input }) => {
    return await getAllTenants(prisma);
  }),

  integration: router({
    createAndAuth: privateProcedure
      .input(
        z.object({
          name: z.string(),
          provider: z.string(),
          integrationType: z.string(),
          data: z.record(z.string(), z.any()),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await createIntegrationAndOauthUrl(
          prisma,
          ctx.session.user.tenantUuid,
          input
        );
      }),
    list: privateProcedure
      .input(z.object({ integrationType: z.string().optional() }).optional())
      .query(async ({ ctx, input }) => {
        return await listIntegrations(
          prisma,
          ctx.session.user.tenantUuid,
          input?.integrationType
        );
      }),
    getCrmObjects: privateProcedure
      .input(
        z.object({
          integrationUuid: z.string(),
        })
      )
      .query(async ({ ctx, input }) => {
        return await getCrmObjects(
          prisma,
          ctx.session.user.tenantUuid,
          input.integrationUuid
        );
      }),
    getCrmObjectFields: privateProcedure
      .input(
        z.object({
          integrationUuid: z.string(),
          crmObjectId: z.string(),
        })
      )
      .query(async ({ ctx, input }) => {
        return await getCrmObjectFields(
          prisma,
          ctx.session.user.tenantUuid,
          input.integrationUuid,
          input.crmObjectId
        );
      }),
  }),
});
