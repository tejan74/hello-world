import { fetchViewData, getTenantDataView, getView, listViews } from "@/services/tenantData";
import {
  TableFilterSchema,
  TableSortSchema,
} from "@/services/tenantData/types";
import { createPrismaClient } from "@/utils/db";
import { z } from "zod";
import { privateProcedure, router } from "../init";

const prisma = await createPrismaClient();

export const tenantDataRouter = router({
  listViews: privateProcedure.query(async ({ ctx }) => {
    return await listViews(prisma, ctx.session.user.tenantUuid);
  }),
  getView: privateProcedure
    .input(z.object({ uuid: z.string() }))
    .query(async ({ input, ctx }) => {
      return await getView(prisma, ctx.session.user.tenantUuid, input.uuid);
    }),
  getViewData: privateProcedure
    .input(
      z.object({
        uuid: z.string(),
        pagination: z.object({
          limit: z.number(),
          offset: z.number(),
        }),
        filter: TableFilterSchema.optional(),
        sort: TableSortSchema.optional(),
      })
    )
    .query(async ({ input, ctx }) => {
      return await fetchViewData(
        prisma,
        ctx.session.user.tenantUuid,
        input.uuid,
        {
          filter: input.filter,
          sort: input.sort,
          pagination: {
            limit: input.pagination.limit,
            offset: input.pagination.offset,
          },
        }
      );
    }),
  getTenantDataView: privateProcedure.query(async ({ ctx }) => {
    return await getTenantDataView(prisma, ctx.session.user.tenantUuid);
  }),
});
