import { getUser, setUserDetails } from "@/services/user/fetch";
import { getAllUser } from "@/services/user/getUser";
import { sendEmail } from "@/services/user/invitation";
import { changeUserTenant } from "@/services/user/update";
import { createPrismaClient } from "@/utils/db";
import { z } from "zod";
import { privateProcedure, router } from "../init";
import { favoritesRouter } from "./userFavariote";

const prisma = await createPrismaClient();

export const userRouter = router({
  get: privateProcedure.query(async ({ ctx, input }) => {
    return await getUser(prisma, ctx.session.user.email || "");
  }),
  update: privateProcedure
    .input(
      z.object({
        id: z.string(),
        name: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await setUserDetails(prisma, input.id, input.name);
    }),
  // TODO: Only allow this for Astronauts by create a separate privateProcedure wrapper that is for Orbital employees only
  updateTenant: privateProcedure
    .input(
      z.object({
        email: z.string(),
        tenantUuid: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await changeUserTenant(prisma, input.email, input.tenantUuid);
    }),
  invitation: privateProcedure
    .input(
      z.object({
        email: z.string(),
        name: z.string(),
      })
    )
    .output(z.object({ status: z.string(), message: z.string() }))
    // .output(object({ message }))
    .mutation(async ({ ctx, input }) => {
      const result = await sendEmail(ctx, input.email, input.name);
      return result;
    }),

  getUserDetails: privateProcedure.query(async ({ ctx, input }) => {
    return await getAllUser(prisma, ctx.session.user.tenantUuid || "");
  }),
  favorites: favoritesRouter,
});
