import {
  userFavoriteDataSchema,
  userFavoriteTypesSchema,
} from "@/services/table/data/types";
import { add, list, remove } from "@/services/user/favorite";
import { createPrismaClient } from "@/utils/db";
import { z } from "zod";
import { privateProcedure, router } from "../init";
const prisma = await createPrismaClient();
export const favoritesRouter = router({
  add: privateProcedure
    .input(
      z.object({
        type: userFavoriteTypesSchema,
        objectId: z.string().optional(),
        data: userFavoriteDataSchema.optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await add(
        prisma,
        ctx.session.user.id,
        ctx.session.user.tenantUuid,
        input.type,
        input.objectId,
        input.data
      );
    }),
  remove: privateProcedure
    .input(
      z.object({
        uuid: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return await remove(prisma, input.uuid);
    }),
  list: privateProcedure.mutation(async ({ ctx, input }) => {
    return await list(prisma, ctx.session.user.id);
  }),
});
