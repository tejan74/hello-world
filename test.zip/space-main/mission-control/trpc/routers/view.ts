import {
  aggregationSchema,
  TableFilterSchema,
  TableSortSchema,
  tableViewSchema,
  TableViewTypesSchema,
} from "@/services/table/data/types";
import {
  createTableView,
  getAllViews,
  getViewDetails,
  updateNameAndType,
  updateView,
} from "@/services/table/view";
import { createPrismaClient } from "@/utils/db";
import { z } from "zod";
import { privateProcedure, router } from "../init";

const prisma = await createPrismaClient();
const viewProcedure = privateProcedure.input(
  z.object({
    viewUuid: z.string(),
  })
);
export const viewRouter = router({
  create: privateProcedure
    .input(
      z.object({
        previousViewUuid: z.string().nullable(),
        view: tableViewSchema,
      })
    )
    .mutation(async ({ ctx, input }) => {
      const newView = await createTableView(
        prisma,
        ctx.session.user.id,
        ctx.session.user.tenantUuid,
        input.previousViewUuid,
        input.view
      );
      return newView;
    }),
  updateNameAndType: viewProcedure
    .input(
      z.object({
        viewName: z.string(),
        viewType: TableViewTypesSchema,
      })
    )
    .query(async ({ ctx, input }) => {
      await updateNameAndType(
        prisma,
        ctx.session.user.tenantUuid,
        input.viewUuid,
        input.viewName,
        input.viewType,
        ctx.session.user.id
      );
    }),
  getViews: privateProcedure
    .input(
      z.object({
        tableUuid: z.string(),
      })
    )
    .query(async ({ ctx, input }) => {
      const allViews = await getAllViews(
        prisma,
        ctx.session.user.id,
        ctx.session.user.tenantUuid,
        input.tableUuid
      );
      return allViews;
    }),
  get: viewProcedure
    .input(
      z.object({
        tableUuid: z.string(),
      })
    )
    .query(async ({ ctx, input }) => {
      return await getViewDetails(
        prisma,
        ctx.session.user.tenantUuid,
        input.viewUuid,
        input.tableUuid
      );
    }),
  update: viewProcedure
    .input(
      z.object({
        tableUuid: z.string(),
        filterData: TableFilterSchema.array().optional(),
        sortData: TableSortSchema.array().optional(),
        aggregationData: aggregationSchema,
      })
    )
    .mutation(async ({ ctx, input }) => {
      await updateView(
        prisma,
        ctx.session.user.tenantUuid,
        input.tableUuid,
        input.viewUuid,
        ctx.session.user.id,
        input.filterData,
        input.sortData,
        input.aggregationData
      );
    }),
});
