import { recommendColumn, runCell, runColumn } from "@/services/table";
import { TableFilterSchema } from "@/services/table/data/types";
import { createPrismaClient } from "@/utils/db";
import { z } from "zod";
import { privateProcedure, router } from "../init";

const prisma = await createPrismaClient();

const tableProcedure = privateProcedure.input(
  z.object({
    tableUuid: z.string(),
  })
);

export const workflowRouter = router({
  recommendColumn: tableProcedure
    .input(
      z.object({
        prompt: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      return await recommendColumn(prisma, input.tableUuid, input.prompt);
    }),
  runCell: tableProcedure
    .input(
      z.object({
        rowUuid: z.string(),
        columnUuid: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      return await runCell(prisma, input.rowUuid, input.columnUuid);
    }),
  runColumn: tableProcedure
    .input(
      z.object({
        columnUuid: z.string(),
        filter: TableFilterSchema.array().optional(),
        rows: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await runColumn(
        prisma,
        input.tableUuid,
        input.columnUuid,
        input.filter,
        input.rows
      );
    }),
});
