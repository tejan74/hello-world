"use client";

import AppModel from "@/mobx/app/appModel";

import { UserType } from "@/mobx/user/types";
import { observer } from "mobx-react-lite";
import { createContext, useContext, useState } from "react";
import ConfirmationDialog from "../components/dialog/ConfirmationDialog";

export const AppContext = createContext<AppModel | null>(null);

const AppContextProvider = observer(
  ({ children, user }: { children: React.ReactNode; user: UserType }) => {
    const [model] = useState<AppModel>(() => new AppModel(user));
    return (
      <AppContext.Provider value={model}>
        {children}
        {model.confirmDialog && (
          <ConfirmationDialog
            open={!!model.confirmDialog}
            title={model.confirmDialog.title}
            message={model.confirmDialog.message}
            confirmButtonText={model.confirmDialog.confirmButtonText}
            cancelButtonText={model.confirmDialog.cancelButtonText}
            onConfirm={model.confirmDialog.onConfirm}
            onCancel={model.confirmDialog.onCancel}
            onClose={model.confirmDialog.onClose}
          />
        )}
      </AppContext.Provider>
    );
  }
);

export const useAppContext = () => {
  const model = useContext(AppContext);
  if (!model)
    throw new Error(
      "No model found! Make sure you are using useAppContext in the correct place"
    );
  return model;
};

export default AppContextProvider;
