"use client";

import React, { createContext, useState } from "react";

export const NavbarContext = createContext<{
  menuState: string;
  setMenuState: (x: string) => void;
}>({
  menuState: "",
  setMenuState: () => {},
});

const NavbarContextProvider = ({ children }: { children: React.ReactNode }) => {
  const [menuState, setMenuState] = useState("nothing");

  return (
    <NavbarContext.Provider value={{ menuState, setMenuState }}>
      {children}
    </NavbarContext.Provider>
  );
};

export default NavbarContextProvider;
