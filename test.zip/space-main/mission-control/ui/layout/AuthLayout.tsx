import "@/ui/styles/auth/styles.css";
import { Flex } from "@radix-ui/themes";
import Image from "next/image";
import AuthBanner from "../components/banner/AuthBanner";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <Flex
      direction="row"
      align="center"
      justify="between"
      width="100%"
      height="100vh"
      p="1.9rem"
    >
      <Flex
        direction="column"
        align="center"
        justify="center"
        width="58%"
        height="100%"
      >
        <Flex direction="column" align="start" justify="center" width="328px">
          <Flex mb="4">
            <Image alt="logo" src="/orbital.svg" width={42} height={42} />
          </Flex>
          {children}
        </Flex>
      </Flex>
      <AuthBanner />
    </Flex>
  );
}
