import { Flex } from "@radix-ui/themes";
import { NavLayoutWithUser } from "./NavLayoutWithUser";

export default function NavLayout({ children }: { children: React.ReactNode }) {
  return (
    <Flex direction="row" width="100%" height="100%" overflowX="hidden">
      <NavLayoutWithUser />
      <Flex flexGrow="1" overflowX="hidden" overflowY="auto">
        {children}
      </Flex>
    </Flex>
  );
}
