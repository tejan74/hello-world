import { authOptions } from "@/services/auth/authOptions";
import { getAllTenants } from "@/services/tenant/fetch";
import { getUser } from "@/services/user/fetch";
import { createPrismaClient } from "@/utils/db";
import { Tenant } from "@prisma/client";
import { getServerSession } from "next-auth";
import Heap from "../components/external/Heap";
import IntercomChat from "../components/external/Intercom";
import Navbar from "../components/navbar/Navbar";
import NavbarContextProvider from "../context/NavbarContext";

const prisma = await createPrismaClient();

const getData = async () => {
  const session = await getServerSession(authOptions);
  if (session && session.user.email) {
    const user = await getUser(prisma, session.user.email);
    if (user) return user;
  }
};

export async function NavLayoutWithUser() {
  const user = await getData();

  let tenants: Tenant[] = [];
  // TODO: Make this eventually check for this AND astronaut!
  if (user?.email.endsWith("@withorbital.com")) {
    tenants = await getAllTenants(prisma);
  }
  return (
    <>
      {user && (
        <>
          <IntercomChat {...user} />
          <Heap {...user} />
          <NavbarContextProvider>
            <Navbar
              user={{
                email: user.email,
                tenantName: user.Tenant.name,
              }}
              tenants={tenants}
            />
          </NavbarContextProvider>
        </>
      )}
    </>
  );
}
