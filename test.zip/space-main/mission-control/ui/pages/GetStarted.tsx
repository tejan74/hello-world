"use client";

import { UserModel } from "@/mobx/user/UserModel";
import { UserType } from "@/mobx/user/types";
import { ArrowRightIcon } from "@radix-ui/react-icons";
import { Button, Flex, Heading, Text } from "@radix-ui/themes";
import { observer } from "mobx-react-lite";
import { signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { InlineWidget } from "react-calendly";
import AuthTextField from "../components/auth/AuthTextField";

const GetStartedPage = ({ user }: { user: UserType }) => {
  const [model] = useState<UserModel>(() => new UserModel(user));
  return (
    <>
      {!user.Tenant.teamCount ? (
        <WorkspaceDetails user={model} />
      ) : (
        <ScheduleMeeting user={model} />
      )}
    </>
  );
};

const WorkspaceDetails = observer(({ user }: { user: UserModel }) => {
  const [teamName, setTeamName] = useState<string>("");
  const [teamCount, setTeamCount] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);

  const updateTenant = async () => {
    setLoading(true);
    if (teamName && teamCount)
      await user.updateTeamDetails(teamName, parseInt(teamCount));
    setLoading(false);
  };

  return (
    <>
      {!user.numberOfTeammates ? (
        <Flex direction="column" gap="5" justify="start" width="100%">
          <Flex direction="column" gap="1">
            <Heading size="6" weight="regular">{`Welcome ${
              user.name?.split(" ")?.[0] || "User"
            }!`}</Heading>
            <Flex direction="row" align="center" gap="1">
              <Text size="2">
                {"Now let's finish getting your workspace setup"}
              </Text>
              <ArrowRightIcon width={14} height={14} />
            </Flex>
          </Flex>
          <Flex direction="column" gap="4">
            <AuthTextField
              value={teamName}
              setValue={setTeamName}
              type="text"
              placeholder="Team or workspace name *"
            />
            <AuthTextField
              value={user.domain}
              setValue={() => {}}
              type="text"
              placeholder="Domain"
              disabled
            />
            <AuthTextField
              value={teamCount}
              setValue={setTeamCount}
              type="number"
              placeholder="# of teammates *"
            />
          </Flex>
          <Button
            disabled={!teamName || !teamCount || isNaN(parseInt(teamCount))}
            mt="3"
            style={{
              textTransform: "none",
              padding: 0,
              height: 38,
              fontSize: 13,
              fontWeight: 500,
              backgroundColor:
                !teamName || !teamCount || isNaN(parseInt(teamCount))
                  ? "#f0f0f3"
                  : "#022C7C",
              color: "#FFFFFF",
              borderRadius: 0,
              border: "none",
              boxShadow: "none",
              transition: "background-color 0.3s ease",
            }}
            onClick={updateTenant}
          >
            {loading ? "Updating..." : "Next"}
          </Button>
        </Flex>
      ) : (
        <ScheduleMeeting user={user} />
      )}
    </>
  );
});

const ScheduleMeeting = observer(({ user }: { user: UserModel }) => {
  const router = useRouter();
  return (
    <Flex direction="column" gap="5" justify="start" width="100%">
      <Flex direction="column" gap="1">
        <Heading size="6" weight="regular">{`Welcome ${
          user.name?.split(" ")?.[0] || "User"
        }!`}</Heading>
        <Text size="2">
          {
            "Last but not least, let's put you in touch with a Solutions Architect that help you build your first pipeline."
          }
        </Text>
      </Flex>
      {process.env.NEXT_PUBLIC_CALENDLY_SCHEDULE_URL && (
        <InlineWidget
          url={process.env.NEXT_PUBLIC_CALENDLY_SCHEDULE_URL}
          styles={{ height: 500, position: "relative" }}
        />
      )}
      <Button
        onClick={() => {
          signOut({ redirect: false }).then(() => {
            router.push("/logout");
          });
        }}
        mt="3"
        style={{
          textTransform: "none",
          padding: 0,
          height: 38,
          fontSize: 13,
          fontWeight: 500,
          backgroundColor: "#022C7C",
          color: "#FFFFFF",
          borderRadius: 0,
          border: "none",
          boxShadow: "none",
          transition: "background-color 0.3s ease",
        }}
      >
        Sign Out
      </Button>
    </Flex>
  );
});

export default GetStartedPage;
