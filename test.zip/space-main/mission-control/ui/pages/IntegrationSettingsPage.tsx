"use client";
import { IntegrationObject, INTEGRATIONS } from "@/constants/integrations";
import { trpc } from "@/trpc/client";
import { TenantIntegration } from "@prisma/client";
import { InfoCircledIcon, PlusIcon } from "@radix-ui/react-icons";
import { Button, Callout, Flex, Heading, Spinner } from "@radix-ui/themes";
import { observer } from "mobx-react-lite";
import { useEffect, useState } from "react";
import Drawer from "../components/drawer";
import { DrawerContent } from "../components/integration/DrawerContent";
import {
  ConnectedIntegrationTiles,
  IntegrationTiles,
} from "../components/integration/Tile";

const IntegrationsSettingsPage = observer(() => {
  const [integrations, setIntegrations] = useState<TenantIntegration[]>([]);
  const [open, setOpen] = useState<boolean>(false);
  const [currentIntegration, setCurrentIntegration] =
    useState<IntegrationObject | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const getIntegrations = async () => {
    setLoading(true);
    const integrations = await trpc.tenant.integration.list.query();
    setIntegrations(integrations);
    setLoading(false);
  };

  useEffect(() => {
    getIntegrations();
  }, []);

  return (
    <>
      <Heading mt="5">Integrations</Heading>
      <Callout.Root mt="2" size="1" color="gray">
        <Callout.Icon>
          <InfoCircledIcon />
        </Callout.Icon>
        <Callout.Text>Connect applications to your account</Callout.Text>
      </Callout.Root>
      <Flex mt="5" style={{ borderTop: "2px solid #eeee" }} direction="column">
        <Heading size="4" mt="5">
          Connected Integrations ({integrations.length})
        </Heading>
        <Flex
          direction="row"
          justify="between"
          gap="5"
          mt="5"
          wrap="wrap"
          overflow="auto"
          maxHeight="60vh"
          width="100%"
        >
          {loading ? (
            <Flex direction="row" align="center" justify="center" width="100%">
              <Spinner size="3" />
            </Flex>
          ) : (
            integrations.map((integration) => (
              <ConnectedIntegrationTiles
                name={integration.name}
                provider={integration.integration}
              />
            ))
          )}
        </Flex>
        <Button variant="soft" mt="5" onClick={() => setOpen(true)}>
          <PlusIcon /> Add new integration
        </Button>
        <Drawer
          header="Add new integration"
          isOpen={open}
          onClose={() => setOpen(false)}
          blocking={true}
          showNavbar={false}
        >
          <Flex
            direction="column"
            justify="between"
            gap="5"
            mt="2"
            overflow="auto"
            maxHeight="90vh"
            width="100%"
            p="3"
          >
            {INTEGRATIONS.map((integration) => (
              <IntegrationTiles
                integration={integration}
                setCurrentIntegration={setCurrentIntegration}
              />
            ))}
          </Flex>
        </Drawer>
      </Flex>
      <Drawer
        header="Add Integration"
        isOpen={Boolean(currentIntegration)}
        onClose={() => setCurrentIntegration(null)}
        blocking={true}
        showNavbar={false}
      >
        {currentIntegration && (
          <DrawerContent integration={currentIntegration} />
        )}
      </Drawer>
    </>
  );
});

export default IntegrationsSettingsPage;
