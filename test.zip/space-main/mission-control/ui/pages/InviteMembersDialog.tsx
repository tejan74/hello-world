import { trpc } from "@/trpc/client";
import { Button, Dialog, Flex, Text, TextField } from "@radix-ui/themes";
import { observer } from "mobx-react-lite";
import { useState } from "react";
import { toast } from "react-hot-toast";


const InviteMembersDialog = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const sendInvitation = async (email: string, name: string) => {
    // Example function to delete a user
    try {
      let regex = new RegExp(
        "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
        "i"
      );
      if (!email || !name) {
        console.log(email, name);
        toast.error("Please fill all the mandatory fields");
      } else if (email && !regex.exec(email)) {
        toast.error("Please Enter Valid Mail Id ");
      } else {
        const response = await trpc.user.invitation.mutate({
          email: email,
          name: name,
        });
        if (response.status == "error") {
          toast.error(response.message);
        } else {
          toast.success(response.message);
        }
      }
    } catch (error) {
      console.error("Error deleting user:", error);
    }
  };

  const handleName = (event: React.ChangeEvent<HTMLInputElement>) => {
    const name = event.target.value;
    setName(name);
  };

  const handleEmail = (event: React.ChangeEvent<HTMLInputElement>) => {
    const email = event.target.value;
    setEmail(email);
  };

  const submitUserData = () => {
    // event.preventDefault(); // Prevent default form submission
    sendInvitation(email, name);
  };

  return (
    <Dialog.Root>
      <Dialog.Trigger>
        <Button size="1" variant="soft">Invite Members</Button>
      </Dialog.Trigger>

      <Dialog.Content maxWidth="450px">
        <Dialog.Title>Invite Members</Dialog.Title>

        <Flex direction="column" gap="3">
          <label>
            <Text as="div" size="2" mb="1" weight="bold">
              Name*
            </Text>
            <TextField.Root
              placeholder="Enter Receiver full name"
              onChange={handleName}
            />
          </label>
          <label>
            <Text as="div" size="2" mb="1" weight="bold">
              Email*
            </Text>
            <TextField.Root
              placeholder="Enter Receiver email"
              onChange={handleEmail}
            />
          </label>
        </Flex>

        <Flex gap="3" mt="4" justify="end">
          <Dialog.Close>
            <Button variant="soft" color="red">
              Cancel
            </Button>
          </Dialog.Close>
          <Dialog.Close>
            <Button variant="soft" onClick={submitUserData}>Save</Button>
          </Dialog.Close>
        </Flex>
      </Dialog.Content>
    </Dialog.Root>
  );
};

export default observer(InviteMembersDialog);
