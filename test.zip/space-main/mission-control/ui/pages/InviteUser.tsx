import { trpc } from "@/trpc/client";
import { Box } from "@mui/material";
import {
  Button,
  Callout,
  Flex,
  Heading,
  Separator,
  Spinner,
  Table,
  Text,
  TextField,
} from "@radix-ui/themes";
import { observer } from "mobx-react-lite";
import { useEffect, useState } from "react";
import InviteMembersDialog from "./InviteMembersDialog";
import { InfoCircledIcon } from "@radix-ui/react-icons";

const InviteUser = () => {
  let [users, setUsers] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  // const [filteredUsers, setFilteredUsers] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const fetchedUsers = await trpc.user.getUserDetails.query();
        setUsers(fetchedUsers || []);
        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching users:", error);
        setIsLoading(false);
      }
    };

    fetchUsers();
  }, []);

  if (isLoading) {
    return (
      <Flex
        direction="row"
        align="center"
        justify="center"
        height="100%"
        width="100%"
        mt="9"
      >
        <Spinner size="3" />
      </Flex>
    );
  }
  const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
    const searchTerm = event.target.value;
    setSearchTerm(searchTerm);
  };

  const resetSearch = async () => {
    setSearchTerm("");
    const fetchedUsers = await trpc.user.getUserDetails.query();
    setUsers(fetchedUsers || []);
  };

  return (
    <Flex direction="column" gap="20" width="100%" mt="5">
      <Heading>Members</Heading>
      <Callout.Root mt="2" size="1" color="gray">
        <Callout.Icon>
          <InfoCircledIcon />
        </Callout.Icon>
        <Callout.Text>Send Invitation to Members</Callout.Text>
      </Callout.Root>
      <Flex mt="6" direction="row" gap="6">
        <Box style={{ width: "50%" }}>
          <TextField.Root
            size="1"
            variant="classic"
            placeholder="Search members"
            style={{ width: "20vw" }}
            value={searchTerm}
            onChange={handleSearch}
          />
        </Box>
        <Box>
          <Button size="1" variant="outline" onClick={resetSearch}>
            Reset
          </Button>
        </Box>
        <Box className="send-invitation">
          <InviteMembersDialog />
        </Box>
      </Flex>
      <Table.Root
        size="1"
        mt="6"
        style={{
          maxHeight: "60%",
          overflowX: "hidden",
          overflowY: "auto",
        }}
      >
        <Table.Header>
          <Table.Row>
            <Table.ColumnHeaderCell>Full name</Table.ColumnHeaderCell>
            <Table.ColumnHeaderCell>Email</Table.ColumnHeaderCell>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {users
            .filter((user) =>
              (user.name + "\n" + user.email)
                .toLocaleLowerCase()
                .includes(searchTerm.toLocaleLowerCase())
            )
            .map((user, index) => (
              <Table.Row key={index}>
                <Table.RowHeaderCell>{user.name}</Table.RowHeaderCell>
                <Table.Cell>{user.email}</Table.Cell>
              </Table.Row>
            ))}
        </Table.Body>
      </Table.Root>
    </Flex>
  );
};

export default observer(InviteUser);
