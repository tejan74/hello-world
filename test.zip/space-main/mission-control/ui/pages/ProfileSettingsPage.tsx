"use client";
import { UserModel } from "@/mobx/user/UserModel";
import { UserType } from "@/mobx/user/types";
import { InfoCircledIcon } from "@radix-ui/react-icons";
import {
  Avatar,
  Button,
  Callout,
  Flex,
  Heading,
  Text,
  TextField,
} from "@radix-ui/themes";
import { observer } from "mobx-react-lite";
import { useState } from "react";
import toast from "react-hot-toast";

const ProfileSettingsPage = observer(({ user }: { user: UserType }) => {
  const [model] = useState<UserModel>(() => new UserModel(user));

  const [name, setName] = useState(user.name || "");

  const onSaveChanges = () => {
    if (name) {
      model.updateUserDetails(name);
    }
  };

  return (
    <>
      <Heading mt="5">Profile</Heading>
      <Callout.Root mt="2" size="1" color="gray">
        <Callout.Icon>
          <InfoCircledIcon />
        </Callout.Icon>
        <Callout.Text>
          Changes to your profile apply to all your work spaces
        </Callout.Text>
      </Callout.Root>
      <Flex mt="5" style={{ borderTop: "2px solid #eeee" }} direction="column">
        <Flex mt="6" direction="row" gapX="6">
          <Avatar
            size="5"
            radius="full"
            src={user.image ?? ""}
            fallback={user.name?.[0] ?? "NA"}
          ></Avatar>

          <Flex direction="column" gapY="3">
            <Heading size="1">Profile Picture</Heading>
            <Button disabled variant="soft" style={{ width: "20vh" }} size="1">
              Upload Image
            </Button>
            <Text size="1" color="gray">
              We support PNGs,JPEGs and GIFs under 10MB
            </Text>
          </Flex>
        </Flex>
        <Flex mt="7" gapX="7">
          <Flex direction="column" gapY="2">
            <Text size="1" color="gray">
              Name
            </Text>
            <TextField.Root
              size="1"
              variant="classic"
              style={{ width: "20vw" }}
              value={name}
              onChange={(e) => {
                setName(e.target.value);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  onSaveChanges();
                  toast.success("Updated Successfully");
                }
              }}
            ></TextField.Root>
          </Flex>
          <Flex direction="column" gapY="2">
            <Text size="1" color="gray">
              Email Address
            </Text>
            <TextField.Root
              size="1"
              variant="classic"
              style={{ width: "20vw" }}
              value={user.email}
              disabled={true}
            ></TextField.Root>
          </Flex>
        </Flex>
      </Flex>
    </>
  );
});

export default ProfileSettingsPage;
