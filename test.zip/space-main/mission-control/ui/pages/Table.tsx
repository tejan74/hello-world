"use client";
// TODO: Clean this
import useUpdateEffect from "@/hooks/useUpdateEffect";
import TablePageModel from "@/mobx/table/tablePageModel";
import CSVReader from "@/ui/components/csvImporter/csvImport";
import Drawer from "@/ui/components/drawer";
import AddActionColumnForm from "@/ui/components/table/AddActionColumnForm";
import AddNewColumnOptions from "@/ui/components/table/AddNewColumnOptions";
import CellView from "@/ui/components/table/CellView";
import EditColumnForm from "@/ui/components/table/EditColumnForm";
import EditTableForm from "@/ui/components/table/EditTableForm";
import RegularColumnOptions from "@/ui/components/table/RegularColumnOptions";
import {
  Flex,
  Heading,
  IconButton,
  Spinner,
  Text,
  TextField,
} from "@radix-ui/themes";
import { observer } from "mobx-react-lite";
import { useSearchParams } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import AggregationOptionsDropdown from "../components/table/AggregationOptionsDropdown";
import CsvExportDialog from "../components/table/CsvExportDialog";
import MultiColumnOptions from "../components/table/MultiColumnOptions";
import TableMeta from "../components/table/TableMeta";
import TableSortAndFilter from "../components/table/TableSortAndFilter";
import TableUI from "../components/table/TableUI";
import { useAppContext } from "../context/AppContext";

import { AddActionModel } from "@/mobx/table/addActionModel";
import EditColumnModel from "@/mobx/table/editColumnModel";
import { HamburgerMenuIcon, Pencil1Icon } from "@radix-ui/react-icons";
import SelectActionForm from "../components/table/SelectActionForm";
import TableImportExport from "../components/tableImportExport";
import ViewForm from "../components/views/ViewForm";

type AddOrEditColumnHeaderProps =
  | {
      model: AddActionModel;
      type: "Add";
    }
  | {
      model: EditColumnModel;
      type: "Edit";
    };

const AddOrEditColumnHeader = observer(
  ({ model, type }: AddOrEditColumnHeaderProps) => {
    const [edit, setEdit] = useState<boolean>(false);
    const [name, setName] = useState(model.name);
    const [showHelpText, setShowHelpText] = useState<boolean>(false);

    useEffect(() => {
      setName(model.name);
    }, [model.name]);

    return (
      <>
        {edit ? (
          <Flex direction="row" align="center" gap="2">
            <TextField.Root
              value={name}
              onChange={(e) => {
                model.user.hasPermission("column.write") &&
                  setName(e.target.value);
              }}
              autoFocus
              onFocus={() => setShowHelpText(true)}
              onBlur={() => {
                setShowHelpText(false);
                setName(model.name);
                setEdit(false);
              }}
              onKeyDown={async (e) => {
                if (e.key === "Enter") {
                  if (type == "Edit") {
                    if (model.user.hasPermission("column.write")) {
                      await model.updateName(name);
                    }
                  } else {
                    model.setName(name);
                  }
                  setEdit(false);
                }
                if (e.key == "Escape") {
                  setName(model.name);
                  setEdit(false);
                }
              }}
            />
            {showHelpText && (
              <Text size="1" color="gray" style={{ width: 120 }}>
                Hit "Enter" to apply or "Esc" to discard
              </Text>
            )}
          </Flex>
        ) : (
          <Flex direction="row" align="center" gap="1">
            <Heading
              size="3"
              style={{ fontWeight: 600 }}
              onClick={() => setEdit(true)}
            >
              {name}
            </Heading>
            <IconButton
              size="1"
              variant="outline"
              style={{ boxShadow: "none" }}
              onClick={() => setEdit(true)}
            >
              <Pencil1Icon />
            </IconButton>
          </Flex>
        )}
      </>
    );
  }
);

const EditColumnMenu = observer(
  ({ model, columnUuid }: { model: TablePageModel; columnUuid: string }) => {
    const elRef = useRef<HTMLButtonElement>(null);

    return (
      <IconButton
        variant="outline"
        size="2"
        style={{ boxShadow: "none" }}
        ref={elRef}
        onClick={() => model.onAgTableHeaderClicked([columnUuid], elRef)}
      >
        <HamburgerMenuIcon />
      </IconButton>
    );
  }
);

function TablePage({ params }: { params: { uuid: string } }) {
  const appModel = useAppContext();
  const searchParams = useSearchParams();
  const [pageModel, setPageModel] = useState<TablePageModel>(
    () =>
      new TablePageModel(
        params.uuid,
        appModel.userModel,
        appModel,
        searchParams
      )
  );
  useEffect(() => pageModel.dispose, [pageModel]);

  useEffect(() => {
    document.addEventListener("paste", pageModel.handleColumnPaste);
    return () => {
      document.removeEventListener("paste", pageModel.handleColumnPaste);
    };
  }, [pageModel]);

  useUpdateEffect(() => {
    pageModel.dispose();
    const model = new TablePageModel(
      params.uuid,
      appModel.userModel,
      appModel,
      searchParams
    );
    setPageModel(model);
    return model.dispose;
  }, [params.uuid]);

  useEffect(() => {
    //TODO: Create a hook for this
    if (pageModel.tableMeta?.name) {
      document.title = pageModel.tableMeta.name + " - Orbital";
    }
  }, [pageModel.tableMeta?.name]);

  const openDrawer = Boolean(
    pageModel.editColumnModel ||
      pageModel.addActionModel ||
      pageModel.cellViewModel ||
      pageModel.editTableModel ||
      pageModel.viewFormModel ||
      pageModel.selectActionModel
  );
  const closeDrawer = () =>
    [
      pageModel.editColumnModel,
      pageModel.addActionModel,
      pageModel.cellViewModel,
      pageModel.editTableModel,
      pageModel.viewFormModel,
      pageModel.selectActionModel,
    ]
      .find((x) => x)
      ?.hide();

  const title = pageModel.editColumnModel ? (
    <AddOrEditColumnHeader model={pageModel.editColumnModel} type="Edit" />
  ) : pageModel.addActionModel ? (
    <AddOrEditColumnHeader model={pageModel.addActionModel} type="Add" />
  ) : pageModel.cellViewModel ? (
    `Cell Data: ${pageModel.cellViewModel?.columnName || ""}`
  ) : pageModel.editTableModel ? (
    "Edit Table Meta"
  ) : pageModel.viewFormModel?.mode === "CREATE" ? (
    "Create View"
  ) : pageModel.viewFormModel?.mode === "UPDATE" ? (
    "Edit View"
  ) : (
    ""
  );

  return (
    <Flex direction="column" width="100%" height="100vh">
      <TableMeta model={pageModel} user={appModel.userModel.data} />
      <TableSortAndFilter model={pageModel} />
      {pageModel.loadingTable ? (
        <Flex
          direction="row"
          align="center"
          justify="center"
          height="80%"
          width="100%"
        >
          <Spinner size="3" />
        </Flex>
      ) : pageModel.agTable && pageModel.user.hasPermission("table.read") ? (
        <TableUI model={pageModel.agTable} />
      ) : (
        <Flex
          direction="row"
          align="center"
          justify="center"
          height="80%"
          width="100%"
        >
          No table
        </Flex>
      )}
      {pageModel.ColumnOptionsModel && (
        <RegularColumnOptions
          model={pageModel.ColumnOptionsModel}
          currentlyEditing={
            pageModel.editColumnModel?.column.uuid ==
            pageModel.ColumnOptionsModel.column.uuid
          }
          // TODO: Make it a stack of sidebars to go back to
          hideSidebar={
            pageModel.editColumnModel?.column.uuid ==
            pageModel.ColumnOptionsModel.column.uuid
              ? pageModel.hideAllSidebarModel
              : undefined
          }
        />
      )}
      {pageModel.AggregationModel && (
        <AggregationOptionsDropdown model={pageModel.AggregationModel} />
      )}
      {pageModel.multiColumnOptionsModel &&
        pageModel.user.hasPermission("table.write") && (
          <MultiColumnOptions model={pageModel.multiColumnOptionsModel} />
        )}
      {pageModel.AddColumnModel &&
        !pageModel.ColumnOptionsModel &&
        pageModel.user.hasPermission("table.write") && (
          <AddNewColumnOptions model={pageModel.AddColumnModel} />
        )}
      <Drawer
        header={title}
        isOpen={openDrawer}
        onClose={closeDrawer}
        blocking={false}
        showNavbar={true}
        extras={
          pageModel.editColumnModel ? (
            <EditColumnMenu
              model={pageModel}
              columnUuid={pageModel.editColumnModel.column.uuid}
            />
          ) : undefined
        }
      >
        {pageModel.selectActionModel &&
          pageModel.user.hasPermission("table.write") && (
            <SelectActionForm model={pageModel.selectActionModel} />
          )}
        {pageModel.editColumnModel &&
          pageModel.user.hasPermission("table.write") && (
            <EditColumnForm model={pageModel.editColumnModel} />
          )}
        {pageModel.addActionModel &&
          pageModel.user.hasPermission("table.write") && (
            <AddActionColumnForm model={pageModel.addActionModel} />
          )}
        {pageModel.cellViewModel && (
          <CellView model={pageModel.cellViewModel} />
        )}
        {pageModel.editTableModel &&
          pageModel.user.hasPermission("table.write") && (
            <EditTableForm model={pageModel.editTableModel} />
          )}
        {pageModel.viewFormModel &&
          pageModel.user.hasPermission("table.write") && (
            <ViewForm model={pageModel.viewFormModel} />
          )}
      </Drawer>
      {pageModel.csvExportModel && pageModel.tableData.data && (
        <CsvExportDialog model={pageModel.csvExportModel} />
      )}
      {pageModel.csvImportModel && pageModel.tableData.data && (
        <CSVReader model={pageModel.csvImportModel} tableUUID={params.uuid} />
      )}
      {pageModel.tableImportExportModel && (
        <TableImportExport
          model={pageModel.tableImportExportModel}
          open={true}
        />
      )}
    </Flex>
  );
}

export default observer(TablePage);
