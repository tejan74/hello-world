"use client";
import TableListPageModel from "@/mobx/table/tableListModel";
import { UserType } from "@/mobx/user/types";
import Drawer from "@/ui/components/drawer";
import {
  Button,
  Flex,
  Heading,
  Spinner,
  Text,
  TextField,
} from "@radix-ui/themes";
import { observer } from "mobx-react-lite";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { useDndScrolling } from "react-dnd-scrolling";
import FoldersComponent from "../components/folder/Folder";
import { TableList } from "../components/table/TableList";
import TablesHeader from "../components/tablesheader/Header";
import { useAppContext } from "../context/AppContext";

function TablePage({ user }: { user: UserType }) {
  const appModel = useAppContext();
  const [pageModel] = useState<TableListPageModel>(
    () => new TableListPageModel(appModel.userModel, appModel)
  );

  const [openDrawer, setOpenDrawer] = useState(false);
  const [createType, setCreateType] = useState<string>("");
  const closeDrawer = () => {
    setOpenDrawer(false);
    setCreateType("");
  };

  const createTable = (value: string) => {
    setOpenDrawer(true);
    setCreateType(value);
  };

  return (
    <Flex direction="column" width="100%" height="100vh">
      <TablesHeader
        user={appModel.userModel.data}
        pageModel={pageModel}
        createTable={createTable}
      ></TablesHeader>
      <Flex width={"100%"} style={{ borderTop: "1px solid #eeee" }} mt="5" />
      <Flex direction="row" align="center" width="95%" p="2" ml="7">
        <Text
          style={{
            fontWeight: "400",
            color: "#888",
            fontSize: "12px",
            flex: "1",
            alignItems: "start",
          }}
          size="1"
          ml="6"
        >
          Name
        </Text>
        <Text
          style={{
            fontWeight: "400",
            color: "#888",
            fontSize: "12px",
            width: "265px",
            alignItems: "start",
            justifyContent: "start",
          }}
          size="1"
        >
          Created By
        </Text>
        <Text
          style={{
            fontWeight: "400",
            color: "#888",
            fontSize: "12px",
            width: "200px",
            alignItems: "start",
          }}
          size="1"
        >
          Created On
        </Text>
        <Text style={{ flex: "none" }}></Text>
      </Flex>
      <Flex width={"100%"} style={{ borderTop: "1px solid #eeee" }} />

      {pageModel.loadingList ? (
        <Flex
          align="center"
          justify="center"
          height="100%"
          width="100%"
          overflow="scroll"
        >
          <Spinner size="3" />
        </Flex>
      ) : (
        pageModel.user.hasPermission("table.read") && (
          <DndProvider backend={HTML5Backend}>
            <List pageModel={pageModel} />
          </DndProvider>
        )
      )}
      <Drawer
        header={
          createType === "table" ? "Create a new table" : "Create a new folder"
        }
        isOpen={openDrawer}
        onClose={closeDrawer}
        blocking={false}
        showNavbar={false}
      >
        {createType === "table" && (
          <CreateTableForm
            model={pageModel}
            close={() => setOpenDrawer(false)}
          />
        )}
        {createType === "folder" && (
          <CreateFolderForm
            model={pageModel}
            close={() => setOpenDrawer(false)}
            parentFolderUuid={undefined}
          ></CreateFolderForm>
        )}
      </Drawer>
    </Flex>
  );
}

const CreateTableForm = observer(
  ({
    model,
    close,
    folderUuid,
  }: {
    model: TableListPageModel;
    close: () => void;
    folderUuid?: string;
  }) => {
    const [name, setName] = useState<string>();
    const [description, setDescription] = useState<string>();
    const router = useRouter();

    const openTableWithUuid = (uuid: string) => {
      router.push(`/table/${uuid}`);
    };

    const save = async () => {
      if (!name) {
        return;
      }
      const uuid = await model.addTable(name, description, folderUuid);
      openTableWithUuid(uuid);
    };

    return (
      <Flex direction={"column"} p="4" gap="5">
        <Flex direction="column" gap="4">
          <Flex direction={"column"} gap="2">
            <Flex justify="between">
              <Heading size="2">Name</Heading>
            </Flex>
            <TextField.Root
              value={name}
              placeholder="Name the table"
              onChange={(e) => setName(e.target.value)}
              autoComplete="off"
            />
          </Flex>
          <Flex direction={"column"} gap="2">
            <Flex justify="between">
              <Heading size="2">Description</Heading>
            </Flex>
            <TextField.Root
              value={description}
              placeholder="Describe the table"
              onChange={(e) => setDescription(e.target.value)}
              autoComplete="off"
            />
          </Flex>
        </Flex>
        <Flex justify="end">
          <Button variant="soft" onClick={() => save()}>
            Create
          </Button>
        </Flex>
      </Flex>
    );
  }
);

const List = observer(({ pageModel }: { pageModel: TableListPageModel }) => {
  const ref = useRef<HTMLDivElement | null>(null);
  useDndScrolling(ref, {});

  return (
    <Flex direction="column" ml="7" overflow="auto" flexGrow="1" ref={ref}>
      {pageModel.filter.length > 0 ? (
        <>
          <TableList model={pageModel} />
        </>
      ) : (
        <>
          {pageModel.sortByFolder ? (
            <>
              <TableList model={pageModel} />
              <FoldersComponent model={pageModel} />
            </>
          ) : (
            <>
              <FoldersComponent model={pageModel} />
              <TableList model={pageModel} />
            </>
          )}
        </>
      )}
    </Flex>
  );
});

const CreateFolderForm = observer(
  ({
    model,
    close,
    parentFolderUuid,
  }: {
    model: TableListPageModel;
    close: () => void;
    parentFolderUuid?: string;
  }) => {
    const [name, setName] = useState<string>();

    const saveHandler = async () => {
      if (!name) {
        return;
      }
      await model.addFolder(name, parentFolderUuid);
      close();
    };
    return (
      <Flex direction={"column"} p="4" gap="5">
        <Flex direction="column" gap="4">
          <Flex direction={"column"} gap="2">
            <Flex justify="between">
              <Heading size="2">Name</Heading>
            </Flex>
            <TextField.Root
              value={name}
              placeholder="Enter folder name"
              onChange={(e) => setName(e.target.value)}
              autoComplete="off"
            />
          </Flex>
        </Flex>
        <Flex justify="end">
          <Button variant="soft" onClick={() => saveHandler()}>
            Create
          </Button>
        </Flex>
      </Flex>
    );
  }
);

export default observer(TablePage);
export { CreateFolderForm, CreateTableForm };
