"use client";
import { UserModel } from "@/mobx/user/UserModel";
import { UserType } from "@/mobx/user/types";
import { InfoCircledIcon } from "@radix-ui/react-icons";
import { Callout, Flex, Heading, Text, TextField } from "@radix-ui/themes";
import { observer } from "mobx-react-lite";
import { useState } from "react";
import toast from "react-hot-toast";
import InviteUser from "./InviteUser";

const TeamSettingsPage = observer(({ user }: { user: UserType }) => {
  const [model] = useState<UserModel>(() => new UserModel(user));

  const [teamName, setTeamName] = useState(user.Tenant.name);
  const [teamCount, setTeamCount] = useState(user.Tenant.teamCount);

  const onSaveChanges = () => {
    model.updateTeamDetails(teamName, teamCount);
  };

  return (
    <>
      <Heading mt="5">Team</Heading>
      <Callout.Root mt="2" size="1" color="gray">
        <Callout.Icon>
          <InfoCircledIcon />
        </Callout.Icon>
        <Callout.Text>
          Changes to your team apply to all your team members
        </Callout.Text>
      </Callout.Root>
      <Flex mt="5" style={{ borderTop: "2px solid #eeee" }} direction="column">
        <Flex>
          <Flex mt="5" gapX="7">
            <Flex gapY="2" direction="column">
              <Text size="1" color="gray">
                Name
              </Text>
              <TextField.Root
                size="1"
                variant="classic"
                style={{ width: "20vw" }}
                value={teamName}
                onChange={(e) => {
                  setTeamName(e.target.value);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    onSaveChanges();
                    toast.success("Updated Successfully");
                  }
                }}
              ></TextField.Root>
            </Flex>
            <Flex gapY="2" direction="column">
              <Text size="1" color="gray">
                Number of Teammates
              </Text>
              <TextField.Root
                size="1"
                variant="classic"
                style={{ width: "20vw" }}
                value={teamCount ?? " "}
                onChange={(e) => {
                  setTeamCount(Number(e.target.value));
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    onSaveChanges();
                    toast.success("Updated Successfully");
                  }
                }}
              ></TextField.Root>
            </Flex>
          </Flex>
        </Flex>
      </Flex>
      <Flex mt="6" style={{ borderTop: "2px solid #eeee" }} direction="column">
        <InviteUser />
      </Flex>
    </>
  );
});

export default TeamSettingsPage;
