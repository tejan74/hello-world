"use client";

import { TenantDataViewPageModel } from "@/mobx/tenantData/tenantDataViewPageModel";
import { TableIcon, UploadIcon } from "@radix-ui/react-icons";
import { Button, Flex, Heading, Skeleton, Text } from "@radix-ui/themes";
import { ColDef, Column, GridApi, IRowNode } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { observer } from "mobx-react-lite";
import { useEffect, useMemo, useState } from "react";
import { DataCellComponent } from "../components/table/DataCellComponent";
import TenantSortAndFilter from "../components/tenant/SortAndFilter";

// styles
import "ag-grid-community/styles/ag-grid.css"; // Mandatory CSS required by the grid
// ------------- This comment is to keep the bellow import bellow "ag-grid-community/styles/ag-grid.css" import
import "@/ui/styles/table/table-style.css"; // our modified ag-theme-quartz Theme applied to the grid
import { IconColumns } from "@tabler/icons-react";
import TableImportExport from "../components/tableImportExport";
import ProfileIcon from "../components/table/ProfileIcon/ProfileIcon";
import { UserType } from "@/mobx/user/types";

const TenantDataViewPage = observer(({ uuid, user }: { uuid: string; user: UserType }) => {
  const [pageModel, setPageModel] = useState<TenantDataViewPageModel>(
    () => new TenantDataViewPageModel(uuid)
  );
  useEffect(() => pageModel.dispose, [pageModel]);

  return (
    <>
      {pageModel.loadingTable ? (
        <LoadingView />
      ) : pageModel.tableData.data ? (
        <TableView model={pageModel} user={user}/>
      ) : (
        "No data"
      )}
      {pageModel.tableImportExportModel && (
        <TableImportExport
          model={pageModel.tableImportExportModel}
          open={true}
        />
      )}
    </>
  );
});

function LoadingView() {
  const [isClient, setIsClient] = useState(false);

  // this remove hydration warning
  useEffect(() => {
    setIsClient(true);
  }, []);
  if (!isClient) return null;

  const getSkeleton = () => {
    return (
      <table style={{ width: "100%" }}>
        <tbody>
          {[...Array(10)].map((x) => (
            <tr>
              {[...Array(5)].map((y) => (
                <td>
                  <Text size={"1"}>
                    <Skeleton>
                      ....................{".".repeat(Math.random() * 40)}
                    </Skeleton>
                  </Text>
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    );
  };
  return (
    <Flex
      direction="column"
      width="100%"
      height="100vh"
      align="center"
      justify="between"
      p="5"
    >
      {[...Array(3)].map(() => getSkeleton())}
    </Flex>
  );
}

const HeaderComponent = (params: {
  displayName: string;
  column: Column;
  eGridHeader: HTMLDivElement;
}) => {
  const field = params.column.getColDef().field;
  return (
    <>
      <Flex justify="between" width="100%" align="center" gap="2">
        {field != TenantDataViewPageModel.checkboxColFieldId && <IconColumns />}
        <Text truncate style={{ flexGrow: 1, color: "rgb(35, 37, 41)" }}>
          {params.displayName}
        </Text>
      </Flex>
    </>
  );
};

const CellComponent = (params: {
  data: any;
  colDef: ColDef;
  node: IRowNode;
}) => {
  if (!params.data) return <div>no data</div>;
  if (!params.colDef.field) return <div>no field</div>;

  if (params.colDef.field === TenantDataViewPageModel.checkboxColFieldId) {
    return (
      <Text style={{ color: "#888", fontSize: "12px" }} truncate as="div">
        {(params.node.rowIndex ?? 0) + 1}
      </Text>
    );
  }
  const data = params.data[params.colDef.field];

  return <DataCellComponent value={data} />;
};

const TableView = observer(({ model, user }: { model: TenantDataViewPageModel; user: UserType }) => {
  const defaultColDef = useMemo(() => {
    return {
      cellRenderer: CellComponent,
      headerComponent: HeaderComponent,
      minWidth: 60,
      sortable: false,
    };
  }, []);

  const onBodyScroll = (gridApi: GridApi) => {
    const hiddenRowCount =
      gridApi.getDisplayedRowCount() - gridApi.getLastDisplayedRowIndex();

    if (hiddenRowCount < 30) model.loadMoreRows();
  };

  return (
    <Flex direction="column" width="100%" height="100vh">
      <Flex direction="column" align={"center"}>
        <Flex
          direction="column"
          justify="center"
          width="100%"
          py="5"
          px="4"
          style={{ borderBottom: "1px solid rgb(238, 239, 241)" }}
        >
          <Flex direction="row" align="center" justify="between">
            <Flex direction="row" align="center" justify="start" gap="3">
              <TableIcon width={20} height={20} />
              <Heading size="5">{model.tableData.data?.name}</Heading>
            </Flex>
            <Flex direction="row" align="center" justify="end" gap="3">
              <Button
                variant="outline"
                onClick={() => model.onExportToTableClicked()}
              >
                <UploadIcon />
                Export to table
              </Button>
              <ProfileIcon user={user} />
            </Flex>
          </Flex>
        </Flex>
      </Flex>
      <TenantSortAndFilter model={model}></TenantSortAndFilter>
      <Flex
        className="ag-theme-quartz" // applying the grid theme
        flexGrow="1"
        direction="column"
      >
        <AgGridReact
          defaultColDef={defaultColDef}
          rowData={model.rowData}
          columnDefs={model.columnDefs}
          getRowId={model.getRowId}
          onBodyScroll={(e) => {
            onBodyScroll(e.api);
          }}
          onRowSelected={(e) => {
            if (!e.data?.uuid) {
              console.error("No data in row selected event");
              return;
            }
            model.setRowSelected(e.data.uuid, e.node.isSelected() ?? false);
          }}
          rowBuffer={50}
          suppressRowClickSelection={true}
          suppressScrollOnNewData={true}
          rowSelection={"multiple"}
        />
      </Flex>
    </Flex>
  );
});

export default TenantDataViewPage;
