/**
 * Remap a value from one set of values to another.
 * @param value any value
 * @param from a single value or an array of values
 * @param to a single value or an array of values
 * @returns the value remapped from the `from` array to the `to` array
 */
export function remap<T>(value: T, from: T, to: T): T;
export function remap<T>(value: T, from: T[], to: T[]): T;
export function remap<T, D>(value: T, from: T, to: D): T | D;
export function remap<T, D>(value: T, from: T[], to: D[]): T | D;
export function remap(value: any, from: any | any[], to: any | any[]): any {
  if (!Array.isArray(from)) {
    from = [from];
    to = [to];
  }
  const idx = from.indexOf(value);
  if (idx === -1) {
    return value;
  }
  return to[idx];
}
