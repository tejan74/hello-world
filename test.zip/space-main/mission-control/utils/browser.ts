/**
 * util function to download a file through browser
 * source: https://github.com/ag-grid/ag-grid/blob/ec1d03206a2622292b63e8c4102f02152ce03b89/community-modules/csv-export/src/csvExport/downloader.ts#L1
 */
export function browserDownload(fileName: string, content: Blob) {
  const win = document.defaultView || window;

  if (!win) {
    console.warn(
      "AG Grid: There is no `window` associated with the current `document`"
    );
    return;
  }

  const element = document.createElement("a");
  // @ts-ignore
  const url = win.URL.createObjectURL(content);
  element.setAttribute("href", url);
  element.setAttribute("download", fileName);
  element.style.display = "none";
  document.body.appendChild(element);

  element.dispatchEvent(
    new MouseEvent("click", {
      bubbles: false,
      cancelable: true,
      view: win,
    })
  );

  document.body.removeChild(element);

  win.setTimeout(() => {
    // @ts-ignore
    win.URL.revokeObjectURL(url);
  }, 0);
}
