import {
  ReadPermissionRoles,
  WritePermissionRoles,
} from "./constant";

export const isPermissionGranted = (role: string, action: string): boolean => {
  const canRead = ReadPermissionRoles.includes(role);
  const canWrite = WritePermissionRoles.includes(role);

  if (
    (action.includes("read") && !canRead) ||
    (action.includes("write") && !canWrite)
  ) {
    return false;
  }
  return true;
};
