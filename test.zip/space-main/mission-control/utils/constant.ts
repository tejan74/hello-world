export const X_REQUEST_ID_HEADER = "X-Request-Id";

export const ReadPermissionRoles = ["Astronaut", "Admin", "Table Editor", "Table Viewer","Guest"];
export const WritePermissionRoles = ["Astronaut", "Admin", "Table Editor"];
