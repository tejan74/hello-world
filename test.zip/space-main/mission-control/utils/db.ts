import { getMainDatabaseUrl, getParam } from "@/services/config/params";
import { PrismaClient } from "@prisma/client";
import { getEnv } from "./env";

const connection_pool_size = await getParam("PRISMA_CONNECTION_POOL_SIZE", "5");

declare const globalThis: {
  prismaGlobal: PrismaClient;
} & typeof global;

// Prisma recommends creating a single PrismaClient instance per server if its not a serverless function
// refer: https://www.prisma.io/docs/orm/prisma-client/setup-and-configuration/databases-connections#optimizing-the-connection-pool
const prisma = globalThis.prismaGlobal ?? new PrismaClient({
  datasources: {
    db: {
      url: (await getMainDatabaseUrl()) + `?connection_limit=${connection_pool_size}&connection_timeout=15`,
    },
  },
  log: ['info'], // lets keep this for now for debugging
});

// This is to avoid multiple instances of PrismaClient during hot reload locally
// ref: https://www.prisma.io/docs/orm/more/help-and-troubleshooting/help-articles/nextjs-prisma-client-dev-practices
if (getEnv() == "local") {
  globalThis.prismaGlobal = prisma;
}

export const createPrismaClient = async () => {
  return getEnv() == "local" ? globalThis.prismaGlobal : prisma;
};
