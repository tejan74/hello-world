/**
 * Gives Standardized Environment value
 */
export function getEnv() {
  const envMap: Record<string, "local" | "DEV" | "PROD"> = {
    local: "local",
    lcl: "local",
    development: "DEV",
    DEV: "DEV",
    production: "PROD",
    PROD: "PROD",
  };
  const pEnv = process.env.ENV ?? "";
  if (pEnv in envMap) return envMap[pEnv];
  else console.log(`Invalid ENV: ${pEnv}, defaulting to local`);

  return "local";
}
