import { headers } from "next/headers";

export function getPathName() {
  const headersList = headers();
  const pathname = headersList.get("x-pathname") || "";
  return pathname;
}

export function getSearchParams() {
  const headersList = headers();
  const searchParams = headersList.get("x-search-params") || "";
  return searchParams;
}

export function getUrlObject() {
  const headersList = headers();
  const url = headersList.get("x-url") || "";
  return new URL(url);
}
