import { AsyncLocalStorage } from "async_hooks";
import { Logger } from "winston";
import { getEnv } from "../env";
import { winstonLogger } from "./logger";

export const LOGGER_CONTEXT_KEY = "winston_logger";
export const REQUEST_CONTEXT = "requestContext";

// TODO: Type the context
export const asyncContext = new AsyncLocalStorage<any>();

export const executeWithAsyncContext = async (
  handle: () => Promise<void> | any,
  loggerContext: Record<string, string | number | undefined>
) => {
  // Find if there is a child already
  const existingLogger: Logger = asyncContext
    .getStore()
    ?.get(LOGGER_CONTEXT_KEY);

  let child;
  if (existingLogger) {
    // Use the parent logger to persist the parent logging context
    child = existingLogger.child(loggerContext);
  } else {
    // Create child logger with logger context
    child = winstonLogger.child({ env: getEnv(), ...loggerContext });
  }
  const store = new Map();

  // Write child to store
  store.set(LOGGER_CONTEXT_KEY, child);

  const requestId = loggerContext.requestId;
  if (requestId) {
    store.set("requestId", requestId);
  }

  // Set additional request context for future usage
  store.set(REQUEST_CONTEXT, loggerContext);

  // Invoke the callback with store as async context
  return await asyncContext.run(store, handle);
};
