import winston from "winston";
import { getEnv } from "../env";
import { LOGGER_CONTEXT_KEY, asyncContext } from "./asyncContext";

// Creates winston logger with transports
export const winstonLogger = winston.createLogger({
  level: getEnv() === "PROD" ? "info" : "debug",
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.colorize({
          all: true,
        }),
        winston.format.errors({ stack: true }),
        winston.format.printf(
          (msg: any) =>
            `[mc][${msg["level"]}][req::${msg["requestId"]}][tnt::${msg["tenant"]}][${msg["path"]}]: ${msg["message"]}`
        )
      ),
    }),
  ],
});

// Return child logger which has log metadata from context if exists or return default logger
export const logger = new Proxy(winstonLogger, {
  get(target, property, receiver) {
    target = asyncContext.getStore()?.get(LOGGER_CONTEXT_KEY) || target;
    return Reflect.get(target, property, receiver);
  },
});
