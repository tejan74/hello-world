/**
 * Poller class to make polling easier.
 */
export class ShortPoller {
  private pollingTimeoutHandle: NodeJS.Timeout | null = null;
  private stopped = true;
  private abortController: AbortController | null = null;

  constructor(
    private poll: (abortController: AbortController) => Promise<void>,
    private interval: number
  ) {}

  start() {
    if (!this.stopped) {
      console.warn("Poller already running, call stop before starting again");
      return;
    }
    this.stopped = false;
    this.runPolling();
  }

  stop() {
    this.abortController?.abort(); // for case when polling is running
    if (this.pollingTimeoutHandle) clearTimeout(this.pollingTimeoutHandle); // for case when polling is scheduled
    this.stopped = true; // for case when polling just finished and next run is not scheduled yet but will be scheduled
    this.abortController = null;
  }

  pollImmediately(killOngoingPoll = false) {
    if (killOngoingPoll) {
      if (this.abortController) {
        this.abortController.abort();
        this.abortController = null;
      }
    } else {
      if (this.abortController) return;
    }

    if (this.pollingTimeoutHandle) clearTimeout(this.pollingTimeoutHandle);
    this.runPolling();
  }

  private runPolling() {
    this.abortController = new AbortController();
    this.poll(this.abortController).then(() => {
      this.abortController = null;
      if (this.stopped) return;
      if (this.pollingTimeoutHandle) clearTimeout(this.pollingTimeoutHandle); // ensure only one polling is scheduled
      this.pollingTimeoutHandle = setTimeout(
        this.runPolling.bind(this),
        this.interval
      );
    });
  }
}
