/**
 * generate a random string with the character set
 * '1234567890abcdefghijklmnopqrstuvwxyz'
 * @param {number} [len=6] - required length for the random string
 * @returns {string} - random string
 */
export function randomStr(len = 6) {
    let str = "";
    while (str.length < len) {
        str += Math.random().toString(36).slice(2);
    }
    return str.slice(0, len);
}
