import { isNotUndefined } from "@/utils/type";
import { Sql } from "@prisma/client/runtime/library";
import { sql } from "slonik";
import { RequireExactlyOne } from "type-fest";

export type SqlFragment = ReturnType<typeof sql.fragment>;
export type SqlIdentifier = ReturnType<typeof sql.identifier>;

export function sqlKeyMapper(
  key: RequireExactlyOne<{
    id: number;
    uuid: string;
    identifier: SqlIdentifier;
  }>
) {
  if (key.id !== undefined) {
    return ["id", key.id] as const;
  } else if (key.uuid !== undefined) {
    return ["uuid", key.uuid] as const;
  } else if (key.identifier !== undefined) {
    return ["id", key.identifier] as const;
  } else throw new Error("All keys are empty");
}

export function sqlWhereFrag(
  frags: (SqlFragment | undefined)[],
  op: { start?: "and" | "or"; join?: "and" | "or" } | undefined,
  undefinedEmpty: true
): SqlFragment | undefined;

export function sqlWhereFrag(
  frags: (SqlFragment | undefined)[],
  op?: { start?: "and" | "or"; join?: "and" | "or" },
  undefinedEmpty?: boolean
): SqlFragment;

export function sqlWhereFrag(
  frags: (SqlFragment | undefined)[],
  op?: { start?: "and" | "or"; join?: "and" | "or" },
  undefinedEmpty?: boolean
) {
  const startOp = op?.start ? sqlBoolOp(op.start) : sql.fragment``;
  const joinOp = op?.join ? sqlBoolOp(op.join) : sql.fragment` and `;
  const emptyOut = undefinedEmpty ? undefined : sql.fragment``;

  const fragsF = frags.filter(isNotUndefined);
  return fragsF.length > 0
    ? sql.fragment`${startOp} ${sql.join(fragsF, joinOp)}`
    : emptyOut;
}

export function sqlSortFrag<T extends Record<string, SqlFragment>>(
  fieldMap: T,
  sort: { key: keyof T; order: "desc" | "asc" }
) {
  const order = { desc: sql.fragment`desc`, asc: sql.fragment`asc` }[
    sort.order
  ];
  return sql.fragment`${fieldMap[sort.key]} ${order}`;
}

export function sqlBoolOp(op: "and" | "or") {
  return {
    and: sql.fragment` and `,
    or: sql.fragment` or `,
  }[op];
}

/**
 * util to convert slonik query to prisma sql, so we can
 * execute slonik query with prisma raw functions.
 * This avoids creating and maintaining slonik connection pool
 * @remarks This util isn't 100% future safe, problem can arise
 * when query itself has '$slonik_' token followed by number
 */
export function sqlPrisma(query: SqlFragment) {
  return new Sql(query.sql.split(/\$slonik_\d+/g), query.values);
}
