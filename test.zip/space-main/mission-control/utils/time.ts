/**
 * Helpful microsecond multipliers.
 */
export const mSec = {
  second: 1000,
  minute: 60 * 1000,
  hour: 60 * 60 * 1000,
  day: 24 * 60 * 60 * 1000,
  week: 7 * 24 * 60 * 60 * 1000,
  month: 30 * 24 * 60 * 60 * 1000,
  year: 365 * 24 * 60 * 60 * 1000,
} as const;

/**
 * async function to introduce delay in async code execution
 * @param ms wait time in milliseconds
 * @returns
 */
export function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * A class to measure time taken by a block of code
 * uses console.time and console.timeEnd underneath
 * This has a static and instance version
 */
export class LogDuration {
  static start(label: string) {
    console.time(label);
  }
  static end(label: string) {
    console.timeEnd(label);
  }

  constructor(private prefix: string) {}

  start(label: string) {
    LogDuration.start(this.prefix + label);
  }
  end(label: string) {
    LogDuration.end(this.prefix + label);
  }
}
