import { TRPCClientError } from "@trpc/client";

export function isTrpcAbortError(err: unknown): boolean {
  return (
    err instanceof TRPCClientError && err.cause?.name === "ObservableAbortError"
  );
}
