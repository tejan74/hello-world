/**
 * predicate function that checks if a is not undefined with proper type narrowing
 * Note: use in filter to remove undefined values
 *
 * @param a variable that can be undefined
 * @returns true if a is not undefined
 */
export function isNotUndefined<T extends any>(
  a: T
): a is Exclude<typeof a, undefined> {
  return a !== undefined;
}

export function isJustObject(a: any): a is Record<string, any> {
  return a !== null && typeof a === "object" && !Array.isArray(a);
}

export function isNotFalse<T extends any>(a: T): a is Exclude<T, false> {
  return a !== false;
}

/** Array.includes replacement with type narrowing */
export function typedIncludes<T = any>(a: T[], b: any): b is T {
  return a.includes(b);
}

/**
 * predicate function that checks if a is not null with proper type narrowing
 * Note: use in filter to remove null values
 *
 
 * @returns true if a is not null
 */
export function isNotNull<T extends any>(a: T): a is Exclude<typeof a, null> {
  return a !== null;
}
