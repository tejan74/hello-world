export function getBaseUrl() {
  if (typeof window !== "undefined")
    return `${window.location.protocol}//${window.location.host}`;
  return `http://localhost:3000`;
}

export const checkAddProtocolToUrl = (url: string) => {
  return url.startsWith("http") ? url : "https://" + url;
};

export const generateSearchParamsFromObject = (params: Record<string, any>) => {
  let searchParams = "";
  for (const [key, value] of Object.entries(params)) {
    if (searchParams.length) searchParams += "&";
    searchParams += `${key}=${value}`;
  }
  return searchParams.length ? `?${searchParams}` : searchParams;
};

export const isValidUrl = (url: string) => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};
