"""
TAILSCALE ROUTER

This launcher gets all the appropriate configuration and runs tailscale
"""

import json
import os
import boto3

def _get_aws_secret(secret_name: str):
    region_name = os.environ.get("AWS_REGION")
    client = boto3.client(
        "secretsmanager",
        region_name=region_name,
    )

    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except Exception as e:
        raise e

    secret = get_secret_value_response["SecretString"]
    return secret

def set_tailscale_env():

    # Check if configuration is in environment variables
    ts_auth = os.environ.get("TS_AUTHKEY")
    ts_routes = os.environ.get("TS_ROUTES")

    # If we cannot find either in environment, then we have to fetch from cloud
    if not ts_routes or not ts_auth:
        try:
            # Check if cloud credentials are provided
            cloud_secret = os.environ.get("CLOUD_SECRET")
            if not cloud_secret:
                raise Exception("Cloud secret not provided")
                        
            secret_str = _get_aws_secret(cloud_secret)
            secret_json = json.loads(secret_str)

            # Override whichever ones are None with what's in the cloud or die trying
            ts_auth = secret_json.get("TAILSCALE_AUTH") if ts_auth is None else ts_auth
            ts_routes = secret_json.get("TAILSCALE_ROUTES") if ts_routes is None else ts_routes

        except Exception as e:
            raise Exception("Tailscale credentials could not be found in variables or secret")

    os.environ["TS_AUTHKEY"] = ts_auth
    os.environ["TS_ROUTES"] = ts_routes
    
    return (ts_auth, ts_routes)

tailscale_auth, tailscale_routes = set_tailscale_env()
# Break out to shell and run migrations
print(f"Starting tailscale with routes {tailscale_routes}")
os.system(f"export TS_AUTHKEY={tailscale_auth} && export TS_ROUTES={tailscale_routes} && /usr/local/bin/containerboot")
